#include "battle/battle_system.h"

#include "global.h"

#include "constants/game_stats.h"
#include "constants/message_tags.h"
#include "constants/sndseq.h"

#include "battle/battle_022378C0.h"
#include "battle/battle_terrain.h"
#include "battle/battle_controller.h"
#include "battle/battle_controller_opponent.h"
#include "battle/battle_hp_bar.h"
#include "battle/battle_input.h"
#include "battle/battle_util.h"
#include "battle/battle_recording_stop.h"
#include "msgdata/msg/msg_0197.h"

#include "msgdata.h"
#include "party.h"
#include "pokemon_mood.h"
#include "screen_fade.h"
#include "text.h"
#include "sound_playback.h"
#include "battle_recording.h"

static u8 BattleSystem_ReadRecordByte(u8 *buffer, u8 *index, u16 *size);
static void BattleSystem_AdjustMessageForSide(BattleSystem *battleSystem, BattleMessage *msg);
static void BattleSystem_BufferMessage(BattleSystem *battleSystem, BattleMessage *msg);
static void BattleMessage_BufferNickname(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferMove(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferItem(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferNumber(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferNumbers(BattleSystem *battleSystem, int bufferIndex, int param, int numDigits);
static void BattleMessage_BufferType(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferAbility(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferStat(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferStatus(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferPokemon(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferPoffin(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferFlavorPreference(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferTrainerClass(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferTrainerName(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_BufferBoxName(BattleSystem *battleSystem, int bufferIndex, int param);
static void BattleMessage_ExpandPlaceholders(BattleSystem *battleSystem, MsgData *data, BattleMessage *msg);
static BOOL BattleSystem_TextPrinterCallback(struct TextPrinterTemplate *template, u16 glyphId);

BgConfig *BattleSystem_GetBgConfig(BattleSystem *battleSystem) {
    return battleSystem->bgConfig;
}

Window *BattleSystem_GetWindow(BattleSystem *battleSystem, int index) {
    return &battleSystem->window[index];
}

u32 BattleSystem_GetBattleType(BattleSystem *battleSystem) {
    return battleSystem->battleType;
}

BattleContext *BattleSystem_GetBattleContext(BattleSystem *battleSystem) {
    return battleSystem->ctx;
}

OpponentData *BattleSystem_GetOpponentData(BattleSystem *battleSystem, int battlerId) {
    return battleSystem->opponentData[battlerId];
}

int BattleSystem_GetMaxBattlers(BattleSystem *battleSystem) {
    return battleSystem->maxBattlers;
}

Party *BattleSystem_GetParty(BattleSystem *battleSystem, int battlerId) {
    if ((battleSystem->battleType & BATTLE_TYPE_MULTI) || ((battleSystem->battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        return battleSystem->trainerParty[battlerId];
    } else if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return battleSystem->trainerParty[battlerId & 1];
    } else {
        return battleSystem->trainerParty[battlerId];
    }
}

int BattleSystem_GetPartySize(BattleSystem *battleSystem, int battlerId) {
    if ((battleSystem->battleType & BATTLE_TYPE_MULTI) || ((battleSystem->battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        return Party_GetCount(battleSystem->trainerParty[battlerId]);
    } else if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return Party_GetCount(battleSystem->trainerParty[battlerId & 1]);
    } else {
        return Party_GetCount(battleSystem->trainerParty[battlerId]);
    }
}

Pokemon *BattleSystem_GetPartyMon(BattleSystem *battleSystem, int battlerId, int index) {
    if ((battleSystem->battleType & BATTLE_TYPE_MULTI) || ((battleSystem->battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        return Party_GetMonByIndex(battleSystem->trainerParty[battlerId], index);
    } else if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return Party_GetMonByIndex(battleSystem->trainerParty[battlerId & 1], index);
    } else {
        return Party_GetMonByIndex(battleSystem->trainerParty[battlerId], index);
    }
}

PokepicManager *BattleSystem_GetPokepicManager(BattleSystem *battleSystem) {
    return battleSystem->pokepicManager;
}

u32 *BattleSystem_GetBattleAnimSystem(BattleSystem *battleSystem) {
    return battleSystem->animSystem;
}

SpriteSystem *BattleSystem_GetSpriteSystem(BattleSystem *battleSystem) {
    return battleSystem->spriteRenderer;
}

SpriteManager *BattleSystem_GetSpriteManager(BattleSystem *battleSystem) {
    return battleSystem->gfxHandler;
}

BattleTerrain *BattleSystem_GetBattleTerrain(BattleSystem *battleSystem, int index) {
    return &battleSystem->terrains[index];
}

BattleInput *BattleSystem_GetBattleInput(BattleSystem *battleSystem) {
    return battleSystem->battleInput;
}

u32 *BattleSystem_GetPartyGauge(BattleSystem *battleSystem, int index) {
    return battleSystem->partyGauges[index];
}

void BattleSystem_SetPartyGauge(BattleSystem *battleSystem, int index, u32 *gauge) {
    battleSystem->partyGauges[index] = gauge;
}

BattleNumberPrinter *BattleSystem_GetHpNumPrinter(BattleSystem *battleSystem) {
    return battleSystem->hpNumPrinter;
}

BattleNumberPrinter *BattleSystem_GetLevelNumPrinter(BattleSystem *battleSystem) {
    return battleSystem->levelNumPrinter;
}

MsgData *BattleSystem_GetMessageLoader(BattleSystem *battleSystem) {
    return battleSystem->msgData;
}

u32 *BattleSystem_GetAttackMessageLoader(BattleSystem *battleSystem) {
    return battleSystem->attackMsgData;
}

PaletteData *BattleSystem_GetPaletteData(BattleSystem *battleSystem) {
    return battleSystem->palette;
}

Pokedex *BattleSystem_GetPokedex(BattleSystem *battleSystem) {
    return battleSystem->pokedex;
}

u8 *BattleSystem_GetSendBufferPtr(BattleSystem *battleSystem) {
    return &battleSystem->sendBuffer[0];
}

u8 *BattleSystem_GetRecvBufferPtr(BattleSystem *battleSystem) {
    return &battleSystem->recvBuffer[0];
}

u16 *BattleSystem_GetSendBufferReadPos(BattleSystem *battleSystem) {
    return &battleSystem->sendReadPos;
}

u16 *BattleSystem_GetSendBufferWritePos(BattleSystem *battleSystem) {
    return &battleSystem->sendWritePos;
}

u16 *BattleSystem_GetSendBufferEndPos(BattleSystem *battleSystem) {
    return &battleSystem->sendEndPos;
}

u16 *BattleSystem_GetRecvBufferReadPos(BattleSystem *battleSystem) {
    return &battleSystem->recvReadPos;
}

u16 *BattleSystem_GetRecvBufferWritePos(BattleSystem *battleSystem) {
    return &battleSystem->recvWritePos;
}

u16 *BattleSystem_GetRecvBufferEndPos(BattleSystem *battleSystem) {
    return &battleSystem->recvEndPos;
}

MonPicData *BattleSystem_GetMonPicDataList(BattleSystem *battleSystem) {
    return &battleSystem->monPicData[0];
}

MessageFormat *BattleSystem_GetMessageFormat(BattleSystem *battleSystem) {
    return battleSystem->msgFormat;
}

String *BattleSystem_GetMessageBuffer(BattleSystem *battleSystem) {
    return battleSystem->msgBuffer;
}

u16 BattleSystem_GetTrainerIndex(BattleSystem *battleSystem, int battlerId) {
    if ((battleSystem->battleType & BATTLE_TYPE_MULTI) || ((battleSystem->battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        return battleSystem->trainerId[battlerId];
    } else if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return battleSystem->trainerId[battlerId & 1];
    } else {
        return battleSystem->trainerId[battlerId];
    }
}

Trainer *BattleSystem_GetTrainer(BattleSystem *battleSystem, int battlerId) {
    if ((battleSystem->battleType & BATTLE_TYPE_MULTI) || ((battleSystem->battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        return &battleSystem->trainers[battlerId];
    } else if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return &battleSystem->trainers[battlerId & 1];
    } else {
        return &battleSystem->trainers[battlerId];
    }
}

PlayerProfile *BattleSystem_GetPlayerProfile(BattleSystem *battleSystem, int battlerId) {
    if ((battleSystem->battleType & BATTLE_TYPE_MULTI) || ((battleSystem->battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        return battleSystem->playerProfile[battlerId];
    } else if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return battleSystem->playerProfile[battlerId & 1];
    } else {
        return battleSystem->playerProfile[battlerId];
    }
}

Bag *BattleSystem_GetBag(BattleSystem *battleSystem) {
    return battleSystem->bag;
}

BagCursor *BattleSystem_GetBagCursor(BattleSystem *battleSystem) {
    return battleSystem->bagCursor;
}

u16 BattleSystem_GetMonBall(BattleSystem *battleSystem, Pokemon *mon) {
    if (battleSystem->hasNonHgssPlayer) {
        return GetMonData(mon, MON_DATA_DP_POKEBALL, NULL);
    } else {
        return GetMonData(mon, MON_DATA_POKEBALL, NULL);
    }
}

BOOL BattleSystem_IsFishing(BattleSystem *battleSystem) {
    return battleSystem->isFishing;
}

u32 BattleSystem_GetTrainerGender(BattleSystem *battleSystem, int battlerId) {
    return PlayerProfile_GetTrainerGender(battleSystem->playerProfile[battlerId]);
}

int BattleSystem_GetBattlerFromBattlerType(BattleSystem *battleSystem, int battlerType) {
    int battlerId;
    for (battlerId = 0; battlerId < battleSystem->maxBattlers; battlerId++) {
        if (OpponentData_GetBattlerType(battleSystem->opponentData[battlerId]) == battlerType) {
            break;
        }
    }

    GF_ASSERT(battlerId < battleSystem->maxBattlers);

    return battlerId;
}

u8 BattleSystem_GetBattlerType(BattleSystem *battleSystem, int battlerId) {
    return OpponentData_GetBattlerType(battleSystem->opponentData[battlerId]);
}

u8 BattleSystem_GetFieldSide(BattleSystem *battleSystem, int battlerId) {
    return OpponentData_GetBattlerType(battleSystem->opponentData[battlerId]) & 1;
}

void *BattleSystem_GetMessageIcon(BattleSystem *battleSystem) {
    return battleSystem->msgIcon;
}

PCStorage *BattleSystem_GetPcStorage(BattleSystem *battleSystem) {
    return battleSystem->storage;
}

Terrain BattleSystem_GetTerrainId(BattleSystem *battleSystem) {
    if (battleSystem->terrain > TERRAIN_MAX || battleSystem->terrain < 0) {
        return TERRAIN_MAX;
    }
    return battleSystem->terrain;
}

int BattleSystem_GetBackgroundId(BattleSystem *battleSystem) {
    return battleSystem->backgroundId;
}

int BattleSystem_GetLocation(BattleSystem *battleSystem) {
    return battleSystem->location;
}

int BattleSystem_GetBattlerIdPartner(BattleSystem *battleSystem, int battlerId) {
    int battlerIdPartner;
    int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);
    u32 battleType = BattleSystem_GetBattleType(battleSystem);

    if (!(battleType & BATTLE_TYPE_DOUBLES)) {
        return battlerId;
    }

    for (battlerIdPartner = 0; battlerIdPartner < maxBattlers; battlerIdPartner++) {
        if (battlerIdPartner != battlerId && BattleSystem_GetFieldSide(battleSystem, battlerIdPartner) == BattleSystem_GetFieldSide(battleSystem, battlerId)) {
            break;
        }
    }

    return battlerIdPartner;
}

int BattleSystem_GetOpponentBattler(BattleSystem *battleSystem, int battlerId, int side) {
    int battlerIdOpponent;
    int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);
    u32 battleType = BattleSystem_GetBattleType(battleSystem);

    if (!(battleType & BATTLE_TYPE_DOUBLES)) {
        return battlerId ^ 1;
    }

    for (battlerIdOpponent = 0; battlerIdOpponent < maxBattlers; battlerIdOpponent++) {
        if (battlerIdOpponent != battlerId && (BattleSystem_GetBattlerType(battleSystem, battlerIdOpponent) & 2) == side && BattleSystem_GetFieldSide(battleSystem, battlerIdOpponent) != BattleSystem_GetFieldSide(battleSystem, battlerId)) {
            break;
        }
    }

    return battlerIdOpponent;
}

BOOL BattleSystem_RecoverStatus(BattleSystem *battleSystem, int battlerId, int selectedMonIndex, int movePos, int item) {
    BattleContext *ctx = battleSystem->ctx;
    Pokemon *mon;
    BOOL ret = FALSE;
    int data;
    int index1 = BattleContext_Get(battleSystem, ctx, 2, battlerId);
    int index2;
    int friendship;

    if (BattleSystem_GetBattleType(battleSystem) == (BATTLE_TYPE_DOUBLES | BATTLE_TYPE_TRAINER) || ((BattleSystem_GetBattleType(battleSystem) & BATTLE_TYPE_TAG) && !(BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        index2 = BattleContext_Get(battleSystem, ctx, 2, BattleSystem_GetBattlerIdPartner(battleSystem, battlerId));
        if (index2 == selectedMonIndex) {
            battlerId = BattleSystem_GetBattlerIdPartner(battleSystem, battlerId);
        }
    } else {
        index2 = index1;
    }
    mon = BattleSystem_GetPartyMon(battleSystem, battlerId, selectedMonIndex);
    friendship = 0;

    if (GetItemAttr(item, ITEMATTR_SLP_HEAL, HEAP_ID_BATTLE)) {
        data = GetMonData(mon, MON_DATA_STATUS, NULL);
        if (data & STATUS_SLEEP) {
            data &= ~STATUS_SLEEP;
            SetMonData(mon, MON_DATA_STATUS, &data);
            if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
                data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, NULL);
                data &= ~STATUS_SLEEP;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, &data);
                data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, NULL);
                data &= ~STATUS2_NIGHTMARE;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, &data);
            }
            ret = TRUE;
        }
    }

    if (GetItemAttr(item, ITEMATTR_PSN_HEAL, HEAP_ID_BATTLE)) {
        data = GetMonData(mon, MON_DATA_STATUS, NULL);
        if (data & STATUS_POISON_ALL) {
            data &= ~STATUS_POISON_ALL;
            SetMonData(mon, MON_DATA_STATUS, &data);
            if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
                data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, NULL);
                data &= ~STATUS_POISON_ALL;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, &data);
            }
            ret = TRUE;
        }
    }

    if (GetItemAttr(item, ITEMATTR_BRN_HEAL, HEAP_ID_BATTLE)) {
        data = GetMonData(mon, MON_DATA_STATUS, NULL);
        if (data & STATUS_BURN) {
            data &= ~STATUS_BURN;
            SetMonData(mon, MON_DATA_STATUS, &data);
            if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
                data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, NULL);
                data &= ~STATUS_BURN;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, &data);
            }
            ret = TRUE;
        }
    }

    if (GetItemAttr(item, ITEMATTR_FRZ_HEAL, HEAP_ID_BATTLE)) {
        data = GetMonData(mon, MON_DATA_STATUS, NULL);
        if (data & STATUS_FREEZE) {
            data &= ~STATUS_FREEZE;
            SetMonData(mon, MON_DATA_STATUS, &data);
            if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
                data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, NULL);
                data &= ~STATUS_FREEZE;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, &data);
            }
            ret = TRUE;
        }
    }

    if (GetItemAttr(item, ITEMATTR_PRZ_HEAL, HEAP_ID_BATTLE)) {
        data = GetMonData(mon, MON_DATA_STATUS, NULL);
        if (data & STATUS_PARALYSIS) {
            data &= ~STATUS_PARALYSIS;
            SetMonData(mon, MON_DATA_STATUS, &data);
            if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
                data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, NULL);
                data &= ~STATUS_PARALYSIS;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS, &data);
            }
            ret = TRUE;
        }
    }

    if (GetItemAttr(item, ITEMATTR_CFS_HEAL, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, NULL);
            if (data & STATUS2_CONFUSION) {
                data &= ~STATUS2_CONFUSION;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, &data);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_INF_HEAL, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, NULL);
            if (data & STATUS2_ATTRACT) {
                data &= ~STATUS2_ATTRACT;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, &data);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_GUARD_SPEC, HEAP_ID_BATTLE)) {
        data = BattleContext_Get(battleSystem, ctx, 1, battlerId);
        if (!data) {
            data = BattleContext_Get(battleSystem, ctx, 0, battlerId);
            data |= SIDE_CONDITION_MIST;
            BattleContext_Set(battleSystem, ctx, 0, battlerId, data);
            BattleContext_Set(battleSystem, ctx, 1, battlerId, 5);
            ret = TRUE;
        }
    }

    if (GetItemAttr(item, ITEMATTR_ATK_STAGES, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            if (GetBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_ATK, NULL) < STAT_UP_6) {
                AddBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_ATK, 1);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_DEF_STAGES, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            if (GetBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_DEF, NULL) < STAT_UP_6) {
                AddBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_DEF, 1);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_SPATK_STAGES, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            if (GetBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_SPATK, NULL) < STAT_UP_6) {
                AddBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_SPATK, 1);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_SPDEF_STAGES, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            if (GetBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_SPDEF, NULL) < STAT_UP_6) {
                AddBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_SPDEF, 1);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_SPEED_STAGES, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            if (GetBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_SPEED, NULL) < STAT_UP_6) {
                AddBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_SPEED, 1);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_ACCURACY_STAGES, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            if (GetBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_ACC, NULL) < STAT_UP_6) {
                AddBattlerVar(ctx, battlerId, BMON_DATA_STAT_CHANGE_ACC, 1);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_CRITRATE_STAGES, HEAP_ID_BATTLE)) {
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            data = GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, NULL);
            if (!(data & STATUS2_FOCUS_ENERGY)) {
                data |= STATUS2_FOCUS_ENERGY;
                SetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, &data);
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_PP_RESTORE, HEAP_ID_BATTLE)) {
        data = GetItemAttr(item, ITEMATTR_PP_RESTORE_PARAM, HEAP_ID_BATTLE);
        if (GetMonData(mon, MON_DATA_MOVE1_PP + movePos, NULL) != GetMonData(mon, MON_DATA_MOVE1_MAX_PP + movePos, NULL)) {
            AddMonData(mon, MON_DATA_MOVE1_PP + movePos, data);
            if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
                if (!(GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, NULL) & STATUS2_TRANSFORM) && !(GetBattlerVar(ctx, battlerId, BMON_DATA_MIMICED_MOVE, NULL) & MaskOfFlagNo(movePos))) {
                    AddBattlerVar(ctx, battlerId, BMON_DATA_CUR_PP_1 + movePos, data);
                }
            }
            ret = TRUE;
        }
    }

    if (GetItemAttr(item, ITEMATTR_PP_RESTORE_ALL, HEAP_ID_BATTLE)) {
        data = GetItemAttr(item, ITEMATTR_PP_RESTORE_PARAM, HEAP_ID_BATTLE);
        for (movePos = 0; movePos < MAX_MON_MOVES; movePos++) {
            if (GetMonData(mon, MON_DATA_MOVE1_PP + movePos, NULL) != GetMonData(mon, MON_DATA_MOVE1_MAX_PP + movePos, NULL)) {
                AddMonData(mon, MON_DATA_MOVE1_PP + movePos, data);
                if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
                    if (!(GetBattlerVar(ctx, battlerId, BMON_DATA_STATUS2, NULL) & STATUS2_TRANSFORM) && !(GetBattlerVar(ctx, battlerId, BMON_DATA_MIMICED_MOVE, NULL) & MaskOfFlagNo(movePos))) {
                        AddBattlerVar(ctx, battlerId, BMON_DATA_CUR_PP_1 + movePos, data);
                    }
                }
                ret = TRUE;
            }
        }
    }

    if (GetItemAttr(item, ITEMATTR_HP_RESTORE, HEAP_ID_BATTLE)) {
        data = 0;
        if (GetItemAttr(item, ITEMATTR_REVIVE, HEAP_ID_BATTLE)) {
            if (GetMonData(mon, MON_DATA_HP, NULL) == 0) {
                data = 1;
            }
        } else {
            data = GetMonData(mon, MON_DATA_HP, NULL);
        }
        if (data && GetMonData(mon, MON_DATA_HP, NULL) != GetMonData(mon, MON_DATA_MAX_HP, NULL)) {
            data = GetItemAttr(item, ITEMATTR_HP_RESTORE_PARAM, HEAP_ID_BATTLE);
            switch (data) {
            case HP_RESTORE_ALL:
                data = GetMonData(mon, MON_DATA_MAX_HP, NULL);
                break;
            case HP_RESTORE_HALF:
                data = GetMonData(mon, MON_DATA_MAX_HP, NULL) / 2;
                if (data == 0) {
                    data = 1;
                }
                break;
            case HP_RESTORE_QTR:
                data = GetMonData(mon, MON_DATA_MAX_HP, NULL) * 25 / 100;
                if (data == 0) {
                    data = 1;
                }
                break;
            default:
                break;
            }
            AddMonData(mon, MON_DATA_HP, data);
            if (!GetItemAttr(item, ITEMATTR_REVIVE, HEAP_ID_BATTLE)) {
                if (BattleSystem_GetFieldSide(battleSystem, battlerId)) {
                    SetBattlerVar(ctx, battlerId, BMON_DATA_HELD_ITEM_RESTORE_HP, &data);
                } else if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
                    AddBattlerVar(ctx, battlerId, BMON_DATA_HP, data);
                }
            }
            ret = TRUE;
        }
    }

    if (GetItemAttr(item, ITEMATTR_FRIENDSHIP_MOD_LO, HEAP_ID_BATTLE)) {
        if (GetMonData(mon, MON_DATA_FRIENDSHIP, NULL) < 100 && ret == TRUE) {
            friendship = GetItemAttr(item, ITEMATTR_FRIENDSHIP_MOD_LO_PARAM, HEAP_ID_BATTLE);
        }
    }

    if (GetItemAttr(item, ITEMATTR_FRIENDSHIP_MOD_MED, HEAP_ID_BATTLE)) {
        if (GetMonData(mon, MON_DATA_FRIENDSHIP, NULL) >= 100 && GetMonData(mon, MON_DATA_FRIENDSHIP, NULL) < 200 && ret == TRUE) {
            friendship = GetItemAttr(item, ITEMATTR_FRIENDSHIP_MOD_MED_PARAM, HEAP_ID_BATTLE);
        }
    }

    if (GetItemAttr(item, ITEMATTR_FRIENDSHIP_MOD_HI, HEAP_ID_BATTLE)) {
        if (GetMonData(mon, MON_DATA_FRIENDSHIP, NULL) >= 200 && ret == TRUE) {
            friendship = GetItemAttr(item, ITEMATTR_FRIENDSHIP_MOD_HI_PARAM, HEAP_ID_BATTLE);
        }
    }

    if (friendship) {
        if (friendship > 0) {
            if (BallToItemId(BattleSystem_GetMonBall(battleSystem, mon)) == ITEM_LUXURY_BALL) {
                friendship++;
            }
            if (GetMonData(mon, MON_DATA_EGG_LOCATION, NULL) == BattleSystem_GetLocation(battleSystem)) {
                friendship++;
            }
            data = GetMonData(mon, MON_DATA_HELD_ITEM, NULL);
            if (GetItemAttr(data, ITEMATTR_HOLD_EFFECT, HEAP_ID_BATTLE) == HOLD_EFFECT_FRIENDSHIP_UP) {
                friendship = friendship * 150 / 100;
            }
        }
        AddMonData(mon, MON_DATA_FRIENDSHIP, friendship);
        if (index1 == selectedMonIndex || index2 == selectedMonIndex) {
            AddBattlerVar(ctx, battlerId, BMON_DATA_FRIENDSHIP, friendship);
        }
    }

    if (ret == TRUE) {
        ApplyItemEffectOnMonMood(mon, item);
    }

    return ret;
}

u32 BattleSystem_GetBattleSpecial(BattleSystem *battleSystem) {
    return battleSystem->battleSpecial;
}

int BattleSystem_GetTimezone(BattleSystem *battleSystem) {
    return battleSystem->timezone;
}

int BattleSystem_GetBgTimeOfDay(BattleSystem *battleSystem) {
    int ret;

    switch (battleSystem->backgroundId) {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
        switch (battleSystem->timezone) {
        case 0:
        case 1:
            ret = 0;
            break;
        case 2:
            ret = 1;
            break;
        case 3:
        case 4:
            ret = 2;
            break;
        }
        break;
    default:
        ret = 0;
        break;
    }

    return ret;
}

u8 BattleSystem_GetCancelRunDisplay(BattleSystem *battleSystem, int battlerId, u8 a2) {
    u16 item;

    if (BattleSystem_GetBattlerType(battleSystem, battlerId) == 4 && !(battleSystem->battleType & BATTLE_TYPE_MULTI)) {
        if (battleSystem->battleType & BATTLE_TYPE_LINK) {
            if (!(a2 & MaskOfFlagNo(BattleSystem_GetBattlerIdPartner(battleSystem, battlerId)))) {
                return 1;
            }
        } else {
            item = BattleContext_Get(battleSystem, battleSystem->ctx, 12, 0);
            if ((BattleContext_Get(battleSystem, battleSystem->ctx, 8, 0) == 14 && item > ITEM_CHERISH_BALL) || (a2 & MaskOfFlagNo(0))) {
                return 0;
            } else {
                return 1;
            }
        }
    }
    return 0;
}

u16 BattleSystem_CheckEvolution(BattleSetup *setup, int *selectedMonIndex, int *evolutionCondition) {
    Pokemon *mon;
    u16 species = 0;

    if (setup->winFlag != BATTLE_OUTCOME_WIN && setup->winFlag != BATTLE_OUTCOME_MON_CAUGHT && setup->winFlag != BATTLE_OUTCOME_PLAYER_FLED) {
        return 0;
    }

    while (setup->levelUpFlag) {
        for (*selectedMonIndex = 0; *selectedMonIndex < PARTY_SIZE; (*selectedMonIndex)++) {
            if (setup->levelUpFlag & MaskOfFlagNo(*selectedMonIndex)) {
                setup->levelUpFlag &= MaskOfFlagNo(*selectedMonIndex) ^ 0xFFFFFFFF;
                break;
            }
        }
        if (*selectedMonIndex < PARTY_SIZE) {
            mon = Party_GetMonByIndex(setup->party[0], *selectedMonIndex);
            species = GetMonEvolution(setup->party[0], mon, EVOCTX_LEVELUP, setup->evolutionLocation, evolutionCondition);
            if (species) {
                return species;
            }
        }
    }
    return species;
}

u8 BattleSystem_IsServer(BattleSystem *battleSystem) {
    return battleSystem->isServer;
}

u8 BattleSystem_GetSafariRunAttempts(BattleSystem *battleSystem) {
    GF_ASSERT(battleSystem->ctx != NULL);
    return BattleContext_Get(battleSystem, battleSystem->ctx, 5, 0);
}

int BattleSystem_GetSafariBallCount(BattleSystem *battleSystem) {
    return battleSystem->safariBallCnt;
}

void BattleSystem_SetSafariBallCount(BattleSystem *battleSystem, int cnt) {
    battleSystem->safariBallCnt = cnt;
}

Options *BattleSystem_GetOptions(BattleSystem *battleSystem) {
    return battleSystem->options;
}

BOOL BattleSystem_AreBattleAnimationsOn(BattleSystem *battleSystem) {
    if ((battleSystem->battleType & BATTLE_TYPE_LINK) && !(battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING)) {
        return TRUE;
    }
    return Options_GetBattleScene(battleSystem->options) == 0;
}

u32 BattleSystem_GetFrame(BattleSystem *battleSystem) {
    return Options_GetFrame(battleSystem->options);
}

u8 BattleSystem_GetTextFrameDelay(BattleSystem *battleSystem) {
    if ((battleSystem->battleType & BATTLE_TYPE_LINK) && !(battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING)) {
        return 1;
    }
    return Options_GetTextFrameDelay(battleSystem->options);
}

u32 BattleSystem_GetBattleStyle(BattleSystem *battleSystem) {
    return Options_GetBattleStyle(battleSystem->options);
}

void *BattleSystem_GetPokepicAnimManager(BattleSystem *battleSystem) {
    return battleSystem->pokepicAnimManager;
}

SOUND_CHATOT *BattleSystem_GetChatotVoice(BattleSystem *battleSystem, int battlerId) {
    if ((battleSystem->battleType & BATTLE_TYPE_MULTI) || ((battleSystem->battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        return battleSystem->chatotVoice[battlerId];
    } else if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return battleSystem->chatotVoice[battlerId & 1];
    } else {
        return battleSystem->chatotVoice[battlerId];
    }
}

void BattleSystem_TryChangeForm(BattleSystem *battleSystem) {
    int i;
    AlternateForms form;
    Pokemon *mon;
    u16 species;

    if (battleSystem->battleType & BATTLE_TYPE_NO_EXP) {
        return;
    }

    for (i = 0; i < BattleSystem_GetPartySize(battleSystem, BATTLER_PLAYER); i++) {
        mon = BattleSystem_GetPartyMon(battleSystem, BATTLER_PLAYER, i);
        species = GetMonData(mon, MON_DATA_SPECIES_OR_EGG, NULL);
        if (species == SPECIES_BURMY && battleSystem->monsBattled[BATTLER_PLAYER] & MaskOfFlagNo(i)) {
            switch (BattleSystem_GetTerrainId(battleSystem)) {
            case TERRAIN_GRASS:
            case TERRAIN_PUDDLE:
            case TERRAIN_SNOW:
            case TERRAIN_WATER:
            case TERRAIN_ICE:
            case TERRAIN_GREAT_MARSH:
            default:
                form = BURMY_PLANT;
                break;
            case TERRAIN_PLAIN:
            case TERRAIN_SAND:
            case TERRAIN_CAVE:
            case TERRAIN_MOUNTAIN:
            case TERRAIN_DISTORTION_WORLD:
            case TERRAIN_GIRATINA:
                form = BURMY_SANDY;
                break;
            case TERRAIN_BUILDING:
            case TERRAIN_UNKNOWN:
            case TERRAIN_WILL:
            case TERRAIN_KOGA:
            case TERRAIN_BRUNO:
            case TERRAIN_KAREN:
            case TERRAIN_LANCE:
            case TERRAIN_BATTLE_TOWER:
            case TERRAIN_BATTLE_FACTORY:
            case TERRAIN_BATTLE_ARCADE:
            case TERRAIN_BATTLE_CASTLE:
            case TERRAIN_BATTLE_HALL:
                form = BURMY_TRASH;
                break;
            }
            SetMonData(mon, MON_DATA_FORM, &form);
        }
    }
}

void BattleSystem_FlagMonBattled(BattleSystem *battleSystem, int battlerId, int selectedMonIndex) {
    battleSystem->monsBattled[battlerId] |= MaskOfFlagNo(selectedMonIndex);
}

// used to be related to poketch in dppt
void BattleSystem_EmptyMonFunc() {
}

void BattleSystem_SetBackground(BattleSystem *battleSystem) {
    NNSG2dImageProxy *image;
    int bgX, bgY, objX, objY, data, i;
    u8 *vram;
    u32 *src;
    u32 *dst;

    battleSystem->bgTiles = Heap_Alloc(HEAP_ID_BATTLE, 0x10000);
    battleSystem->bgPalette = Heap_Alloc(HEAP_ID_BATTLE, 0x200);

    MIi_CpuCopy32((void *)0x6010000, (u32 *)battleSystem->bgTiles, 0x10000);
    dst = (u32 *)battleSystem->bgPalette;
    src = (u32 *)PaletteData_GetUnfadedBuf(battleSystem->palette, PLTTBUF_MAIN_BG);
    MIi_CpuCopy32(src, dst, 0x200);

    vram = (u8 *)0x6400000;
    image = Sprite_GetImageProxy(battleSystem->terrains[1].sprite->sprite);
    vram += image->vramLocation.baseAddrOfVram[NNS_G2D_VRAM_TYPE_2DMAIN];

    for (bgY = 20; bgY < 28; bgY++) {
        for (bgX = 16; bgX < 32; bgX++) {
            objX = bgX - 16;
            objY = bgY - 20;
            for (i = 0; i < 64; i++) {
                if (objX < 8) {
                    if (i & 1) {
                        data = (vram[objY * 0x100 + objX * 0x20 + i / 2] & 0xF0) >> 4;
                    } else {
                        data = (vram[objY * 0x100 + objX * 0x20 + i / 2] & 0xF);
                    }
                } else if (i & 1) {
                    data = (vram[0x700 + objY * 0x100 + objX * 0x20 + i / 2] & 0xF0) >> 4;
                } else {
                    data = (vram[0x700 + objY * 0x100 + objX * 0x20 + i / 2] & 0xF);
                }
                if (data) {
                    battleSystem->bgTiles[bgY * 0x800 + bgX * 0x40 + i] = data + 0x70;
                }
            }
        }
    }

    vram = (u8 *)0x6400000;
    image = Sprite_GetImageProxy(battleSystem->terrains[0].sprite->sprite);
    vram += image->vramLocation.baseAddrOfVram[NNS_G2D_VRAM_TYPE_2DMAIN];

    for (i = 0; i < 0x800; i++) {
        if (i & 1) {
            data = (vram[i / 2] & 0xF0) >> 4;
        } else {
            data = (vram[i / 2] & 0xF);
        }
        if (data) {
            battleSystem->bgTiles[0x9800 + i] = data + 0x70;
        }
    }

    for (bgY = 28; bgY < 32; bgY++) {
        for (bgX = 0; bgX < 24; bgX++) {
            objX = bgX;
            objY = bgY - 28;
            for (i = 0; i < 0x40; i++) {
                if (i & 1) {
                    data = (vram[0x400 + (objX / 8) * 0x400 + (objX % 8) * 0x20 + objY * 0x100 + i / 2] & 0xF0) >> 4;
                } else {
                    data = (vram[0x400 + (objX / 8) * 0x400 + (objX % 8) * 0x20 + objY * 0x100 + i / 2] & 0xF);
                }
                if (data) {
                    battleSystem->bgTiles[bgY * 0x800 + bgX * 0x40 + i] = data + 0x70;
                }
            }
        }
    }

    BG_LoadCharTilesData(battleSystem->bgConfig, 3, battleSystem->bgTiles, 0x10000, 0);

    BattleTerrain_Free(&battleSystem->terrains[0]);
    BattleTerrain_Free(&battleSystem->terrains[1]);
}

u8 *BattleSystem_GetBattleBgTiles(BattleSystem *battleSystem) {
    return battleSystem->bgTiles;
}

u16 *BattleSystem_GetBattleBgPalette(BattleSystem *battleSystem) {
    return battleSystem->bgPalette;
}

u16 *BattleSystem_GetBgPaletteBackup(BattleSystem *battleSystem) {
    return &battleSystem->bgPaletteBackup[0];
}

u16 *BattleSystem_GetObjPaletteBackup(BattleSystem *battleSystem) {
    return &battleSystem->objPaletteBackup[0];
}

int BattleSystem_GetWeather(BattleSystem *battleSystem) {
    return battleSystem->weather;
}

u8 BattleSystem_GetTutorialState(BattleSystem *battleSystem) {
    return battleSystem->tutorialState;
}

void BattleSystem_SetTutorialState(BattleSystem *battleSystem, u8 tutorialState) {
    battleSystem->tutorialState = tutorialState;
}

BOOL BattleSystem_MetBill(BattleSystem *battleSystem) {
    return battleSystem->metBill;
}

void BattleSystem_GameStatIncrement(BattleSystem *battleSystem, int id) {
    if (battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING) {
        return;
    }
    GameStats_Inc(battleSystem->gameStats, id);
}

void BattleSystem_AddSpeciesCaughtScore(BattleSystem *battleSystem) {
    if (battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING) {
        return;
    }
    GameStats_AddScore(battleSystem->gameStats, SCORE_EVENT_REGISTER_SPECIES_CAUGHT);
}

void BattleSystem_SetField2440(BattleSystem *battleSystem, int a1) {
    battleSystem->unk2440 = a1;
}

void BattleSystem_SetSwitchingOrCanPickCommandMask(BattleSystem *battleSystem, u8 a1) {
    battleSystem->unk2442 = a1;
}

void *BattleSystem_GetWaitingIcon(BattleSystem *battleSystem) {
    return battleSystem->waitingIcon;
}

void BattleSystem_SetWaitingIcon(BattleSystem *battleSystem, void *waitingIcon) {
    battleSystem->waitingIcon = waitingIcon;
}

MonPicData *BattleSystem_GetMonPicData(BattleSystem *battleSystem, int index) {
    return &battleSystem->monPicData[index];
}

u8 *MonPicData_GetCharBuffer(MonPicData *ptr, int index) {
    GF_ASSERT(index < 4);
    return ptr[index].charBuffer;
}

void MonPicData_SetNarcId(MonPicData *ptr, int index, int narcId) {
    GF_ASSERT(index < 4);
    ptr[index].narcId = narcId;
}

void MonPicData_SetPaletteId(MonPicData *ptr, int index, int paletteId) {
    GF_ASSERT(index < 4);
    ptr[index].paletteId = paletteId;
}

void MonPicData_SetHeight(MonPicData *ptr, int index, int height) {
    GF_ASSERT(index < 4);
    ptr[index].height = height;
}

void BattleSystem_SetGraphicsState(BattleSystem *battleSystem, u8 graphicsMode) {
    battleSystem->graphicsMode = graphicsMode;
}

void BattleSystem_SetLinkSendStatePtr(BattleSystem *battleSystem, u8 *sendState) {
    battleSystem->linkSendState = sendState;
}

void BattleSystem_SetLinkRecvStatePtr(BattleSystem *battleSystem, u8 *recvState) {
    battleSystem->linkRecvState = recvState;
}

void BattleSystem_SetLinkSendState(BattleSystem *battleSystem, u8 state) {
    *battleSystem->linkSendState = state;
}

void BattleSystem_SetLinkRecvState(BattleSystem *battleSystem, u8 state) {
    *battleSystem->linkRecvState = state;
}

void BattleSystem_SetBattleFinished(BattleSystem *battleSystem, u8 finished) {
    battleSystem->battleFinished = finished;
}

BattleHpBar *BattleSystem_GetHpBar(BattleSystem *battleSystem, int battlerId) {
    return OpponentData_GetHpBar(battleSystem->opponentData[battlerId]);
}

void BattleSystem_HpBar_Init(BattleSystem *battleSystem) {
    int i;
    BattleHpBar *hpBar;

    for (i = 0; i < battleSystem->maxBattlers; i++) {
        hpBar = OpponentData_GetHpBar(battleSystem->opponentData[i]);
        hpBar->battleSystem = battleSystem;
        hpBar->type = BattleHpBar_Util_GetBarTypeFromBattlerSide(OpponentData_GetBattlerType(battleSystem->opponentData[i]), BattleSystem_GetBattleType(battleSystem));
        BattleHpBar_LoadResources(hpBar);
        BattleHpBar_SetEnabled(hpBar, FALSE);
    }
}

void BattleSystem_SetHpBarEnabled(BattleSystem *battleSystem) {
    int i;
    BattleHpBar *hpBar;

    for (i = 0; i < battleSystem->maxBattlers; i++) {
        hpBar = OpponentData_GetHpBar(battleSystem->opponentData[i]);
        if (hpBar->hp) {
            BattleHpBar_SetEnabled(hpBar, TRUE);
        }
    }
}

void BattleSystem_SetHpBarDisabled(BattleSystem *battleSystem) {
    int i;
    BattleHpBar *hpBar;

    for (i = 0; i < battleSystem->maxBattlers; i++) {
        hpBar = OpponentData_GetHpBar(battleSystem->opponentData[i]);
        BattleHpBar_SetEnabled(hpBar, FALSE);
    }
}

void BattleSystem_HpBar_Delete(BattleSystem *battleSystem) {
    int i;
    BattleHpBar *hpBar;

    for (i = 0; i < battleSystem->maxBattlers; i++) {
        hpBar = OpponentData_GetHpBar(battleSystem->opponentData[i]);
        BattleHpBar_FreeResources(hpBar);
    }
}

u8 BattleSystem_GetBattleOutcomeFlags(BattleSystem *battleSystem) {
    return battleSystem->battleOutcomeFlag;
}

void BattleSystem_SetBattleOutcomeFlags(BattleSystem *battleSystem, u8 battleOutcomeFlag) {
    battleSystem->battleOutcomeFlag = battleOutcomeFlag;
}

u8 BattleSystem_GetCriticalHpMusicFlag(BattleSystem *battleSystem) {
    return battleSystem->criticalHpMusic;
}

void BattleSystem_SetCriticalHpMusicFlag(BattleSystem *battleSystem, u8 flag) {
    battleSystem->criticalHpMusic = flag;
}

u8 BattleSystem_GetCriticalHpMusicDelay(BattleSystem *battleSystem) {
    return battleSystem->criticalHpMusicDelay;
}

void BattleSystem_SetCriticalHpMusicDelay(BattleSystem *battleSystem, u8 delay) {
    GF_ASSERT(delay < 15);
    battleSystem->criticalHpMusicDelay = delay;
}

void BattleSystem_SetCaughtBattlerId(BattleSystem *battleSystem, int battlerId) {
    battleSystem->caughtBattlerId = battlerId;
}

u16 BattleSystem_Random(BattleSystem *battleSystem) {
    battleSystem->rand = battleSystem->rand * 1103515245L + 24691;
    return battleSystem->rand / 65536L;
}

u32 BattleSystem_GetRandTemp(BattleSystem *battleSystem) {
    return battleSystem->randTemp;
}

void BattleSystem_SetRandTemp(BattleSystem *battleSystem, u32 temp) {
    battleSystem->randTemp = temp;
}

void BattleSystem_RecordInput(BattleSystem *battleSystem, int battlerId, u8 data) {
    if (!(battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING) && battleSystem->recordInputCount[battlerId] < 1024) {
        BattleRecord_SetCommand(battlerId, battleSystem->recordInputCount[battlerId], data);
        battleSystem->recordInputCount[battlerId]++;
    }
}

BOOL BattleSystem_ReadRecordedInput(BattleSystem *battleSystem, int battlerId, u8 *data) {
    BOOL ret;
    *data = 0xFF;
    if ((battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING) && (battleSystem->recordInputCount[battlerId] < 1024)) {
        *data = BattleRecord_GetCommand(battlerId, battleSystem->recordInputCount[battlerId]);
        battleSystem->recordInputCount[battlerId]++;
        ret = FALSE;
    } else if ((battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING) && battleSystem->recordInputCount[battlerId] >= 1024) {
        ret = TRUE;
    }
    return ret;
}

u8 BattleSystem_PackRecordUpdate(BattleSystem *battleSystem, u8 *buffer) {
    u8 i;
    u8 battlerId;
    u8 index = 0;

    for (battlerId = 0; battlerId < battleSystem->maxBattlers; battlerId++) {
        if (battleSystem->recordInputCount[battlerId] != battleSystem->recordSentCount[battlerId]) {
            buffer[index++] = battlerId;
            buffer[index++] = battleSystem->recordInputCount[battlerId] - battleSystem->recordSentCount[battlerId];
            for (i = 0; i < battleSystem->recordInputCount[battlerId] - battleSystem->recordSentCount[battlerId]; i++) {
                buffer[index++] = BattleRecord_GetCommand(battlerId, battleSystem->recordSentCount[battlerId] + i);
            }
            battleSystem->recordSentCount[battlerId] = battleSystem->recordInputCount[battlerId];
        }
    }

    GF_ASSERT(index <= 28);

    return index;
}

void BattleSystem_UnpackRecordUpdate(BattleSystem *battleSystem, u16 size, u8 *buffer) {
    int i;
    u8 battlerId;
    u8 byte;
    u8 index = 0;

    if (!(battleSystem->battleType & BATTLE_TYPE_LINK)) {
        return;
    }

    if (battleSystem->isServer) {
        return;
    }

    while (size) {
        battlerId = BattleSystem_ReadRecordByte(buffer, &index, &size);
        byte = BattleSystem_ReadRecordByte(buffer, &index, &size);
        for (i = 0; i < byte; i++) {
            BattleRecord_SetCommand(battlerId, battleSystem->recordRecvCount[battlerId] + i, BattleSystem_ReadRecordByte(buffer, &index, &size));
        }
        battleSystem->recordRecvCount[battlerId] += byte;
    }
}

static u8 BattleSystem_ReadRecordByte(u8 *buffer, u8 *index, u16 *size) {
    (*size)--;
    return buffer[(*index)++];
}

u16 BattleSystem_GetNetworkId(BattleSystem *battleSystem) {
    return battleSystem->networkId;
}

int BattleSystem_GetLinkPosition(BattleSystem *battleSystem, u16 battlerId) {
    return battleSystem->linkPositions[battlerId];
}

u16 BattleSystem_GetTrainerItem(BattleSystem *battleSystem, int battlerId, int index) {
    return battleSystem->trainers[battlerId].data.items[index];
}

BOOL BattleSystem_IsRecordingPaused(BattleSystem *battleSystem) {
    return battleSystem->isRecordingPaused;
}

void BattleSystem_PauseRecording(BattleSystem *battleSystem, u32 flag) {
    if (!(battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING) || battleSystem->isRecordingPaused || BattleContext_Get(battleSystem, battleSystem->ctx, 13, 0) == 44 || BattleContext_Get(battleSystem, battleSystem->ctx, 14, 0) == 44) {
        return;
    }

    BattleInput_PrintSystemMessage(battleSystem->battleInput, flag);
    BeginNormalPaletteFade(FADE_MAIN_ONLY, FADE_TYPE_BRIGHTNESS_OUT, FADE_TYPE_BRIGHTNESS_OUT, RGB_BLACK, 16, 2, HEAP_ID_BATTLE);
    Sound_Stop();
    Sound_SetMasterVolume(0);
    battleSystem->isRecordingPaused = TRUE;
}

BOOL BattleSystem_CanPauseRecording(BattleSystem *battleSystem) {
    if (!(battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING) || battleSystem->isRecordingPaused || BattleContext_Get(battleSystem, battleSystem->ctx, 13, 0) == 44 || BattleContext_Get(battleSystem, battleSystem->ctx, 14, 0) == 44) {
        return FALSE;
    }
    return TRUE;
}

void BattleSystem_StartRecordingStopTask(BattleSystem *battleSystem) {
    if (!(battleSystem->battleSpecial & BATTLE_SPECIAL_RECORDING) || battleSystem->recordingStopTask) {
        return;
    }
    battleSystem->recordingStopTask = BattleRecordingStop_CreateTask(battleSystem);
}

u8 BattleSystem_GetChatotVoiceParam(BattleSystem *battleSystem, int battlerId) {
    if ((battleSystem->battleType & BATTLE_TYPE_MULTI) || ((battleSystem->battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        return battleSystem->chatotVoiceParam[battlerId];
    } else if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return battleSystem->chatotVoiceParam[battlerId & 1];
    } else {
        return battleSystem->chatotVoiceParam[battlerId];
    }
}

Pokemon *BattleSystem_GetBugContestCaughtMon(BattleSystem *battleSystem) {
    return battleSystem->bugContestCaughtMon;
}

u8 BattleSystem_GetFollowMonSlot(BattleSystem *battleSystem, u32 battlerId) {
    if (battlerId >= 4) {
        return 0xFF;
    }
    if (battleSystem->battleType & (BATTLE_TYPE_LINK | BATTLE_TYPE_SAFARI | BATTLE_TYPE_FRONTIER | BATTLE_TYPE_PAL_PARK)) {
        return 0xFF;
    }

    if ((battleSystem->battleType & BATTLE_TYPE_DOUBLES) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1)) {
        return 0xFF;
    }

    if (battleSystem->battleType & BATTLE_TYPE_MULTI) {
        return battleSystem->followMonSlot[battlerId];
    }
    if (battleSystem->battleType & BATTLE_TYPE_DOUBLES) {
        return battleSystem->followMonSlot[battlerId & 1];
    }
    return battleSystem->followMonSlot[battlerId];
}

void BattleSystem_GetBattlerIdsByType(BattleSystem *battleSystem, u8 *buffer) {
    int i;
    for (i = 0; i < battleSystem->maxBattlers; i++) {
        buffer[OpponentData_GetBattlerType(battleSystem->opponentData[i])] = i;
    }
}

void BattleSystem_GetBattlerTypes(BattleSystem *battleSystem, u8 *buffer) {
    int i;

    for (i = 0; i < 4; i++) {
        buffer[i] = 0xFF;
    }

    for (i = 0; i < battleSystem->maxBattlers; i++) {
        buffer[i] = OpponentData_GetBattlerType(battleSystem->opponentData[i]);
    }
}

void BattleSystem_GetPokepics(BattleSystem *battleSystem, void **pokepics) {
    int i;

    for (i = 0; i < 4; i++) {
        pokepics[i] = NULL;
    }

    for (i = 0; i < battleSystem->maxBattlers; i++) {
        pokepics[i] = OpponentData_GetPokepic(battleSystem->opponentData[i]);
    }
}

void BattleSystem_SetHpBarPriority(BattleSystem *battleSystem, int priority) {
    int i;
    BattleHpBar *hpBar;

    for (i = 0; i < battleSystem->maxBattlers; i++) {
        hpBar = OpponentData_GetHpBar(battleSystem->opponentData[i]);
        BattleHpBar_SetPriority(hpBar, priority);
    }
}

u32 CalcMoneyLoss(Party *party, PlayerProfile *profile) {
    static const u8 sBadgePenalty[] = {
        2, 4, 6, 9, 12, 16, 20, 25, 30
    };
    u8 badgeCount = PlayerProfile_CountBadges(profile);
    if (badgeCount > 8) {
        badgeCount = 8;
    }
    u32 loss = Party_GetMaxLevel(party) * 4 * sBadgePenalty[badgeCount];
    u32 money = PlayerProfile_GetMoney(profile);

    if (loss > money) {
        loss = money;
    }

    return loss;
}

void BattleSystem_SetPokedexSeen(BattleSystem *battleSystem, int battlerId) {
    u32 flag = OpponentData_GetBattlerType(battleSystem->opponentData[battlerId]);
    Pokemon *mon = BattleSystem_GetPartyMon(battleSystem, battlerId, BattleContext_Get(battleSystem, battleSystem->ctx, 2, battlerId));

    if (!(battleSystem->battleType & (BATTLE_TYPE_LINK | BATTLE_TYPE_FRONTIER))) {
        if ((flag & 1) || battleSystem->battleType == (BATTLE_TYPE_AI | BATTLE_TYPE_DOUBLES | BATTLE_TYPE_MULTI) || battleSystem->battleType == (BATTLE_TYPE_TRAINER | BATTLE_TYPE_AI | BATTLE_TYPE_DOUBLES | BATTLE_TYPE_MULTI)) {
            Pokedex_SetMonSeenFlag(battleSystem->pokedex, mon);
        }
    }
    if (!(flag & 1) && GetMonData(mon, MON_DATA_SPECIES_OR_EGG, NULL) == SPECIES_BURMY) {
        Pokedex_SetMonCaughtFlag(battleSystem->pokedex, mon);
    }
}

void BattleSystem_SetPokedexCaught(BattleSystem *battleSystem, int battlerId) {
    u32 flag = OpponentData_GetBattlerType(battleSystem->opponentData[battlerId]);

    if (!(battleSystem->battleType & (BATTLE_TYPE_LINK | BATTLE_TYPE_FRONTIER)) && (flag & 1)) {
        int selectedMonIndex = BattleContext_Get(battleSystem, battleSystem->ctx, 2, battlerId);
        Pokemon *mon = BattleSystem_GetPartyMon(battleSystem, battlerId, selectedMonIndex);
        Pokedex_SetMonCaughtFlag(battleSystem->pokedex, mon);
    }
}

BOOL BattleSystem_CheckMonCaught(BattleSystem *battleSystem, int battlerId) {
    return Pokedex_CheckMonCaughtFlag(battleSystem->pokedex, battlerId);
}

void BattleSystem_SetDefaultBlend() {
    G2_BlendNone();
}

u8 BattleSystem_PrintTrainerMessage(BattleSystem *battleSystem, int trainerId, int battlerId, int msgType, int delay) {
    Window *window = BattleSystem_GetWindow(battleSystem, 0);
    int index;

    if (battleSystem->battleType & BATTLE_TYPE_FRONTIER) {
        if (trainerId == 0x2710 || battleSystem->battleType & BATTLE_TYPE_13) {
            String *msg;

            if (msgType == 0x64) {
                msg = MailMsg_GetExpandedString(&battleSystem->trainers[battlerId].winMessage, HEAP_ID_BATTLE);
            } else {
                msg = MailMsg_GetExpandedString(&battleSystem->trainers[battlerId].loseMessage, HEAP_ID_BATTLE);
            }
            FillWindowPixelBuffer(window, 0xFF);
            String_Copy(battleSystem->msgBuffer, msg);
            index = AddTextPrinterParameterized(window, 1, battleSystem->msgBuffer, 0, 0, delay, BattleSystem_TextPrinterCallback);
            String_Delete(msg);
        } else {
            MsgData *data;
            String *msg;
            int stringId;
            u32 msgId;
            int i;

            if (msgType == 0x64) {
                stringId = trainerId * 3 + 1;
            } else {
                stringId = trainerId * 3 + 2;
            }

            for (i = 0; i < 4; i++) {
                if (PlayerProfile_GetVersion(battleSystem->playerProfile[i]) == 0) {
                    break;
                }
            }

            if (i == 4) {
                msgId = msg_0197_00724;
            } else {
                msgId = msg_0197_00723;
            }

            data = NewMsgDataFromNarc(MSGDATA_LOAD_DIRECT, NARC_msgdata_msg, msgId, HEAP_ID_BATTLE);
            msg = NewString_ReadMsgData(data, stringId);
            FillWindowPixelBuffer(window, 0xFF);
            String_Copy(battleSystem->msgBuffer, msg);
            index = AddTextPrinterParameterized(window, 1, battleSystem->msgBuffer, 0, 0, delay, BattleSystem_TextPrinterCallback);
            String_Delete(msg);
            DestroyMsgData(data);
        }
    } else {
        GetTrainerMessageByIdPair(trainerId, msgType, battleSystem->msgBuffer, HEAP_ID_BATTLE);
        FillWindowPixelBuffer(window, 0xFF);
        index = AddTextPrinterParameterized(window, 1, battleSystem->msgBuffer, 0, 0, delay, BattleSystem_TextPrinterCallback);
    }
    return index;
}

u32 BattleSystem_PrintBattleMessage(BattleSystem *battleSystem, MsgData *data, BattleMessage *msg, u8 delay) {
    Window *window = BattleSystem_GetWindow(battleSystem, 0);
    BattleSystem_AdjustMessageForSide(battleSystem, msg);
    BattleSystem_BufferMessage(battleSystem, msg);
    BattleMessage_ExpandPlaceholders(battleSystem, data, msg);
    FillWindowPixelBuffer(window, 0xFF);
    return AddTextPrinterParameterized(window, 1, battleSystem->msgBuffer, 0, 0, delay, BattleSystem_TextPrinterCallback);
}

u32 BattleSystem_PrintMessageToWindow(BattleSystem *battleSystem, Window *window, MsgData *data, BattleMessage *msg, int x, int y, int flag, int width, int delay) {
    int dx;

    BattleSystem_AdjustMessageForSide(battleSystem, msg);
    BattleSystem_BufferMessage(battleSystem, msg);
    BattleMessage_ExpandPlaceholders(battleSystem, data, msg);

    if (flag & 1) {
        FillWindowPixelBuffer(window, 0xFF);
    }

    if (flag & 2) {
        dx = width - FontID_String_GetWidth(0, battleSystem->msgBuffer, 0);
    } else {
        dx = 0;
    }

    return AddTextPrinterParameterized(window, 0, battleSystem->msgBuffer, x + dx, y, delay, BattleSystem_TextPrinterCallback);
}

static void BattleSystem_AdjustMessageForSide(BattleSystem *battleSystem, BattleMessage *msg) {
    u32 battleType = BattleSystem_GetBattleType(battleSystem);

    if (msg->tag & 0x80) {
        return;
    }

    if (msg->tag & 0x40) {
        if (BattleSystem_GetFieldSide(battleSystem, msg->battlerId)) {
            msg->id++;
        }
        return;
    }

    switch (msg->tag & 0x3F) {
    case TAG_NONE:
    case TAG_MOVE:
    case TAG_STAT:
    case TAG_ITEM:
    case TAG_NUMBER:
    case TAG_NUMBERS:
    case TAG_TRNAME:
    case TAG_MOVE_MOVE:
    case TAG_ITEM_MOVE:
    case TAG_NUMBER_NUMBER:
    case TAG_TRNAME_TRNAME:
    case TAG_TRNAME_NICKNAME:
    case TAG_TRNAME_ITEM:
    case TAG_TRNAME_NUM:
    case TAG_TRCLASS_TRNAME:
    case TAG_TRNAME_NICKNAME_NICKNAME:
    case TAG_TRCLASS_TRNAME_NICKNAME:
    case TAG_TRCLASS_TRNAME_ITEM:
    case TAG_TRNAME_NICKNAME_TRNAME_NICKNAME:
    case TAG_TRCLASS_TRNAME_NICKNAME_NICKNAME:
    case TAG_TRCLASS_TRNAME_NICKNAME_TRNAME:
    case TAG_TRCLASS_TRNAME_TRCLASS_TRNAME:
    case TAG_TRCLASS_TRNAME_NICKNAME_TRCLASS_TRNAME_NICKNAME:
        break;
    case TAG_NONE_SIDE:
        if (BattleSystem_GetFieldSide(battleSystem, msg->param[0] & 0xFF)) {
            msg->id++;
        }
        break;
    case TAG_NICKNAME:
    case TAG_NICKNAME_MOVE:
    case TAG_NICKNAME_ABILITY:
    case TAG_NICKNAME_STAT:
    case TAG_NICKNAME_TYPE:
    case TAG_NICKNAME_POKE:
    case TAG_NICKNAME_ITEM:
    case TAG_NICKNAME_POFFIN:
    case TAG_NICKNAME_NUM:
    case TAG_NICKNAME_TRNAME:
    case TAG_NICKNAME_BOX:
    case TAG_NICKNAME_MOVE_MOVE:
    case TAG_NICKNAME_MOVE_NUMBER:
    case TAG_NICKNAME_ABILITY_MOVE:
    case TAG_NICKNAME_ABILITY_ITEM:
    case TAG_NICKNAME_ABILITY_STAT:
    case TAG_NICKNAME_ABILITY_TYPE:
    case TAG_NICKNAME_ABILITY_STATUS:
    case TAG_NICKNAME_ABILITY_NUMBER:
    case TAG_NICKNAME_ITEM_MOVE:
    case TAG_NICKNAME_ITEM_STAT:
    case TAG_NICKNAME_ITEM_STATUS:
    case TAG_NICKNAME_BOX_BOX:
        if (BattleSystem_GetFieldSide(battleSystem, msg->param[0] & 0xFF)) {
            msg->id++;
            if (battleType & BATTLE_TYPE_TRAINER) {
                msg->id++;
            }
        }
        break;
    case TAG_MOVE_SIDE:
        if (BattleSystem_GetFieldSide(battleSystem, msg->param[1] & 0xFF)) {
            msg->id++;
        }
        break;
    case TAG_MOVE_NICKNAME:
    case TAG_ABILITY_NICKNAME:
    case TAG_ITEM_NICKNAME_FLAVOR:
        if (BattleSystem_GetFieldSide(battleSystem, msg->param[1] & 0xFF)) {
            msg->id++;
            if (battleType & BATTLE_TYPE_TRAINER) {
                msg->id++;
            }
        }
        break;
    case TAG_NICKNAME_NICKNAME:
    case TAG_NICKNAME_NICKNAME_MOVE:
    case TAG_NICKNAME_NICKNAME_ABILITY:
    case TAG_NICKNAME_NICKNAME_ITEM:
        if (BattleSystem_GetFieldSide(battleSystem, msg->param[0] & 0xFF)) {
            msg->id += 3;
            if (battleType & BATTLE_TYPE_TRAINER) {
                msg->id += 2;
            }
            if (BattleSystem_GetFieldSide(battleSystem, msg->param[1] & 0xFF)) {
                msg->id++;
            }
        } else if (BattleSystem_GetFieldSide(battleSystem, msg->param[1] & 0xFF)) {
            msg->id++;
            if (battleType & BATTLE_TYPE_TRAINER) {
                msg->id++;
            }
        }
        break;
    case TAG_NICKNAME_ABILITY_NICKNAME:
    case TAG_NICKNAME_ITEM_NICKNAME:
    case TAG_NICKNAME_ABILITY_NICKNAME_MOVE:
    case TAG_NICKNAME_ABILITY_NICKNAME_ABILITY:
    case TAG_NICKNAME_ABILITY_NICKNAME_STAT:
    case TAG_NICKNAME_ITEM_NICKNAME_ITEM:
        if (BattleSystem_GetFieldSide(battleSystem, msg->param[0] & 0xFF)) {
            msg->id += 3;
            if (battleType & BATTLE_TYPE_TRAINER) {
                msg->id += 2;
            }
            if (BattleSystem_GetFieldSide(battleSystem, msg->param[2] & 0xFF)) {
                msg->id++;
            }
        } else if (BattleSystem_GetFieldSide(battleSystem, msg->param[2] & 0xFF)) {
            msg->id++;
            if (battleType & BATTLE_TYPE_TRAINER) {
                msg->id++;
            }
        }
        break;
    default:
        GF_ASSERT(FALSE);
    }
}

static void BattleSystem_BufferMessage(BattleSystem *battleSystem, BattleMessage *msg) {
    switch (msg->tag & 0x3F) {
    case TAG_NONE:
    case TAG_NONE_SIDE:
        break;
    case TAG_NICKNAME:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        break;
    case TAG_MOVE:
    case TAG_MOVE_SIDE:
        BattleMessage_BufferMove(battleSystem, 0, msg->param[0]);
        break;
    case TAG_STAT:
        BattleMessage_BufferStat(battleSystem, 0, msg->param[0]);
        break;
    case TAG_ITEM:
        BattleMessage_BufferItem(battleSystem, 0, msg->param[0]);
        break;
    case TAG_NUMBER:
        BattleMessage_BufferNumber(battleSystem, 0, msg->param[0]);
        break;
    case TAG_NUMBERS:
        BattleMessage_BufferNumbers(battleSystem, 0, msg->param[0], msg->numDigits);
        break;
    case TAG_TRNAME:
        BattleMessage_BufferTrainerName(battleSystem, 0, msg->param[0]);
        break;
    case TAG_NICKNAME_NICKNAME:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_MOVE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferMove(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_ABILITY:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_STAT:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferStat(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_TYPE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferType(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_POKE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferPokemon(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_ITEM:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferItem(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_POFFIN: // unused
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferPoffin(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_NUM:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNumber(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_TRNAME:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_BOX:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferBoxName(battleSystem, 1, msg->param[1]);
        break;
    case TAG_MOVE_NICKNAME:
        BattleMessage_BufferMove(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        break;
    case TAG_MOVE_MOVE:
        BattleMessage_BufferMove(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferMove(battleSystem, 1, msg->param[1]);
        break;
    case TAG_ABILITY_NICKNAME:
        BattleMessage_BufferAbility(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        break;
    case TAG_ITEM_MOVE:
        BattleMessage_BufferItem(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferMove(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NUMBER_NUMBER:
        BattleMessage_BufferNumber(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNumber(battleSystem, 1, msg->param[1]);
        break;
    case TAG_TRNAME_TRNAME:
        BattleMessage_BufferTrainerName(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        break;
    case TAG_TRNAME_NICKNAME:
        BattleMessage_BufferTrainerName(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        break;
    case TAG_TRNAME_ITEM:
        BattleMessage_BufferTrainerName(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferItem(battleSystem, 1, msg->param[1]);
        break;
    case TAG_TRNAME_NUM:
        BattleMessage_BufferTrainerName(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNumber(battleSystem, 1, msg->param[1]);
        break;
    case TAG_TRCLASS_TRNAME:
        BattleMessage_BufferTrainerClass(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        break;
    case TAG_NICKNAME_NICKNAME_MOVE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferMove(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_NICKNAME_ABILITY:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferAbility(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_NICKNAME_ITEM:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferItem(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_MOVE_MOVE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferMove(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferMove(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_MOVE_NUMBER:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferMove(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNumber(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ABILITY_NICKNAME:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ABILITY_MOVE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferMove(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ABILITY_ITEM:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferItem(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ABILITY_STAT:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferStat(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ABILITY_TYPE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferType(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ABILITY_STATUS:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferStatus(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ABILITY_NUMBER:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNumber(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ITEM_NICKNAME:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferItem(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ITEM_MOVE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferItem(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferMove(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ITEM_STAT:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferItem(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferStat(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ITEM_STATUS:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferItem(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferStatus(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_BOX_BOX:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferBoxName(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferBoxName(battleSystem, 2, msg->param[2]);
        break;
    case TAG_ITEM_NICKNAME_FLAVOR:
        BattleMessage_BufferItem(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferFlavorPreference(battleSystem, 2, msg->param[2]);
        break;
    case TAG_TRNAME_NICKNAME_NICKNAME:
        BattleMessage_BufferTrainerName(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        break;
    case TAG_TRCLASS_TRNAME_NICKNAME:
        BattleMessage_BufferTrainerClass(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        break;
    case TAG_TRCLASS_TRNAME_ITEM:
        BattleMessage_BufferTrainerClass(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferItem(battleSystem, 2, msg->param[2]);
        break;
    case TAG_NICKNAME_ABILITY_NICKNAME_MOVE:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferMove(battleSystem, 3, msg->param[3]);
        break;
    case TAG_NICKNAME_ABILITY_NICKNAME_ABILITY:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferAbility(battleSystem, 3, msg->param[3]);
        break;
    case TAG_NICKNAME_ABILITY_NICKNAME_STAT:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferAbility(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferStat(battleSystem, 3, msg->param[3]);
        break;
    case TAG_NICKNAME_ITEM_NICKNAME_ITEM:
        BattleMessage_BufferNickname(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferItem(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferItem(battleSystem, 3, msg->param[3]);
        break;
    case TAG_TRNAME_NICKNAME_TRNAME_NICKNAME:
        BattleMessage_BufferTrainerName(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferNickname(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferTrainerName(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferNickname(battleSystem, 3, msg->param[3]);
        break;
    case TAG_TRCLASS_TRNAME_NICKNAME_NICKNAME:
        BattleMessage_BufferTrainerClass(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferNickname(battleSystem, 3, msg->param[3]);
        break;
    case TAG_TRCLASS_TRNAME_NICKNAME_TRNAME:
        BattleMessage_BufferTrainerClass(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferTrainerName(battleSystem, 3, msg->param[3]);
        break;
    case TAG_TRCLASS_TRNAME_TRCLASS_TRNAME:
        BattleMessage_BufferTrainerClass(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferTrainerClass(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferTrainerName(battleSystem, 3, msg->param[3]);
        break;
    case TAG_TRCLASS_TRNAME_NICKNAME_TRCLASS_TRNAME_NICKNAME:
        BattleMessage_BufferTrainerClass(battleSystem, 0, msg->param[0]);
        BattleMessage_BufferTrainerName(battleSystem, 1, msg->param[1]);
        BattleMessage_BufferNickname(battleSystem, 2, msg->param[2]);
        BattleMessage_BufferTrainerClass(battleSystem, 3, msg->param[3]);
        BattleMessage_BufferTrainerName(battleSystem, 4, msg->param[4]);
        BattleMessage_BufferNickname(battleSystem, 5, msg->param[5]);
        break;
    default:
        GF_ASSERT(FALSE);
    }
}

static void BattleMessage_BufferNickname(BattleSystem *battleSystem, int bufferIndex, int param) {
    Pokemon *mon = BattleSystem_GetPartyMon(battleSystem, param & 0xFF, (param & 0xFF00) >> 8);
    BufferBoxMonNickname(battleSystem->msgFormat, bufferIndex, &mon->box);
}

static void BattleMessage_BufferMove(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferMoveName(battleSystem->msgFormat, bufferIndex, param);
}

static void BattleMessage_BufferItem(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferItemName(battleSystem->msgFormat, bufferIndex, param);
}

static void BattleMessage_BufferNumber(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferIntegerAsString(battleSystem->msgFormat, bufferIndex, param, 5, PRINTING_MODE_LEFT_ALIGN, TRUE);
}

static void BattleMessage_BufferNumbers(BattleSystem *battleSystem, int bufferIndex, int param, int numDigits) {
    if (numDigits) {
        BufferIntegerAsString(battleSystem->msgFormat, bufferIndex, param, numDigits, PRINTING_MODE_RIGHT_ALIGN, TRUE);
    } else {
        BufferIntegerAsString(battleSystem->msgFormat, bufferIndex, param, 5, PRINTING_MODE_RIGHT_ALIGN, TRUE);
    }
}

static void BattleMessage_BufferType(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferTypeName(battleSystem->msgFormat, bufferIndex, param);
}

static void BattleMessage_BufferAbility(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferAbilityName(battleSystem->msgFormat, bufferIndex, param);
}

static void BattleMessage_BufferStat(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferStatName(battleSystem->msgFormat, bufferIndex, param);
}

static void BattleMessage_BufferStatus(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferStatusName(battleSystem->msgFormat, bufferIndex, param);
}

static void BattleMessage_BufferPokemon(BattleSystem *battleSystem, int bufferIndex, int param) {
    Pokemon *mon = BattleSystem_GetPartyMon(battleSystem, param & 0xFF, (param & 0xFF00) >> 8);
    BufferBoxMonSpeciesName(battleSystem->msgFormat, bufferIndex, &mon->box);
}

static void BattleMessage_BufferPoffin(BattleSystem *battleSystem, int bufferIndex, int param) {
    // poffins don't exist in HGSS
}

static void BattleMessage_BufferFlavorPreference(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferFlavorDislikeText(battleSystem->msgFormat, bufferIndex, param);
}

static void BattleMessage_BufferTrainerClass(BattleSystem *battleSystem, int bufferIndex, int param) {
    Trainer *trainer = BattleSystem_GetTrainer(battleSystem, param);
    BufferTrainerClassNameFromDataStruct(battleSystem->msgFormat, bufferIndex, trainer);
}

static void BattleMessage_BufferTrainerName(BattleSystem *battleSystem, int bufferIndex, int param) {
    Trainer *trainer = BattleSystem_GetTrainer(battleSystem, param);
    BufferTrainerNameFromDataStruct(battleSystem->msgFormat, bufferIndex, trainer);
}

static void BattleMessage_BufferBoxName(BattleSystem *battleSystem, int bufferIndex, int param) {
    BufferPCBoxName(battleSystem->msgFormat, bufferIndex, battleSystem->storage, param);
}

static void BattleMessage_ExpandPlaceholders(BattleSystem *battleSystem, MsgData *data, BattleMessage *msg) {
    String *str = NewString_ReadMsgData(data, msg->id);
    StringExpandPlaceholders(battleSystem->msgFormat, battleSystem->msgBuffer, str);
    String_Delete(str);
}

static BOOL BattleSystem_TextPrinterCallback(struct TextPrinterTemplate *template, u16 glyphId) {
    BOOL ret = FALSE;

    switch (glyphId) {
    case 1:
        ret = GF_IsAnySEPlaying();
        break;
    case 2:
        ret = IsFanfarePlaying();
        break;
    case 3:
        PlayFanfare(SEQ_ME_POKEGET);
        break;
    case 4:
        PlaySE(SEQ_SE_DP_KON);
        break;
    case 5:
        PlayFanfare(SEQ_ME_LVUP);
        break;
    default:
        break;
    }

    return ret;
}
