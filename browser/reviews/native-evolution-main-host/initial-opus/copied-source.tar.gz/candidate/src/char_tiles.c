#include "char_tiles.h"

#include "global.h"

#include "constants/pokemon.h"
#include "constants/species.h"

#include "pokepic.h"

static void CharTiles_CopyRows(const u8 *src, u8 *dest, int *pSrcOffset, int *pDestOffset, u32 destBlockSize, u32 srcBlockSize);
static void CharTiles_LoadUnpacked(NarcId narcId, s32 fileId, enum HeapID heapID, NNSG2dCharacterData **pCharData);
static void CharTiles_CopyRect(int x, int y, int width, int height, NNSG2dCharacterData *pCharData, void *dest);
static BOOL SpeciesHasSpindaSpots(int species);
static void CharTiles_LoadMonRect(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height, void *dest, u32 pid, BOOL isAnimated, int whichFacing, int species);
static void *CharTiles_AllocAndLoadMonRect(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height, u32 pid, BOOL isAnimated, int whichFacing, int species);
static void CharTiles_CopyBlock(int srcWidth, int srcHeight, int x, int y, int width, int height, int *pDstOffset, const void *src, void *dest);
static void CharTiles_CopyBlockFromRect(int srcWidth, int srcHeight, const TileRect *template, int *pDstOffset, const void *src, void *dest);
static void CharTiles_LoadObjBlocksFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height, void *dest);

static void CharTiles_CopyRows(const u8 *src, u8 *dest, int *pSrcOffset, int *pDestOffset, u32 destBlockSize, u32 srcBlockSize) {
    for (int i = 0; i < 8; ++i) {
        memcpy(dest + *pDestOffset, src + *pSrcOffset, destBlockSize);
        *pSrcOffset += srcBlockSize;
        *pDestOffset += destBlockSize;
    }
}

static void CharTiles_LoadUnpacked(NarcId narcId, s32 fileId, enum HeapID heapID, NNSG2dCharacterData **pCharData) {
    BOOL result;
    void *pRaw = AllocAndReadWholeNarcMemberByIdPair(narcId, fileId, heapID);
    GF_ASSERT(pRaw != NULL);
    result = NNS_G2dGetUnpackedCharacterData(pRaw, pCharData);
    GF_ASSERT(pCharData != NULL);
    GF_ASSERT(result);
    Heap_Free(pRaw);
}

static void CharTiles_CopyRect(int x, int y, int width, int height, NNSG2dCharacterData *pCharData, void *dest) {
    int srcOffset;
    int dstOffset;
    const u8 *srcu8;
    u8 *dstu8;
    int srcBlockSize;

    GF_ASSERT(pCharData->W >= x + width);
    GF_ASSERT(pCharData->H >= y + height);

    srcu8 = pCharData->pRawData;
    dstu8 = dest;
    srcBlockSize = pCharData->W * 4;
    srcOffset = 4 * x + y * srcBlockSize;
    dstOffset = 0;

    for (int i = y; i < y + height; ++i) {
        for (int j = x; j < x + width; ++j) {
            srcOffset = j * 4 + i * srcBlockSize * 8;
            CharTiles_CopyRows(srcu8, dstu8, &srcOffset, &dstOffset, 4, srcBlockSize);
        }
    }
}

static BOOL SpeciesHasSpindaSpots(int species) {
    // This function is held together with scotch tape and rubber bands.
    int horribleArray[2] = {
        SPECIES_SPINDA,
        SPECIES_BAD_EGG,
    };
    for (int i = 0; i < SPECIES_BAD_EGG; ++i) {
        int test = horribleArray[i];
        if (test == SPECIES_BAD_EGG) {
            break;
        }
        if (test == species) {
            return TRUE;
        }
    }
    return FALSE;
}

static void CharTiles_LoadMonRect(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height, void *dest, u32 pid, BOOL isAnimated, int whichFacing, int species) {
    NNSG2dCharacterData *ppCharData = NULL;
    CharTiles_LoadUnpacked(narcId, fileId, heapID, &ppCharData);
    UnscanPokepic(ppCharData->pRawData, narcId);
    BOOL isSpinda = SpeciesHasSpindaSpots(species);
    if (whichFacing == MON_PIC_FACING_FRONT && isSpinda == TRUE) {
        RawChardata_PlaceSpindaSpots(ppCharData->pRawData, pid, isAnimated);
    }
    CharTiles_CopyRect(x, y, width, height, ppCharData, dest);
}

static void *CharTiles_AllocAndLoadMonRect(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height, u32 pid, BOOL isAnimated, int whichFacing, int species) {
    void *ret = Heap_Alloc(heapID, width * height * 32);
    CharTiles_LoadMonRect(narcId, fileId, heapID, x, y, width, height, ret, pid, isAnimated, whichFacing, species);
    return ret;
}

void CharTiles_LoadRectFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height, void *dest) {
    NNSG2dCharacterData *ppCharData = NULL;
    int srcOffset;
    int dstOffset;
    void *pNcgrFile = AllocAndReadWholeNarcMemberByIdPair(narcId, fileId, heapID);
    u8 *srcu8;
    u8 *dstu8;
    int srcWidth;

    GF_ASSERT(pNcgrFile != NULL);
    GF_ASSERT(NNS_G2dGetUnpackedCharacterData(pNcgrFile, &ppCharData));
    GF_ASSERT(ppCharData->W >= x + width);
    GF_ASSERT(ppCharData->H >= y + height);

    srcu8 = ppCharData->pRawData;
    UnscanPokepic(srcu8, narcId);
    dstu8 = dest;
    srcWidth = ppCharData->W * 4;
    srcOffset = x * 4 + y * srcWidth;
    dstOffset = 0;

    for (int i = y; i < y + height; ++i) {
        for (int j = x; j < x + width; ++j) {
            srcOffset = j * 4 + i * srcWidth * 8;
            CharTiles_CopyRows(srcu8, dstu8, &srcOffset, &dstOffset, 4, srcWidth);
        }
    }
    Heap_Free(pNcgrFile);
}

void *CharTiles_AllocAndLoadRectFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height) {
    void *ret = Heap_Alloc(heapID, width * height * 32);
    CharTiles_LoadRectFromNarc(narcId, fileId, heapID, x, y, width, height, ret);
    return ret;
}

static void CharTiles_CopyBlock(int srcWidth, int srcHeight, int x, int y, int width, int height, int *pDstOffset, const void *src, void *dest) {
    int j, i;
    const u8 *srcu8;
    u8 *dstu8;
    int srcOffset;
    int xmax;
    int ymax;

    srcu8 = src;
    dstu8 = dest;
    xmax = x + width;
    ymax = y + height;
    for (i = y; i < ymax; ++i) {
        for (j = x; j < xmax; ++j) {
            srcOffset = 32 * j + 32 * i * srcWidth;
            memcpy(dstu8 + *pDstOffset, srcu8 + srcOffset, 32);
            *pDstOffset += 32;
        }
    }
}

static void CharTiles_CopyBlockFromRect(int srcWidth, int srcHeight, const TileRect *template, int *pDstOffset, const void *src, void *dest) {
    CharTiles_CopyBlock(srcWidth, srcHeight, template->x, template->y, template->w, template->h, pDstOffset, src, dest);
}

static void CharTiles_LoadObjBlocksFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height, void *dest) {
    TileRect blocks[6] = {
        { 0, 0, 8, 8 },
        { 8, 0, 2, 4 },
        { 8, 4, 2, 4 },
        { 0, 8, 4, 2 },
        { 4, 8, 4, 2 },
        { 8, 8, 2, 2 },
    };

    int dstOffset = 0;
    void *rectBuf = CharTiles_AllocAndLoadRectFromNarc(narcId, fileId, heapID, x, y, width, height);
    for (int i = 0; i < 6; ++i) {
        CharTiles_CopyBlockFromRect(width, height, &blocks[i], &dstOffset, rectBuf, dest);
    }
    Heap_Free(rectBuf);
}

void CharTiles_LoadRectAsObjFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, TileRect *rect, void *dest) {
    CharTiles_LoadObjBlocksFromNarc(narcId, fileId, heapID, rect->x, rect->y, rect->w, rect->h, dest);
}

void CharTiles_LoadPicAsObjFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, void *dest) {
    TileRect rect = { 0, 0, 10, 10 };
    CharTiles_LoadRectAsObjFromNarc(narcId, fileId, heapID, &rect, dest);
}

void *CharTiles_AllocAndLoadPicAsObjFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID) {
    void *ret = Heap_Alloc(heapID, 3200);
    CharTiles_LoadPicAsObjFromNarc(narcId, fileId, heapID, ret);
    return ret;
}

void *AllocAndLoadPltt16FromNarc(NarcId narcId, s32 fileId, enum HeapID heapID) {
    void *ret = Heap_Alloc(heapID, 0x20);
    void *pNclrFile = AllocAndReadWholeNarcMemberByIdPair(narcId, fileId, heapID);
    NNSG2dPaletteData *pPlttData;
    GF_ASSERT(NNS_G2dGetUnpackedPaletteData(pNclrFile, &pPlttData) == TRUE);
    MI_CpuCopy16(pPlttData->pRawData, ret, 0x20);
    Heap_Free(pNclrFile);
    return ret;
}

void CharTiles_LoadMonObjBlocksFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, int x, int y, int width, int height, void *dest, u32 pid, BOOL isAnimated, int whichFacing, int species) {
    TileRect blocks[6] = {
        { 0, 0, 8, 8 },
        { 8, 0, 2, 4 },
        { 8, 4, 2, 4 },
        { 0, 8, 4, 2 },
        { 4, 8, 4, 2 },
        { 8, 8, 2, 2 },
    };

    int dstOffset = 0;
    void *rectBuf = CharTiles_AllocAndLoadMonRect(narcId, fileId, heapID, x, y, width, height, pid, isAnimated, whichFacing, species);
    for (int i = 0; i < 6; ++i) {
        CharTiles_CopyBlockFromRect(width, height, &blocks[i], &dstOffset, rectBuf, dest);
    }
    Heap_Free(rectBuf);
}

void CharTiles_LoadMonRectAsObjFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, TileRect *rect, void *dest, u32 personality, BOOL isAnimated, int whichFacing, int species) {
    CharTiles_LoadMonObjBlocksFromNarc(narcId, fileId, heapID, rect->x, rect->y, rect->w, rect->h, dest, personality, isAnimated, whichFacing, species);
}

void CharTiles_LoadMonPicAsObjFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, void *dest, u32 personality, BOOL isAnimated, int whichFacing, int species) {
    TileRect rect = { 0, 0, 10, 10 };
    CharTiles_LoadMonRectAsObjFromNarc(narcId, fileId, heapID, &rect, dest, personality, isAnimated, whichFacing, species);
}

void *CharTiles_AllocAndLoadMonPicAsObjFromNarc(NarcId narcId, s32 fileId, enum HeapID heapID, u32 personality, BOOL isAnimated, int whichFacing, int species) {
    void *ret = Heap_Alloc(heapID, 3200);
    CharTiles_LoadMonPicAsObjFromNarc(narcId, fileId, heapID, ret, personality, isAnimated, whichFacing, species);
    return ret;
}

void CharTiles_CopyRectFromBuffer(const void *texSrc, int texDim, int x, int y, int w, int h, void *dest) {
    int srcOffset;
    int dstOffset;
    const u8 *srcu8;
    u8 *dstu8;
    int srcBlockSize;

    srcu8 = texSrc;
    dstu8 = dest;
    srcBlockSize = texDim * 4;
    srcOffset = 4 * x + y * srcBlockSize;
    dstOffset = 0;

    for (int i = y; i < y + h; ++i) {
        for (int j = x; j < x + w; ++j) {
            srcOffset = j * 4 + i * srcBlockSize * 8;
            CharTiles_CopyRows(srcu8, dstu8, &srcOffset, &dstOffset, 4, srcBlockSize);
        }
    }
}
