#include "overlay_36.h"

#include "global.h"

#include "constants/easy_chat.h"
#include "constants/mail.h"
#include "constants/species.h"

#include "msgdata/msg.naix"
#include "msgdata/msg/msg_0292.h"
#include "msgdata/msg/msg_0293.h"
#include "msgdata/msg/msg_0445.h"

#include "apricorn_tree.h"
#include "field_system.h"
#include "friend_group.h"
#include "heap.h"
#include "location_backup.h"
#include "mail.h"
#include "main.h"
#include "math_util.h"
#include "msgdata.h"
#include "options.h"
#include "overlay_manager.h"
#include "party.h"
#include "pokemon.h"
#include "pokewalker.h"
#include "safari_zone.h"
#include "sav_system_info.h"
#include "sys_flags.h"
#include "sys_vars.h"
#include "igt_counter.h"
#include "friend_group_access.h"
#include "union_room_avatar.h"
#include "frontier_field_support.h"
#include "field_comm_cmds.h"

#define HEAPID_OV36 (HEAP_ID_OV36)

extern const OverlayManagerTemplate gApplication_OakSpeech;

static BOOL ov36_App_MainMenu_SelectOption_Continue_AppInit(OverlayManager *man, int *state);
static BOOL ov36_App_MainMenu_SelectOption_Continue_AppExec(OverlayManager *man, int *state);
static BOOL ov36_App_MainMenu_SelectOption_Continue_AppExit(OverlayManager *man, int *state);
static BOOL ov36_App_InitGameState_AfterOakSpeech_AppInit(OverlayManager *man, int *state);
static BOOL ov36_App_InitGameState_AfterOakSpeech_AppExec(OverlayManager *man, int *state);
static BOOL ov36_App_InitGameState_AfterOakSpeech_AppExit(OverlayManager *man, int *state);
static BOOL ov36_TitleScreen_NewGame_AppInit(OverlayManager *man, int *state);
static BOOL ov36_TitleScreen_NewGame_AppExec(OverlayManager *man, int *state);
static BOOL ov36_TitleScreen_NewGame_AppExit(OverlayManager *man, int *state);
static void InitGameStateAfterOakSpeech_Internal(enum HeapID heapID, SaveData *saveData, BOOL set_trainer_id);
static void Continue_LoadSaveData_HandleError(enum HeapID heapID, SaveData *saveData);
static void NewGame_InitSaveData(enum HeapID heapID, SaveData *saveData);

const OverlayManagerTemplate ov36_App_MainMenu_SelectOption_NewGame = {
    .init = ov36_TitleScreen_NewGame_AppInit,
    .exec = ov36_TitleScreen_NewGame_AppExec,
    .exit = ov36_TitleScreen_NewGame_AppExit,
    .ovy_id = FS_OVERLAY_ID_NONE,
};

const OverlayManagerTemplate ov36_App_InitGameState_AfterOakSpeech = {
    .init = ov36_App_InitGameState_AfterOakSpeech_AppInit,
    .exec = ov36_App_InitGameState_AfterOakSpeech_AppExec,
    .exit = ov36_App_InitGameState_AfterOakSpeech_AppExit,
    .ovy_id = FS_OVERLAY_ID_NONE,
};

const OverlayManagerTemplate ov36_App_MainMenu_SelectOption_Continue = {
    .init = ov36_App_MainMenu_SelectOption_Continue_AppInit,
    .exec = ov36_App_MainMenu_SelectOption_Continue_AppExec,
    .exit = ov36_App_MainMenu_SelectOption_Continue_AppExit,
    .ovy_id = FS_OVERLAY_ID_NONE,
};

static const MailMessageTemplate sMailMsgTemplates[2] = {
    {
     // ADVENTURE! EXCITED!
        .msg_bank = MAILMSG_BANK_0292_GMM,
     .msg_no = msg_0292_00004,
     .ec_groups = { EC_GROUP_LIFESTYLE, EC_GROUP_FEELINGS },
     .ec_words = { EC_WORD_LIFESTYLE_ADVENTURE - EC_WORDS_LIFESTYLE_MIN, EC_WORD_FEELINGS_EXCITED - EC_WORDS_FEELINGS_MIN },
     },
    {
     // I love POKEMON!
        .msg_bank = MAILMSG_BANK_0293_GMM,
     .msg_no = msg_0293_00001,
     .ec_groups = { EC_GROUP_UNION, 0xFF },
     .ec_words = { EC_WORD_UNION_POKEMON - EC_WORDS_UNION_MIN, 0 },
     },
};

BOOL ov36_TitleScreen_NewGame_AppInit(OverlayManager *man, int *state) {
#pragma unused(man, state)
    Heap_Create(HEAP_ID_3, HEAPID_OV36, 0x20000);
    InitializeMainRNG();

    return TRUE;
}

BOOL ov36_TitleScreen_NewGame_AppExec(OverlayManager *man, int *state) {
#pragma unused(state)
    SaveData *saveData = ((struct MainOverlayArgs *)OverlayManager_GetArgs(man))->saveData;
    NewGame_InitSaveData(HEAPID_OV36, saveData);

    return TRUE;
}

BOOL ov36_TitleScreen_NewGame_AppExit(OverlayManager *man, int *state) {
#pragma unused(man, state)
    Heap_Destroy(HEAPID_OV36);
    RegisterMainOverlay(FS_OVERLAY_ID_NONE, &gApplication_OakSpeech);

    return TRUE;
}

BOOL ov36_App_InitGameState_AfterOakSpeech_AppInit(OverlayManager *man, int *state) {
#pragma unused(man, state)
    Heap_Create(HEAP_ID_3, HEAPID_OV36, 0x20000);
    InitializeMainRNG();

    return TRUE;
}

BOOL ov36_App_InitGameState_AfterOakSpeech_AppExec(OverlayManager *man, int *state) {
#pragma unused(state)
    struct MainOverlayArgs *unk_work = OverlayManager_GetArgs(man);
    SaveData *saveData = unk_work->saveData;
    InitGameStateAfterOakSpeech_Internal(HEAPID_OV36, saveData, TRUE);
    IGTCounter_Start(Save_PlayerData_GetIGTAddr(saveData));

    return TRUE;
}

BOOL ov36_App_InitGameState_AfterOakSpeech_AppExit(OverlayManager *man, int *state) {
#pragma unused(man, state)
    Heap_Destroy(HEAPID_OV36);
    RegisterMainOverlay(FS_OVERLAY_ID_NONE, &gApplication_NewGameFieldsys);

    return TRUE;
}

BOOL ov36_App_MainMenu_SelectOption_Continue_AppInit(OverlayManager *man, int *state) {
#pragma unused(man, state)
    Heap_Create(HEAP_ID_3, HEAPID_OV36, 0x20000);
    InitializeMainRNG();

    return TRUE;
}

BOOL ov36_App_MainMenu_SelectOption_Continue_AppExec(OverlayManager *man, int *state) {
    struct MainOverlayArgs *unk_work = OverlayManager_GetArgs(man);
    SaveData *saveData = unk_work->saveData;
    SysInfo *sys_info = Save_SysInfo_Get(saveData);

    Continue_LoadSaveData_HandleError(HEAPID_OV36, saveData);

    Options_SetButtonModeOnMain(saveData, 0);

    if (!Save_SysInfo_MacAddressIsMine(sys_info) || !Save_SysInfo_RTCOffsetIsMine(sys_info)) {
        SysInfoRTC_HandleContinueOnNewConsole(Save_SysInfo_RTC_Get(saveData));
        Save_BerryPotRTC_Init(Save_BerryPotRTC_Get(saveData));
        Save_SysInfo_InitFromSystem(sys_info);
        Party_ResetAllShayminToLandForm(SaveArray_Party_Get(saveData));
    }

    IGTCounter_Start(Save_PlayerData_GetIGTAddr(saveData));

    return TRUE;
}

BOOL ov36_App_MainMenu_SelectOption_Continue_AppExit(OverlayManager *man, int *state) {
#pragma unused(man, state)
    Heap_Destroy(HEAPID_OV36);
    RegisterMainOverlay(FS_OVERLAY_ID_NONE, &gApplication_ContinueFieldsys);

    return TRUE;
}

static void InitGameStateAfterOakSpeech_Internal(enum HeapID heapID, SaveData *saveData, BOOL set_trainer_id) {
#pragma unused(heapID)
    s32 i;
    MsgData *friend_names_msgdata;
    String *author_name;

    Save_SysInfo_InitFromSystem(Save_SysInfo_Get(saveData));
    Save_SysInfo_RTC_Init(Save_SysInfo_RTC_Get(saveData));
    Save_BerryPotRTC_Init(Save_BerryPotRTC_Get(saveData));
    Save_FriendGroup_SetGroupId(Save_FriendGroup_Get(saveData), 1, MTRandom());
    BattleTower_InitSeed(saveData);

    PlayerProfile *profile = Save_PlayerData_GetProfile(saveData);
    u32 rand = MTRandom();

    if (set_trainer_id) {
        PlayerProfile_SetTrainerID(profile, rand);
    }

    SafariZone *safari_zone = Save_SafariZone_Get(saveData);
    SafariZone_ResetAreaSetToDefaultSet(safari_zone->area_sets, rand);

    PlayerProfile_SetAvatar(profile, UnionRoomAvatarIdxToSprite(rand, PlayerProfile_GetTrainerGender(profile), 0));

    ApricornTrees_GrowAll(Save_FieldApricornTrees_Get(saveData));

    u32 *pokewalker_unk = Pokewalker_GetIrClock(Save_Pokewalker_Get(saveData));
    for (i = 0; i < 10; i++) {
        pokewalker_unk[i] = MTRandom();
    }

    // Put an email from your friend into your PC.
    friend_names_msgdata = NewMsgDataFromNarc(MSGDATA_LOAD_LAZY, NARC_msgdata_msg, NARC_msg_msg_0445_bin, HEAP_ID_3);
    Mailbox *mailbox = Save_Mailbox_Get(saveData);
    Pokemon *mon = AllocMonZeroed(HEAP_ID_3);

    CreateMon(mon, SPECIES_MARILL, 1, 0, FALSE, 0, OT_ID_PLAYER_ID, 0);

    Mail *mail;
    if (PlayerProfile_GetTrainerGender(profile) == PLAYER_GENDER_MALE) {
        author_name = NewString_ReadMsgData(friend_names_msgdata, msg_0445_00001);
        mail = CreateKenyaMail(mon, MAIL_AIR, MON_FEMALE, author_name, 0);
    } else {
        author_name = NewString_ReadMsgData(friend_names_msgdata, msg_0445_00000);
        mail = CreateKenyaMail(mon, MAIL_AIR, MON_MALE, author_name, 0);
    }

    MailMessage mail_message;

    for (i = 0; i < (s32)NELEMS(sMailMsgTemplates); i++) {
        MailMsg_Init_FromTemplate(&mail_message, &sMailMsgTemplates[i]);
        Mail_SetMessage(mail, &mail_message, (u8)i);
    }

    MailMsg_Init(&mail_message);
    Mail_SetMessage(mail, &mail_message, 2);
    Mailbox_CopyMailToSlotI(mailbox->msgs, FALSE, 0, mail);

    Heap_Free(mon);
    String_Delete(author_name);
    Heap_Free(mail);
    DestroyMsgData(friend_names_msgdata);
}

static void Continue_LoadSaveData_HandleError(enum HeapID heapID, SaveData *saveData) {
#pragma unused(heapID)
    if (!SaveData_TryLoadOnContinue(saveData)) {
        OS_ResetSystem(0);
    }
}

static void NewGame_InitSaveData(enum HeapID heapID, SaveData *saveData) {
#pragma unused(heapID)
    Save_InitDynamicRegion(saveData);
    Save_SetPositionToPlayerRoom(saveData);

    PlayerProfile_SetMoney(Save_PlayerData_GetProfile(saveData), 3000);

    Save_VarsFlags_SetFishingCompetitionLengthRecord(Save_VarsFlags_Get(saveData), 56150); // 3'6"

    SetFlag960(Save_VarsFlags_Get(saveData));
}
