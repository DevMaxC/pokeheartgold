#include "scrcmd_link_sync.h"

#include "global.h"

#include "assert.h"
#include "bag.h"
#include "ball_capsule_editor.h"
#include "heap.h"
#include "launch_application.h"
#include "mail.h"
#include "map_header.h"
#include "party.h"
#include "party_menu.h"
#include "player_avatar.h"
#include "player_data.h"
#include "pokemon.h"
#include "render_text.h"
#include "save_arrays.h"
#include "scrcmd.h"
#include "script.h"
#include "script_manager.h"
#include "seal_case.h"
#include "task.h"
#include "link_synchronization.h"
#include "field_overworld_transition.h"
#include "field_overworld_restore.h"
#include "seal_data.h"

FS_EXTERN_OVERLAY(OVY_57);

typedef struct BallCapsuleEditorTaskData {
    u8 filler00[4];
    BallCapsuleEditorArgs *editorArgs;
    PartyMenuArgs *partyMenu;
    SaveData *saveData;
    u32 state;
} BallCapsuleEditorTaskData;

typedef struct LinkSyncWorkParams {
    u8 unk00;
    u8 unk01;
    u8 unk02;
    u8 filler03[21];
    SaveData *saveData;
} LinkSyncWorkParams;

typedef struct LinkSyncWork {
    u8 filler00[4];
    u8 syncEnabled;
    u8 filler05[15];
} LinkSyncWork;

static const OverlayManagerTemplate sOverlayTemplate_BallCapsuleEditor = {
    .init = BallCapsuleEditor_Init,
    .exec = BallCapsuleEditor_Main,
    .exit = BallCapsuleEditor_Exit,
    .ovy_id = FS_OVERLAY_ID(OVY_57),
};

static BOOL Task_BallCapsuleEditor(TaskManager *taskManager);
static BOOL ScrNative_WaitLinkSyncWork(ScriptContext *ctx);
static void LinkSyncWork_StartSync(LinkSyncWork *a0, u8 syncState);
static BOOL LinkSyncWork_IsSynced(LinkSyncWork *a0, u8 syncState);
static LinkSyncWork *LinkSyncWork_New(void);
static LinkSyncWork *LinkSyncWork_CreateWithHeap(LinkSyncWorkParams *unused);
static void LinkSyncWork_Delete(LinkSyncWork *a0);

void CallTask_BallCapsuleEditor(TaskManager *taskManager, SaveData *saveData) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    BallCapsuleEditorTaskData *r4 = Heap_AllocAtEnd(HEAP_ID_FIELD2, sizeof(BallCapsuleEditorTaskData));
    memset(r4, 0, sizeof(BallCapsuleEditorTaskData));
    r4->saveData = saveData;
    r4->editorArgs = Heap_Alloc(HEAP_ID_FIELD2, sizeof(BallCapsuleEditorArgs));
    memset(r4->editorArgs, 0, sizeof(BallCapsuleEditorArgs));
    r4->editorArgs->options = Save_PlayerData_GetOptionsAddr(saveData);
    r4->editorArgs->saveData = saveData;
    r4->editorArgs->menuInputStatePtr = &fieldSystem->menuInputState;
    r4->partyMenu = Heap_Alloc(HEAP_ID_FIELD2, sizeof(PartyMenuArgs));
    memset(r4->partyMenu, 0, sizeof(PartyMenuArgs));
    TaskManager_Call(taskManager, Task_BallCapsuleEditor, r4);
}

static BOOL Task_BallCapsuleEditor(TaskManager *taskManager) {
    BallCapsuleEditorTaskData *r7 = TaskManager_GetEnvironment(taskManager);
    BallCapsuleEditorArgs *r6 = r7->editorArgs;
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    switch (r7->state) {
    case 0:
        CallTask_LeaveOverworld(taskManager);
        SealCase *sealCase = Save_SealCase_Get(r7->saveData);
        r6->sealCase = sealCase;
        r6->setCapsuleOnMon = 0;
        r6->menuInputStatePtr = &fieldSystem->menuInputState;
        Party *party = SaveArray_Party_Get(r7->saveData);
        r6->party = party;
        s32 partyCount = Party_GetCount(party);
        r6->partyCount = partyCount;
        s32 i;
        for (i = 0; i < partyCount; i++) {
            r6->mons[i] = Party_GetMonByIndex(r6->party, i);
        }
        for (; i < PARTY_SIZE; i++) {
            r6->mons[i] = NULL;
        }
        r7->state = 1;
        break;
    case 1:
        CallApplicationAsTask(taskManager, &sOverlayTemplate_BallCapsuleEditor, r6);
        r7->state = 2;
        break;
    case 2:
        switch (r7->editorArgs->setCapsuleOnMon) {
        default:
            GF_ASSERT(FALSE);
        case 0:
            r7->state = 5;
            break;
        case 1:
            r7->state = 3;
            break;
        }
        break;
    case 3:
        PartyMenuArgs *partyMenu = r7->partyMenu;
        partyMenu->party = r6->party;
        partyMenu->bag = Save_Bag_Get(r7->saveData);
        partyMenu->mailbox = Save_Mailbox_Get(r7->saveData);
        partyMenu->partySlot = 0;
        partyMenu->panelLayout = 0;
        partyMenu->context = PARTY_MENU_CONTEXT_ATTACH_CAPSULE;
        partyMenu->options = r6->options;
        partyMenu->fieldSystem = fieldSystem;
        partyMenu->menuInputStatePtr = &(fieldSystem->menuInputState);
        CallApplicationAsTask(taskManager, &gOverlayTemplate_PartyMenu, partyMenu);
        r7->state = 4;
        break;
    case 4: {
        PartyMenuArgs *partyMenu = r7->partyMenu;
        u32 index = r7->editorArgs->capsuleIndex + 1;
        if (partyMenu->partySlot != 7) {
            Pokemon *mon = r7->editorArgs->mons[partyMenu->partySlot];
            SetMonData(mon, MON_DATA_BALL_CAPSULE_ID, &index);
            SetMonData(mon, MON_DATA_BALL_CAPSULE, SealCase_GetCapsuleI(r6->sealCase, index - 1));
            Seal_GetNameMsgId(SealOnCapsuleGetID(CapsuleGetSealI(SealCase_GetCapsuleI(r6->sealCase, index - 1), 0)));
            Save_Block23_Get(fieldSystem->saveData);
        }
        r7->state = 1;
        break;
    }
    case 5:
        CallTask_RestoreOverworld(taskManager);
        r7->state = 6;
        break;
    case 6:
        Heap_Free(r7->partyMenu);
        Heap_Free(r7->editorArgs);
        Heap_Free(r7);
        return TRUE;
    }
    return FALSE;
}

BOOL ScrCmd_ConditionalLinkSyncStart(ScriptContext *ctx) {
    LinkSyncWork **unkStruct = FieldSysGetAttrAddr(ctx->fieldSystem, SCRIPTENV_MISC_DATA_PTR);
    LinkSyncWork_StartSync(*unkStruct, ScriptGetVar(ctx));
    return FALSE;
}

BOOL ScrCmd_ConditionalLinkSyncWait(ScriptContext *ctx) {
    void *unused = FieldSysGetAttrAddr(ctx->fieldSystem, SCRIPTENV_MISC_DATA_PTR);
    ctx->data[0] = ScriptGetVar(ctx);
    SetupNativeScript(ctx, ScrNative_WaitLinkSyncWork);
    return TRUE;
}

static BOOL ScrNative_WaitLinkSyncWork(ScriptContext *ctx) {
    LinkSyncWork **unkStruct = FieldSysGetAttrAddr(ctx->fieldSystem, SCRIPTENV_MISC_DATA_PTR);
    return LinkSyncWork_IsSynced(*unkStruct, ctx->data[0]);
}

BOOL ScrCmd_ConditionalLinkSyncCreate(ScriptContext *ctx) {
    LinkSyncWork **unkStruct = FieldSysGetAttrAddr(ctx->fieldSystem, SCRIPTENV_MISC_DATA_PTR);
    u16 arg1 = ScriptGetVar(ctx);
    u16 arg2 = ScriptGetVar(ctx);
    u16 arg3 = ScriptGetVar(ctx);
    u16 unused = ScriptGetVar(ctx);
    LinkSyncWorkParams unusedStruct;
    unusedStruct.unk00 = arg2;
    unusedStruct.unk01 = arg1;
    unusedStruct.unk02 = arg3;
    unusedStruct.saveData = ctx->fieldSystem->saveData;
    *unkStruct = LinkSyncWork_CreateWithHeap(&unusedStruct);
    return FALSE;
}

BOOL ScrCmd_ConditionalLinkSyncDestroy(ScriptContext *ctx) {
    LinkSyncWork **unkStruct = FieldSysGetAttrAddr(ctx->fieldSystem, SCRIPTENV_MISC_DATA_PTR);
    u16 unused = ScriptGetVar(ctx);
    u32 unused2 = MapHeader_GetMapSec(ctx->fieldSystem->location->mapId);
    LinkSyncWork_Delete(*unkStruct);
    return FALSE;
}

BOOL ScrCmd_SetVarZero(ScriptContext *ctx) {
    void **unused = FieldSysGetAttrAddr(ctx->fieldSystem, SCRIPTENV_MISC_DATA_PTR);
    u16 *result = ScriptGetVarPointer(ctx);
    *result = 0;
    return FALSE;
}

BOOL ScrCmd_BeginTextAutoScroll(ScriptContext *ctx) {
    void **unused = FieldSysGetAttrAddr(ctx->fieldSystem, SCRIPTENV_MISC_DATA_PTR);
    TextFlags_BeginAutoScroll(TRUE);
    return FALSE;
}

static void LinkSyncWork_StartSync(LinkSyncWork *a0, u8 syncState) {
    if (a0->syncEnabled != 0) {
        LinkSync_StartSync(syncState);
    }
}

static BOOL LinkSyncWork_IsSynced(LinkSyncWork *a0, u8 syncState) {
    if (a0->syncEnabled == 0) {
        return TRUE;
    }
    return LinkSync_IsSynced(syncState) == TRUE;
}

static LinkSyncWork *LinkSyncWork_New(void) {
    LinkSyncWork *unkStruct = Heap_Alloc(HEAP_ID_20, sizeof(LinkSyncWork));
    MI_CpuFill8(unkStruct, 0, sizeof(LinkSyncWork));
    return unkStruct;
}

static LinkSyncWork *LinkSyncWork_CreateWithHeap(LinkSyncWorkParams *unused) {
    Heap_Create(HEAP_ID_FIELD2, HEAP_ID_20, 0x4000);
    return LinkSyncWork_New();
}

static void LinkSyncWork_Delete(LinkSyncWork *a0) {
    Heap_Free(a0);
    Heap_Destroy(HEAP_ID_20);
}
