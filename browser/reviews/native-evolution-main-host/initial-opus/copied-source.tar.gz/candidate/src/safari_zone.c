#include "safari_zone.h"

#include <nitro/mi/memory.h>
#include <nitro/os/ownerInfo.h>

#include "global.h"

#include "gf_rtc.h"
#include "string_util.h"

static const u8 sSafariZoneDefaultAreaSets[10][SAFARI_ZONE_MAX_AREAS_PER_SET] = {
    { SAFARI_ZONE_AREA_PLAINS,    SAFARI_ZONE_AREA_SWAMP,     SAFARI_ZONE_AREA_MEADOW,    SAFARI_ZONE_AREA_WETLAND,   SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_FOREST    },
    { SAFARI_ZONE_AREA_MEADOW,    SAFARI_ZONE_AREA_MARSHLAND, SAFARI_ZONE_AREA_WETLAND,   SAFARI_ZONE_AREA_FOREST,    SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_SWAMP     },
    { SAFARI_ZONE_AREA_WETLAND,   SAFARI_ZONE_AREA_WASTELAND, SAFARI_ZONE_AREA_FOREST,    SAFARI_ZONE_AREA_SWAMP,     SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_MARSHLAND },
    { SAFARI_ZONE_AREA_FOREST,    SAFARI_ZONE_AREA_MOUNTAIN,  SAFARI_ZONE_AREA_SWAMP,     SAFARI_ZONE_AREA_MARSHLAND, SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_WASTELAND },
    { SAFARI_ZONE_AREA_SWAMP,     SAFARI_ZONE_AREA_SAVANNAH,  SAFARI_ZONE_AREA_MARSHLAND, SAFARI_ZONE_AREA_WASTELAND, SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_MOUNTAIN  },
    { SAFARI_ZONE_AREA_MARSHLAND, SAFARI_ZONE_AREA_PLAINS,    SAFARI_ZONE_AREA_WASTELAND, SAFARI_ZONE_AREA_MOUNTAIN,  SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_SAVANNAH  },
    { SAFARI_ZONE_AREA_WASTELAND, SAFARI_ZONE_AREA_MEADOW,    SAFARI_ZONE_AREA_MOUNTAIN,  SAFARI_ZONE_AREA_SAVANNAH,  SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_PLAINS    },
    { SAFARI_ZONE_AREA_MOUNTAIN,  SAFARI_ZONE_AREA_WETLAND,   SAFARI_ZONE_AREA_SAVANNAH,  SAFARI_ZONE_AREA_PLAINS,    SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_MEADOW    },
    { SAFARI_ZONE_AREA_SAVANNAH,  SAFARI_ZONE_AREA_FOREST,    SAFARI_ZONE_AREA_PLAINS,    SAFARI_ZONE_AREA_MEADOW,    SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_WETLAND   },
    { SAFARI_ZONE_AREA_PLAINS,    SAFARI_ZONE_AREA_SAVANNAH,  SAFARI_ZONE_AREA_WETLAND,   SAFARI_ZONE_AREA_SWAMP,     SAFARI_ZONE_AREA_PEAK, SAFARI_ZONE_AREA_WASTELAND },
};

u32 Save_SafariZone_sizeof(void) {
    return sizeof(SafariZone);
}

SafariZone *Save_SafariZone_Get(SaveData *saveData) {
    return SaveArray_Get(saveData, SAVE_SAFARI_ZONE);
}

void Save_SafariZone_Init(SafariZone *safari_zone) {
    for (s32 i = 0; i < SAFARI_ZONE_MAX_AREA_SETS; i++) {
        MI_CpuClear8(&safari_zone->area_sets[i], sizeof(SafariZoneAreaSet));
    }

    SafariZone_ClearLeader(&safari_zone->link_leader);
}

void SafariZone_ResetAreaSetToDefaultSet(SafariZoneAreaSet *area_set, u32 default_set_no) {
    u32 default_set_no_mod = default_set_no % NELEMS(sSafariZoneDefaultAreaSets);
    for (s32 i = 0; i < SAFARI_ZONE_MAX_AREAS_PER_SET; i++) {
        SafariZone_InitArea(&area_set->areas[i], sSafariZoneDefaultAreaSets[default_set_no_mod][i]);
    }

    MI_CpuClear8(area_set->areaLevels, sizeof(area_set->areaLevels));
}

void SafariZone_SetActiveAreaSet(SafariZone *safari_zone, s32 areaSetNo) {
    if (areaSetNo >= SAFARI_ZONE_MAX_AREA_SETS) {
        GF_ASSERT(FALSE);
        areaSetNo = 0;
    }

    safari_zone->activeAreaSet = areaSetNo;
}

u8 SafariZone_GetActiveAreaSet(SafariZone *safari_zone) {
    return safari_zone->activeAreaSet;
}

SafariZoneAreaSet *SafariZone_GetAreaSet(SafariZone *safari_zone, s32 area_set_no) {
    if (area_set_no == 3) {
        area_set_no = safari_zone->activeAreaSet;
    }

    if (area_set_no >= SAFARI_ZONE_MAX_AREA_SETS) {
        GF_ASSERT(FALSE);
        area_set_no = 0;
    }

    return &safari_zone->area_sets[area_set_no];
}

void SafariZone_CopyAreaSet(SafariZone *safari_zone, s32 area_set_no, SafariZoneAreaSet *area_set_dest) {
    if (area_set_no >= SAFARI_ZONE_MAX_AREA_SETS) {
        GF_ASSERT(FALSE);
        SafariZone_InitAreaSet(area_set_dest);
        return;
    }

    MI_CpuCopy8(&safari_zone->area_sets[area_set_no], area_set_dest, sizeof(SafariZoneAreaSet));
}

void SafariZone_SetAreaSet(SafariZone *safari_zone, s32 area_set_no, SafariZoneAreaSet *area_set_src) {
    if (area_set_no >= SAFARI_ZONE_MAX_AREA_SETS) {
        GF_ASSERT(FALSE);
        return;
    }

    MI_CpuCopy8(area_set_src, &safari_zone->area_sets[area_set_no], sizeof(SafariZoneAreaSet));
}

void SafariZone_SetLevel(SafariZone *safari_zone, u8 level) {
    safari_zone->level = level;
}

u8 SafariZone_GetLevel(SafariZone *safari_zone) {
    return safari_zone->level;
}

void SafariZone_AddToAllAreaLevels(SafariZone *safariZone, s32 amount) {
    u8 doneAreas[6];
    u32 area_no;
    int j;
    int i;

    if (amount <= 0) {
        return;
    }

    j = 0;
    MI_CpuClear8(doneAreas, NELEMS(doneAreas));
    for (i = 0; i < SAFARI_ZONE_MAX_AREAS_PER_SET; i++) {
        area_no = safariZone->area_sets[0].areas[i].area_no;
        if (SafariZone_IsAreaInList(area_no, doneAreas, j)) {
            continue;
        }

        if (safariZone->area_sets[0].areaLevels[area_no] + amount < 0xFF) {
            safariZone->area_sets[0].areaLevels[area_no] += amount;
        } else {
            safariZone->area_sets[0].areaLevels[area_no] = 0xFF;
        }

        doneAreas[j++] = area_no;
    }
}

u8 SafariZone_GetObjectUnlockLevel(SafariZone *safari_zone) {
    return safari_zone->objectUnlockLevel;
}

u8 SafariZone_IncObjectUnlockLevel(SafariZone *safari_zone, s32 amount) {
    SafariZone_SetObjectUnlockLevel(safari_zone, (u8)(safari_zone->objectUnlockLevel + amount));
    return safari_zone->objectUnlockLevel;
}

void SafariZone_SetObjectUnlockLevel(SafariZone *safari_zone, u8 level) {
    if (level > 4) {
        safari_zone->objectUnlockLevel = 4;
    } else {
        safari_zone->objectUnlockLevel = level;
    }
}

void SafariZone_SetUnlockTime(SafariZone *safari_zone, IGT *igt) {
    safari_zone->unlockTime = (igt->hours * 60) + igt->minutes;
}

u32 SafariZone_CheckUnlockWaitPassed(SafariZone *safari_zone, IGT *igt, s32 hours) {
    u16 minutes = (igt->hours * 60) + igt->minutes;
    s32 delta = minutes - safari_zone->unlockTime;

    if (delta >= hours * 60) {
        return 1;
    }

    if (minutes >= 59999) {
        return 2;
    }

    return 0;
}

void SafariZone_SetLinkLeaderFromProfile(SafariZone *safari_zone, PlayerProfile *profile, enum HeapID heapID) {
    SAFARIZONE_LINKLEADER *link_leader = &safari_zone->link_leader;
    link_leader->id = PlayerProfile_GetTrainerID(profile);
    link_leader->gender = PlayerProfile_GetTrainerGender(profile);
    link_leader->language = PlayerProfile_GetLanguage(profile);
    link_leader->version = PlayerProfile_GetVersion(profile);

    String *name = String_New((PLAYER_NAME_LENGTH + 1) * sizeof(u16), heapID);
    PlayerName_FlatToString(profile, name);
    CopyStringToU16Array(name, link_leader->name, (PLAYER_NAME_LENGTH + 1) * sizeof(u16));
    String_Delete(name);

    link_leader->linked = TRUE;

    link_leader->received_timestamp = GF_RTC_DateTimeToSec();
    link_leader->rtc_offset = OS_GetOwnerRtcOffset();
}

void SafariZone_GetLinkLeaderToProfile(SafariZone *safari_zone, PlayerProfile *profile) {
    SAFARIZONE_LINKLEADER *link_leader = &safari_zone->link_leader;
    PlayerProfile_SetTrainerID(profile, link_leader->id);
    PlayerProfile_SetTrainerGender(profile, link_leader->gender);
    PlayerProfile_SetLanguage(profile, link_leader->language);
    PlayerProfile_SetVersion(profile, link_leader->version);
    Save_Profile_PlayerName_Set(profile, link_leader->name);
}

u8 SafariZone_GetLinkLeaderGender(SafariZone *safari_zone) {
    return safari_zone->link_leader.gender;
}

u8 SafariZone_IsCurrentlyLinked(SafariZone *safari_zone) {
    return safari_zone->link_leader.linked;
}

void SafariZone_DeactivateLinkIfExpired(SafariZone *safari_zone) {
    SAFARIZONE_LINKLEADER *link_leader = &safari_zone->link_leader;
    if (!link_leader->linked) {
        return;
    }

    if ((24 * 60 * 60) < GF_RTC_DateTimeToSec() - link_leader->received_timestamp) {
        // It has been 24 hours since the player received the Safari Zone.
        link_leader->linked = FALSE;
        return;
    }

    if (link_leader->rtc_offset != OS_GetOwnerRtcOffset()) {
        // The player changed their system's time since receiving the Safari Zone.
        link_leader->linked = FALSE;
    }
}

void SafariZone_SwapAreasInSet(SafariZoneAreaSet *area_set, u32 first, u32 second) {
    SAFARIZONE_AREA tmp = area_set->areas[first];
    area_set->areas[first] = area_set->areas[second];
    area_set->areas[second] = tmp;
}

void SafariZone_InitAreaInSet(SafariZoneAreaSet *area_set, s32 area_idx, u32 area_no) {
    SafariZone_InitArea(&area_set->areas[area_idx], area_no);
}

void SafariZone_AddObjectToArea(SafariZoneAreaSet *area_set, s32 area_idx, const SAFARIZONE_OBJECT *object) {
    if (area_idx >= SAFARI_ZONE_MAX_AREAS_PER_SET) {
        GF_ASSERT(FALSE);
        return;
    }

    SAFARIZONE_AREA *area = &area_set->areas[area_idx];
    if (area->active_object_count >= SAFARI_ZONE_MAX_OBJECTS) {
        GF_ASSERT(FALSE);
        return;
    }

    area->objects[area->active_object_count++] = *object;
}

void SafariZone_RemoveObjectFromArea(SafariZoneAreaSet *area_set, s32 area_idx, s32 object_idx) {
    if (area_idx >= SAFARI_ZONE_MAX_AREAS_PER_SET) {
        GF_ASSERT(FALSE);
        return;
    }

    SAFARIZONE_AREA *area = &area_set->areas[area_idx];
    if ((u32)object_idx >= area->active_object_count) {
        GF_ASSERT(FALSE);
        return;
    }

    if (object_idx == --area->active_object_count) {
        SafariZone_ClearObject(&area->objects[object_idx]);
    } else {
        for (; object_idx < area->active_object_count; object_idx++) {
            area->objects[object_idx] = area->objects[object_idx + 1];
        }

        SafariZone_ClearObject(&area->objects[area->active_object_count]);
    }
}

void SafariZone_InitAreaSet(SafariZoneAreaSet *area_set) {
    for (s32 i = 0; i < SAFARI_ZONE_MAX_AREAS_PER_SET; i++) {
        SafariZone_InitArea(&area_set->areas[i], i);
    }
}

void SafariZone_InitArea(SAFARIZONE_AREA *area, u8 area_no) {
    MI_CpuClear8(area, sizeof(SAFARIZONE_AREA));
    area->area_no = area_no;
}

void SafariZone_ClearObject(SAFARIZONE_OBJECT *object) {
    MI_CpuClear8(object, sizeof(SAFARIZONE_OBJECT));
}

void SafariZone_ClearLeader(SAFARIZONE_LINKLEADER *link_leader) {
    MI_CpuClear8(link_leader, sizeof(SAFARIZONE_LINKLEADER));

    link_leader->id = 0;
    link_leader->gender = 0;
    link_leader->language = gGameLanguage;
    link_leader->version = gGameVersion;
    StringFillEOS(link_leader->name, PLAYER_NAME_LENGTH + 1);
}

BOOL SafariZone_IsAreaInList(u8 value, u8 *array, u8 count) {
    for (s32 i = 0; i < count; i++) {
        if (value == array[i]) {
            return TRUE;
        }
    }

    return FALSE;
}
