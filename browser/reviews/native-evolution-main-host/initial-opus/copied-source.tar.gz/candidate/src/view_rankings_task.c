#include "view_rankings_task.h"

#include "field_system.h"
#include "heap.h"
#include "launch_application.h"
#include "screen_fade.h"
#include "task.h"

static BOOL Task_ViewRankingsApp(TaskManager *taskManager);

void FieldSystem_LaunchTask_ViewRankingsApp(FieldSystem *fieldSystem, u8 pageScrollParam, u8 cursorPos) {
    ViewRankingsTaskData *taskData = Heap_AllocAtEnd(HEAP_ID_FIELD2, sizeof(ViewRankingsTaskData));
    taskData->state = 0;
    taskData->args = Heap_AllocAtEnd(HEAP_ID_FIELD2, sizeof(ViewRankingsArgs));
    taskData->args->saveData = FieldSystem_GetSaveData(fieldSystem);
    taskData->args->page_scroll = pageScrollParam;
    taskData->args->cursorPos = cursorPos;
    TaskManager_Call(fieldSystem->taskman, Task_ViewRankingsApp, taskData);
}

static BOOL Task_ViewRankingsApp(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    ViewRankingsTaskData *taskData = TaskManager_GetEnvironment(taskManager);

    switch (taskData->state) {
    case 0:
        BeginNormalPaletteFade(FADE_BOTH_SCREENS, FADE_TYPE_BRIGHTNESS_OUT, FADE_TYPE_BRIGHTNESS_OUT, RGB_BLACK, 6, 1, HEAP_ID_FIELD1);
        taskData->state++;

        break;
    case 1:
        if (!IsPaletteFadeFinished()) {
            break;
        }

        LaunchApp_ViewRankings(fieldSystem, taskData->args);
        FieldSystem_ResumeProcesses();
        taskData->state++;
        break;
    case 2:
        if (FieldSystem_ApplicationIsRunning(fieldSystem)) {
            break;
        }

        taskData->state++;
        FieldSystem_LoadFieldOverlay(fieldSystem);
        break;
    case 3:
        if (FieldSystem_IsOverworldRestored(fieldSystem)) {
            BeginNormalPaletteFade(FADE_BOTH_SCREENS, FADE_TYPE_BRIGHTNESS_IN, FADE_TYPE_BRIGHTNESS_IN, RGB_BLACK, 6, 1, HEAP_ID_FIELD1);
            taskData->state++;
        }

        break;
    case 4:
        if (!IsPaletteFadeFinished()) {
            break;
        }

        Heap_Free(taskData->args);
        Heap_Free(taskData);
        return TRUE;
    }

    return FALSE;
}
