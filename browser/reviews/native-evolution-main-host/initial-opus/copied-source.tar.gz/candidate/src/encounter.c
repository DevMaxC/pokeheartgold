#include "encounter.h"

#include "global.h"

#include "constants/battle.h"
#include "constants/game_stats.h"
#include "constants/std_script.h"

#include "battle/battle_setup.h"
#include "field/encounter_check.h"
#include "fielddata/script/scr_seq/event_D10R0101.h"

#include "blackout.h"
#include "catching_show.h"
#include "field_system.h"
#include "field_warp_tasks.h"
#include "game_clear.h"
#include "game_stats.h"
#include "launch_application.h"
#include "link_ruleset_data.h"
#include "map_object.h"
#include "overlay_02.h"
#include "overlay_03.h"
#include "pokedex_util.h"
#include "save_arrays.h"
#include "save_local_field_data.h"
#include "sound.h"
#include "sound_system.h"
#include "sys_flags.h"
#include "battle_record.h"
#include "battle_recording.h"
#include "communication_player_state.h"
#include "battle_intro_config.h"
#include "battle_transition_task.h"
#include "field_overworld_transition.h"
#include "field_overworld_restore.h"
#include "communication_club_link.h"
#include "frontier_field_support.h"
#include "field_misc_events.h"
#include "field_environment_sound.h"
#include "gear_phone_ring_manager.h"
#include "use_item_on_mon.h"

static BOOL Task_StartBattle(TaskManager *taskManager);
static void CallTask_StartBattle(TaskManager *taskManager, BattleSetup *setup);
static Encounter *Encounter_New(BattleSetup *setup, s32 effect, s32 bgm, u32 *winFlag);
static void Encounter_Delete(Encounter *encounter);
static void Encounter_CopyResultsToSaveData(BattleSetup *setup, FieldSystem *fieldSystem);
static BOOL Task_StartEncounter(TaskManager *taskManager);
static void RecordLinkBattleResult(s32 flag, FieldSystem *fieldSystem);
static BOOL Task_LinkBattle(TaskManager *taskManager);
static BOOL Task_WifiClubBattle(TaskManager *taskManager);
static BOOL Task_TrainerHouseBattle(TaskManager *taskManager);
static BOOL Task_WildEncounter(TaskManager *taskManager);
static BOOL Task_SafariEncounter(TaskManager *taskManager);
static BOOL Task_BugContestEncounter(TaskManager *taskManager);
static BOOL Task_TutorialBattle(TaskManager *taskManager);
static u32 Encounter_GetLinkBattleMode(LinkBattleRuleset *ruleset, u32 battleType);
static void Encounter_AddBattleScore(FieldSystem *fieldSystem, BattleSetup *setup);

static BOOL Task_StartBattle(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    BattleSetup *battleSetup = TaskManager_GetEnvironment(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);

    switch (*state) {
    case 0:
        Battle_LaunchApp(fieldSystem, battleSetup);
        Field_ForceEnvironmentSoundRecheck();
        (*state)++;
        break;
    case 1:
        if (!FieldSystem_ApplicationIsRunning(fieldSystem)) {
            return TRUE;
        }
        break;
    }
    return FALSE;
}

static void CallTask_StartBattle(TaskManager *taskManager, BattleSetup *setup) {
    TaskManager_Call(taskManager, Task_StartBattle, setup);
}

static Encounter *Encounter_New(BattleSetup *setup, s32 effect, s32 bgm, u32 *winFlag) {
    Encounter *encounter = Heap_AllocAtEnd(HEAP_ID_FIELD2, sizeof(Encounter));
    encounter->winFlag = winFlag;
    if (winFlag != NULL) {
        *winFlag = BATTLE_OUTCOME_NONE;
    }
    encounter->effect = effect;
    encounter->bgm = bgm;
    encounter->setup = setup;
    return encounter;
}

static void Encounter_Delete(Encounter *encounter) {
    BattleSetup_Delete(encounter->setup);
    Heap_Free(encounter);
}

static BOOL Encounter_GetResult(Encounter *encounter, FieldSystem *fieldSystem) {
    if (encounter->winFlag != NULL) {
        *(encounter->winFlag) = encounter->setup->winFlag;
    }
    FieldSystem_VarSet(fieldSystem, VAR_BATTLE_RESULT, encounter->setup->winFlag);
    return IsBattleResultWin(encounter->setup->winFlag);
}

static void Encounter_CopyResultsToSaveData(BattleSetup *setup, FieldSystem *fieldSystem) {
    if (!(setup->battleType & BATTLE_TYPE_DEBUG)) {
        BattleSetup_CopyResultsToSaveData(setup, fieldSystem);
    }
}

static BOOL Task_StartEncounter(TaskManager *taskManager) { // todo: better name
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);

    switch (*state) {
    case 0:
        MapObjectManager_PauseAllMovement(fieldSystem->mapObjectManager);
        CallTask_BattleTransition(taskManager, encounter->effect, encounter->bgm);
        (*state)++;
        break;
    case 1:
        CallTask_LeaveOverworld(taskManager);
        (*state)++;
        break;
    case 2:
        CallTask_StartBattle(taskManager, encounter->setup);
        (*state)++;
        break;
    case 3:
        Encounter_CopyResultsToSaveData(encounter->setup, fieldSystem);
        if (encounter->setup->battleType == BATTLE_TYPE_NONE || encounter->setup->battleType == BATTLE_TYPE_ROAMER || encounter->setup->battleType == (BATTLE_TYPE_DOUBLES | BATTLE_TYPE_MULTI | BATTLE_TYPE_AI)) {
            FieldSystem_TryTriggerBillPCFullCall(fieldSystem);
            FieldSystem_TryTriggerOakDexProgressCall(fieldSystem);
        }

        fieldSystem->encounterInhibitSteps = 0;
        fieldSystem->reverseTurnFrameSteps = 0;

        if (Encounter_GetResult(encounter, fieldSystem) == FALSE) {
            if (encounter->setup->battleType & BATTLE_TYPE_11) {
                HealParty(SaveArray_Party_Get(fieldSystem->saveData));
            } else {
                Encounter_Delete(encounter);
                return TRUE;
            }
        }

        if (Save_VarsFlags_CheckHaveFollower(Save_VarsFlags_Get(fieldSystem->saveData))) {
            HealParty(SaveArray_Party_Get(fieldSystem->saveData));
        }

        Encounter_AddBattleScore(fieldSystem, encounter->setup);
        CallTask_RestoreOverworld(taskManager);
        (*state)++;
        break;
    case 4:
        MapObjectManager_UnpauseAllMovement(fieldSystem->mapObjectManager);
        CallTask_FadeFromBlack(taskManager);
        (*state)++;
        break;
    case 5:
        Encounter_Delete(encounter);
        return TRUE;
    }

    return FALSE;
}

static void CallTask_StartEncounter(TaskManager *taskManager, BattleSetup *setup, s32 effect, s32 bgm, u32 *winFlag) {
    Encounter *encounter = Encounter_New(setup, effect, bgm, winFlag);
    TaskManager_Call(taskManager, Task_StartEncounter, encounter);
}

static void RecordLinkBattleResult(s32 flag, FieldSystem *fieldSystem) {
    switch (flag & 0xF) {
    case 1:
    case 6:
        CommPlayerInfo_RecordBattleResult(fieldSystem->saveData, 1);
        break;
    case 2:
    case 5:
        CommPlayerInfo_RecordBattleResult(fieldSystem->saveData, -1);
        break;
    }
}

static BOOL Task_LinkBattle(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);

    switch (*state) {
    case 0:
        CallTask_BattleTransition(taskManager, encounter->effect, encounter->bgm);
        (*state)++;
        break;
    case 1:
        CallTask_LeaveOverworld(taskManager);
        (*state)++;
        break;
    case 2:
        CallTask_StartBattle(taskManager, encounter->setup);
        (*state)++;
        break;
    case 3:
        RecordLinkBattleResult(encounter->setup->winFlag, fieldSystem);
        BattleSetup_CopyPokedexToSaveData(encounter->setup, fieldSystem);
        GameStats_AddScore(Save_GameStats_Get(fieldSystem->saveData), SCORE_EVENT_LINK_BATTLE);
        Encounter_GetResult(encounter, fieldSystem);
        CallTask_RestoreOverworld(taskManager);
        (*state)++;
        break;
    case 4:
        Encounter_Delete(encounter);
        return TRUE;
        break;
    }
    return FALSE;
}

static BOOL Task_WifiClubBattle(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);

    switch (*state) {
    case 0:
        Sound_SetScene(SOUND_SCENE_NONE);
        Sound_SetSceneAndPlayBGM(5, encounter->bgm, 1);
        CallTask_StartBattle(taskManager, encounter->setup);
        (*state)++;
        break;
    case 1:
        RecordLinkBattleResult(encounter->setup->winFlag, fieldSystem);
        BattleSetup_CopyPokedexToSaveData(encounter->setup, fieldSystem);
        GameStats_AddScore(Save_GameStats_Get(fieldSystem->saveData), SCORE_EVENT_LINK_BATTLE);
        Encounter_GetResult(encounter, fieldSystem);
        (*state)++;
        break;
    case 2:
        Encounter_Delete(encounter);
        BattleRecord_Delete();
        return TRUE;
    }
    return FALSE;
}

static BOOL Task_TrainerHouseBattle(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);

    switch (*state) {
    case 0:
        CallTask_BattleTransition(taskManager, encounter->effect, encounter->bgm);
        (*state)++;
        break;
    case 1:
        CallTask_LeaveOverworld(taskManager);
        (*state)++;
        break;
    case 2:
        CallTask_StartBattle(taskManager, encounter->setup);
        (*state)++;
        break;
    case 3:
        BattleSetup_CopyPokedexToSaveData(encounter->setup, fieldSystem);
        if (fieldSystem->frontierFsys != NULL) {
            FrontierFieldSystem_AddBattleTotals(fieldSystem, &encounter->setup->battleTotals);
        }
        Encounter_GetResult(encounter, fieldSystem);
        CallTask_RestoreOverworld(taskManager);
        (*state)++;
        break;
    case 4:
        CallTask_FadeFromBlack(taskManager);
        (*state)++;
        break;
    case 5:
        Encounter_Delete(encounter);
        return TRUE;
    }
    return FALSE;
}

void CallTask_TrainerHouseBattle(TaskManager *taskManager, BattleSetup *battleSetup, s32 effect, s32 bgm, u32 *winFlag) {
    Encounter *encounter = Encounter_New(battleSetup, effect, bgm, winFlag);
    TaskManager_Call(taskManager, Task_TrainerHouseBattle, encounter);
}

static WildEncounter *WildEncounter_New(BattleSetup *setup, s32 effect, s32 bgm, u32 *winFlag) {
    WildEncounter *encounter = Heap_AllocAtEnd(HEAP_ID_FIELD2, sizeof(WildEncounter));
    encounter->winFlag = winFlag;
    if (winFlag != NULL) {
        *winFlag = BATTLE_OUTCOME_NONE;
    }
    encounter->effect = effect;
    encounter->bgm = bgm;
    encounter->setup = setup;
    encounter->state = 0;
    return encounter;
}

static void WildEncounter_Delete(WildEncounter *encounter) {
    BattleSetup_Delete(encounter->setup);
    Heap_Free(encounter);
}

void FieldSystem_StartWildEncounter(FieldSystem *fieldSystem, BattleSetup *setup) {
    SaveVarsFlags *flags = Save_VarsFlags_Get(fieldSystem->saveData);
    s32 effect = BattleSetup_GetWildTransitionEffect(setup);
    s32 bgm = BattleSetup_GetWildBattleMusic(setup);

    if (Save_VarsFlags_CheckSafariSysFlag(flags)) {
        Encounter *encounter = Encounter_New(setup, effect, bgm, NULL);
        FieldSystem_CreateTask(fieldSystem, Task_SafariEncounter, encounter);
    } else if (Save_VarsFlags_CheckBugContestFlag(flags)) {
        Encounter *encounter = Encounter_New(setup, effect, bgm, NULL);
        FieldSystem_CreateTask(fieldSystem, Task_BugContestEncounter, encounter);
    } else {
        WildEncounter *encounter = WildEncounter_New(setup, effect, bgm, NULL);
        FieldSystem_CreateTask(fieldSystem, Task_WildEncounter, encounter);
    }
}

void FieldSystem_StartForcedWildBattle(FieldSystem *fieldSystem, TaskManager *taskManager, BattleSetup *setup) {
    SaveVarsFlags *flags = Save_VarsFlags_Get(fieldSystem->saveData);
    s32 effect = BattleSetup_GetWildTransitionEffect(setup);
    s32 bgm = BattleSetup_GetWildBattleMusic(setup);

    if (Save_VarsFlags_CheckSafariSysFlag(flags)) {
        Encounter *encounter = Encounter_New(setup, effect, bgm, NULL);
        TaskManager_Jump(taskManager, Task_SafariEncounter, encounter);
    } else if (Save_VarsFlags_CheckBugContestFlag(flags)) {
        Encounter *encounter = Encounter_New(setup, effect, bgm, NULL);
        TaskManager_Jump(taskManager, Task_BugContestEncounter, encounter);
    } else {
        WildEncounter *encounter = WildEncounter_New(setup, effect, bgm, NULL);
        TaskManager_Jump(taskManager, Task_WildEncounter, encounter);
    }
}

static BOOL Task_WildEncounter(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    WildEncounter *encounter = TaskManager_GetEnvironment(taskManager);

    switch (encounter->state) {
    case 0:
        MapObjectManager_PauseAllMovement(fieldSystem->mapObjectManager);
        GameStats_Inc(Save_GameStats_Get(fieldSystem->saveData), GAME_STAT_WILD_ENCOUNTERS);
        CallTask_BattleTransition(taskManager, encounter->effect, encounter->bgm);
        encounter->state++;
        break;
    case 1:
        CallTask_LeaveOverworld(taskManager);
        encounter->state++;
        break;
    case 2:
        CallTask_StartBattle(taskManager, encounter->setup);
        encounter->state++;
        break;
    case 3:
        Encounter_CopyResultsToSaveData(encounter->setup, fieldSystem);
        FieldSystem_TryTriggerBillPCFullCall(fieldSystem);
        FieldSystem_TryTriggerOakDexProgressCall(fieldSystem);

        if (IsBattleResultWin(encounter->setup->winFlag) == FALSE) {
            WildEncounter_Delete(encounter);
            TaskManager_Jump(taskManager, Task_Blackout, NULL);
            return FALSE;
        }

        if (Save_VarsFlags_CheckHaveFollower(Save_VarsFlags_Get(fieldSystem->saveData))) {
            HealParty(SaveArray_Party_Get(fieldSystem->saveData));
        }

        Encounter_AddBattleScore(fieldSystem, encounter->setup);
        CallTask_RestoreOverworld(taskManager);

        encounter->state++;
        break;
    case 4:
        ov02_BattleExit_HandleRoamerAction(fieldSystem, encounter->setup);
        CallTask_FadeFromBlack(taskManager);
        encounter->state++;
        break;
    case 5:
        MapObjectManager_UnpauseAllMovement(fieldSystem->mapObjectManager);
        WildEncounter_Delete(encounter);
        return TRUE;
    }
    return FALSE;
}

static BOOL Task_SafariEncounter(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);
    u16 *safariBalls = LocalFieldData_GetSafariBallsCounter(Save_LocalFieldData_Get(fieldSystem->saveData));

    switch (*state) {
    case 0:
        MapObjectManager_PauseAllMovement(fieldSystem->mapObjectManager);
        GameStats_Inc(Save_GameStats_Get(fieldSystem->saveData), GAME_STAT_WILD_ENCOUNTERS);
        CallTask_BattleTransition(taskManager, encounter->effect, encounter->bgm);
        (*state)++;
        break;
    case 1:
        CallTask_LeaveOverworld(taskManager);
        (*state)++;
        break;
    case 2:
        CallTask_StartBattle(taskManager, encounter->setup);
        (*state)++;
        break;
    case 3:
        Encounter_CopyResultsToSaveData(encounter->setup, fieldSystem);
        if (encounter->setup->winFlag == BATTLE_OUTCOME_MON_CAUGHT) {
            Save_Block23_Get(fieldSystem->saveData); // Save_SafariZone_Get?
            Party_GetMonByIndex(encounter->setup->party[BATTLER_ENEMY], 0);
            FieldSystem_TryTriggerBillPCFullCall(fieldSystem);
            FieldSystem_TryTriggerOakDexProgressCall(fieldSystem);
        }

        Encounter_AddBattleScore(fieldSystem, encounter->setup);

        if (*safariBalls == 0 && encounter->setup->winFlag != BATTLE_OUTCOME_MON_CAUGHT) {
            Location *location = LocalFieldData_GetDynamicWarp(Save_LocalFieldData_Get(fieldSystem->saveData));
            CallTask_ChangeMap(taskManager, location);
        } else {
            *state = 5;
            return FALSE;
        }

        (*state)++;
        break;
    case 4:
        QueueScript(taskManager, std_safari_enter, NULL, NULL);
        (*state)++;
        break;
    case 5:
        CallTask_RestoreOverworld(taskManager);
        (*state)++;
        break;
    case 6:
        MapObjectManager_UnpauseAllMovement(fieldSystem->mapObjectManager);
        CallTask_FadeFromBlack(taskManager);
        (*state)++;
        break;
    case 7:
        if (*safariBalls == 0) {
            if (encounter->setup->winFlag == BATTLE_OUTCOME_MON_CAUGHT) {
                QueueScript(taskManager, std_safari_balls_out, NULL, NULL);
            }
        } else {
            PCStorage *pc = SaveArray_PCStorage_Get(fieldSystem->saveData);
            Party *party = SaveArray_Party_Get(fieldSystem->saveData);
            if (PCStorage_FindFirstBoxWithEmptySlot(pc) == NUM_BOXES && Party_GetCount(party) == PARTY_SIZE) {
                QueueScript(taskManager, std_safari_storage_out, NULL, NULL);
            }
        }
        (*state)++;
        break;
    case 8:
        Encounter_Delete(encounter);
        return TRUE;
    }
    return FALSE;
}

static BOOL Task_BugContestEncounter(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    BugContest *contest = FieldSystem_BugContest_Get(fieldSystem);
    u32 *state = TaskManager_GetStatePtr(taskManager);
    u16 *sportBall = BugContest_GetSportBallsAddr(contest);

    switch (*state) {
    case 0:
        MapObjectManager_PauseAllMovement(fieldSystem->mapObjectManager);
        GameStats_Inc(Save_GameStats_Get(fieldSystem->saveData), GAME_STAT_WILD_ENCOUNTERS);
        CallTask_BattleTransition(taskManager, encounter->effect, encounter->bgm);
        (*state)++;
        break;
    case 1:
        CallTask_LeaveOverworld(taskManager);
        (*state)++;
        break;
    case 2:
        CallTask_StartBattle(taskManager, encounter->setup);
        (*state)++;
        break;
    case 3:
        Encounter_CopyResultsToSaveData(encounter->setup, fieldSystem);
        if (!IsBattleResultWin(encounter->setup->winFlag)) {
            Encounter_Delete(encounter);
            TaskManager_Jump(taskManager, Task_BugContestWarpToJudging, NULL);
            return FALSE;
        }

        Encounter_AddBattleScore(fieldSystem, encounter->setup);

        if (encounter->setup->winFlag == BATTLE_OUTCOME_MON_CAUGHT) {
            BugContest_PromptSwapPokemon(taskManager, encounter->setup->bugContestMon);
            FieldSystem_TryTriggerBillPCFullCall(fieldSystem);
            FieldSystem_TryTriggerOakDexProgressCall(fieldSystem);
        }
        (*state)++;
        break;
    case 4:
        if (*sportBall == 0 && encounter->setup->winFlag != BATTLE_OUTCOME_MON_CAUGHT) {
            BugContest_WarpToJudging(taskManager, fieldSystem);
        }
        (*state)++;
        break;
    case 5:
        CallTask_RestoreOverworld(taskManager);
        (*state)++;
        break;
    case 6:
        MapObjectManager_UnpauseAllMovement(fieldSystem->mapObjectManager);
        CallTask_FadeFromBlack(taskManager);
        (*state)++;
        break;
    case 7:
        Encounter_Delete(encounter);
        if (*sportBall == 0 && encounter->setup->winFlag == BATTLE_OUTCOME_MON_CAUGHT) {
            StartScriptFromMenu(taskManager, std_bug_contest_balls_up, NULL);
            return FALSE;
        }
        return TRUE;
    }
    return FALSE;
}

void SetupAndStartWildBattle(TaskManager *taskManager, u16 species, u8 level, u32 *winFlag, BOOL canFlee, BOOL shiny) {
    BattleSetup *setup;
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    setup = BattleSetup_New(HEAP_ID_FIELD2, BATTLE_TYPE_NONE);
    BattleSetup_InitFromFieldSystem(setup, fieldSystem);
    FieldSystem_GenerateSingleWildPokemon(fieldSystem, species, level, shiny, setup);

    if (canFlee) {
        setup->battleSpecial |= 8;
    }

    GameStats_Inc(Save_GameStats_Get(fieldSystem->saveData), GAME_STAT_WILD_ENCOUNTERS);

    CallTask_StartEncounter(taskManager, setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), winFlag);
}

void SetupAndStartFatefulWildBattle(TaskManager *taskManager, u16 species, u8 level, u32 *winFlag, BOOL canRun) {
    BattleSetup *setup;
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    setup = BattleSetup_New(HEAP_ID_FIELD2, 0);
    BattleSetup_InitFromFieldSystem(setup, fieldSystem);
    FieldSystem_GenerateSingleWildPokemon(fieldSystem, species, level, FALSE, setup);

    u32 var = 1;

    SetMonData(Party_GetMonByIndex(setup->party[BATTLER_ENEMY], 0), MON_DATA_FATEFUL_ENCOUNTER, &var);

    if (canRun) {
        setup->battleSpecial |= 8;
    }

    GameStats_Inc(Save_GameStats_Get(fieldSystem->saveData), GAME_STAT_WILD_ENCOUNTERS);

    CallTask_StartEncounter(taskManager, setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), winFlag);
}

static BOOL Task_PalParkEncounter(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);

    switch (*state) {
    case 0:
        MapObjectManager_PauseAllMovement(fieldSystem->mapObjectManager);
        GameStats_Inc(Save_GameStats_Get(fieldSystem->saveData), GAME_STAT_WILD_ENCOUNTERS);
        CallTask_BattleTransition(taskManager, encounter->effect, encounter->bgm);
        (*state)++;
        break;
    case 1:
        CallTask_LeaveOverworld(taskManager);
        (*state)++;
        break;
    case 2:
        CallTask_StartBattle(taskManager, encounter->setup);
        (*state)++;
        break;
    case 3:
        Encounter_CopyResultsToSaveData(encounter->setup, fieldSystem);
        FieldSystem_UpdateCatchingShowResult(fieldSystem, encounter->setup);
        Encounter_AddBattleScore(fieldSystem, encounter->setup);
        (*state)++;
        break;
    case 4:
        CallTask_RestoreOverworld(taskManager);
        (*state)++;
        break;
    case 5:
        MapObjectManager_UnpauseAllMovement(fieldSystem->mapObjectManager);
        CallTask_FadeFromBlack(taskManager);
        (*state)++;
        break;
    case 6:
        Encounter_Delete(encounter);
        if (FieldSystem_GetParkBallCount(fieldSystem) == 0) {
            // Ding-dong!
            // Congratulations!
            // $PLAYER has successfully
            // caught the stocked Pokémon!
            StartScriptFromMenu(taskManager, _EV_scr_seq_D10R0101_002 + 1, NULL); //??? - what is script 3?
            return FALSE;
        }
        return TRUE;
    }
    return FALSE;
}

void FieldSystem_StartPalParkEncounter(FieldSystem *fieldSystem, BattleSetup *setup) {
    Encounter *encounter = Encounter_New(setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), NULL);
    FieldSystem_CreateTask(fieldSystem, Task_PalParkEncounter, encounter);
}

void SetupAndStartFirstBattle(TaskManager *taskManager, u16 species, u8 level) { // leftover from DP, still used to setup a battle where items are not usable and the player cannot run
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    BattleSetup *setup = BattleSetup_New(HEAP_ID_FIELD2, BATTLE_TYPE_NONE);
    BattleSetup_InitFromFieldSystem(setup, fieldSystem);

    FieldSystem_GenerateSingleWildPokemon(fieldSystem, species, level, FALSE, setup);

    setup->battleSpecial = BATTLE_SPECIAL_FIRST_RIVAL;

    GameStats_Inc(Save_GameStats_Get(fieldSystem->saveData), GAME_STAT_WILD_ENCOUNTERS);

    CallTask_StartEncounter(taskManager, setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), NULL);
}

static BOOL Task_TutorialBattle(TaskManager *taskManager) {
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);

    switch (*state) {
    case 0:
        MapObjectManager_PauseAllMovement(fieldSystem->mapObjectManager);
        CallTask_BattleTransition(taskManager, encounter->effect, encounter->bgm);
        (*state)++;
        break;
    case 1:
        CallTask_LeaveOverworld(taskManager);
        (*state)++;
        break;
    case 2:
        CallTask_StartBattle(taskManager, encounter->setup);
        (*state)++;
        break;
    case 3:
        (*state)++;
        break;
    case 4:
        CallTask_RestoreOverworld(taskManager);
        (*state)++;
        break;
    case 5:
        MapObjectManager_UnpauseAllMovement(fieldSystem->mapObjectManager);
        CallTask_FadeFromBlack(taskManager);
        (*state)++;
        break;
    case 6:
        Encounter_Delete(encounter);
        return TRUE;
    }
    return FALSE;
}

void SetupAndStartTutorialBattle(TaskManager *taskManager) {
    Encounter *encounter;
    BattleSetup *setup;
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);

    setup = BattleSetup_New_Tutorial(HEAP_ID_FIELD2, fieldSystem);
    encounter = Encounter_New(setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), NULL);

    TaskManager_Call(taskManager, Task_TutorialBattle, encounter);
}

void SetupAndStartTrainerBattle(TaskManager *taskManager, u32 opponentTrainer1, u32 opponentTrainer2, u32 followerTrainerNum, u32 a4, u32 a5, enum HeapID heapID, u32 *winFlag) {
    u32 battleType;
    BattleSetup *setup;
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);

    if (opponentTrainer2 != 0 && opponentTrainer1 != opponentTrainer2) {
        if (followerTrainerNum == 0) {
            battleType = (BATTLE_TYPE_TRAINER | BATTLE_TYPE_DOUBLES | BATTLE_TYPE_TAG);
        } else {
            battleType = (BATTLE_TYPE_TRAINER | BATTLE_TYPE_DOUBLES | BATTLE_TYPE_MULTI | BATTLE_TYPE_AI);
        }
    } else if (opponentTrainer1 == opponentTrainer2) {
        battleType = (BATTLE_TYPE_TRAINER | BATTLE_TYPE_DOUBLES);
    } else {
        battleType = BATTLE_TYPE_TRAINER;
        if (a4) {
            battleType |= BATTLE_TYPE_11;
        }
    }

    setup = BattleSetup_New(HEAP_ID_FIELD2, battleType);
    BattleSetup_InitFromFieldSystem(setup, fieldSystem);

    setup->trainerId[BATTLER_ENEMY] = opponentTrainer1;
    setup->trainerId[BATTLER_ENEMY2] = opponentTrainer2;
    setup->trainerId[BATTLER_PLAYER2] = followerTrainerNum;

    EnemyTrainerSet_Init(setup, fieldSystem->saveData, heapID);

    GameStats_Inc(Save_GameStats_Get(fieldSystem->saveData), GAME_STAT_TRAINER_BATTLES);

    if (a5) {
        if (battleType & BATTLE_TYPE_MULTI) {
            setup->followMonSlot[2] = 0;
        } else if (!(battleType & BATTLE_TYPE_DOUBLES)) {
            setup->followMonSlot[1] = 0;
        }
    }

    CallTask_StartEncounter(taskManager, setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), winFlag);
}

void CallTask_LinkBattle(TaskManager *taskManager, void *partySlots, u32 battleType) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter;
    BattleSetup *setup;

    setup = BattleSetup_New(HEAP_ID_FIELD2, battleType);

    BattleSetup_InitForLinkBattle(setup, fieldSystem, partySlots);

    encounter = Encounter_New(setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), NULL);
    TaskManager_Call(taskManager, Task_LinkBattle, encounter);
}

static u32 Encounter_GetLinkBattleMode(LinkBattleRuleset *ruleset, u32 battleType) {
    int var = LinkBattleRuleset_GetRegulationIndex(ruleset);
    u32 mode;

    if (battleType & BATTLE_TYPE_MULTI) {
        mode = 14;
    } else if (battleType & BATTLE_TYPE_DOUBLES) {
        mode = 7;
    } else {
        mode = 0;
    }

    if (var != 255) {
        mode += 1 + BattleRegulation_GetLinkModeOffset(var);
    }
    return mode;
}

void CallTask_WifiClubBattle(TaskManager *taskManager, s32 target, s32 maxLevel, u32 flag) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter;
    BattleSetup *setup;
    u32 result;
    u32 mode;

    if (flag == 0) {
        setup = BattleSetup_New(HEAP_ID_FIELD2, BATTLE_TYPE_LINK | BATTLE_TYPE_TRAINER);
        mode = 0;
    } else if (flag == 1) {
        setup = BattleSetup_New(HEAP_ID_FIELD2, BATTLE_TYPE_LINK | BATTLE_TYPE_DOUBLES | BATTLE_TYPE_TRAINER);
        mode = 7;
    } else {
        setup = BattleSetup_New(HEAP_ID_FIELD2, BATTLE_TYPE_FRONTIER | BATTLE_TYPE_MULTI | BATTLE_TYPE_LINK | BATTLE_TYPE_DOUBLES | BATTLE_TYPE_TRAINER);

        // these don't seem right
        setup->trainerId[BATTLER_ENEMY] = TRAINER_RIVAL_SILVER;
        setup->trainerId[BATTLER_ENEMY2] = TRAINER_RIVAL_SILVER_2;

        EnemyTrainerSet_Init(setup, fieldSystem->saveData, HEAP_ID_FIELD2);
        mode = 14;
    }

    BattleSetup_InitForFixedLevelFacility(setup, fieldSystem, maxLevel);

    BattleRecord_Create(fieldSystem->saveData, HEAP_ID_FIELD2, &result);

    setup->linkBattleMode = mode;

    encounter = Encounter_New(setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), NULL);
    encounter->unkC = target;

    TaskManager_Call(taskManager, Task_WifiClubBattle, encounter);
}

static BOOL Task_CommClubLinkBattle(TaskManager *taskManager) {
    FieldSystem *fieldSystem = TaskManager_GetFieldSystem(taskManager);
    Encounter *encounter = TaskManager_GetEnvironment(taskManager);
    u32 *state = TaskManager_GetStatePtr(taskManager);

    switch (*state) {
    case 0:
        TaskManager_Call(taskManager, Task_LinkBattle, encounter);
        (*state)++;
        break;
    case 1:
        if (BattleRecord_Exists() == TRUE) {
            BattleRecord_Delete();
        }
        CommClubLink_StartCardExchange(fieldSystem);
        return TRUE;
    }
    return FALSE;
}

void FieldSystem_StartCommClubLinkBattle(FieldSystem *fieldSystem, void *partySlots, s32 battleType) {
    Encounter *encounter;
    BattleSetup *setup = BattleSetup_New(HEAP_ID_FIELD2, battleType);
    u32 var;

    BattleSetup_InitForLinkBattle(setup, fieldSystem, partySlots);
    BattleRecord_Create(fieldSystem->saveData, HEAP_ID_FIELD2, &var);

    setup->linkBattleMode = Encounter_GetLinkBattleMode(fieldSystem->linkBattleRuleset, battleType);

    encounter = Encounter_New(setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), NULL);

    FieldSystem_CreateTask(fieldSystem, Task_CommClubLinkBattle, encounter);
}

void FieldSystem_StartCommClubLinkBattleWithParty(FieldSystem *fieldSystem, Party *party, s32 battleType) {
    Encounter *encounter;
    BattleSetup *setup = BattleSetup_New(HEAP_ID_FIELD2, battleType);
    u32 var;

    BattleSetup_InitForLinkBattleWithParty(setup, fieldSystem, party, NULL);
    BattleRecord_Create(fieldSystem->saveData, HEAP_ID_FIELD2, &var);

    setup->linkBattleMode = Encounter_GetLinkBattleMode(fieldSystem->linkBattleRuleset, battleType);

    encounter = Encounter_New(setup, BattleSetup_GetWildTransitionEffect(setup), BattleSetup_GetWildBattleMusic(setup), NULL);

    FieldSystem_CreateTask(fieldSystem, Task_CommClubLinkBattle, encounter);
}

static void Encounter_AddBattleScore(FieldSystem *fieldSystem, BattleSetup *setup) {
    Pokemon *mon;
    u32 battleType = setup->battleType;
    u32 winFlag = setup->winFlag;

    if (battleType & BATTLE_TYPE_LINK || battleType & BATTLE_TYPE_FRONTIER) {
        return;
    }

    if (battleType == BATTLE_TYPE_NONE || battleType == BATTLE_TYPE_ROAMER || battleType == (BATTLE_TYPE_DOUBLES | BATTLE_TYPE_MULTI | BATTLE_TYPE_AI)) {
        if (winFlag == BATTLE_OUTCOME_WIN) {
            GameStats_AddScore(Save_GameStats_Get(fieldSystem->saveData), SCORE_EVENT_WILD_MON_DEFEATED);
        } else if (winFlag == BATTLE_OUTCOME_MON_CAUGHT) {
            mon = Party_GetMonByIndex(setup->party[BATTLER_ENEMY], 0);
            if (Pokedex_ConvertToCurrentDexNo(FALSE, GetMonData(mon, MON_DATA_SPECIES, NULL)) != 0) {
                GameStats_AddScore(Save_GameStats_Get(fieldSystem->saveData), SCORE_EVENT_MON_CAUGHT_REGIONAL);
            } else {
                GameStats_AddScore(Save_GameStats_Get(fieldSystem->saveData), SCORE_EVENT_MON_CAUGHT_NATIONAL);
            }
        }
    } else if ((battleType & BATTLE_TYPE_TRAINER) || (battleType & BATTLE_TYPE_TAG)) {
        if (winFlag == BATTLE_OUTCOME_WIN) {
            GameStats_AddScore(Save_GameStats_Get(fieldSystem->saveData), SCORE_EVENT_TRAINER_DEFEATED);
        }
    } else if ((battleType & BATTLE_TYPE_SAFARI || battleType & BATTLE_TYPE_PAL_PARK) && winFlag == BATTLE_OUTCOME_MON_CAUGHT) {
        mon = Party_GetMonByIndex(setup->party[BATTLER_ENEMY], 0);
        if (Pokedex_ConvertToCurrentDexNo(FALSE, GetMonData(mon, MON_DATA_SPECIES, NULL)) != 0) {
            GameStats_AddScore(Save_GameStats_Get(fieldSystem->saveData), SCORE_EVENT_MON_CAUGHT_REGIONAL);
        } else {
            GameStats_AddScore(Save_GameStats_Get(fieldSystem->saveData), SCORE_EVENT_MON_CAUGHT_NATIONAL);
        }
    }
}
