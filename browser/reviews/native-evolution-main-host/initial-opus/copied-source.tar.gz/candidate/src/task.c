#include "task.h"

#include "field_system.h"

static TaskManager *Task_New(FieldSystem *fieldSystem, TaskFunc taskFunc, void *env) {
    TaskManager *taskman;

    taskman = Heap_AllocAtEnd((enum HeapID)32, sizeof(TaskManager));
    taskman->prev = NULL;
    taskman->func = taskFunc;
    taskman->state = 0;
    taskman->env = env;
    taskman->unk10 = 0;
    taskman->unk14 = NULL;
    taskman->fieldSystem = fieldSystem;
    taskman->bgGoTo = Heap_AllocAtEnd((enum HeapID)32, sizeof(TaskManagerBgGoTo));
    return taskman;
}

TaskManager *FieldSystem_CreateTask(FieldSystem *fieldSystem, TaskFunc taskFunc, void *env) {
    TaskManager *ret;
    GF_ASSERT(fieldSystem->taskman == NULL);
    ret = Task_New(fieldSystem, taskFunc, env);
    fieldSystem->taskman = ret;
    return ret;
}

void TaskManager_Jump(TaskManager *taskman, TaskFunc taskFunc, void *env) {
    taskman->func = taskFunc;
    taskman->state = 0;
    taskman->env = env;
    if (taskman->unk14 != NULL || taskman->unk14 != NULL) {
        Heap_Free(taskman->unk14);
        taskman->unk10 = 0;
        taskman->unk14 = NULL;
    }
}

// Synchronously executes a new task, returning to the current task `taskman`
// once finished.
void TaskManager_Call(TaskManager *taskman, TaskFunc taskFunc, void *env) {
    TaskManager *newman;

    newman = Task_New(taskman->fieldSystem, taskFunc, env);
    newman->prev = taskman;
    taskman->fieldSystem->taskman = newman;
}

BOOL FieldSystem_RunTaskFrame(FieldSystem *fieldSystem) {
    TaskManager *prevTask;

    if (fieldSystem->taskman == 0) {
        return FALSE;
    }
    while (fieldSystem->taskman->func(fieldSystem->taskman) == TRUE) {
        prevTask = fieldSystem->taskman->prev;
        if (fieldSystem->taskman->unk14 != NULL) {
            Heap_Free(fieldSystem->taskman->unk14);
        }
        Heap_Free(fieldSystem->taskman->bgGoTo);
        Heap_Free(fieldSystem->taskman);
        fieldSystem->taskman = prevTask;
        if (prevTask == NULL) {
            return TRUE;
        }
    }
    return FALSE;
}

BOOL FieldSystem_TaskIsRunning(FieldSystem *fieldSystem) {
    return fieldSystem->taskman != NULL;
}

BOOL FieldSystem_ApplicationIsRunning(FieldSystem *fieldSystem) {
    return FieldSystem_IsFieldMapLoaded(fieldSystem) || FieldSystem_IsChildAppRunning(fieldSystem);
}

void FieldSystem_LoadFieldOverlay(FieldSystem *fieldSystem) {
    FieldSystem_LoadFieldOverlayInternal(fieldSystem);
}

BOOL FieldSystem_IsOverworldRestored(FieldSystem *fieldSystem) {
    return FieldSystem_IsFieldMapRunning(fieldSystem) != FALSE;
}

static BOOL Task_RunApplicationUntilComplete(TaskManager *taskManager) {
    FieldSystem *fieldSystem;
    struct ApplicationTaskEnv *env;

    fieldSystem = TaskManager_GetFieldSystem(taskManager);
    env = TaskManager_GetEnvironment(taskManager);

    switch (env->state) {
    case 0:
        FieldSystem_LaunchApplication(fieldSystem, env->template, env->work);
        env->state++;
        break;
    case 1:
        if (!FieldSystem_ApplicationIsRunning(fieldSystem)) {
            Heap_Free(env);
            return TRUE;
        }
        break;
    }
    return FALSE;
}

void CallApplicationAsTask(TaskManager *taskManager, const OverlayManagerTemplate *template, void *work) {
    struct ApplicationTaskEnv *env;

    env = Heap_AllocAtEnd((enum HeapID)32, sizeof(struct ApplicationTaskEnv));
    env->state = 0;
    env->template = template;
    env->work = work;
    TaskManager_Call(taskManager, Task_RunApplicationUntilComplete, env);
}

FieldSystem *TaskManager_GetFieldSystem(TaskManager *taskManager) {
    return taskManager->fieldSystem;
}

void *TaskManager_GetEnvironment(TaskManager *taskManager) {
    return taskManager->env;
}

u32 *TaskManager_GetStatePtr(TaskManager *taskManager) {
    return &taskManager->state;
}

u32 TaskManager_GetBgGoToId(TaskManager *taskManager) {
    return taskManager->bgGoTo->bgGoToId;
}
