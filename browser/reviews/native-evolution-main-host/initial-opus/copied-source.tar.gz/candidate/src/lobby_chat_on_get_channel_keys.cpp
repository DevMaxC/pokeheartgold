#pragma force_active on
#include <nitro/types.h>

// The code below is compiled as ARM (32-bit) code.
#include <nitro/code32.h>

union String {
    struct L {
        u32 flag : 1;
        u32 capacity : 31;
        u32 size;
        char *data;
    } l;

    struct S {
        u8 flag : 1;
        u8 size : 7;
        char data[11];
    } s;

    u32 w[3];

    const char *c_str() const {
        return !l.flag ? s.data : l.data;
    }
};

extern "C" void LobbyString_InitFromCStr(String *s, const char *t);
extern "C" void LobbyString_Destroy(String *s);
struct Handler;

struct HandlerVtbl {
    void *f0, *f4, *f8;
    u32 (*getArg)(Handler *h);
};

struct Base {
    HandlerVtbl *vtbl;
    u32 id;
    u32 unk8;
};

struct Handler {
    virtual void f0();
    virtual void f4();
    virtual void f8();
    virtual u32 getArg();
    u32 id;
    u32 unk8;
    void (*callback)(BOOL ok, const char *str, int x, u32 a, u32 b, u32 extra);
};

extern "C" HandlerVtbl gLobbyRequestVtable;

struct Node {
    Node *l, *r, *p;
    Handler *value;
};

struct It {
    Node *n;

    It() {
    }

    It(Node *q)
        : n(q) {
    }
};

struct Map {
    u32 size;
    Node header;
};

struct Manager {
    u8 pad[0x4];
    u32 state;
    u8 pad2[0x88];
    Map map;
};

extern "C" Manager *gLobbyChatManager;
extern "C" It LobbyRequestMap_Find(Map *map, Base *const &key);
extern "C" void LobbyRequestMap_DeleteKey(Map *map, u32 id);
extern "C" int LobbyChat_FindUserIdByNick(Manager *m, String *s);
extern "C" void LobbyChat_StripChannelPrefix(String *dst, Manager *m, String *s);

inline void KeyInit(Base *k, u32 id) {
    k->vtbl = &gLobbyRequestVtable;
    k->id = id;
    k->unk8 = 0;
}

inline Handler *Lookup(Manager *m, const It &it) {
    return it.n == &m->map.header ? 0 : it.n->value;
}

inline Handler *Find(Manager *m, u32 id) {
    Base key;
    KeyInit(&key, id);
    Base *kp = &key;
    return Lookup(m, LobbyRequestMap_Find(&m->map, kp));
}

inline It FindIt(Manager *m, u32 id) {
    Base key;
    KeyInit(&key, id);
    Base *kp = &key;
    return LobbyRequestMap_Find(&m->map, kp);
}

extern "C" void LobbyChat_OnGetChannelKeys(void *self, int result, const char *name, const char *other, int n, u32 *pa, u32 *pb, u32 id);
#pragma push
#pragma opt_propagation off

extern "C" void LobbyChat_OnGetChannelKeys(void *self, int result, const char *name, const char *other, int n, u32 *pa, u32 *pb, u32 id) {
    if (gLobbyChatManager != NULL && gLobbyChatManager->state == 5) {
        return;
    }
    if (name == NULL) {
        return;
    }
    int x;
    if (other == NULL) {
        x = -1;
    } else {
        String s;
        LobbyString_InitFromCStr(&s, other);
        x = LobbyChat_FindUserIdByNick(gLobbyChatManager, &s);
        LobbyString_Destroy(&s);
    }
    int sid = id;
    u32 a, b;
    Handler *h;
    Manager *m = gLobbyChatManager;
    It it = FindIt(m, sid);
    if (it.n == &m->map.header) {
        h = 0;
    } else {
        Node *nd = it.n;
        h = nd->value;
    }
    a = 0;
    b = a;
    if (result == 1 && n > 0) {
        a = *pa;
        b = *pb;
    }
    String t;
    LobbyString_InitFromCStr(&t, name);
    String k;
    LobbyChat_StripChannelPrefix(&k, gLobbyChatManager, &t);
    const char *str = k.c_str();
    void (*cb)(BOOL, const char *, int, u32, u32, u32) = h->callback;
    cb(result == 1, str, x, a, b, h->getArg());
    LobbyString_Destroy(&k);
    LobbyString_Destroy(&t);
    LobbyRequestMap_DeleteKey(&gLobbyChatManager->map, sid);
}

#pragma pop
