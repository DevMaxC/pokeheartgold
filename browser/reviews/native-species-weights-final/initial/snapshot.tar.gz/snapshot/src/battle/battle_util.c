#include "battle/battle_util.h"

#include "global.h"

#include "constants/abilities.h"
#include "constants/battle.h"
#include "constants/battle_menu.h"
#include "constants/battle_subscript.h"
#include "constants/game_stats.h"
#include "constants/items.h"
#include "constants/message_tags.h"
#include "constants/move_effects.h"
#include "constants/moves.h"
#include "constants/species.h"
#include "constants/trainers.h"

#include "battle/battle.h"
#include "battle/battle_controller.h"
#include "battle/battle_controller_opponent.h"
#include "battle/battle_system.h"
#include "msgdata/msg/msg_0197.h"

#include "dex_mon_measures.h"
#include "filesystem.h"
#include "item.h"
#include "party.h"
#include "pokemon.h"
#include "comm_state.h"
#include "ui_util.h"

static const u8 sStatChangeTable[][2];

static BOOL CheckFlyingImmunity(BattleContext *ctx, int item, int index);
static void ApplyEffectivenessFlags(int effectiveness, u32 *moveStatusFlag);
static int GetMoveStatusChangeScript(BattleContext *ctx, int statChangeType, u32 flag);
static int ApplyTypeMultiplier(BattleContext *ctx, int battlerId, int typeEffectiveness, int damage, int moveDamage, u32 *flag);
static int CheckChargeMoveHitTurn(BattleContext *ctx, int moveNo);
static u8 Battler_GetType(BattleContext *ctx, int battlerId, int var);
static void TrainerAIData_ClearMoves(BattleContext *ctx, u8 battlerId);
static void TrainerAIData_ClearAbility(BattleContext *ctx, u8 battlerId);
static void TrainerAIData_ClearHeldItem(BattleContext *ctx, u8 battlerId);
static int ChooseTraceTarget(BattleSystem *battleSystem, BattleContext *ctx, int battlerIdTarget1, int battlerIdTarget2);
static BOOL IsFixedDamageMove(BattleContext *ctx, int moveNo);
static int GetDynamicMoveType(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, int moveNo);

void BattleSystem_GetBattleMon(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, u8 selectedMon) {
    Pokemon *mon = BattleSystem_GetPartyMon(battleSystem, battlerId, selectedMon);
    int i;
    int side;
    struct PokedexData *dexData;

    ctx->battleMons[battlerId].species = GetMonData(mon, MON_DATA_SPECIES, NULL);
    ctx->battleMons[battlerId].atk = GetMonData(mon, MON_DATA_ATK, NULL);
    ctx->battleMons[battlerId].def = GetMonData(mon, MON_DATA_DEF, NULL);
    ctx->battleMons[battlerId].speed = GetMonData(mon, MON_DATA_SPEED, NULL);
    ctx->battleMons[battlerId].spAtk = GetMonData(mon, MON_DATA_SP_ATK, NULL);
    ctx->battleMons[battlerId].spDef = GetMonData(mon, MON_DATA_SP_DEF, NULL);

    for (i = 0; i < 4; i++) {
        ctx->battleMons[battlerId].moves[i] = GetMonData(mon, MON_DATA_MOVE1 + i, NULL);
        ctx->battleMons[battlerId].movePPCur[i] = GetMonData(mon, MON_DATA_MOVE1_PP + i, NULL);
        ctx->battleMons[battlerId].movePP[i] = GetMonData(mon, MON_DATA_MOVE1_PP_UPS + i, NULL);
    }

    ctx->battleMons[battlerId].hpIV = GetMonData(mon, MON_DATA_HP_IV, NULL);
    ctx->battleMons[battlerId].atkIV = GetMonData(mon, MON_DATA_ATK_IV, NULL);
    ctx->battleMons[battlerId].defIV = GetMonData(mon, MON_DATA_DEF_IV, NULL);
    ctx->battleMons[battlerId].speedIV = GetMonData(mon, MON_DATA_SPEED_IV, NULL);
    ctx->battleMons[battlerId].spAtkIV = GetMonData(mon, MON_DATA_SPATK_IV, NULL);
    ctx->battleMons[battlerId].spDefIV = GetMonData(mon, MON_DATA_SPDEF_IV, NULL);

    ctx->battleMons[battlerId].isEgg = GetMonData(mon, MON_DATA_IS_EGG, NULL);
    ctx->battleMons[battlerId].hasNickname = GetMonData(mon, MON_DATA_HAS_NICKNAME, NULL);

    if (!(ctx->battleStatus & BATTLE_STATUS_BATON_PASS)) {
        for (i = 0; i < 8; i++) {
            ctx->battleMons[battlerId].statChanges[i] = 6; // 6 is the default for stat changes
        }
    }

    ctx->battleMons[battlerId].sendOutFlag = 0;
    ctx->battleMons[battlerId].intimidateFlag = 0;
    ctx->battleMons[battlerId].traceFlag = 0;
    ctx->battleMons[battlerId].downloadFlag = 0;
    ctx->battleMons[battlerId].anticipationFlag = 0;
    ctx->battleMons[battlerId].forewarnFlag = 0;
    ctx->battleMons[battlerId].slowStartFlag = 0;
    ctx->battleMons[battlerId].slowStartEnded = 0;
    ctx->battleMons[battlerId].friskFlag = 0;
    ctx->battleMons[battlerId].moldBreakerFlag = 0;
    ctx->battleMons[battlerId].pressureFlag = 0;

    ctx->battleMons[battlerId].type1 = GetMonData(mon, MON_DATA_TYPE_1, NULL);
    ctx->battleMons[battlerId].type2 = GetMonData(mon, MON_DATA_TYPE_2, NULL);

    ctx->battleMons[battlerId].gender = GetMonGender(mon);
    ctx->battleMons[battlerId].shiny = MonIsShiny(mon);

    if (BattleSystem_GetBattleType(battleSystem) & (BATTLE_TYPE_SAFARI | BATTLE_TYPE_PAL_PARK)) { // No abilities battle
        ctx->battleMons[battlerId].ability = 0;
        ctx->battleMons[battlerId].status = 0;
        ctx->battleMons[battlerId].item = 0;
    } else {
        ctx->battleMons[battlerId].ability = GetMonData(mon, MON_DATA_ABILITY, NULL);
        ctx->battleMons[battlerId].status = GetMonData(mon, MON_DATA_STATUS, NULL);
        ctx->battleMons[battlerId].item = GetMonData(mon, MON_DATA_HELD_ITEM, NULL);
    }

    if ((BattleSystem_GetBattleType(battleSystem) & (BATTLE_TYPE_SAFARI | BATTLE_TYPE_PAL_PARK)) && !BattleSystem_GetFieldSide(battleSystem, battlerId)) {
        ctx->battleMons[battlerId].form = 0;
    } else {
        ctx->battleMons[battlerId].form = GetMonData(mon, MON_DATA_FORM, NULL);
    }

    ctx->battleMons[battlerId].level = GetMonData(mon, MON_DATA_LEVEL, NULL);
    ctx->battleMons[battlerId].friendship = GetMonData(mon, MON_DATA_FRIENDSHIP, NULL);

    ctx->battleMons[battlerId].hp = GetMonData(mon, MON_DATA_HP, NULL);
    ctx->battleMons[battlerId].maxHp = GetMonData(mon, MON_DATA_MAX_HP, NULL);

    ctx->battleMons[battlerId].exp = GetMonData(mon, MON_DATA_EXPERIENCE, NULL);
    ctx->battleMons[battlerId].personality = GetMonData(mon, MON_DATA_PERSONALITY, NULL);
    ctx->battleMons[battlerId].otid = GetMonData(mon, MON_DATA_OT_ID, NULL);
    ctx->battleMons[battlerId].otGender = GetMonData(mon, MON_DATA_OT_GENDER, NULL);

    ctx->battleMons[battlerId].ball = BattleSystem_GetMonBall(battleSystem, mon);

    SetDexBanksByGiratinaForm(ctx->battleMons[battlerId].form);
    dexData = PokedexData_Create(HEAP_ID_BATTLE);
    PokedexData_LoadAll(dexData, 0, HEAP_ID_BATTLE);

    ctx->battleMons[battlerId].weight = PokedexData_GetWeight(dexData, ctx->battleMons[battlerId].species);

    PokedexData_UnloadAll(dexData);
    PokedexData_Delete(dexData);

    GetMonData(mon, MON_DATA_NICKNAME, ctx->battleMons[battlerId].nickname);
    GetMonData(mon, MON_DATA_OT_NAME, ctx->battleMons[battlerId].otName);

    ctx->battleMons[battlerId].hitCount = 0;
    ctx->battleMons[battlerId].msgFlag = 0;

    side = BattleSystem_GetFieldSide(battleSystem, battlerId);

    if (ctx->fieldSideConditionData[side].battlerBitKnockedOffItem & MaskOfFlagNo(ctx->selectedMonIndex[battlerId])) {
        ctx->battleMons[battlerId].item = 0;
        ctx->battleMons[battlerId].moveEffectData.knockOffFlag = FALSE;
    } else if (ctx->battleMons[battlerId].item) {
        ctx->battleMons[battlerId].moveEffectData.knockOffFlag = TRUE;
    }
}

void BattleSystem_ReloadMonData(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, int monIndex) {
    Pokemon *mon = BattleSystem_GetPartyMon(battleSystem, battlerId, monIndex);
    int i;

    ctx->battleMons[battlerId].atk = GetMonData(mon, MON_DATA_ATK, NULL);
    ctx->battleMons[battlerId].def = GetMonData(mon, MON_DATA_DEF, NULL);
    ctx->battleMons[battlerId].speed = GetMonData(mon, MON_DATA_SPEED, NULL);
    ctx->battleMons[battlerId].spAtk = GetMonData(mon, MON_DATA_SP_ATK, NULL);
    ctx->battleMons[battlerId].spDef = GetMonData(mon, MON_DATA_SP_DEF, NULL);
    ctx->battleMons[battlerId].level = GetMonData(mon, MON_DATA_LEVEL, NULL);
    ctx->battleMons[battlerId].friendship = GetMonData(mon, MON_DATA_FRIENDSHIP, NULL);
    ctx->battleMons[battlerId].hp = GetMonData(mon, MON_DATA_HP, NULL);
    ctx->battleMons[battlerId].maxHp = GetMonData(mon, MON_DATA_MAX_HP, NULL);

    if (!(ctx->battleMons[battlerId].status2 & STATUS2_TRANSFORM)) {
        for (i = 0; i < 4; i++) {
            if (!(ctx->battleMons[battlerId].moveEffectData.mimicedMoveIndex & MaskOfFlagNo(i))) {
                ctx->battleMons[battlerId].moves[i] = GetMonData(mon, MON_DATA_MOVE1 + i, NULL);
                ctx->battleMons[battlerId].movePPCur[i] = GetMonData(mon, MON_DATA_MOVE1_PP + i, NULL);
                ctx->battleMons[battlerId].movePP[i] = GetMonData(mon, MON_DATA_MOVE1_PP_UPS + i, NULL);
            }
        }
        ctx->battleMons[battlerId].exp = GetMonData(mon, MON_DATA_EXPERIENCE, NULL);
    }
}

void ReadBattleScriptFromNarc(BattleContext *ctx, NarcId narcId, int fileId) {
    GF_ASSERT(GetNarcMemberSizeByIdPair(narcId, fileId) < 1600);
    ctx->scriptNarcId = narcId;
    ctx->scriptFileId = fileId;
    ctx->scriptSeqNo = 0;
    ReadWholeNarcMemberByIdPair(&ctx->battleScriptBuffer, narcId, fileId);
}

// PushBattleScriptFromNarc..?
void BattleScript_Call(BattleContext *ctx, NarcId narcId, int fileId) {
    GF_ASSERT(GetNarcMemberSizeByIdPair(narcId, fileId) < 1600);
    GF_ASSERT(ctx->scriptStackDepth < 4);
    ctx->scriptStackNarcId[ctx->scriptStackDepth] = ctx->scriptNarcId;
    ctx->scriptStackFileId[ctx->scriptStackDepth] = ctx->scriptFileId;
    ctx->scriptStackSeqNo[ctx->scriptStackDepth] = ctx->scriptSeqNo;
    ctx->scriptStackDepth++;
    ctx->scriptNarcId = narcId;
    ctx->scriptFileId = fileId;
    ctx->scriptSeqNo = 0;
    ReadWholeNarcMemberByIdPair(&ctx->battleScriptBuffer, narcId, fileId);
}

// BattleScript_Pop..?
BOOL BattleScript_Return(BattleContext *ctx) {
    if (ctx->scriptStackDepth) {
        ctx->scriptStackDepth--;
        ReadBattleScriptFromNarc(ctx, ctx->scriptStackNarcId[ctx->scriptStackDepth], ctx->scriptStackFileId[ctx->scriptStackDepth]);
        ctx->scriptSeqNo = ctx->scriptStackSeqNo[ctx->scriptStackDepth];
        return FALSE;
    }
    return TRUE;
}

// Link_QueueAdd..?
void BattleContext_AddLinkBufferEntry(BattleContext *ctx, int id, int battlerId, int index) {
    int i;

    for (i = 0; i < 16; i++) {
        if (!ctx->linkBuffer[id][battlerId][i]) {
            ctx->linkBuffer[id][battlerId][i] = index;
            break;
        }
    }

    GF_ASSERT(i < 16);
}

// Link_QueueReset..?
void BattleContext_RemoveLinkBufferEntry(BattleContext *ctx, int id, int battlerId, int index) {
    int i;

    GF_ASSERT(index != 0);

    for (i = 0; i < 16; i++) {
        if (ctx->linkBuffer[id][battlerId][i] == index) {
            ctx->linkBuffer[id][battlerId][i] = 0;
            break;
        }
    }

    GF_ASSERT(i < 16);
}

BOOL Link_QueueNotEmpty(BattleContext *ctx) {
    int i;
    int battlerId;
    int j;
    int cnt = 0;

    for (i = 0; i < 4; i++) {
        for (battlerId = 0; battlerId < 4; battlerId++) {
            for (j = 0; j < 16; j++) {
                cnt += ctx->linkBuffer[i][battlerId][j];
            }
        }
    }

    if (cnt == 0) {
        ctx->queueTimeout = 0;
    }
    return cnt == 0;
}

void Link_CheckTimeout(BattleContext *ctx) {
    ctx->queueTimeout++;
    if (ctx->queueTimeout > 1800) {
        CommState_SetError(1);
    }
}

void BattleBuffer_Clear(BattleContext *ctx, int battlerId) {
    for (int i = 0; i < 256; i++) {
        ctx->battleBuffer[battlerId][i] = 0;
    }
}

int GetBattlerVar(BattleContext *ctx, int battlerId, u32 id, void *data) {
    BattleMon *mon = &ctx->battleMons[battlerId];

    switch (id) {
    case BMON_DATA_SPECIES:
        return mon->species;
    case BMON_DATA_ATK:
        return mon->atk;
    case BMON_DATA_DEF:
        return mon->def;
    case BMON_DATA_SPEED:
        return mon->speed;
    case BMON_DATA_SPATK:
        return mon->spAtk;
    case BMON_DATA_SPDEF:
        return mon->spDef;
    case BMON_DATA_MOVE1:
    case BMON_DATA_MOVE2:
    case BMON_DATA_MOVE3:
    case BMON_DATA_MOVE4: {
        int index = id - BMON_DATA_MOVE1; // see below
        return mon->moves[index];
    }
    case BMON_DATA_HP_IV:
        return mon->hpIV;
    case BMON_DATA_ATK_IV:
        return mon->atkIV;
    case BMON_DATA_DEF_IV:
        return mon->defIV;
    case BMON_DATA_SPEED_IV:
        return mon->speedIV;
    case BMON_DATA_SPATK_IV:
        return mon->spAtkIV;
    case BMON_DATA_SPDEF_IV:
        return mon->spDefIV;
    case BMON_DATA_IS_EGG:
        return mon->isEgg;
    case BMON_DATA_HAS_NICKNAME:
        return mon->hasNickname;
    case BMON_DATA_STAT_CHANGE_HP:
    case BMON_DATA_STAT_CHANGE_ATK:
    case BMON_DATA_STAT_CHANGE_DEF:
    case BMON_DATA_STAT_CHANGE_SPEED:
    case BMON_DATA_STAT_CHANGE_SPATK:
    case BMON_DATA_STAT_CHANGE_SPDEF:
    case BMON_DATA_STAT_CHANGE_ACC:
    case BMON_DATA_STAT_CHANGE_EVASION: {
        int index = id - BMON_DATA_STAT_CHANGE_HP; // see below
        return mon->statChanges[index];
    }
    case BMON_DATA_ABILITY:
        return mon->ability;
    case BMON_DATA_TYPE_1:
    case BMON_DATA_TYPE_2:
        return Battler_GetType(ctx, battlerId, id);
    case BMON_DATA_GENDER:
        return mon->gender;
    case BMON_DATA_IS_SHINY:
        return mon->shiny;
    case BMON_DATA_CUR_PP_1:
    case BMON_DATA_CUR_PP_2:
    case BMON_DATA_CUR_PP_3:
    case BMON_DATA_CUR_PP_4: {
        int index = id - BMON_DATA_CUR_PP_1; // annoying but required to match
        return mon->movePPCur[index];
    }
    case BMON_DATA_PP_UPS_1:
    case BMON_DATA_PP_UPS_2:
    case BMON_DATA_PP_UPS_3:
    case BMON_DATA_PP_UPS_4: {
        int index = id - BMON_DATA_PP_UPS_1; // see above
        return mon->movePP[index];
    }
    case BMON_DATA_MAX_PP_1:
    case BMON_DATA_MAX_PP_2:
    case BMON_DATA_MAX_PP_3:
    case BMON_DATA_MAX_PP_4: {
        int index = id - BMON_DATA_MAX_PP_1; // see above
        return GetMoveMaxPP(mon->moves[index], mon->movePP[index]);
    }
    case BMON_DATA_LEVEL:
        return mon->level;
    case BMON_DATA_FRIENDSHIP:
        return mon->friendship;
    case BMON_DATA_NICKNAME: {
        int i;
        u16 *buffer = data;

        for (i = 0; i < POKEMON_NAME_LENGTH + 1; i++) {
            buffer[i] = mon->nickname[i];
        }
    } break;
    case BMON_DATA_NICKNAME_STRBUF:
        CopyU16ArrayToString((String *)data, mon->nickname);
        break;
    case BMON_DATA_HP:
        return mon->hp;
    case BMON_DATA_MAXHP:
        return mon->maxHp;
    case BMON_DATA_OT_NAME: {
        int i;
        u16 *buffer = data;
        for (i = 0; i < POKEMON_NAME_LENGTH + 1; i++) {
            // BUG: this array doesn't have 11 elements, the reason for the bug is a typo in the original code
            //      where it used the length of a Pokemon's nickname rather than a trainer's nickname
            buffer[i] = mon->otName[i];
        }
    } break;
    case BMON_DATA_EXP:
        return mon->exp;
    case BMON_DATA_PERSONALITY:
        return mon->personality;
    case BMON_DATA_STATUS:
        return mon->status;
    case BMON_DATA_STATUS2:
        return mon->status2;
    case BMON_DATA_OT_ID:
        return mon->otid;
    case BMON_DATA_HELD_ITEM:
        return mon->item;
    case BMON_DATA_TIMES_DAMAGED:
        return mon->hitCount;
    case BMON_DATA_MSG_FLAG:
        return mon->msgFlag;
    case BMON_DATA_OT_GENDER:
        return mon->otGender;
    case BMON_DATA_MOVE_EFFECT:
        return mon->moveEffectFlags;
    case BMON_DATA_MOVE_EFFECT_TEMP:
        return mon->moveEffectFlagsTemp;
    case BMON_DATA_DISABLED_TURNS:
        return mon->moveEffectData.disabledTurns;
    case BMON_DATA_ENCORED_TURNS:
        return mon->moveEffectData.encoredTurns;
    case BMON_DATA_CHARGED_TURNS:
        return mon->moveEffectData.isCharged;
    case BMON_DATA_TAUNTED_TURNS:
        return mon->moveEffectData.tauntTurns;
    case BMON_DATA_PROTECT_SUCCESS_COUNT:
        return mon->moveEffectData.protectSuccessTurns;
    case BMON_DATA_PERISH_SONG_TURNS:
        return mon->moveEffectData.perishSongTurns;
    case BMON_DATA_ROLLOUT_TURNS:
        return mon->moveEffectData.rolloutCount;
    case BMON_DATA_FURY_CUTTER_TURNS:
        return mon->moveEffectData.furyCutterCount;
    case BMON_DATA_STOCKPILE_COUNT:
        return mon->moveEffectData.stockpileCount;
    case BMON_DATA_STOCKPILE_DEF_BOOSTS:
        return mon->moveEffectData.stockpileDefCount;
    case BMON_DATA_STOCKPILE_SPDEF_BOOSTS:
        return mon->moveEffectData.stockpileSpDefCount;
    case BMON_DATA_TRUANT:
        return mon->moveEffectData.truantFlag;
    case BMON_DATA_FLASH_FIRE:
        return mon->moveEffectData.flashFire;
    case BMON_DATA_LOCK_ON_TARGET:
        return mon->moveEffectData.battlerIdLockOn;
    case BMON_DATA_MIMICED_MOVE:
        return mon->moveEffectData.mimicedMoveIndex;
    case BMON_DATA_BIND_TARGET:
        return mon->moveEffectData.battlerIdBinding;
    case BMON_DATA_MEAN_LOOK_TARGET:
        return mon->moveEffectData.battlerIdMeanLook;
    case BMON_DATA_LAST_RESORT_COUNT:
        return mon->moveEffectData.lastResortCount;
    case BMON_DATA_MAGNET_RISE_TURNS:
        return mon->moveEffectData.magnetRiseTurns;
    case BMON_DATA_HEAL_BLOCK_TURNS:
        return mon->moveEffectData.healBlockTurns;
    case BMON_DATA_EMBARGO_TURNS:
        return mon->moveEffectData.embargoFlag;
    case BMON_DATA_CAN_UNBURDEN:
        return mon->moveEffectData.knockOffFlag;
    case BMON_DATA_METRONOME_TURNS: // refers to the actual item, not the move
        return mon->moveEffectData.metronomeTurns;
    case BMON_DATA_MICLE_BERRY_FLAG:
        return mon->moveEffectData.micleBerryFlag;
    case BMON_DATA_CUSTAP_FLAG:
        return mon->moveEffectData.custapBerryFlag;
    case BMON_DATA_QUICK_CLAW_FLAG:
        return mon->moveEffectData.quickClawFlag;
    case BMON_DATA_RECHARGE:
        return mon->moveEffectData.rechargeCount;
    case BMON_DATA_FAKE_OUT:
        return mon->moveEffectData.fakeOutCount;
    case BMON_DATA_SLOW_START_TURN_NUMBER:
        return mon->moveEffectData.slowStartTurns;
    case BMON_DATA_SUBSTITUTE_HP:
        return mon->moveEffectData.substituteHp;
    case BMON_DATA_TRANSFORMED_PERSONALITY:
        return mon->moveEffectData.transformPersonality;
    case BMON_DATA_DISABLED_MOVE_NO:
        return mon->moveEffectData.disabledMove;
    case BMON_DATA_ENCORED_MOVE_NO:
        return mon->moveEffectData.encoredMove;
    case BMON_DATA_BINDING_MOVE_NO:
        return mon->moveEffectData.bindingMove;
    case BMON_DATA_HELD_ITEM_RESTORE_HP:
        return mon->moveEffectData.heldItemRestoreHp;
    case BMON_DATA_SLOW_START_FLAG:
        return mon->slowStartFlag;
    case BMON_DATA_SLOW_START_END:
        return mon->slowStartEnded;
    case BMON_DATA_FORM:
        return mon->form;
    case BMON_DATA_TEMP:
        return GetBattlerVar(ctx, battlerId, ctx->tempData, data);
    default:
        GF_ASSERT(FALSE);
    }

    return 0;
}

void SetBattlerVar(BattleContext *ctx, int battlerId, u32 id, void *data) {
    u32 *data32 = (u32 *)data;
    u16 *data16 = (u16 *)data;
    s16 *datas16 = (s16 *)data;
    u8 *data8 = (u8 *)data;
    s8 *datas8 = (s8 *)data;
    BattleMon *mon = &ctx->battleMons[battlerId];

    switch (id) {
    case BMON_DATA_SPECIES:
        mon->species = *data16;
        break;
    case BMON_DATA_ATK:
        mon->atk = *data16;
        break;
    case BMON_DATA_DEF:
        mon->def = *data16;
        break;
    case BMON_DATA_SPEED:
        mon->speed = *data16;
        break;
    case BMON_DATA_SPATK:
        mon->spAtk = *data16;
        break;
    case BMON_DATA_SPDEF:
        mon->spDef = *data16;
        break;
    case BMON_DATA_MOVE1:
    case BMON_DATA_MOVE2:
    case BMON_DATA_MOVE3:
    case BMON_DATA_MOVE4: {
        int index = id - BMON_DATA_MOVE1;
        mon->moves[index] = *data16;
    } break;
    case BMON_DATA_HP_IV:
        mon->hpIV = *data8;
        break;
    case BMON_DATA_ATK_IV:
        mon->atkIV = *data8;
        break;
    case BMON_DATA_DEF_IV:
        mon->defIV = *data8;
        break;
    case BMON_DATA_SPEED_IV:
        mon->speedIV = *data8;
        break;
    case BMON_DATA_SPATK_IV:
        mon->spAtkIV = *data8;
        break;
    case BMON_DATA_SPDEF_IV:
        mon->spDefIV = *data8;
        break;
    case BMON_DATA_IS_EGG:
        mon->isEgg = *data8;
        break;
    case BMON_DATA_HAS_NICKNAME:
        mon->hasNickname = *data8;
        break;
    case BMON_DATA_STAT_CHANGE_HP:
    case BMON_DATA_STAT_CHANGE_ATK:
    case BMON_DATA_STAT_CHANGE_DEF:
    case BMON_DATA_STAT_CHANGE_SPEED:
    case BMON_DATA_STAT_CHANGE_SPATK:
    case BMON_DATA_STAT_CHANGE_SPDEF:
    case BMON_DATA_STAT_CHANGE_ACC:
    case BMON_DATA_STAT_CHANGE_EVASION: {
        int index = id - BMON_DATA_STAT_CHANGE_HP;
        mon->statChanges[index] = *datas8;
    } break;
    case BMON_DATA_ABILITY:
        mon->ability = *data8;
        break;
    case BMON_DATA_TYPE_1:
        mon->type1 = *data8;
        break;
    case BMON_DATA_TYPE_2:
        mon->type2 = *data8;
        break;
    case BMON_DATA_GENDER:
        mon->gender = *data8;
        break;
    case BMON_DATA_IS_SHINY:
        mon->shiny = *data8;
        break;
    case BMON_DATA_CUR_PP_1:
    case BMON_DATA_CUR_PP_2:
    case BMON_DATA_CUR_PP_3:
    case BMON_DATA_CUR_PP_4: {
        int index = id - BMON_DATA_CUR_PP_1;
        mon->movePPCur[index] = *data8;
    } break;
    case BMON_DATA_PP_UPS_1:
    case BMON_DATA_PP_UPS_2:
    case BMON_DATA_PP_UPS_3:
    case BMON_DATA_PP_UPS_4: {
        int index = id - BMON_DATA_PP_UPS_1;
        mon->movePP[index] = *data8;
    } break;
    case BMON_DATA_MAX_PP_1:
    case BMON_DATA_MAX_PP_2:
    case BMON_DATA_MAX_PP_3:
    case BMON_DATA_MAX_PP_4:
        GF_ASSERT(FALSE);
        break;
    case BMON_DATA_LEVEL:
        mon->level = *data8;
        break;
    case BMON_DATA_FRIENDSHIP:
        mon->friendship = *data8;
        break;
    case BMON_DATA_NICKNAME:
        for (int i = 0; i < POKEMON_NAME_LENGTH + 1; i++) {
            mon->nickname[i] = data16[i];
        }
        break;
    case BMON_DATA_HP:
        mon->hp = *datas16;
        break;
    case BMON_DATA_MAXHP:
        mon->maxHp = *data16;
        break;
    case BMON_DATA_OT_NAME:
        for (int i = 0; i < POKEMON_NAME_LENGTH + 1; i++) {
            // BUG: this array doesn't have 11 elements, the reason for the bug is a typo in the original code
            //      where it used the length of a Pokemon's nickname rather than a trainer's nickname
            mon->otName[i] = data16[i];
            // Side note but since this will overwrite the space in memory where the pokemon's exp is stored, there could be some funny things to come of this
        }
        break;
    case BMON_DATA_EXP:
        mon->exp = *data32;
        break;
    case BMON_DATA_PERSONALITY:
        mon->personality = *data32;
        break;
    case BMON_DATA_STATUS:
        mon->status = *data32;
        break;
    case BMON_DATA_STATUS2:
        mon->status2 = *data32;
        break;
    case BMON_DATA_OT_ID:
        mon->otid = *data32;
        break;
    case BMON_DATA_HELD_ITEM:
        mon->item = *data16;
        break;
    case BMON_DATA_TIMES_DAMAGED:
        mon->hitCount = *data8;
        break;
    case BMON_DATA_MSG_FLAG:
        mon->msgFlag = *data8;
        break;
    case BMON_DATA_OT_GENDER:
        mon->otGender = *data8;
        break;
    case BMON_DATA_MOVE_EFFECT:
        mon->moveEffectFlags = *data32;
        break;
    case BMON_DATA_MOVE_EFFECT_TEMP:
        mon->moveEffectFlagsTemp = *data32;
        break;
    case BMON_DATA_DISABLED_TURNS:
        mon->moveEffectData.disabledTurns = *data8;
        break;
    case BMON_DATA_ENCORED_TURNS:
        mon->moveEffectData.encoredTurns = *data8;
        break;
    case BMON_DATA_CHARGED_TURNS:
        mon->moveEffectData.isCharged = *data8;
        break;
    case BMON_DATA_TAUNTED_TURNS:
        mon->moveEffectData.tauntTurns = *data8;
        break;
    case BMON_DATA_PROTECT_SUCCESS_COUNT:
        mon->moveEffectData.protectSuccessTurns = *data8;
        break;
    case BMON_DATA_PERISH_SONG_TURNS:
        mon->moveEffectData.perishSongTurns = *data8;
        break;
    case BMON_DATA_ROLLOUT_TURNS:
        mon->moveEffectData.rolloutCount = *data8;
        break;
    case BMON_DATA_FURY_CUTTER_TURNS:
        mon->moveEffectData.furyCutterCount = *data8;
        break;
    case BMON_DATA_STOCKPILE_COUNT:
        mon->moveEffectData.stockpileCount = *data8;
        break;
    case BMON_DATA_STOCKPILE_DEF_BOOSTS:
        mon->moveEffectData.stockpileDefCount = *data8;
        break;
    case BMON_DATA_STOCKPILE_SPDEF_BOOSTS:
        mon->moveEffectData.stockpileSpDefCount = *data8;
        break;
    case BMON_DATA_TRUANT:
        mon->moveEffectData.truantFlag = *data8;
        break;
    case BMON_DATA_FLASH_FIRE:
        mon->moveEffectData.flashFire = *data8;
        break;
    case BMON_DATA_LOCK_ON_TARGET:
        mon->moveEffectData.battlerIdLockOn = *data8;
        break;
    case BMON_DATA_MIMICED_MOVE:
        mon->moveEffectData.mimicedMoveIndex = *data8;
        break;
    case BMON_DATA_BIND_TARGET:
        mon->moveEffectData.battlerIdBinding = *data8;
        break;
    case BMON_DATA_MEAN_LOOK_TARGET:
        mon->moveEffectData.battlerIdMeanLook = *data8;
        break;
    case BMON_DATA_LAST_RESORT_COUNT:
        mon->moveEffectData.lastResortCount = *data8;
        break;
    case BMON_DATA_MAGNET_RISE_TURNS:
        mon->moveEffectData.magnetRiseTurns = *data8;
        break;
    case BMON_DATA_HEAL_BLOCK_TURNS:
        mon->moveEffectData.healBlockTurns = *data8;
        break;
    case BMON_DATA_EMBARGO_TURNS:
        mon->moveEffectData.embargoFlag = *data8;
        break;
    case BMON_DATA_CAN_UNBURDEN:
        mon->moveEffectData.knockOffFlag = *data8;
        break;
    case BMON_DATA_METRONOME_TURNS: // refers to the actual item, not the move
        mon->moveEffectData.metronomeTurns = *data8;
        break;
    case BMON_DATA_MICLE_BERRY_FLAG:
        mon->moveEffectData.micleBerryFlag = *data8;
        break;
    case BMON_DATA_CUSTAP_FLAG:
        mon->moveEffectData.custapBerryFlag = *data8;
        break;
    case BMON_DATA_QUICK_CLAW_FLAG:
        mon->moveEffectData.quickClawFlag = *data8;
        break;
    case BMON_DATA_RECHARGE:
        mon->moveEffectData.rechargeCount = *data32;
        break;
    case BMON_DATA_FAKE_OUT:
        mon->moveEffectData.fakeOutCount = *data32;
        break;
    case BMON_DATA_SLOW_START_TURN_NUMBER:
        mon->moveEffectData.slowStartTurns = *data32;
        break;
    case BMON_DATA_SUBSTITUTE_HP:
        mon->moveEffectData.substituteHp = *data32;
        break;
    case BMON_DATA_TRANSFORMED_PERSONALITY:
        mon->moveEffectData.transformPersonality = *data32;
        break;
    case BMON_DATA_DISABLED_MOVE_NO:
        mon->moveEffectData.disabledMove = *data16;
        break;
    case BMON_DATA_ENCORED_MOVE_NO:
        mon->moveEffectData.encoredMove = *data16;
        break;
    case BMON_DATA_BINDING_MOVE_NO:
        mon->moveEffectData.bindingMove = *data16;
        break;
    case BMON_DATA_HELD_ITEM_RESTORE_HP:
        mon->moveEffectData.heldItemRestoreHp = *data32;
        break;
    case BMON_DATA_SLOW_START_FLAG:
        mon->slowStartFlag = *data8;
        break;
    case BMON_DATA_SLOW_START_END:
        mon->slowStartEnded = *data8;
        break;
    case BMON_DATA_FORM:
        mon->form = *data8;
        break;
    case BMON_DATA_TEMP:
        SetBattlerVar(ctx, battlerId, ctx->tempData, data);
        break;
    default:
        GF_ASSERT(FALSE);
    }
}

void AddBattlerVar(BattleContext *ctx, int battlerId, u32 varId, int data) {
    BattleMon_AddVar(&ctx->battleMons[battlerId], varId, data);
}

void BattleMon_AddVar(BattleMon *mon, u32 varId, int data) {
    switch (varId) {
    case BMON_DATA_ATK:
        mon->atk += data;
        break;
    case BMON_DATA_DEF:
        mon->def += data;
        break;
    case BMON_DATA_SPEED:
        mon->speed += data;
        break;
    case BMON_DATA_SPATK:
        mon->spAtk += data;
        break;
    case BMON_DATA_SPDEF:
        mon->spDef += data;
        break;
    case BMON_DATA_HP_IV:
        mon->hpIV += data;
        break;
    case BMON_DATA_ATK_IV:
        mon->atkIV += data;
        break;
    case BMON_DATA_DEF_IV:
        mon->defIV += data;
        break;
    case BMON_DATA_SPEED_IV:
        mon->speedIV += data;
        break;
    case BMON_DATA_SPATK_IV:
        mon->spAtkIV += data;
        break;
    case BMON_DATA_SPDEF_IV:
        mon->spDefIV += data;
        break;
    case BMON_DATA_STAT_CHANGE_HP:
    case BMON_DATA_STAT_CHANGE_ATK:
    case BMON_DATA_STAT_CHANGE_DEF:
    case BMON_DATA_STAT_CHANGE_SPEED:
    case BMON_DATA_STAT_CHANGE_SPATK:
    case BMON_DATA_STAT_CHANGE_SPDEF:
    case BMON_DATA_STAT_CHANGE_ACC:
    case BMON_DATA_STAT_CHANGE_EVASION: {
        int index = varId - BMON_DATA_STAT_CHANGE_HP;
        if (mon->statChanges[index] + data < 0) {
            mon->statChanges[index] = 0;
        } else if (mon->statChanges[index] + data > BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            mon->statChanges[index] = BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE;
        } else {
            mon->statChanges[index] += data;
        }
    } break;
    case BMON_DATA_CUR_PP_1:
    case BMON_DATA_CUR_PP_2:
    case BMON_DATA_CUR_PP_3:
    case BMON_DATA_CUR_PP_4: {
        int index = varId - BMON_DATA_CUR_PP_1;
        int maxPP = GetMoveMaxPP(mon->moves[index], mon->movePP[index]);
        if (mon->movePPCur[index] + data > maxPP) {
            mon->movePPCur[index] = maxPP;
        } else {
            mon->movePPCur[index] += data;
        }
    } break;
    case BMON_DATA_PP_UPS_1:
    case BMON_DATA_PP_UPS_2:
    case BMON_DATA_PP_UPS_3:
    case BMON_DATA_PP_UPS_4: {
        int index = varId - BMON_DATA_PP_UPS_1;
        mon->movePP[index] += data;
    } break;
    case BMON_DATA_LEVEL:
        mon->level += data;
        break;
    case BMON_DATA_FRIENDSHIP: {
        int temp = mon->friendship;

        if (temp + data > 255) {
            temp = 255;
        } else if (temp + data < 0) {
            temp = 0;
        } else {
            temp += data;
        }

        mon->friendship = temp;
    } break;
    case BMON_DATA_HP: {
        if (mon->hp + data > mon->maxHp) {
            mon->hp = mon->maxHp;
        } else {
            mon->hp += data;
        }
    } break;
    case BMON_DATA_MAXHP:
        mon->maxHp += data;
        break;
    case BMON_DATA_EXP:
        mon->exp += data;
        break;
    case BMON_DATA_PERSONALITY:
        mon->personality += data;
        break;
    case BMON_DATA_DISABLED_TURNS:
        mon->moveEffectData.disabledTurns += data;
        break;
    case BMON_DATA_ENCORED_TURNS:
        mon->moveEffectData.encoredTurns += data;
        break;
    case BMON_DATA_CHARGED_TURNS:
        mon->moveEffectData.isCharged += data;
        break;
    case BMON_DATA_TAUNTED_TURNS:
        mon->moveEffectData.tauntTurns += data;
        break;
    case BMON_DATA_PROTECT_SUCCESS_COUNT:
        mon->moveEffectData.protectSuccessTurns += data;
        break;
    case BMON_DATA_PERISH_SONG_TURNS:
        mon->moveEffectData.perishSongTurns += data;
        break;
    case BMON_DATA_ROLLOUT_TURNS:
        mon->moveEffectData.rolloutCount += data;
        break;
    case BMON_DATA_FURY_CUTTER_TURNS:
        mon->moveEffectData.furyCutterCount += data;
        break;
    case BMON_DATA_STOCKPILE_COUNT:
        mon->moveEffectData.stockpileCount += data;
        break;
    case BMON_DATA_STOCKPILE_DEF_BOOSTS:
        mon->moveEffectData.stockpileDefCount += data;
        break;
    case BMON_DATA_STOCKPILE_SPDEF_BOOSTS:
        mon->moveEffectData.stockpileSpDefCount += data;
        break;
    case BMON_DATA_LAST_RESORT_COUNT:
        mon->moveEffectData.lastResortCount += data;
        break;
    case BMON_DATA_MAGNET_RISE_TURNS:
        mon->moveEffectData.magnetRiseTurns += data;
        break;
    case BMON_DATA_HEAL_BLOCK_TURNS:
        mon->moveEffectData.healBlockTurns += data;
        break;
    case BMON_DATA_RECHARGE:
        mon->moveEffectData.rechargeCount += data;
        break;
    case BMON_DATA_FAKE_OUT:
        mon->moveEffectData.fakeOutCount += data;
        break;
    case BMON_DATA_SLOW_START_TURN_NUMBER:
        mon->moveEffectData.slowStartTurns += data;
        break;
    case BMON_DATA_SUBSTITUTE_HP:
        mon->moveEffectData.substituteHp += data;
        break;
    case BMON_DATA_HELD_ITEM_RESTORE_HP:
        mon->moveEffectData.heldItemRestoreHp += data;
        break;
    case BMON_DATA_SLOW_START_FLAG:
        mon->slowStartFlag += data;
        break;
    case BMON_DATA_SLOW_START_END:
        mon->slowStartEnded += data;
        break;
    case BMON_DATA_FORM:
        mon->form += data;
        break;
    default:
        GF_ASSERT(FALSE);
    }
}

static const u8 sSpeedHalvingItemEffects[] = {
    HOLD_EFFECT_EVS_UP_SPEED_DOWN,   // Macho Brace
    HOLD_EFFECT_SPEED_DOWN_GROUNDED, // Iron Ball
    HOLD_EFFECT_LVLUP_HP_EV_UP,      // Power Weight
    HOLD_EFFECT_LVLUP_ATK_EV_UP,     // Power Bracer
    HOLD_EFFECT_LVLUP_DEF_EV_UP,     // Power Belt
    HOLD_EFFECT_LVLUP_SPEED_EV_UP,   // Power Anklet
    HOLD_EFFECT_LVLUP_SPATK_EV_UP,   // Power Lens
    HOLD_EFFECT_LVLUP_SPDEF_EV_UP    // Power Band
};

u8 CheckSortSpeed(BattleSystem *battleSystem, BattleContext *ctx, int battlerId1, int battlerId2, int flag) {
    u8 ret = 0; // 0 - don't sort, 1 - sort, 2 - sort (speed tie + won random check)
    u32 speed1, speed2;
    u16 moveNo1 = 0;
    u16 moveNo2 = 0;
    u8 heldItem1;
    u8 extra1;
    u8 heldItem2;
    u8 extra2;
    s8 movePriority1 = 0;
    s8 movePriority2 = 0;
    u8 boostedPriority1 = 0;
    u8 boostedPriority2 = 0;
    u8 loweredPriority1 = 0;
    u8 loweredPriority2 = 0;
    int action1;
    int action2;
    int movePos1;
    int movePos2;
    int ability1;
    int ability2;
    int speedStatChange1;
    int speedStatChange2;
    int i;

    if (ctx->battleMons[battlerId1].hp == 0 && ctx->battleMons[battlerId2].hp) {
        return 1;
    }
    if (ctx->battleMons[battlerId1].hp && ctx->battleMons[battlerId2].hp == 0) {
        return 0;
    }

    ability1 = GetBattlerAbility(ctx, battlerId1);
    ability2 = GetBattlerAbility(ctx, battlerId2);

    heldItem1 = GetBattlerHeldItemEffect(ctx, battlerId1);
    extra1 = GetHeldItemModifier(ctx, battlerId1, 0);
    heldItem2 = GetBattlerHeldItemEffect(ctx, battlerId2);
    extra2 = GetHeldItemModifier(ctx, battlerId2, 0);

    speedStatChange1 = ctx->battleMons[battlerId1].statChanges[3];
    speedStatChange2 = ctx->battleMons[battlerId2].statChanges[3];

    if (GetBattlerAbility(ctx, battlerId1) == ABILITY_SIMPLE) {
        speedStatChange1 = 6 + (speedStatChange1 - 6) * 2;

        if (speedStatChange1 > BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            speedStatChange1 = BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE;
        }

        if (speedStatChange1 < 0) {
            speedStatChange1 = 0;
        }
    }
    if (GetBattlerAbility(ctx, battlerId2) == ABILITY_SIMPLE) {
        speedStatChange2 = 6 + (speedStatChange2 - 6) * 2;

        if (speedStatChange2 > BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            speedStatChange2 = BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE;
        }

        if (speedStatChange2 < 0) {
            speedStatChange2 = 0;
        }
    }

    speed1 = ctx->battleMons[battlerId1].speed * sStatChangeTable[speedStatChange1][0] / sStatChangeTable[speedStatChange1][1];
    speed2 = ctx->battleMons[battlerId2].speed * sStatChangeTable[speedStatChange2][0] / sStatChangeTable[speedStatChange2][1];

    if (!CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_CLOUD_NINE) && !CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_AIR_LOCK)) {
        if ((ability1 == ABILITY_SWIFT_SWIM && ctx->fieldCondition & FIELD_CONDITION_RAIN_ALL) || (ability1 == ABILITY_CHLOROPHYLL && ctx->fieldCondition & FIELD_CONDITION_SUN_ALL)) {
            speed1 *= 2;
        }
        if ((ability2 == ABILITY_SWIFT_SWIM && ctx->fieldCondition & FIELD_CONDITION_RAIN_ALL) || (ability2 == ABILITY_CHLOROPHYLL && ctx->fieldCondition & FIELD_CONDITION_SUN_ALL)) {
            speed2 *= 2;
        }
    }

    for (i = 0; i < NELEMS(sSpeedHalvingItemEffects); i++) {
        if (GetItemVar(ctx, ctx->battleMons[battlerId1].item, ITEM_VAR_HOLD_EFFECT) == sSpeedHalvingItemEffects[i]) {
            speed1 /= 2;
            break;
        }
    }

    if (heldItem1 == HOLD_EFFECT_CHOICE_SPEED) {
        speed1 = speed1 * 15 / 10;
    }

    if (heldItem1 == HOLD_EFFECT_DITTO_SPEED_UP && ctx->battleMons[battlerId1].species == SPECIES_DITTO) {
        speed1 *= 2;
    }

    if (ability1 == ABILITY_QUICK_FEET && ctx->battleMons[battlerId1].status & 0xFF) {
        speed1 = speed1 * 15 / 10;
    } else if (ctx->battleMons[battlerId1].status & STATUS_PARALYSIS) {
        speed1 /= 4;
    }

    if (ability1 == ABILITY_SLOW_START && ctx->totalTurns - ctx->battleMons[battlerId1].moveEffectData.slowStartTurns < 5) {
        speed1 /= 2;
    }

    if (ability1 == ABILITY_UNBURDEN && ctx->battleMons[battlerId1].moveEffectData.knockOffFlag && ctx->battleMons[battlerId1].item == FALSE) {
        speed1 *= 2;
    }

    if (ctx->fieldSideConditionFlags[BattleSystem_GetFieldSide(battleSystem, battlerId1)] & SIDE_CONDITION_TAILWIND) {
        speed1 *= 2;
    }

    if (heldItem1 == HOLD_EFFECT_SOMETIMES_PRIORITY) {
        if (ctx->quickClawRandom[battlerId1] % (100 / extra1) == 0) {
            boostedPriority1 = 1;

            if (!flag) {
                ctx->battleMons[battlerId1].moveEffectData.quickClawFlag = TRUE;
            }
        }
    }

    if (heldItem1 == HOLD_EFFECT_PINCH_PRIORITY) {
        if (GetBattlerAbility(ctx, battlerId1) == ABILITY_GLUTTONY) {
            extra1 /= 2;
        }
        if (ctx->battleMons[battlerId1].hp <= ctx->battleMons[battlerId1].maxHp / extra1) {
            boostedPriority1 = 1;
            if (!flag) {
                ctx->battleMons[battlerId1].moveEffectData.custapBerryFlag = TRUE;
            }
        }
    }

    if (heldItem1 == HOLD_EFFECT_SPEED_DOWN) {
        loweredPriority1 = 1;
    }

    for (i = 0; i < NELEMS(sSpeedHalvingItemEffects); i++) {
        if (GetItemVar(ctx, ctx->battleMons[battlerId2].item, ITEM_VAR_HOLD_EFFECT) == sSpeedHalvingItemEffects[i]) {
            speed2 /= 2;
            break;
        }
    }

    if (heldItem2 == HOLD_EFFECT_CHOICE_SPEED) {
        speed2 = speed2 * 15 / 10;
    }

    if (heldItem2 == HOLD_EFFECT_DITTO_SPEED_UP && ctx->battleMons[battlerId2].species == SPECIES_DITTO) {
        speed2 *= 2;
    }

    if (ability2 == ABILITY_QUICK_FEET && ctx->battleMons[battlerId2].status & 0xFF) {
        speed2 = speed2 * 15 / 10;
    } else if (ctx->battleMons[battlerId2].status & STATUS_PARALYSIS) {
        speed2 /= 4;
    }

    if (ability2 == ABILITY_SLOW_START && ctx->totalTurns - ctx->battleMons[battlerId2].moveEffectData.slowStartTurns < 5) {
        speed2 /= 2;
    }

    if (ability2 == ABILITY_UNBURDEN && ctx->battleMons[battlerId2].moveEffectData.knockOffFlag && ctx->battleMons[battlerId2].item == FALSE) {
        speed2 *= 2;
    }

    if (ctx->fieldSideConditionFlags[BattleSystem_GetFieldSide(battleSystem, battlerId2)] & SIDE_CONDITION_TAILWIND) {
        speed2 *= 2;
    }

    if (heldItem2 == HOLD_EFFECT_SOMETIMES_PRIORITY) {
        if (ctx->quickClawRandom[battlerId2] % (100 / extra2) == 0) {
            boostedPriority2 = 1;

            if (!flag) {
                ctx->battleMons[battlerId2].moveEffectData.quickClawFlag = TRUE;
            }
        }
    }

    if (heldItem2 == HOLD_EFFECT_PINCH_PRIORITY) {
        if (GetBattlerAbility(ctx, battlerId2) == ABILITY_GLUTTONY) {
            extra2 /= 2;
        }
        if (ctx->battleMons[battlerId2].hp <= ctx->battleMons[battlerId2].maxHp / extra2) {
            boostedPriority2 = 1;
            if (!flag) {
                ctx->battleMons[battlerId2].moveEffectData.custapBerryFlag = TRUE;
            }
        }
    }

    if (heldItem2 == HOLD_EFFECT_SPEED_DOWN) {
        loweredPriority2 = 1;
    }

    ctx->effectiveSpeed[battlerId1] = speed1;
    ctx->effectiveSpeed[battlerId2] = speed2;

    if (!flag) {
        action1 = ctx->playerActions[battlerId1].inputSelection;
        action2 = ctx->playerActions[battlerId2].inputSelection;
        movePos1 = ctx->movePos[battlerId1];
        movePos2 = ctx->movePos[battlerId2];
        if (action1 == 1) { // fight button
            if (ctx->turnData[battlerId1].struggleFlag) {
                moveNo1 = MOVE_STRUGGLE;
            } else {
                moveNo1 = GetBattlerVar(ctx, battlerId1, BMON_DATA_MOVE1 + movePos1, NULL);
            }
        }
        if (action2 == 1) { // fight button
            if (ctx->turnData[battlerId2].struggleFlag) {
                moveNo2 = MOVE_STRUGGLE;
            } else {
                moveNo2 = GetBattlerVar(ctx, battlerId2, BMON_DATA_MOVE1 + movePos2, NULL);
            }
        }
        movePriority1 = ctx->trainerAIData.moveData[moveNo1].priority;
        movePriority2 = ctx->trainerAIData.moveData[moveNo2].priority;
    }

    if (movePriority1 == movePriority2) {
        if (boostedPriority1 && boostedPriority2) {
            if (speed1 < speed2) {
                ret = 1;
            } else if (speed1 == speed2 && BattleSystem_Random(battleSystem) & 1) {
                ret = 2;
            }
        } else if (!boostedPriority1 && boostedPriority2) {
            ret = 1;
        } else if (boostedPriority1 && !boostedPriority2) {
            ret = 0;
        } else if (loweredPriority1 && loweredPriority2) {
            if (speed1 > speed2) {
                ret = 1;
            } else if (speed1 == speed2 && BattleSystem_Random(battleSystem) & 1) {
                ret = 2;
            }
        } else if (loweredPriority1 && !loweredPriority2) {
            ret = 1;
        } else if (!loweredPriority1 && loweredPriority2) {
            ret = 0;
        } else if (ability1 == ABILITY_STALL && ability2 == ABILITY_STALL) {
            if (speed1 > speed2) {
                ret = 1;
            } else if (speed1 == speed2 && BattleSystem_Random(battleSystem) & 1) {
                ret = 2;
            }
        } else if (ability1 == ABILITY_STALL && ability2 != ABILITY_STALL) {
            ret = 1;
        } else if (ability1 != ABILITY_STALL && ability2 == ABILITY_STALL) {
            ret = 0;
        } else if (ctx->fieldCondition & FIELD_CONDITION_TRICK_ROOM) {
            if (speed1 > speed2) {
                ret = 1;
            }
            if (speed1 == speed2 && BattleSystem_Random(battleSystem) & 1) {
                ret = 2;
            }
        } else {
            if (speed1 < speed2) {
                ret = 1;
            }
            if (speed1 == speed2 && BattleSystem_Random(battleSystem) & 1) {
                ret = 2;
            }
        }
    } else if (movePriority1 < movePriority2) {
        ret = 1;
    }

    return ret;
}

// Function may be mislabeled
void BattleSystem_ClearExperienceEarnFlags(BattleContext *ctx, int battlerId) {
    ctx->expEarnFlags[(battlerId >> 1) & 1] = 0;
}

void BattleSystem_SetExperienceEarnFlags(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    int i = 0;
    u32 battleType = BattleSystem_GetBattleType(battleSystem);

    while (i <= 2) {
        if (!(ctx->switchInFlag & MaskOfFlagNo(i)) && !(ctx->switchInFlag & MaskOfFlagNo(battlerId)) && ctx->battleMons[battlerId].hp) {
            ctx->expEarnFlags[(battlerId >> 1) & 1] |= MaskOfFlagNo(ctx->selectedMonIndex[i]);
        }
        i += 2;
        if (battleType == 0x4a || battleType == 0x4b) {
            break;
        }
    }
}

BOOL BattleSystem_TryDirectSideEffect(BattleSystem *battleSystem, BattleContext *ctx, int *out) {
    BOOL ret = FALSE;

    if (ctx->sideEffectFlagsDirect & (1 << 29)) {
        *out = GetMoveStatusChangeScript(ctx, 1, ctx->sideEffectFlagsDirect);
        ctx->sideEffectFlagsDirect = 0;
        if (!(ctx->moveStatusFlag & MOVE_STATUS_FAIL)) {
            ret = TRUE;
        }
    } else if (ctx->sideEffectFlagsDirect) {
        *out = GetMoveStatusChangeScript(ctx, 1, ctx->sideEffectFlagsDirect);
        if (ctx->battleMons[ctx->battlerIdStatChange].hp && (!(ctx->moveStatusFlag & MOVE_STATUS_FAIL) || ((ctx->sideEffectFlagsDirect & (1 << 23)) && (ctx->moveStatusFlag & 0x40008)) || ((ctx->sideEffectFlagsDirect & (1 << 28)) && (ctx->moveStatusFlag & 0x10001)))) {
            ret = TRUE;
        }
        ctx->sideEffectFlagsDirect = 0;
    }

    return ret;
}

BOOL BattleSystem_TryIndirectSideEffect(BattleSystem *battleSystem, BattleContext *ctx, int *out) {
    BOOL ret = FALSE;
    u16 effectChance;

    if (ctx->sideEffectFlagsIndirect & (1 << 29)) {
        *out = GetMoveStatusChangeScript(ctx, 2, ctx->sideEffectFlagsIndirect);
        ctx->sideEffectFlagsIndirect = 0;
        if (!(ctx->moveStatusFlag & MOVE_STATUS_FAIL)) {
            ret = TRUE;
        }
    } else if (ctx->sideEffectFlagsIndirect & (1 << 24)) {
        *out = GetMoveStatusChangeScript(ctx, 2, ctx->sideEffectFlagsIndirect);
        ctx->sideEffectFlagsIndirect = 0;
        if (!BattlerCheckSubstitute(ctx, ctx->battlerIdStatChange) && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL)) {
            ret = TRUE;
        }
    } else if (ctx->sideEffectFlagsIndirect & (1 << 25)) {
        *out = GetMoveStatusChangeScript(ctx, 2, ctx->sideEffectFlagsIndirect);
        ctx->sideEffectFlagsIndirect = 0;
        if (ctx->battleMons[ctx->battlerIdStatChange].hp && !BattlerCheckSubstitute(ctx, ctx->battlerIdStatChange) && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL)) {
            ret = TRUE;
        }
    } else if (ctx->sideEffectFlagsIndirect & (1 << 28)) {
        *out = GetMoveStatusChangeScript(ctx, 2, ctx->sideEffectFlagsIndirect);
        ctx->sideEffectFlagsIndirect = 0;
        if (ctx->battleMons[ctx->battlerIdStatChange].hp) {
            ret = TRUE;
        }
    } else if (ctx->sideEffectFlagsIndirect & (1 << 26)) {
        // the inclusion of serene grace here makes me think this function has to do with secondary move effects
        if (GetBattlerAbility(ctx, ctx->battlerIdAttacker) == ABILITY_SERENE_GRACE) {
            effectChance = ctx->trainerAIData.moveData[ctx->moveNoCur].effectChance * 2;
        } else {
            effectChance = ctx->trainerAIData.moveData[ctx->moveNoCur].effectChance;
        }

        GF_ASSERT(effectChance);

        if ((BattleSystem_Random(battleSystem) % 100) < effectChance) {
            ctx->battleStatus |= BATTLE_STATUS_SECONDARY_EFFECT;
        }
        *out = GetMoveStatusChangeScript(ctx, 2, ctx->sideEffectFlagsIndirect);
        ctx->sideEffectFlagsIndirect = 0;

        if (!ctx->battleMons[ctx->battlerIdStatChange].hp) {
            ctx->battleStatus &= ~BATTLE_STATUS_SECONDARY_EFFECT;
        }

        ret = TRUE;
    } else if (ctx->sideEffectFlagsIndirect) {
        // the inclusion of serene grace here makes me think this function has to do with secondary move effects
        if (GetBattlerAbility(ctx, ctx->battlerIdAttacker) == ABILITY_SERENE_GRACE) {
            effectChance = ctx->trainerAIData.moveData[ctx->moveNoCur].effectChance * 2;
        } else {
            effectChance = ctx->trainerAIData.moveData[ctx->moveNoCur].effectChance;
        }

        GF_ASSERT(effectChance);

        if ((BattleSystem_Random(battleSystem) % 100) < effectChance) {
            *out = GetMoveStatusChangeScript(ctx, 2, ctx->sideEffectFlagsIndirect);
            ctx->sideEffectFlagsIndirect = 0;

            if (ctx->battleMons[ctx->battlerIdStatChange].hp && !BattlerCheckSubstitute(ctx, ctx->battlerIdStatChange) && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL)) {
                ret = TRUE;
            }
        }
    } else if (ctx->sideEffectFlagsAbility) {
        *out = GetMoveStatusChangeScript(ctx, 3, ctx->sideEffectFlagsAbility);
        ctx->sideEffectFlagsAbility = 0;

        if (ctx->battleMons[ctx->battlerIdStatChange].hp) {
            ret = TRUE;
        }
    }

    return ret;
}

int BattleSystem_GetMoveTarget(BattleSystem *battleSystem, BattleContext *ctx, int battlerIdAttacker, u16 moveNo, int a4, int range) {
    int battlerIdTarget = BATTLER_NONE;
    int moveRange;

    if (moveNo) {
        moveRange = ctx->trainerAIData.moveData[moveNo].range;
    } else {
        moveRange = range;
    }

    if (moveRange == RANGE_ADJACENT_OPPONENTS) {
        int battlerId;
        int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);
        OpponentData *opponent = BattleSystem_GetOpponentData(battleSystem, battlerIdAttacker);
        u8 flag = OpponentData_GetBattlerType(opponent);

        for (ctx->moveTargetLoopIndex = 0; ctx->moveTargetLoopIndex < maxBattlers; ctx->moveTargetLoopIndex++) {
            battlerId = ctx->turnOrder[ctx->moveTargetLoopIndex];
            if (ctx->battleMons[battlerId].hp) {
                opponent = BattleSystem_GetOpponentData(battleSystem, battlerId);
                if (((flag & 1) && !(OpponentData_GetBattlerType(opponent) & 1)) || (!(flag & 1) && (OpponentData_GetBattlerType(opponent) & 1))) {
                    battlerIdTarget = battlerId;
                    break;
                }
            }
        }

        if (ctx->moveTargetLoopIndex != maxBattlers) {
            ctx->moveTargetLoopIndex++;
        }
    } else if (moveRange == RANGE_ALL_ADJACENT) {
        int battlerId;
        int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

        for (ctx->moveTargetLoopIndex = 0; ctx->moveTargetLoopIndex < maxBattlers; ctx->moveTargetLoopIndex++) {
            battlerId = ctx->turnOrder[ctx->moveTargetLoopIndex];
            if (ctx->battleMons[battlerId].hp) {
                if (battlerId != battlerIdAttacker) {
                    battlerIdTarget = battlerId;
                    break;
                }
            }
        }

        if (ctx->moveTargetLoopIndex != maxBattlers) {
            ctx->moveTargetLoopIndex++;
        }
    } else if (moveRange == RANGE_SINGLE_TARGET_USER_SIDE && (a4 == 1)) {
        int battleType = BattleSystem_GetBattleType(battleSystem);

        if ((battleType & BATTLE_TYPE_DOUBLES) && (BattleSystem_Random(battleSystem) % 2) == 0) {
            battlerIdTarget = BattleSystem_GetBattlerIdPartner(battleSystem, battlerIdAttacker);
            if (!ctx->battleMons[battlerIdTarget].hp) {
                battlerIdTarget = battlerIdAttacker;
            }
        } else {
            battlerIdTarget = battlerIdAttacker;
        }
    } else if (moveRange == RANGE_FRONT && (a4 == 1)) {
        battlerIdTarget = Battler_GetRandomOpposingBattlerId(battleSystem, ctx, battlerIdAttacker);
    } else if (moveRange == RANGE_OPPONENT_SIDE) {
        battlerIdTarget = Battler_GetRandomOpposingBattlerId(battleSystem, ctx, battlerIdAttacker);
    } else if (moveRange == RANGE_USER || moveRange == RANGE_USER_SIDE || moveRange == RANGE_SINGLE_TARGET_SPECIAL || moveRange == RANGE_FIELD) {
        battlerIdTarget = battlerIdAttacker;
    } else if (moveRange == RANGE_ALLY) {
        int battleType = BattleSystem_GetBattleType(battleSystem);

        if (battleType & BATTLE_TYPE_DOUBLES) {
            battlerIdTarget = BattleSystem_GetBattlerIdPartner(battleSystem, battlerIdAttacker);
        } else {
            battlerIdTarget = battlerIdAttacker;
        }
    } else if (moveRange == RANGE_SINGLE_TARGET_USER_SIDE) {
        int battleType = BattleSystem_GetBattleType(battleSystem);

        if (battleType & BATTLE_TYPE_DOUBLES) {
            battlerIdTarget = ctx->playerActions[battlerIdAttacker].battlerIdTarget;
            if (!ctx->battleMons[battlerIdTarget].hp) {
                battlerIdTarget = battlerIdAttacker;
            }
        } else {
            battlerIdTarget = battlerIdAttacker;
        }
    } else if (moveRange == RANGE_RANDOM_OPPONENT || a4 == 1) {
        int battleType = BattleSystem_GetBattleType(battleSystem);
        int side = BattleSystem_GetFieldSide(battleSystem, battlerIdAttacker) ^ 1;
        int battlerIdOpponents[2];
        battlerIdOpponents[0] = BattleSystem_GetOpponentBattler(battleSystem, battlerIdAttacker, 0);
        battlerIdOpponents[1] = BattleSystem_GetOpponentBattler(battleSystem, battlerIdAttacker, 2);

        if (battleType & BATTLE_TYPE_DOUBLES) {
            if (ctx->fieldSideConditionData[side].followMeFlag && ctx->battleMons[ctx->fieldSideConditionData[side].battlerIdFollowMe].hp) {
                battlerIdTarget = ctx->fieldSideConditionData[side].battlerIdFollowMe;
            } else if (ctx->battleMons[battlerIdOpponents[0]].hp && ctx->battleMons[battlerIdOpponents[1]].hp) {
                // This looks like targeting for Outrage in double battles
                side = BattleSystem_Random(battleSystem) & 1;
                battlerIdTarget = battlerIdOpponents[side];
            } else if (ctx->battleMons[battlerIdOpponents[0]].hp) {
                battlerIdTarget = battlerIdOpponents[0];
            } else if (ctx->battleMons[battlerIdOpponents[1]].hp) {
                battlerIdTarget = battlerIdOpponents[1];
            }
        } else if (ctx->battleMons[battlerIdAttacker ^ 1].hp) {
            battlerIdTarget = battlerIdAttacker ^ 1;
        }
    } else {
        int side = BattleSystem_GetFieldSide(battleSystem, battlerIdAttacker) ^ 1;
        int battlerIdTargetTemp = ctx->playerActions[battlerIdAttacker].battlerIdTarget;
        BattleSystem_GetMaxBattlers(battleSystem);

        if (ctx->fieldSideConditionData[side].followMeFlag && ctx->battleMons[ctx->fieldSideConditionData[side].battlerIdFollowMe].hp) {
            battlerIdTarget = ctx->fieldSideConditionData[side].battlerIdFollowMe;
        } else if (ctx->battleMons[battlerIdTargetTemp].hp) {
            battlerIdTarget = battlerIdTargetTemp;
        } else {
            battlerIdTargetTemp = Battler_GetRandomOpposingBattlerId(battleSystem, ctx, battlerIdAttacker);
            if (ctx->battleMons[battlerIdTargetTemp].hp) {
                battlerIdTarget = battlerIdTargetTemp;
            }
        }
    }

    return battlerIdTarget;
}

void BattleSystem_TryRedirectMoveTarget(BattleSystem *battleSystem, BattleContext *ctx, int battlerIdAttacker, u16 moveNo) {
    int side;
    int battlerId;
    int battlerIdTarget;
    int moveType;
    int maxBattlers;

    if (ctx->battlerIdTarget == BATTLER_NONE) {
        return;
    }

    if (GetBattlerAbility(ctx, battlerIdAttacker) == ABILITY_NORMALIZE || GetBattlerAbility(ctx, battlerIdAttacker) == ABILITY_MOLD_BREAKER) {
        return;
    }

    side = BattleSystem_GetFieldSide(battleSystem, battlerIdAttacker) ^ 1;

    if (ctx->fieldSideConditionData[side].followMeFlag && ctx->battleMons[ctx->fieldSideConditionData[side].battlerIdFollowMe].hp) {
        return;
    }

    moveType = GetDynamicMoveType(battleSystem, ctx, battlerIdAttacker, moveNo);
    if (!moveType) {
        moveType = ctx->trainerAIData.moveData[moveNo].type;
    }

    maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    if (moveType == TYPE_ELECTRIC && (ctx->trainerAIData.moveData[moveNo].range == RANGE_SINGLE_TARGET || ctx->trainerAIData.moveData[moveNo].range == RANGE_RANDOM_OPPONENT) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP_NOT_USER, battlerIdAttacker, ABILITY_LIGHTNINGROD)) {
        for (battlerId = 0; battlerId < maxBattlers; battlerId++) {
            battlerIdTarget = ctx->turnOrder[battlerId];
            if (GetBattlerAbility(ctx, battlerIdTarget) == ABILITY_LIGHTNINGROD && ctx->battleMons[battlerIdTarget].hp && battlerIdAttacker != battlerIdTarget) {
                break;
            }
        }
        if (battlerIdTarget != ctx->battlerIdTarget) {
            ctx->selfTurnData[battlerIdTarget].lightningRodFlag = TRUE;
            ctx->battlerIdTarget = battlerIdTarget;
        }
    } else if (moveType == TYPE_WATER && (ctx->trainerAIData.moveData[moveNo].range == RANGE_SINGLE_TARGET || ctx->trainerAIData.moveData[moveNo].range == RANGE_RANDOM_OPPONENT) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP_NOT_USER, battlerIdAttacker, ABILITY_STORM_DRAIN)) {
        for (battlerId = 0; battlerId < maxBattlers; battlerId++) {
            battlerIdTarget = ctx->turnOrder[battlerId];
            if (GetBattlerAbility(ctx, battlerIdTarget) == ABILITY_STORM_DRAIN && ctx->battleMons[battlerIdTarget].hp && battlerIdAttacker != battlerIdTarget) {
                break;
            }
        }
        if (battlerIdTarget != ctx->battlerIdTarget) {
            ctx->selfTurnData[battlerIdTarget].stormDrainFlag = TRUE;
            ctx->battlerIdTarget = battlerIdTarget;
        }
    }
}

BOOL BattleContext_TryRedirectAbility(BattleSystem *battleSystem, BattleContext *ctx) {
    BOOL ret = FALSE;

    if (!(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && ctx->selfTurnData[ctx->battlerIdTarget].lightningRodFlag) {
        ctx->selfTurnData[ctx->battlerIdTarget].lightningRodFlag = FALSE;
        ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, 180);
        ctx->commandNext = ctx->command;
        ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
        ret = TRUE;
    }

    if (!(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && ctx->selfTurnData[ctx->battlerIdTarget].stormDrainFlag) {
        ctx->selfTurnData[ctx->battlerIdTarget].stormDrainFlag = FALSE;
        ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, 180);
        ctx->commandNext = ctx->command;
        ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
        ret = TRUE;
    }

    return ret;
}

void CopyBattleMonToPartyMon(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {

    if (!ctx->battleMons[battlerId].item) {
        TrainerAIData_ClearHeldItem(ctx, battlerId);
    }

    BattleController_EmitBattleMonToPartyMonCopy(battleSystem, ctx, battlerId);
}

void LockBattlerIntoCurrentMove(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    ctx->battleMons[battlerId].status2 |= STATUS2_LOCKED_INTO_MOVE;
    ctx->moveNoLockedInto[battlerId] = ctx->moveNoCur;
}

void UnlockBattlerOutOfCurrentMove(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    ctx->battleMons[battlerId].status2 &= ~STATUS2_LOCKED_INTO_MOVE;
    ctx->battleMons[battlerId].status2 &= ~STATUS2_BIDE;
    ctx->battleMons[battlerId].moveEffectFlags &= 0xDFFBFF3F;
    ctx->battleMons[battlerId].moveEffectData.rolloutCount = 0;
    ctx->battleMons[battlerId].moveEffectData.furyCutterCount = 0;
}

int GetBattlerStatusCondition(BattleContext *ctx, int battlerId) {
    if (ctx->battleMons[battlerId].status & STATUS_SLEEP) {
        return CONDITION_SLEEP;
    } else if (ctx->battleMons[battlerId].status & STATUS_POISON) {
        return CONDITION_POISON;
    } else if (ctx->battleMons[battlerId].status & STATUS_BURN) {
        return CONDITION_BURN;
    } else if (ctx->battleMons[battlerId].status & STATUS_FREEZE) {
        return CONDITION_FREEZE;
    } else if (ctx->battleMons[battlerId].status & STATUS_PARALYSIS) {
        return CONDITION_PARALYSIS;
    } else if (ctx->battleMons[battlerId].status & STATUS_BAD_POISON) {
        return CONDITION_POISON;
    }

    return CONDITION_NONE;
}

BOOL CheckTrainerMessage(BattleSystem *battleSystem, BattleContext *ctx) {
    int state = BattleSystem_GetBattleType(battleSystem); // note: this should be battleType for the following three if statements, but it won't match if an additional variable is used
    int trainerIndex;

    if (state & (BATTLE_TYPE_FRONTIER | BATTLE_TYPE_LINK)) {
        return FALSE;
    }

    if (!(state & BATTLE_TYPE_TRAINER)) {
        return FALSE;
    }

    if (state & BATTLE_TYPE_DOUBLES) {
        return FALSE;
    }

    trainerIndex = BattleSystem_GetTrainerIndex(battleSystem, 1);
    state = 0;

    do {
        switch (state) {
        case 0:
            if (ctx->battleMons[1].hitCount == 1 && !(ctx->battleStatus2 & BATTLE_STATUS2_FIRST_DAMAGE_MESSAGE) && TrainerMessageWithIdPairExists(trainerIndex, TRMSG_HIT_POKE_FIRST_TIME, HEAP_ID_BATTLE)) {
                ctx->battleStatus2 |= BATTLE_STATUS2_FIRST_DAMAGE_MESSAGE;
                ctx->msgTemp = TRMSG_HIT_POKE_FIRST_TIME;
                return TRUE;
            }
            state++;
            break;
        case 1:
            if (!(ctx->battleMons[1].msgFlag & 2) && ctx->battleMons[1].hp <= ctx->battleMons[1].maxHp / 2 && TrainerMessageWithIdPairExists(trainerIndex, TRMSG_CURRENT_POKE_HALF, HEAP_ID_BATTLE)) {
                ctx->battleMons[1].msgFlag |= 2;
                ctx->msgTemp = TRMSG_CURRENT_POKE_HALF;
                return TRUE;
            }
            state++;
            break;
        case 2:
            if (!(ctx->battleMons[1].msgFlag & 3)) {
                int i;
                int aliveMons;
                Party *party;
                Pokemon *mon;

                party = BattleSystem_GetParty(battleSystem, 1);
                aliveMons = 0;

                for (i = 0; i < Party_GetCount(party); i++) {
                    mon = Party_GetMonByIndex(party, i);
                    if (GetMonData(mon, MON_DATA_HP, NULL)) {
                        aliveMons++;
                    }
                }
                if (aliveMons == 1 && TrainerMessageWithIdPairExists(trainerIndex, 15, HEAP_ID_BATTLE)) {
                    ctx->battleMons[1].msgFlag |= 3;
                    ctx->msgTemp = TRMSG_LAST_POKE;
                    return TRUE;
                }
            }
            state++;
            break;
        case 3:
            if (!(ctx->battleMons[1].msgFlag & 4)) {
                int i;
                int aliveMons;
                Party *party;
                Pokemon *mon;

                party = BattleSystem_GetParty(battleSystem, 1);
                aliveMons = 0;

                for (i = 0; i < Party_GetCount(party); i++) {
                    mon = Party_GetMonByIndex(party, i);
                    if (GetMonData(mon, MON_DATA_HP, NULL)) {
                        aliveMons++;
                    }
                }
                if (aliveMons == 1 && (ctx->battleMons[1].hp <= ctx->battleMons[1].maxHp / 2) && TrainerMessageWithIdPairExists(trainerIndex, 16, HEAP_ID_BATTLE)) {
                    ctx->battleMons[1].msgFlag |= 4;
                    ctx->msgTemp = TRMSG_LAST_POKE_HALF;
                    return TRUE;
                }
            }
            state++;
            break;
        case 4:
            break;
        }
    } while (state != 4);

    return FALSE;
}

// This is technically a correct function name but it doesn't account for the other battle context initilzation functions
// which init different parts of the struct, so this can be more descriptive once the variables are ID'd
void BattleContext_Init(BattleContext *ctx) {
    int battlerId;

    // related to damage calculation
    ctx->damage = 0;
    ctx->criticalMultiplier = 1;
    ctx->criticalCnt = 0;
    ctx->movePower = 0;
    ctx->powerMultiplier = 10;
    ctx->moveType = 0;
    ctx->moveAnimVariant = 0;
    ctx->moveStatusFlag = 0;

    ctx->battlerIdFainted = 0xFF;

    // related to statusing a mon..?
    ctx->sideEffectFlagsDirect = 0;
    ctx->sideEffectFlagsIndirect = 0;
    ctx->sideEffectFlagsAbility = 0;

    // related to stat changes
    ctx->statChangeType = 0;
    ctx->statChangeParam = 0;
    ctx->battlerIdStatChange = 0xFF;

    // related to multi hit moves
    ctx->multiHitCount = 0;
    ctx->multiHitCountTemp = 0;
    ctx->moveTargetLoopIndex = 0;
    ctx->multiHitLoop = 0;
    ctx->afterMoveMessageType = 0;
    ctx->moveCheckSkipFlags = 0;
    ctx->checkMultiHit = 0;

    // unidentified states for different state machines
    ctx->stateFieldConditionUpdate = 0;
    ctx->stateUpdateMonCondition = 0;
    ctx->stateUpdateFieldConditionExtra = 0;
    ctx->stateBeforeTurn = 0;
    ctx->attackerAfterMoveState = 0;
    ctx->afterMoveHitState = 0;
    ctx->afterMoveEffectState = 0;
    ctx->tryMoveState = 0;
    ctx->checkMoveHitState = 0;
    ctx->checkAttackerStatusState = 0;
    ctx->checkMoveImmunityState = 0;

    ctx->battleStatus &= 0xFF800000;
    ctx->battleStatus2 &= 0xFFFFFEA1;

    ctx->magnitude = 0;

    for (battlerId = 0; battlerId < 4; battlerId++) {
        MIi_CpuClearFast(0, (u32 *)&ctx->selfTurnData[battlerId], sizeof(SelfTurnData));
        ctx->aiSwitchedPartySlot[battlerId] = 6;
    }
}

void BattleContext_InitBattleStart(BattleSystem *battleSystem, BattleContext *ctx) {
    int battleType;

    for (int battlerId = 0; battlerId < 4; battlerId++) {
        ctx->moveNoHitBattler[battlerId] = 0xFF;
        ctx->switchMonIndex[battlerId] = 6;
        ctx->quickClawRandom[battlerId] = BattleSystem_Random(battleSystem);
    }

    ctx->prizeMoneyValue = 1;

    ctx->meFirstTotal = 1;

    battleType = BattleSystem_GetBattleType(battleSystem);

    if (!(battleType & BATTLE_TYPE_DOUBLES)) {
        ctx->switchInFlag |= MaskOfFlagNo(2);
        ctx->switchInFlag |= MaskOfFlagNo(3);
    }

    ctx->safariCatchRateStage = 6;
    ctx->safariRunAttempts = 6;
}

void InitSwitchWork(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    int i;
    int maxBattlers;
    u8 *data;
    MoveEffectData unkStruct = ctx->battleMons[battlerId].moveEffectData;

    maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);
    BattleSystem_GetBattleType(battleSystem);
    ctx->playerActions[battlerId].command = CONTROLLER_COMMAND_40;

    if (!(ctx->battleStatus & BATTLE_STATUS_BATON_PASS)) {
        for (i = 0; i < maxBattlers; i++) {
            if ((ctx->battleMons[i].status2 & STATUS2_MEAN_LOOK) && (ctx->battleMons[i].moveEffectData.battlerIdMeanLook == battlerId)) {
                ctx->battleMons[i].status2 &= ~STATUS2_MEAN_LOOK;
            }
            if ((ctx->battleMons[i].moveEffectFlags & MOVE_EFFECT_FLAG_LOCK_ON) && ctx->battleMons[i].moveEffectData.battlerIdLockOn == battlerId) {
                ctx->battleMons[i].moveEffectFlags &= ~MOVE_EFFECT_FLAG_LOCK_ON;
                ctx->battleMons[i].moveEffectData.battlerIdLockOn = 0;
            }
        }
        ctx->battleMons[battlerId].status2 = 0;
        ctx->battleMons[battlerId].moveEffectFlags = 0;
    } else { // baton pass
        ctx->battleMons[battlerId].status2 &= STATUS2_BATON_PASSABLE;
        ctx->battleMons[battlerId].moveEffectFlags &= MOVE_EFFECT_FLAG_BATON_PASSABLE;
        for (i = 0; i < maxBattlers; i++) {
            if ((ctx->battleMons[i].moveEffectFlags & MOVE_EFFECT_FLAG_LOCK_ON) && ctx->battleMons[i].moveEffectData.battlerIdLockOn == battlerId) {
                ctx->battleMons[i].moveEffectFlags &= ~MOVE_EFFECT_FLAG_LOCK_ON;
                ctx->battleMons[i].moveEffectFlags |= MOVE_EFFECT_FLAG_LOCK_ON_SET;
            }
        }
    }

    for (i = 0; i < maxBattlers; i++) {
        if (ctx->battleMons[i].status2 & (MaskOfFlagNo(battlerId) << STATUS2_ATTRACT_SHIFT)) {
            ctx->battleMons[i].status2 &= (MaskOfFlagNo(battlerId) << STATUS2_ATTRACT_SHIFT) ^ 0xFFFFFFFF;
        }
        if ((ctx->battleMons[i].status2 & STATUS2_BIND) && ctx->battleMons[i].moveEffectData.battlerIdBinding == battlerId) {
            ctx->battleMons[i].status2 &= ~STATUS2_BIND;
        }
    }

    data = (u8 *)&ctx->battleMons[battlerId].moveEffectData;
    for (i = 0; i < sizeof(MoveEffectData); i++) {
        data[i] = 0;
    }

    if (ctx->battleStatus & BATTLE_STATUS_BATON_PASS) {
        ctx->battleMons[battlerId].moveEffectData.substituteHp = unkStruct.substituteHp;
        ctx->battleMons[battlerId].moveEffectData.battlerIdLockOn = unkStruct.battlerIdLockOn;
        ctx->battleMons[battlerId].moveEffectData.perishSongTurns = unkStruct.perishSongTurns;
        ctx->battleMons[battlerId].moveEffectData.battlerIdMeanLook = unkStruct.battlerIdMeanLook;
        ctx->battleMons[battlerId].moveEffectData.magnetRiseTurns = unkStruct.magnetRiseTurns;
        ctx->battleMons[battlerId].moveEffectData.embargoFlag = unkStruct.embargoFlag;
        ctx->battleMons[battlerId].moveEffectData.healBlockTurns = unkStruct.healBlockTurns;
    }

    ctx->battleMons[battlerId].moveEffectData.fakeOutCount = ctx->totalTurns + 1;
    ctx->battleMons[battlerId].moveEffectData.slowStartTurns = ctx->totalTurns + 1;
    ctx->battleMons[battlerId].moveEffectData.truantFlag = (ctx->totalTurns + 1) & 1;

    ctx->moveNoProtect[battlerId] = 0;
    ctx->moveNoHit[battlerId] = 0;
    ctx->moveNoHitBattler[battlerId] = 0xFF;
    ctx->moveNoHitType[battlerId] = 0;
    ctx->moveNoBattlerPrev[battlerId] = 0;
    ctx->moveNoCopied[battlerId] = 0;
    ctx->moveNoCopiedHit[battlerId][0] = 0;
    ctx->moveNoCopiedHit[battlerId][1] = 0;
    ctx->moveNoCopiedHit[battlerId][2] = 0;
    ctx->moveNoCopiedHit[battlerId][3] = 0;
    ctx->moveNoSketch[battlerId] = 0;
    ctx->conversion2Move[battlerId] = 0;
    ctx->conversion2BattlerId[battlerId] = 0;
    ctx->conversion2Type[battlerId] = 0;
    ctx->moveNoMetronome[battlerId] = 0;

    ctx->fieldCondition &= (MaskOfFlagNo(battlerId) << 8) ^ 0xFFFFFFFF; //??

    if (ctx->battleMons[battlerId].moveEffectFlags & MOVE_EFFECT_FLAG_POWER_TRICK) {
        i = ctx->battleMons[battlerId].atk;
        ctx->battleMons[battlerId].atk = ctx->battleMons[battlerId].def;
        ctx->battleMons[battlerId].def = i;
    }

    for (i = 0; i < maxBattlers; i++) {
        if (i != battlerId && BattleSystem_GetFieldSide(battleSystem, i) != BattleSystem_GetFieldSide(battleSystem, battlerId)) {
            ctx->moveNoCopied[i] = 0;
        }
        ctx->moveNoCopiedHit[i][battlerId] = 0;
    }

    TrainerAIData_ClearMoves(ctx, battlerId);
    TrainerAIData_ClearAbility(ctx, battlerId);
    TrainerAIData_ClearHeldItem(ctx, battlerId);
}

void InitFaintedWork(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    int i;
    int maxBattlers;
    u8 *data;

    maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    for (int stat = 0; stat < 8; stat++) {
        ctx->battleMons[battlerId].statChanges[stat] = 6;
    }

    ctx->battleMons[battlerId].status2 = 0;
    ctx->battleMons[battlerId].moveEffectFlags = 0;

    for (i = 0; i < maxBattlers; i++) {
        if ((ctx->battleMons[i].status2 & STATUS2_MEAN_LOOK) && ctx->battleMons[i].moveEffectData.battlerIdMeanLook == battlerId) {
            ctx->battleMons[i].status2 &= ~STATUS2_MEAN_LOOK;
        }
        if (ctx->battleMons[i].status2 & (MaskOfFlagNo(battlerId) << STATUS2_ATTRACT_SHIFT)) {
            ctx->battleMons[i].status2 &= (MaskOfFlagNo(battlerId) << STATUS2_ATTRACT_SHIFT) ^ 0xFFFFFFFF;
        }
        if ((ctx->battleMons[i].status2 & STATUS2_BIND) && ctx->battleMons[i].moveEffectData.battlerIdBinding == battlerId) {
            ctx->battleMons[i].status2 &= STATUS2_BIND ^ 0xFFFFFFFF;
        }
    }

    data = (u8 *)&ctx->battleMons[battlerId].moveEffectData;
    for (i = 0; i < sizeof(MoveEffectData); i++) {
        data[i] = 0;
    }

    data = (u8 *)&ctx->turnData[battlerId];
    for (i = 0; i < sizeof(TurnData); i++) {
        data[i] = 0;
    }

    ctx->battleMons[battlerId].moveEffectData.fakeOutCount = ctx->totalTurns + 1;
    ctx->battleMons[battlerId].moveEffectData.slowStartTurns = ctx->totalTurns + 1;
    ctx->battleMons[battlerId].moveEffectData.truantFlag = (ctx->totalTurns + 1) & 1;

    ctx->moveNoProtect[battlerId] = 0;
    ctx->moveNoHit[battlerId] = 0;
    ctx->moveNoHitBattler[battlerId] = 0xFF;
    ctx->moveNoHitType[battlerId] = 0;
    ctx->moveNoBattlerPrev[battlerId] = 0;
    ctx->moveNoCopied[battlerId] = 0;
    ctx->moveNoCopiedHit[battlerId][0] = 0;
    ctx->moveNoCopiedHit[battlerId][1] = 0;
    ctx->moveNoCopiedHit[battlerId][2] = 0;
    ctx->moveNoCopiedHit[battlerId][3] = 0;
    ctx->moveNoSketch[battlerId] = 0;
    ctx->conversion2Move[battlerId] = 0;
    ctx->conversion2BattlerId[battlerId] = 0;
    ctx->conversion2Type[battlerId] = 0;
    ctx->moveNoMetronome[battlerId] = 0;

    ctx->fieldCondition &= (MaskOfFlagNo(battlerId) << 8) ^ 0xFFFFFFFF; //??

    for (i = 0; i < maxBattlers; i++) {
        if (i != battlerId && BattleSystem_GetFieldSide(battleSystem, i) != BattleSystem_GetFieldSide(battleSystem, battlerId)) {
            ctx->moveNoCopied[i] = 0;
        }
        ctx->moveNoCopiedHit[i][battlerId] = 0;
    }

    ctx->showPartyFlags[battlerId] &= ~1;

    TrainerAIData_ClearMoves(ctx, battlerId);
    TrainerAIData_ClearAbility(ctx, battlerId);
    TrainerAIData_ClearHeldItem(ctx, battlerId);
}

// BattleContext_InitTurnData..? BattleContext_InitStartTurn..?
void BattleContext_ResetTurnData(BattleSystem *battleSystem, BattleContext *ctx) {
    int battlerId;

    for (battlerId = 0; battlerId < 4; battlerId++) {
        MIi_CpuClearFast(0, (u32 *)&ctx->turnData[battlerId], sizeof(TurnData));
        MIi_CpuClearFast(0, (u32 *)&ctx->moveFail[battlerId], sizeof(MoveFailFlags));
        ctx->battleMons[battlerId].status2 &= ~STATUS2_FLINCH;
        if (ctx->battleMons[battlerId].moveEffectData.rechargeCount + 1 < ctx->totalTurns) {
            ctx->battleMons[battlerId].status2 &= ~STATUS2_RECHARGE;
        }
        if ((ctx->battleMons[battlerId].status & STATUS_SLEEP) && (ctx->battleMons[battlerId].status2 & STATUS2_LOCKED_INTO_MOVE)) {
            UnlockBattlerOutOfCurrentMove(battleSystem, ctx, battlerId);
        }
        if ((ctx->battleMons[battlerId].status & STATUS_SLEEP) && (ctx->battleMons[battlerId].status2 & STATUS2_RAMPAGE)) {
            ctx->battleMons[battlerId].status2 &= ~STATUS2_RAMPAGE;
        }
    }

    ctx->fieldSideConditionData[0].followMeFlag = 0;
    ctx->fieldSideConditionData[1].followMeFlag = 0;
}

u32 StruggleCheck(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, u32 nonSelectableMoves, u32 struggleCheckFlags) {
    int movePos;
    int item = GetBattlerHeldItemEffect(ctx, battlerId);

    for (movePos = 0; movePos < 4; movePos++) {
        if (!(ctx->battleMons[battlerId].moves[movePos]) && (struggleCheckFlags & STRUGGLE_CHECK_NO_MOVES)) {
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if (!(ctx->battleMons[battlerId].movePPCur[movePos]) && (struggleCheckFlags & STRUGGLE_CHECK_NO_PP)) {
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if ((ctx->battleMons[battlerId].moves[movePos] == ctx->battleMons[battlerId].moveEffectData.disabledMove) && (struggleCheckFlags & STRUGGLE_CHECK_DISABLED)) {
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if ((ctx->battleMons[battlerId].moves[movePos] == ctx->moveNoBattlerPrev[battlerId]) && (struggleCheckFlags & STRUGGLE_CHECK_TORMENT) && (ctx->battleMons[battlerId].status2 & STATUS2_TORMENT)) {
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if (ctx->battleMons[battlerId].moveEffectData.tauntTurns && (struggleCheckFlags & STRUGGLE_CHECK_TAUNT) && !(ctx->trainerAIData.moveData[ctx->battleMons[battlerId].moves[movePos]].power)) {
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if (BattleContext_CheckMoveImprisoned(battleSystem, ctx, battlerId, ctx->battleMons[battlerId].moves[movePos]) && (struggleCheckFlags & STRUGGLE_CHECK_IMPRISON)) {
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if (BattleContext_CheckMoveUnuseableInGravity(battleSystem, ctx, battlerId, ctx->battleMons[battlerId].moves[movePos]) && (struggleCheckFlags & STRUGGLE_CHECK_GRAVITY)) {
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if (BattleContext_CheckMoveHealBlocked(battleSystem, ctx, battlerId, ctx->battleMons[battlerId].moves[movePos]) && (struggleCheckFlags & STRUGGLE_CHECK_HEAL_BLOCK)) {
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if ((ctx->battleMons[battlerId].moveEffectData.encoredMove) && (ctx->battleMons[battlerId].moveEffectData.encoredMove != ctx->battleMons[battlerId].moves[movePos])) {
            // BUG: The flag check for encore is missing in this if statement, though it's unclear if this effects anything functionally
            nonSelectableMoves |= MaskOfFlagNo(movePos);
        }
        if ((item == HOLD_EFFECT_CHOICE_ATK || item == HOLD_EFFECT_CHOICE_SPEED || item == HOLD_EFFECT_CHOICE_SPATK) && (struggleCheckFlags & STRUGGLE_CHECK_CHOICED)) {
            if (BattleMon_GetMoveIndex(&ctx->battleMons[battlerId], ctx->battleMons[battlerId].moveEffectData.moveNoChoice) == 4) {
                ctx->battleMons[battlerId].moveEffectData.moveNoChoice = 0;
            } else if (ctx->battleMons[battlerId].moveEffectData.moveNoChoice && ctx->battleMons[battlerId].moveEffectData.moveNoChoice != ctx->battleMons[battlerId].moves[movePos]) {
                nonSelectableMoves |= MaskOfFlagNo(movePos);
            }
        }
    }
    return nonSelectableMoves;
}

// Buffer messages related to being unable to select moves?
BOOL BattleContext_CheckMoveSelectable(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, int movePos, BattleMessage *msg) {
    BOOL ret = TRUE;

    if (StruggleCheck(battleSystem, ctx, battlerId, 0, STRUGGLE_CHECK_DISABLED) & MaskOfFlagNo(movePos)) {
        msg->tag = TAG_NICKNAME_MOVE;
        msg->id = msg_0197_00609;
        msg->param[0] = CreateNicknameTag(ctx, battlerId);
        msg->param[1] = ctx->battleMons[battlerId].moves[movePos];
        ret = FALSE;
    } else if (StruggleCheck(battleSystem, ctx, battlerId, 0, STRUGGLE_CHECK_TORMENT) & MaskOfFlagNo(movePos)) {
        msg->tag = TAG_NICKNAME;
        msg->id = msg_0197_00612;
        msg->param[0] = CreateNicknameTag(ctx, battlerId);
        ret = FALSE;
    } else if (StruggleCheck(battleSystem, ctx, battlerId, 0, STRUGGLE_CHECK_TAUNT) & MaskOfFlagNo(movePos)) {
        msg->tag = TAG_NICKNAME_MOVE;
        msg->id = msg_0197_00613;
        msg->param[0] = CreateNicknameTag(ctx, battlerId);
        msg->param[1] = ctx->battleMons[battlerId].moves[movePos];
        ret = FALSE;
    } else if (StruggleCheck(battleSystem, ctx, battlerId, 0, STRUGGLE_CHECK_IMPRISON) & MaskOfFlagNo(movePos)) {
        msg->tag = TAG_NICKNAME_MOVE;
        msg->id = msg_0197_00616;
        msg->param[0] = CreateNicknameTag(ctx, battlerId);
        msg->param[1] = ctx->battleMons[battlerId].moves[movePos];
        ret = FALSE;
    } else if (StruggleCheck(battleSystem, ctx, battlerId, 0, STRUGGLE_CHECK_GRAVITY) & MaskOfFlagNo(movePos)) {
        msg->tag = TAG_NICKNAME_MOVE;
        msg->id = msg_0197_01001;
        msg->param[0] = CreateNicknameTag(ctx, battlerId);
        msg->param[1] = ctx->battleMons[battlerId].moves[movePos];
        ret = FALSE;
    } else if (StruggleCheck(battleSystem, ctx, battlerId, 0, STRUGGLE_CHECK_HEAL_BLOCK) & MaskOfFlagNo(movePos)) {
        msg->tag = TAG_NICKNAME_MOVE_MOVE;
        msg->id = msg_0197_01057;
        msg->param[0] = CreateNicknameTag(ctx, battlerId);
        msg->param[1] = MOVE_HEAL_BLOCK;
        msg->param[2] = ctx->battleMons[battlerId].moves[movePos];
        ret = FALSE;
    } else if (StruggleCheck(battleSystem, ctx, battlerId, 0, STRUGGLE_CHECK_CHOICED) & MaskOfFlagNo(movePos)) {
        msg->tag = TAG_ITEM_MOVE;
        msg->id = msg_0197_00911;
        msg->param[0] = ctx->battleMons[battlerId].item;
        msg->param[1] = ctx->battleMons[battlerId].moveEffectData.moveNoChoice;
        ret = FALSE;
    } else if (StruggleCheck(battleSystem, ctx, battlerId, 0, STRUGGLE_CHECK_NO_PP) & MaskOfFlagNo(movePos)) {
        msg->tag = TAG_NONE;
        msg->id = msg_0197_00823;
        ret = FALSE;
    }

    return ret;
}

int BattleMon_GetMoveIndex(BattleMon *mon, u16 moveNo) {
    int movePos;

    for (movePos = 0; movePos < 4; movePos++) {
        if (mon->moves[movePos] == moveNo) {
            break;
        }
    }

    return movePos;
}

enum {
    TYPETABLE_ATTACKER,
    TYPETABLE_DEFENDER,
    TYPETABLE_EFFECT,
};

static const u8 sTypeEffectiveness[][3] = {
    { TYPE_NORMAL,    TYPE_ROCK,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_NORMAL,    TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIRE,      TYPE_FIRE,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIRE,      TYPE_WATER,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIRE,      TYPE_GRASS,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FIRE,      TYPE_ICE,       TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FIRE,      TYPE_BUG,       TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FIRE,      TYPE_ROCK,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIRE,      TYPE_DRAGON,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIRE,      TYPE_STEEL,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_WATER,     TYPE_FIRE,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_WATER,     TYPE_WATER,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_WATER,     TYPE_GRASS,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_WATER,     TYPE_GROUND,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_WATER,     TYPE_ROCK,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_WATER,     TYPE_DRAGON,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ELECTRIC,  TYPE_WATER,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ELECTRIC,  TYPE_ELECTRIC,  TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ELECTRIC,  TYPE_GRASS,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ELECTRIC,  TYPE_GROUND,    TYPE_MUL_NO_EFFECT       },
    { TYPE_ELECTRIC,  TYPE_FLYING,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ELECTRIC,  TYPE_DRAGON,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GRASS,     TYPE_FIRE,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GRASS,     TYPE_WATER,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_GRASS,     TYPE_GRASS,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GRASS,     TYPE_POISON,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GRASS,     TYPE_GROUND,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_GRASS,     TYPE_FLYING,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GRASS,     TYPE_BUG,       TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GRASS,     TYPE_ROCK,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_GRASS,     TYPE_DRAGON,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GRASS,     TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ICE,       TYPE_WATER,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ICE,       TYPE_GRASS,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ICE,       TYPE_ICE,       TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ICE,       TYPE_GROUND,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ICE,       TYPE_FLYING,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ICE,       TYPE_DRAGON,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ICE,       TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ICE,       TYPE_FIRE,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIGHTING,  TYPE_NORMAL,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FIGHTING,  TYPE_ICE,       TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FIGHTING,  TYPE_POISON,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIGHTING,  TYPE_FLYING,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIGHTING,  TYPE_PSYCHIC,   TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIGHTING,  TYPE_BUG,       TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FIGHTING,  TYPE_ROCK,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FIGHTING,  TYPE_DARK,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FIGHTING,  TYPE_STEEL,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_POISON,    TYPE_GRASS,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_POISON,    TYPE_POISON,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_POISON,    TYPE_GROUND,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_POISON,    TYPE_ROCK,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_POISON,    TYPE_GHOST,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_POISON,    TYPE_STEEL,     TYPE_MUL_NO_EFFECT       },
    { TYPE_GROUND,    TYPE_FIRE,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_GROUND,    TYPE_ELECTRIC,  TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_GROUND,    TYPE_GRASS,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GROUND,    TYPE_POISON,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_GROUND,    TYPE_FLYING,    TYPE_MUL_NO_EFFECT       },
    { TYPE_GROUND,    TYPE_BUG,       TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GROUND,    TYPE_ROCK,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_GROUND,    TYPE_STEEL,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FLYING,    TYPE_ELECTRIC,  TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FLYING,    TYPE_GRASS,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FLYING,    TYPE_FIGHTING,  TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FLYING,    TYPE_BUG,       TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_FLYING,    TYPE_ROCK,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FLYING,    TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_PSYCHIC,   TYPE_FIGHTING,  TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_PSYCHIC,   TYPE_POISON,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_PSYCHIC,   TYPE_PSYCHIC,   TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_PSYCHIC,   TYPE_DARK,      TYPE_MUL_NO_EFFECT       },
    { TYPE_PSYCHIC,   TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_BUG,       TYPE_FIRE,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_BUG,       TYPE_GRASS,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_BUG,       TYPE_FIGHTING,  TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_BUG,       TYPE_POISON,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_BUG,       TYPE_FLYING,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_BUG,       TYPE_PSYCHIC,   TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_BUG,       TYPE_GHOST,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_BUG,       TYPE_DARK,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_BUG,       TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ROCK,      TYPE_FIRE,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ROCK,      TYPE_ICE,       TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ROCK,      TYPE_FIGHTING,  TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ROCK,      TYPE_GROUND,    TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_ROCK,      TYPE_FLYING,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ROCK,      TYPE_BUG,       TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_ROCK,      TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GHOST,     TYPE_NORMAL,    TYPE_MUL_NO_EFFECT       },
    { TYPE_GHOST,     TYPE_PSYCHIC,   TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_GHOST,     TYPE_DARK,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GHOST,     TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_GHOST,     TYPE_GHOST,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_DRAGON,    TYPE_DRAGON,    TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_DRAGON,    TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_DARK,      TYPE_FIGHTING,  TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_DARK,      TYPE_PSYCHIC,   TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_DARK,      TYPE_GHOST,     TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_DARK,      TYPE_DARK,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_DARK,      TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_STEEL,     TYPE_FIRE,      TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_STEEL,     TYPE_WATER,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_STEEL,     TYPE_ELECTRIC,  TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_STEEL,     TYPE_ICE,       TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_STEEL,     TYPE_ROCK,      TYPE_MUL_SUPER_EFFECTIVE },
    { TYPE_STEEL,     TYPE_STEEL,     TYPE_MUL_NOT_EFFECTIVE   },
    { TYPE_FORESIGHT, TYPE_FORESIGHT, TYPE_MUL_NO_EFFECT       },
    { TYPE_NORMAL,    TYPE_GHOST,     TYPE_MUL_NO_EFFECT       },
    { TYPE_FIGHTING,  TYPE_GHOST,     TYPE_MUL_NO_EFFECT       },
    { TYPE_ENDTABLE,  TYPE_ENDTABLE,  TYPE_MUL_NO_EFFECT       }
};

// static
BOOL BattleSystem_IsTypeMatchupActive(BattleContext *ctx, int battlerIdAttacker, int battlerIdTarget, int index) {
    int item = GetBattlerHeldItemEffect(ctx, battlerIdTarget);
    BOOL ret = TRUE;

    if (item == HOLD_EFFECT_SPEED_DOWN_GROUNDED || (ctx->battleMons[battlerIdTarget].moveEffectFlags & MOVE_EFFECT_FLAG_INGRAIN)) {
        if (sTypeEffectiveness[index][1] == TYPE_FLYING && sTypeEffectiveness[index][2] == TYPE_MUL_NO_EFFECT) {
            ret = FALSE;
        }
    }

    if (ctx->turnData[battlerIdTarget].roostFlag && sTypeEffectiveness[index][1] == TYPE_FLYING) {
        ret = FALSE;
    }

    if (ctx->fieldCondition & FIELD_CONDITION_GRAVITY) {
        if (sTypeEffectiveness[index][1] == TYPE_FLYING && sTypeEffectiveness[index][2] == TYPE_MUL_NO_EFFECT) {
            ret = FALSE;
        }
    }

    if (ctx->battleMons[battlerIdTarget].moveEffectFlags & MOVE_EFFECT_FLAG_MIRACLE_EYE) {
        if (sTypeEffectiveness[index][1] == TYPE_DARK && sTypeEffectiveness[index][2] == TYPE_MUL_NO_EFFECT) {
            ret = FALSE;
        }
    }

    return ret;
}

int BattleSystem_ApplyTypeEffectiveness(BattleSystem *battleSystem, BattleContext *ctx, int moveNo, int moveTypeDefault, int battlerIdAttacker, int battlerIdTarget, int damage, u32 *moveStatusFlag) {
    int i;
    int seffectMod; // this variable is not used but is required to match
    u8 moveType;
    u32 movePower;
    u8 itemAttacker;
    u8 itemTarget;
    u8 extraAttacker;
    u8 extraTarget;

    seffectMod = 1;

    if (moveNo == MOVE_STRUGGLE) {
        return damage;
    }

    itemAttacker = GetBattlerHeldItemEffect(ctx, battlerIdAttacker);
    extraAttacker = GetHeldItemModifier(ctx, battlerIdAttacker, 0);
    itemTarget = GetBattlerHeldItemEffect(ctx, battlerIdTarget);
    extraTarget = GetHeldItemModifier(ctx, battlerIdTarget, 0);

    if (GetBattlerAbility(ctx, battlerIdAttacker) == ABILITY_NORMALIZE) {
        moveType = TYPE_NORMAL;
    } else if (moveTypeDefault) {
        moveType = moveTypeDefault;
    } else {
        moveType = ctx->trainerAIData.moveData[moveNo].type;
    }

    movePower = ctx->trainerAIData.moveData[moveNo].power;

    // STAB
    if (!(ctx->battleStatus & BATTLE_STATUS_IGNORE_TYPE_EFFECTIVENESS) && (GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_TYPE_1, NULL) == moveType || GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_TYPE_2, NULL) == moveType)) {
        if (GetBattlerAbility(ctx, battlerIdAttacker) == ABILITY_ADAPTABILITY) {
            damage *= 2;
        } else {
            damage = damage * 15 / 10;
        }
    }

    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_LEVITATE) == TRUE && moveType == TYPE_GROUND && itemTarget != HOLD_EFFECT_SPEED_DOWN_GROUNDED) {
        *moveStatusFlag |= MOVE_STATUS_LEVITATE_IMMUNE;
    } else if (ctx->battleMons[battlerIdTarget].moveEffectData.magnetRiseTurns && !(ctx->battleMons[battlerIdTarget].moveEffectFlags & MOVE_EFFECT_FLAG_INGRAIN) && moveType == TYPE_GROUND && itemTarget != HOLD_EFFECT_SPEED_DOWN_GROUNDED) {
        *moveStatusFlag |= MOVE_STATUS_MAGNET_RISE_IMMUNE;
    } else {
        i = 0;
        do {
            // &sTypeEffectiveness[i] -> spC
            if (sTypeEffectiveness[i][TYPETABLE_ATTACKER] == TYPE_FORESIGHT) {
                if ((ctx->battleMons[battlerIdTarget].status2 & STATUS2_FORESIGHT) || GetBattlerAbility(ctx, battlerIdAttacker) == ABILITY_SCRAPPY) {
                    break;
                } else {
                    i++;
                    continue;
                }
            }
            if (sTypeEffectiveness[i][TYPETABLE_ATTACKER] == moveType) {
                // sTypeEffectiveness[i][TYPETABLE_DEFENDER] -> sp10
                if (sTypeEffectiveness[i][TYPETABLE_DEFENDER] == GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_TYPE_1, NULL)) {
                    if (BattleSystem_IsTypeMatchupActive(ctx, battlerIdAttacker, battlerIdTarget, i) == TRUE) {
                        damage = ApplyTypeMultiplier(ctx, battlerIdAttacker, sTypeEffectiveness[i][TYPETABLE_EFFECT], damage, movePower, moveStatusFlag);
                        if (sTypeEffectiveness[i][TYPETABLE_EFFECT] == TYPE_MUL_SUPER_EFFECTIVE) {
                            seffectMod *= 2;
                        }
                    }
                }
                if (sTypeEffectiveness[i][TYPETABLE_DEFENDER] == GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_TYPE_2, NULL) && GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_TYPE_1, NULL) != GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_TYPE_2, NULL)) {
                    if (BattleSystem_IsTypeMatchupActive(ctx, battlerIdAttacker, battlerIdTarget, i) == TRUE) {
                        damage = ApplyTypeMultiplier(ctx, battlerIdAttacker, sTypeEffectiveness[i][TYPETABLE_EFFECT], damage, movePower, moveStatusFlag);
                        if (sTypeEffectiveness[i][TYPETABLE_EFFECT] == TYPE_MUL_SUPER_EFFECTIVE) {
                            seffectMod *= 2;
                        }
                    }
                }
            }
            i++;
        } while (sTypeEffectiveness[i][TYPETABLE_ATTACKER] != TYPE_ENDTABLE);
    }

    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_WONDER_GUARD) == TRUE && CheckChargeMoveHitTurn(ctx, moveNo) && (!(*moveStatusFlag & MOVE_STATUS_SUPER_EFFECTIVE) || ((*moveStatusFlag & MOVE_STATUS_ANY_EFFECTIVE) == MOVE_STATUS_ANY_EFFECTIVE)) && movePower) {
        *moveStatusFlag |= MOVE_STATUS_WONDER_GUARD_IMMUNE;
    } else if (!(ctx->battleStatus & BATTLE_STATUS_IGNORE_TYPE_EFFECTIVENESS) && !(ctx->battleStatus & BATTLE_STATUS_IGNORE_TYPE_IMMUNITY)) {
        if ((*moveStatusFlag & MOVE_STATUS_SUPER_EFFECTIVE) && movePower) {
            if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_FILTER) == TRUE || CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_SOLID_ROCK) == TRUE) {
                damage = DamageDivide(damage * 3, 4);
            }
            if (itemAttacker == HOLD_EFFECT_POWER_UP_SE) {
                damage = damage * (100 + extraAttacker) / 100;
            }
        }
        if ((*moveStatusFlag & MOVE_STATUS_NOT_VERY_EFFECTIVE) && movePower) {
            if (GetBattlerAbility(ctx, battlerIdAttacker) == ABILITY_TINTED_LENS) {
                damage *= 2;
            }
        }
    } else {
        *moveStatusFlag &= ~MOVE_STATUS_SUPER_EFFECTIVE;
        *moveStatusFlag &= ~MOVE_STATUS_NOT_VERY_EFFECTIVE;
    }

    return damage;
}

void CalcTypeEffectivenessFlags(BattleContext *ctx, int moveNo, int moveTypeDefault, int abilityAttacker, int abilityTarget, int item, int type1, int type2, u32 *moveStatusFlag) {
    int i;
    u8 moveType;

    if (moveNo == MOVE_STRUGGLE) {
        return;
    }

    if (abilityAttacker == ABILITY_NORMALIZE) {
        moveType = TYPE_NORMAL;
    } else if (moveTypeDefault) {
        moveType = moveTypeDefault;
    } else {
        moveType = ctx->trainerAIData.moveData[moveNo].type;
    }

    if (abilityAttacker != ABILITY_MOLD_BREAKER && abilityTarget == ABILITY_LEVITATE && moveType == TYPE_GROUND && !(ctx->fieldCondition & FIELD_CONDITION_GRAVITY) && item != HOLD_EFFECT_SPEED_DOWN_GROUNDED) {
        *moveStatusFlag |= MOVE_STATUS_NO_EFFECT;
    } else {
        i = 0;
        do {
            if (sTypeEffectiveness[i][0] == TYPE_FORESIGHT) {
                if (abilityAttacker == ABILITY_SCRAPPY) {
                    break;
                } else {
                    i++;
                    continue;
                }
            }
            if (sTypeEffectiveness[i][0] == moveType) {
                u8 monType = sTypeEffectiveness[i][1];
                if (type1 == monType && CheckFlyingImmunity(ctx, item, i) == TRUE) {
                    ApplyEffectivenessFlags(sTypeEffectiveness[i][2], moveStatusFlag);
                }
                if ((type2 == monType) && (type1 != type2) && CheckFlyingImmunity(ctx, item, i) == TRUE) {
                    ApplyEffectivenessFlags(sTypeEffectiveness[i][2], moveStatusFlag);
                }
            }
            i++;
        } while (sTypeEffectiveness[i][0] != TYPE_ENDTABLE);
    }

    if (abilityAttacker != ABILITY_MOLD_BREAKER && abilityTarget == ABILITY_WONDER_GUARD && CheckChargeMoveHitTurn(ctx, moveNo) && (!(*moveStatusFlag & MOVE_STATUS_SUPER_EFFECTIVE) || (*moveStatusFlag & MOVE_STATUS_ANY_EFFECTIVE) == MOVE_STATUS_ANY_EFFECTIVE)) {
        *moveStatusFlag |= MOVE_STATUS_NO_EFFECT;
    }
}

static BOOL CheckFlyingImmunity(BattleContext *ctx, int item, int index) {
    BOOL ret = TRUE;

    if (item == HOLD_EFFECT_SPEED_DOWN_GROUNDED && sTypeEffectiveness[index][1] == TYPE_FLYING && sTypeEffectiveness[index][2] == TYPE_MUL_NO_EFFECT) {
        ret = FALSE;
    }

    if (ctx->fieldCondition & FIELD_CONDITION_GRAVITY && sTypeEffectiveness[index][1] == TYPE_FLYING && sTypeEffectiveness[index][2] == TYPE_MUL_NO_EFFECT) {
        ret = FALSE;
    }

    return ret;
}

static void ApplyEffectivenessFlags(int effectiveness, u32 *moveStatusFlag) {
    switch (effectiveness) {
    case TYPE_MUL_NO_EFFECT:
        *moveStatusFlag |= MOVE_STATUS_NO_EFFECT;
        *moveStatusFlag &= ~MOVE_STATUS_NOT_VERY_EFFECTIVE;
        *moveStatusFlag &= ~MOVE_STATUS_SUPER_EFFECTIVE;
        break;
    case TYPE_MUL_NOT_EFFECTIVE:
        if (*moveStatusFlag & MOVE_STATUS_SUPER_EFFECTIVE) {
            *moveStatusFlag &= ~MOVE_STATUS_SUPER_EFFECTIVE;
        } else {
            *moveStatusFlag |= MOVE_STATUS_NOT_VERY_EFFECTIVE;
        }
        break;
    case TYPE_MUL_SUPER_EFFECTIVE:
        if (*moveStatusFlag & MOVE_STATUS_NOT_VERY_EFFECTIVE) {
            *moveStatusFlag &= ~MOVE_STATUS_NOT_VERY_EFFECTIVE;
        } else {
            *moveStatusFlag |= MOVE_STATUS_SUPER_EFFECTIVE;
        }
        break;
    }
}

BOOL BattleContext_HasMoveFailed(BattleContext *ctx, int battlerId) {
    if (ctx->moveFail[battlerId].paralysis || ctx->moveFail[battlerId].noEffect || ctx->moveFail[battlerId].imprison || ctx->moveFail[battlerId].infatuation || ctx->moveFail[battlerId].disabled || ctx->moveFail[battlerId].unk0_5 || ctx->moveFail[battlerId].flinch || ctx->moveFail[battlerId].gravity || ctx->moveFail[battlerId].confusion) {
        return TRUE;
    }
    return FALSE;
}

u8 GetMonsHitCount(BattleSystem *battleSystem, BattleContext *ctx, u32 flag, int battlerId) {
    int i;
    u8 cnt = 0;
    int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    switch (flag) {
    case 0:
        for (i = 0; i < maxBattlers; i++) {
            if (i != battlerId && ctx->battleMons[i].hp) {
                cnt++;
            }
        }
        break;
    case 1:
        for (i = 0; i < maxBattlers; i++) {
            if (BattleSystem_GetFieldSide(battleSystem, i) == BattleSystem_GetFieldSide(battleSystem, battlerId) && ctx->battleMons[i].hp) {
                cnt++;
            }
        }
        break;
    }
    return cnt;
}

int CreateNicknameTag(BattleContext *ctx, int battlerId) {
    return battlerId | (ctx->selectedMonIndex[battlerId] << 8);
}

u16 GetBattlerSelectedMove(BattleContext *ctx, int battlerId) {
    u16 moveNo = 0;

    if (ctx->playerActions[battlerId].inputSelection == BATTLE_INPUT_FIGHT && ctx->playerActions[battlerId].unk8) {
        moveNo = ctx->battleMons[battlerId].moves[ctx->playerActions[battlerId].unk8 - 1];
    }

    return moveNo;
}

int CheckAbilityActive(BattleSystem *battleSystem, BattleContext *ctx, int flag, int battlerId, int ability) {
    int cnt = 0;
    int i;
    int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    switch (flag) {
    case CHECK_ABILITY_SAME_SIDE:
        for (i = 0; i < maxBattlers; i++) {
            if (BattleSystem_GetFieldSide(battleSystem, i) == BattleSystem_GetFieldSide(battleSystem, battlerId) && GetBattlerAbility(ctx, i) == ability) {
                cnt++;
            }
        }
        break;
    case CHECK_ABILITY_SAME_SIDE_HP:
        for (i = 0; i < maxBattlers; i++) {
            if (BattleSystem_GetFieldSide(battleSystem, i) == BattleSystem_GetFieldSide(battleSystem, battlerId) && ctx->battleMons[i].hp && GetBattlerAbility(ctx, i) == ability) {
                cnt++;
            }
        }
        break;
    case CHECK_ABILITY_OPPOSING_SIDE:
        for (i = 0; i < maxBattlers; i++) {
            if (BattleSystem_GetFieldSide(battleSystem, i) != BattleSystem_GetFieldSide(battleSystem, battlerId) && GetBattlerAbility(ctx, i) == ability) {
                cnt++;
            }
        }
        break;
    case CHECK_ABILITY_OPPOSING_SIDE_HP:
        for (i = 0; i < maxBattlers; i++) {
            if (BattleSystem_GetFieldSide(battleSystem, i) != BattleSystem_GetFieldSide(battleSystem, battlerId) && ctx->battleMons[i].hp && GetBattlerAbility(ctx, i) == ability) {
                cnt++;
            }
        }
        break;
    case CHECK_ABILITY_OPPOSING_SIDE_HP_RET:
        for (i = 0; i < maxBattlers; i++) {
            if (BattleSystem_GetFieldSide(battleSystem, i) != BattleSystem_GetFieldSide(battleSystem, battlerId) && ctx->battleMons[i].hp && GetBattlerAbility(ctx, i) == ability) {
                cnt |= MaskOfFlagNo(i);
            }
        }
        break;
    case CHECK_ABILITY_ALL:
        for (i = 0; i < maxBattlers; i++) {
            if (GetBattlerAbility(ctx, i) == ability) {
                cnt++;
            }
        }
        break;
    case CHECK_ABILITY_ALL_NOT_USER:
        for (i = 0; i < maxBattlers; i++) {
            if (i != battlerId && GetBattlerAbility(ctx, i) == ability) {
                cnt++;
            }
        }
        break;
    case CHECK_ABILITY_ALL_NOT_USER_RET:
        for (i = 0; i < maxBattlers; i++) {
            if (i != battlerId && GetBattlerAbility(ctx, i) == ability) {
                cnt = i + 1;
                break;
            }
        }
        break;
    case CHECK_ABILITY_ALL_HP:
        for (i = 0; i < maxBattlers; i++) {
            if (GetBattlerAbility(ctx, i) == ability && ctx->battleMons[i].hp) {
                cnt++;
            }
        }
        break;
    case CHECK_ABILITY_ALL_HP_NOT_USER:
        for (i = 0; i < maxBattlers; i++) {
            if (i != battlerId && GetBattlerAbility(ctx, i) == ability && ctx->battleMons[i].hp) {
                cnt++;
            }
        }
        break;
    }

    return cnt;
}

// FIXME: Function name is wrong
BOOL BattleCtx_IsIdenticalToCurrentMove(BattleContext *ctx, int moveNo) {
    switch (ctx->trainerAIData.moveData[moveNo].effect) {
    case MOVE_EFFECT_BIDE:
    case MOVE_EFFECT_CHARGE_TURN_HIGH_CRIT:
    case MOVE_EFFECT_CHARGE_TURN_HIGH_CRIT_FLINCH:
    case MOVE_EFFECT_CHARGE_TURN_DEF_UP:
    case MOVE_EFFECT_151:
    case MOVE_EFFECT_FLY:
    case MOVE_EFFECT_DIVE:
    case MOVE_EFFECT_DIG:
    case MOVE_EFFECT_BOUNCE:
    case MOVE_EFFECT_SHADOW_FORCE:
        return TRUE;
    }
    return FALSE;
}

BOOL GetTypeEffectivnessData(BattleSystem *battleSystem, int index, u8 *typeMove, u8 *typeMon, u8 *eff) {
    BOOL ret = TRUE;

    if (index >= NELEMS(sTypeEffectiveness)) {
        index = BattleSystem_Random(battleSystem) % NELEMS(sTypeEffectiveness);
        ret = FALSE;
    }

    *typeMove = sTypeEffectiveness[index][0];
    *typeMon = sTypeEffectiveness[index][1];
    *eff = sTypeEffectiveness[index][2];

    return ret;
}

int CalculateTypeEffectiveness(u8 typeMove, u8 typeMon1, u8 typeMon2) {
    int i = 0;
    int damage = 40;

    do {
        if (sTypeEffectiveness[i][0] == typeMove) {
            if (sTypeEffectiveness[i][1] == typeMon1) {
                damage = damage * sTypeEffectiveness[i][2] / 10;
            }
            if (sTypeEffectiveness[i][1] == typeMon2 && typeMon1 != typeMon2) {
                damage = damage * sTypeEffectiveness[i][2] / 10;
            }
        }
        i++;
    } while (sTypeEffectiveness[i][0] != TYPE_ENDTABLE);

    return damage;
}

BOOL CheckMoveCallsOtherMove(u16 moveNo) {
    if (moveNo == MOVE_NONE || moveNo == MOVE_SLEEP_TALK || moveNo == MOVE_COPYCAT || moveNo == MOVE_ASSIST || moveNo == MOVE_ME_FIRST || moveNo == MOVE_MIRROR_MOVE || moveNo == MOVE_METRONOME) {
        return TRUE;
    }
    return FALSE;
}

BOOL CurseUserIsGhost(BattleContext *ctx, u16 moveNo, int battlerId) {
    return moveNo == MOVE_CURSE && (GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_1, NULL) == TYPE_GHOST || GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_2, NULL) == TYPE_GHOST);
}

BOOL CanStealHeldItem(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;
    int side = BattleSystem_GetFieldSide(battleSystem, battlerId);

    if (ctx->battleMons[battlerId].item && !(ctx->fieldSideConditionData[side].battlerBitKnockedOffItem & MaskOfFlagNo(ctx->selectedMonIndex[battlerId])) && !ItemIdIsMail(ctx->battleMons[battlerId].item)) {
        ret = TRUE;
    }

    return ret;
}

BOOL CanTrickHeldItem(BattleContext *ctx, int battlerId) {
    return !ItemIdIsMail(ctx->battleMons[battlerId].item);
}

BOOL WhirlwindCheck(BattleSystem *battleSystem, BattleContext *ctx) {
    BOOL ret = FALSE;

    if (ctx->battleMons[ctx->battlerIdAttacker].level >= ctx->battleMons[ctx->battlerIdTarget].level) {
        ret = TRUE;
    } else {
        int level = ((BattleSystem_Random(battleSystem) & 0xFF) * (ctx->battleMons[ctx->battlerIdAttacker].level + ctx->battleMons[ctx->battlerIdTarget].level) >> 8) + 1;

        if (level > ctx->battleMons[ctx->battlerIdTarget].level / 4) {
            ret = TRUE;
        }
    }

    return ret;
}

u8 GetBattlerAbility(BattleContext *ctx, int battlerId) {
    if ((ctx->battleMons[battlerId].moveEffectFlags & MOVE_EFFECT_FLAG_ABILITY_SUPPRESSED) && ctx->battleMons[battlerId].ability != ABILITY_MULTITYPE) {
        return ABILITY_NONE;
    } else if ((ctx->fieldCondition & FIELD_CONDITION_GRAVITY) && ctx->battleMons[battlerId].ability == ABILITY_LEVITATE) {
        return ABILITY_NONE;
    } else if ((ctx->battleMons[battlerId].moveEffectFlags & MOVE_EFFECT_FLAG_INGRAIN) && ctx->battleMons[battlerId].ability == ABILITY_LEVITATE) {
        return ABILITY_NONE;
    } else {
        return ctx->battleMons[battlerId].ability;
    }
}

BOOL CheckBattlerAbilityIfNotIgnored(BattleContext *ctx, int battlerIdAttacker, int battlerIdTarget, int ability) {
    BOOL ret = FALSE;

    if (GetBattlerAbility(ctx, battlerIdAttacker) != ABILITY_MOLD_BREAKER) {
        if (GetBattlerAbility(ctx, battlerIdTarget) == ability) {
            ret = TRUE;
        }
    } else if (GetBattlerAbility(ctx, battlerIdTarget) == ability && !ctx->selfTurnData[battlerIdAttacker].moldBreakerFlag) {
        ctx->selfTurnData[battlerIdAttacker].moldBreakerFlag = TRUE;
        ctx->battleStatus |= BATTLE_STATUS_MOLD_BREAKER;
    }

    return ret;
}

BOOL CanSwitchMon(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret;
    Party *party;
    Pokemon *mon;
    int partySize;
    int cnt;
    int cntMax;
    int i;
    int start;
    int monIndex1;
    int monIndex2;
    u32 battleType;

    cnt = 0;
    ret = FALSE;
    battleType = BattleSystem_GetBattleType(battleSystem);
    party = BattleSystem_GetParty(battleSystem, battlerId);
    partySize = BattleSystem_GetPartySize(battleSystem, battlerId);

    if ((battleType & BATTLE_TYPE_MULTI) || ((battleType & BATTLE_TYPE_TAG) && (BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        start = 0;
        cntMax = 1;
        monIndex1 = ctx->selectedMonIndex[battlerId];
        monIndex2 = ctx->selectedMonIndex[battlerId];
    } else if (battleType & BATTLE_TYPE_DOUBLES) {
        start = 0;
        cntMax = 1;
        monIndex1 = ctx->selectedMonIndex[battlerId];
        monIndex2 = ctx->selectedMonIndex[BattleSystem_GetBattlerIdPartner(battleSystem, battlerId)];
    } else {
        start = 0;
        cntMax = 1;
        monIndex1 = ctx->selectedMonIndex[battlerId];
        monIndex2 = ctx->selectedMonIndex[battlerId];
    }

    for (i = start; i < partySize; i++) {
        mon = Party_GetMonByIndex(party, i);
        if (GetMonData(mon, MON_DATA_SPECIES, NULL) != SPECIES_NONE
            && !GetMonData(mon, MON_DATA_IS_EGG, NULL)
            && GetMonData(mon, MON_DATA_HP, NULL) != 0
            && monIndex1 != i
            && monIndex2 != i) {
            cnt++;
        }
    }
    if (cnt >= cntMax) {
        ret = TRUE;
    }
    return ret;
}

BOOL CantEscape(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, BattleMessage *msg) {
    int battlerIdAbility;
    int maxBattlers;
    u8 side;
    int item;
    u32 battleType;

    battleType = BattleSystem_GetBattleType(battleSystem);
    item = GetBattlerHeldItemEffect(ctx, battlerId);

    if (item == HOLD_EFFECT_FLEE || (battleType & BATTLE_TYPE_NO_EXP) || GetBattlerAbility(ctx, battlerId) == ABILITY_RUN_AWAY) {
        return FALSE;
    }

    side = BattleSystem_GetFieldSide(battleSystem, battlerId);
    maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    battlerIdAbility = CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP_NOT_USER, battlerId, ABILITY_SHADOW_TAG);
    if (battlerIdAbility && GetBattlerAbility(ctx, battlerId) != ABILITY_SHADOW_TAG) {
        if (msg == NULL) {
            return TRUE;
        }
        msg->tag = TAG_NICKNAME_ABILITY;
        msg->id = msg_0197_00039;
        msg->param[0] = CreateNicknameTag(ctx, battlerIdAbility);
        msg->param[1] = ABILITY_SHADOW_TAG;
        return TRUE;
    }

    battlerIdAbility = CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_OPPOSING_SIDE_HP, battlerId, ABILITY_ARENA_TRAP);
    if (battlerIdAbility) {
        if (!(ctx->fieldCondition & FIELD_CONDITION_GRAVITY) && item != HOLD_EFFECT_SPEED_DOWN_GROUNDED) {
            if (GetBattlerAbility(ctx, battlerId) != ABILITY_LEVITATE && !ctx->battleMons[battlerId].moveEffectData.magnetRiseTurns && GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_1, NULL) != TYPE_FLYING && GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_2, NULL) != TYPE_FLYING) {
                if (msg == NULL) {
                    return TRUE;
                }
                msg->tag = TAG_NICKNAME_ABILITY;
                msg->id = msg_0197_00039;
                msg->param[0] = CreateNicknameTag(ctx, battlerIdAbility);
                msg->param[1] = ABILITY_ARENA_TRAP;
                return TRUE;
            }
        } else {
            if (msg == NULL) {
                return TRUE;
            }
            msg->tag = TAG_NICKNAME_ABILITY;
            msg->id = msg_0197_00039;
            msg->param[0] = CreateNicknameTag(ctx, battlerIdAbility);
            msg->param[1] = ABILITY_ARENA_TRAP;
            return TRUE;
        }
    }

    battlerIdAbility = CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_OPPOSING_SIDE_HP, battlerId, ABILITY_MAGNET_PULL);
    if (battlerIdAbility && (GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_1, NULL) == TYPE_STEEL || GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_2, NULL) == TYPE_STEEL)) {
        if (msg == NULL) {
            return TRUE;
        }
        msg->tag = TAG_NICKNAME_ABILITY;
        msg->id = msg_0197_00039;
        msg->param[0] = CreateNicknameTag(ctx, battlerIdAbility);
        msg->param[1] = ABILITY_MAGNET_PULL;
        return TRUE;
    }

    if ((ctx->battleMons[battlerId].status2 & (STATUS2_BIND | STATUS2_MEAN_LOOK)) || (ctx->battleMons[battlerId].moveEffectFlags & MOVE_EFFECT_FLAG_INGRAIN)) {
        if (msg == NULL) {
            return TRUE;
        }
        msg->tag = TAG_NONE;
        msg->id = msg_0197_00794;
        return TRUE;
    }

    return FALSE;
}

BOOL BattleTryRun(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret;
    u8 run;
    int item;
    u32 battleType;

    battleType = BattleSystem_GetBattleType(battleSystem);
    item = GetBattlerHeldItemEffect(ctx, battlerId);
    ret = FALSE;

    if (item == HOLD_EFFECT_FLEE) {
        ctx->turnData[battlerId].runFlag = 1;
        ret = TRUE;
    } else if (battleType & BATTLE_TYPE_NO_EXP) {
        ret = TRUE;
    } else if (GetBattlerAbility(ctx, battlerId) == ABILITY_RUN_AWAY) {
        ctx->turnData[battlerId].runFlag = 2;
        ret = TRUE;
    } else {
        if (ctx->battleMons[battlerId].speed < ctx->battleMons[battlerId ^ 1].speed) {
            run = ctx->battleMons[battlerId].speed * 128 / ctx->battleMons[battlerId ^ 1].speed + ctx->runAttempts * 30;
            if (run > (BattleSystem_Random(battleSystem) % 256)) {
                ret = TRUE;
            }
        } else {
            ret = TRUE;
        }
        if (!ret) {
            BattleController_EmitIncrementGameStat(battleSystem, battlerId, 0, GAME_STAT_RUN_FAILURES);
        }
        ctx->runAttempts++;
    }
    return ret;
}

BOOL CheckTruant(BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;

    if (GetBattlerAbility(ctx, battlerId) == ABILITY_TRUANT) {
        if (ctx->battleMons[battlerId].moveEffectData.truantFlag != (ctx->totalTurns & 1)) {
            ret = TRUE;
        }
    }

    return ret;
}

BOOL BattleContext_CheckMoveImprisoned(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, int moveNo) {
    int maxBattlers;
    int side;
    int battlerIdCur;
    BOOL ret;
    int i;

    ret = FALSE;
    maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);
    side = BattleSystem_GetFieldSide(battleSystem, battlerId);

    for (battlerIdCur = 0; battlerIdCur < maxBattlers; battlerIdCur++) {
        if ((side != BattleSystem_GetFieldSide(battleSystem, battlerIdCur)) && (ctx->battleMons[battlerIdCur].moveEffectFlags & MOVE_EFFECT_FLAG_IMPRISON_USER)) {
            for (i = 0; i < MAX_MON_MOVES; i++) {
                if (moveNo == ctx->battleMons[battlerIdCur].moves[i]) {
                    break;
                }
            }
            if (i != MAX_MON_MOVES) {
                ret = TRUE;
            }
        }
    }

    return ret;
}

BOOL CheckMoveEffectOnField(BattleSystem *battleSystem, BattleContext *ctx, int moveEffect) {
    int battlerId;
    int maxBattlers;
    BOOL ret = FALSE;

    maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    for (battlerId = 0; battlerId < maxBattlers; battlerId++) {
        if (ctx->battleMons[battlerId].moveEffectFlags & moveEffect) {
            ret = TRUE;
            break;
        }
    }

    return ret;
}

void BattleContext_ResetMoveStatus(BattleSystem *battleSystem, BattleContext *ctx) {
    ctx->moveStatusFlag = 0;
    ctx->criticalMultiplier = 1;
    ctx->battleStatus &= (0x100000 ^ 0xFFFFFFFF);
}

void SortMonsBySpeed(BattleSystem *battleSystem, BattleContext *ctx) {
    int battlerId;
    int maxBattlers;
    int i, j;
    int temp1, temp2;

    maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    for (battlerId = 0; battlerId < maxBattlers; battlerId++) {
        ctx->turnOrder[battlerId] = battlerId;
    }
    for (i = 0; i < maxBattlers - 1; i++) {
        for (j = i + 1; j < maxBattlers; j++) {
            temp1 = ctx->turnOrder[i];
            temp2 = ctx->turnOrder[j];
            if (CheckSortSpeed(battleSystem, ctx, temp1, temp2, 1)) {
                ctx->turnOrder[i] = temp2;
                ctx->turnOrder[j] = temp1;
            }
        }
    }
}

static const u16 sGravityUnusableMoves[] = {
    MOVE_FLY,
    MOVE_BOUNCE,
    MOVE_JUMP_KICK,
    MOVE_HI_JUMP_KICK,
    MOVE_SPLASH,
    MOVE_MAGNET_RISE
};

BOOL BattleContext_CheckMoveUnuseableInGravity(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, int moveNo) {
    int i;
    BOOL ret = FALSE;

    if (ctx->fieldCondition & FIELD_CONDITION_GRAVITY) {
        for (i = 0; i < NELEMS(sGravityUnusableMoves); i++) {
            if (sGravityUnusableMoves[i] == moveNo) {
                ret = TRUE;
                break;
            }
        }
    }

    return ret;
}

static const u16 sHealBlockUnusableMoves[] = {
    MOVE_RECOVER,
    MOVE_SOFTBOILED,
    MOVE_REST,
    MOVE_MILK_DRINK,
    MOVE_MORNING_SUN,
    MOVE_SYNTHESIS,
    MOVE_MOONLIGHT,
    MOVE_SWALLOW,
    MOVE_HEAL_ORDER,
    MOVE_SLACK_OFF,
    MOVE_ROOST,
    MOVE_LUNAR_DANCE,
    MOVE_HEALING_WISH,
    MOVE_WISH
};

BOOL BattleContext_CheckMoveHealBlocked(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, int moveNo) {
    int i;
    BOOL ret = FALSE;

    if (ctx->battleMons[battlerId].moveEffectData.healBlockTurns) {
        for (i = 0; i < NELEMS(sHealBlockUnusableMoves); i++) {
            if (sHealBlockUnusableMoves[i] == moveNo) {
                ret = TRUE;
                break;
            }
        }
    }

    return ret;
}

void BattleContext_UpdateLastResortMoves(BattleSystem *battleSystem, BattleContext *ctx) {
    int i;

    if (ctx->moveNoTemp == MOVE_LAST_RESORT || ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.lastResortCount == MAX_MON_MOVES) {
        return;
    }

    for (i = 0; i < ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.lastResortCount; i++) {
        if (ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.lastResortMoves[i] == ctx->moveNoTemp) {
            return;
        }
    }

    ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.lastResortMoves[i] = ctx->moveNoTemp;
    ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.lastResortCount++;
}

int GetBattlerLearnedMoveCount(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    int cnt;

    for (cnt = 0; cnt < MAX_MON_MOVES; cnt++) {
        if (ctx->battleMons[battlerId].moves[cnt] == MOVE_NONE) {
            break;
        }
    }

    return cnt;
}

// BUG: There isn't a reason why this shouldn't be const, but it's located in .data and not .rodata
static u16 sSoundMoves[] = {
    MOVE_GROWL,
    MOVE_ROAR,
    MOVE_SING,
    MOVE_SUPERSONIC,
    MOVE_SCREECH,
    MOVE_SNORE,
    MOVE_UPROAR,
    MOVE_METAL_SOUND,
    MOVE_GRASS_WHISTLE,
    MOVE_HYPER_VOICE,
    MOVE_BUG_BUZZ,
    MOVE_CHATTER
};

int BattleContext_CheckMoveImmunityFromAbility(BattleContext *ctx, int battlerIdAttacker, int battlerIdTarget) {
    int script;
    int moveType;

    script = BATTLE_SUBSCRIPT_NONE;

    if (GetBattlerAbility(ctx, battlerIdAttacker) == ABILITY_NORMALIZE) {
        moveType = TYPE_NORMAL;
    } else if (ctx->moveType) {
        moveType = ctx->moveType;
    } else {
        moveType = ctx->trainerAIData.moveData[ctx->moveNoCur].type;
    }

    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_VOLT_ABSORB) == TRUE && moveType == TYPE_ELECTRIC && battlerIdAttacker != battlerIdTarget) {
        ctx->hpCalc = DamageDivide(ctx->battleMons[battlerIdTarget].maxHp, 4);
        script = BATTLE_SUBSCRIPT_ABILITY_RESTORES_HP;
    }

    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_WATER_ABSORB) == TRUE && moveType == TYPE_WATER && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && ctx->trainerAIData.moveData[ctx->moveNoCur].power) {
        ctx->hpCalc = DamageDivide(ctx->battleMons[battlerIdTarget].maxHp, 4);
        script = BATTLE_SUBSCRIPT_ABILITY_RESTORES_HP;
    }
    int moveNoCur = ctx->moveNoCur;
    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_FLASH_FIRE) == TRUE && moveType == TYPE_FIRE && !(ctx->battleMons[battlerIdTarget].status & STATUS_FREEZE) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN)) {
        if (ctx->trainerAIData.moveData[ctx->moveNoCur].power || ctx->moveNoCur == MOVE_WILL_O_WISP) {
            script = BATTLE_SUBSCRIPT_ABSORB_AND_BOOST_FIRE_TYPE_MOVES;
        }
    }
    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_SOUNDPROOF) == TRUE) {
        for (int i = 0; i < NELEMS(sSoundMoves); i++) {
            if (sSoundMoves[i] == ctx->moveNoCur) {
                script = BATTLE_SUBSCRIPT_BLOCKED_BY_SOUNDPROOF;
                break;
            }
        }
    }
    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_MOTOR_DRIVE) == TRUE && moveType == TYPE_ELECTRIC && battlerIdAttacker != battlerIdTarget) {
        script = BATTLE_SUBSCRIPT_ABSORB_AND_SPEED_UP_1_STAGE;
    }
    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_DRY_SKIN) == TRUE && moveType == TYPE_WATER && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && ctx->trainerAIData.moveData[ctx->moveNoCur].power) {
        ctx->hpCalc = DamageDivide(ctx->battleMons[battlerIdTarget].maxHp, 4);
        script = BATTLE_SUBSCRIPT_ABILITY_RESTORES_HP;
    }

    return script;
}

BOOL BattleContext_TryEndOfTurnAbility(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;
    int script;

    switch (GetBattlerAbility(ctx, battlerId)) {
    case ABILITY_SPEED_BOOST:
        if (ctx->battleMons[battlerId].hp && ctx->battleMons[battlerId].statChanges[3] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE && ctx->battleMons[battlerId].moveEffectData.fakeOutCount != ctx->totalTurns + 1) {
            ctx->statChangeParam = 17;
            ctx->statChangeType = 3;
            ctx->battlerIdStatChange = battlerId;
            script = BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE;
            ret = TRUE;
        }
        break;
    case ABILITY_SHED_SKIN:
        if ((ctx->battleMons[battlerId].status & STATUS_ALL) && ctx->battleMons[battlerId].hp && ((BattleSystem_Random(battleSystem) % 10) < 3)) {
            if (ctx->battleMons[battlerId].status & STATUS_SLEEP) {
                ctx->msgTemp = 0;
            } else if (ctx->battleMons[battlerId].status & STATUS_POISON_ALL) {
                ctx->msgTemp = 1;
            } else if (ctx->battleMons[battlerId].status & STATUS_BURN) {
                ctx->msgTemp = 2;
            } else if (ctx->battleMons[battlerId].status & STATUS_PARALYSIS) {
                ctx->msgTemp = 3;
            } else {
                ctx->msgTemp = 4;
            }
            ctx->battlerIdTemp = battlerId;
            script = BATTLE_SUBSCRIPT_ABILITY_RESTORE_STATUS;
            ret = TRUE;
        }
        break;
    default:
        break;
    }

    if (ret == TRUE) {
        ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, script);
        ctx->commandNext = ctx->command;
        ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
    }

    return ret;
}

int DamageDivide(int num, int denom) {
    int sign;

    if (num == 0) {
        return num;
    }

    if (num < 0) {
        sign = -1;
    } else {
        sign = 1;
    }

    num /= denom;

    if (num == 0) {
        num = sign;
    }

    return num;
}

int TryAbilityOnEntry(BattleSystem *battleSystem, BattleContext *ctx) {
    int i;
    int j;
    int script;
    BOOL flag;
    int battlerId;
    int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    script = BATTLE_SUBSCRIPT_NONE;
    flag = FALSE;

    do {
        switch (ctx->sendOutState) {
        case 0: // field weather
            if (!ctx->weatherCheckFlag) {
                switch (BattleSystem_GetWeather(battleSystem)) {
                case 1:
                case 2:
                case 3:
                    script = BATTLE_SUBSCRIPT_OVERWORLD_RAIN;
                    flag = TRUE;
                    break;
                case 4:
                case 5:
                case 6:
                    script = BATTLE_SUBSCRIPT_OVERWORLD_HAIL;
                    flag = TRUE;
                    break;
                case 7:
                    script = BATTLE_SUBSCRIPT_OVERWORLD_SAND;
                    flag = TRUE;
                    break;
                case 9:
                case 10:
                    script = BATTLE_SUBSCRIPT_OVERWORLD_FOG;
                    flag = TRUE;
                    break;
                case 1001:
                    script = BATTLE_SUBSCRIPT_OVERWORLD_SUN;
                    flag = TRUE;
                    break;
                case 1002:
                    script = BATTLE_SUBSCRIPT_OVERWORLD_TRICK_ROOM;
                    flag = TRUE;
                    break;
                default:
                    break;
                }
                if (flag == TRUE) {
                    ctx->weatherCheckFlag = TRUE;
                }
            }
            ctx->sendOutState++;
            break;
        case 1: // Trace
        {
            int battlerIdTargetR;
            int battlerIdTargetL;

            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                battlerIdTargetR = BattleSystem_GetOpponentBattler(battleSystem, battlerId, 0);
                battlerIdTargetL = BattleSystem_GetOpponentBattler(battleSystem, battlerId, 2);
                ctx->battlerIdLeechSeeded = ChooseTraceTarget(battleSystem, ctx, battlerIdTargetR, battlerIdTargetL);
                if (!ctx->battleMons[battlerId].traceFlag && ctx->battlerIdLeechSeeded != 0xFF && ctx->battleMons[battlerId].hp && ctx->battleMons[battlerId].item != ITEM_GRISEOUS_ORB && ctx->battleMons[ctx->battlerIdLeechSeeded].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_TRACE) {
                    ctx->battleMons[battlerId].traceFlag = TRUE;
                    ctx->battlerIdTemp = battlerId;
                    script = BATTLE_SUBSCRIPT_TRACE;
                    flag = TRUE;
                    break;
                }
            }
        }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 2: // Weather from abilities
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].sendOutFlag && ctx->battleMons[battlerId].hp) {
                    switch (GetBattlerAbility(ctx, battlerId)) {
                    case ABILITY_DRIZZLE:
                        ctx->battleMons[battlerId].sendOutFlag = TRUE;
                        if (!(ctx->fieldCondition & FIELD_CONDITION_RAIN_PERMANENT)) {
                            script = BATTLE_SUBSCRIPT_DRIZZLE;
                            flag = TRUE;
                        }
                        break;
                    case ABILITY_SAND_STREAM:
                        ctx->battleMons[battlerId].sendOutFlag = TRUE;
                        if (!(ctx->fieldCondition & FIELD_CONDITION_SANDSTORM_PERMANENT)) {
                            script = BATTLE_SUBSCRIPT_SAND_STREAM;
                            flag = TRUE;
                        }
                        break;
                    case ABILITY_DROUGHT:
                        ctx->battleMons[battlerId].sendOutFlag = TRUE;
                        if (!(ctx->fieldCondition & FIELD_CONDITION_SUN_PERMANENT)) {
                            script = BATTLE_SUBSCRIPT_DROUGHT;
                            flag = TRUE;
                        }
                        break;
                    case ABILITY_SNOW_WARNING:
                        ctx->battleMons[battlerId].sendOutFlag = TRUE;
                        if (!(ctx->fieldCondition & FIELD_CONDITION_HAIL_PERMANENT)) {
                            script = BATTLE_SUBSCRIPT_SNOW_WARNING;
                            flag = TRUE;
                        }
                        break;
                    }
                }
                if (flag == TRUE) {
                    ctx->battlerIdTemp = battlerId;
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 3: // Intimidate
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].intimidateFlag && ctx->battleMons[battlerId].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_INTIMIDATE) {
                    ctx->battleMons[battlerId].intimidateFlag = TRUE;
                    ctx->battlerIdTemp = battlerId;
                    script = BATTLE_SUBSCRIPT_INTIMIDATE;
                    flag = TRUE;
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 4: // Download
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].downloadFlag && ctx->battleMons[battlerId].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_DOWNLOAD) {
                    int battlerIdCheck;
                    int def = 0;
                    int spdef = 0;

                    for (battlerIdCheck = 0; battlerIdCheck < maxBattlers; battlerIdCheck++) {
                        if (BattleSystem_GetFieldSide(battleSystem, battlerId) != BattleSystem_GetFieldSide(battleSystem, battlerIdCheck) && !(ctx->battleMons[battlerIdCheck].status2 & STATUS2_SUBSTITUTE) && ctx->battleMons[battlerIdCheck].hp) {
                            def += ctx->battleMons[battlerIdCheck].def * sStatChangeTable[ctx->battleMons[battlerIdCheck].statChanges[2]][0] / sStatChangeTable[ctx->battleMons[battlerIdCheck].statChanges[2]][1];
                            spdef += ctx->battleMons[battlerIdCheck].spDef * sStatChangeTable[ctx->battleMons[battlerIdCheck].statChanges[5]][0] / sStatChangeTable[ctx->battleMons[battlerIdCheck].statChanges[5]][1];
                        }
                    }
                    ctx->battleMons[battlerId].downloadFlag = TRUE;
                    if (def + spdef != 0) {
                        if (def >= spdef) {
                            ctx->statChangeParam = 0x12;
                        } else {
                            ctx->statChangeParam = 0xF;
                        }
                        ctx->statChangeType = 3;
                        ctx->battlerIdStatChange = battlerId;
                        script = BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE;
                        flag = TRUE;
                        break;
                    }
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 5: // Anticipation
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].anticipationFlag && ctx->battleMons[battlerId].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_ANTICIPATION) {
                    ctx->battleMons[battlerId].anticipationFlag = TRUE;
                    int battlerIdCheck;
                    int index;
                    u16 moveNo;
                    u32 moveStatus;
                    for (battlerIdCheck = 0; battlerIdCheck < maxBattlers; battlerIdCheck++) {
                        if (BattleSystem_GetFieldSide(battleSystem, battlerId) != BattleSystem_GetFieldSide(battleSystem, battlerIdCheck) && ctx->battleMons[battlerIdCheck].hp) {
                            for (index = 0; index < MAX_MON_MOVES; index++) {
                                moveNo = ctx->battleMons[battlerIdCheck].moves[index];
                                if (moveNo) {
                                    moveStatus = 0;
                                    ctx->damage = BattleSystem_ApplyTypeEffectiveness(battleSystem, ctx, moveNo, 0, battlerIdCheck, battlerId, ctx->damage, &moveStatus);
                                    if (!(moveStatus & MOVE_STATUS_NO_EFFECT) && !IsFixedDamageMove(ctx, moveNo) && ((moveStatus & MOVE_STATUS_SUPER_EFFECTIVE) || (ctx->trainerAIData.moveData[moveNo].effect == MOVE_EFFECT_ONE_HIT_KO && ctx->battleMons[battlerId].level <= ctx->battleMons[battlerIdCheck].level))) {
                                        flag = TRUE;
                                        break;
                                    }
                                }
                            }
                            if (flag == TRUE) {
                                break;
                            }
                        }
                    }
                    if (flag == TRUE) {
                        ctx->battlerIdTemp = battlerId;
                        script = BATTLE_SUBSCRIPT_ANTICIPATION;
                    }
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 6: // forewarn
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].forewarnFlag && ctx->battleMons[battlerId].hp && (GetBattlerAbility(ctx, battlerId) == ABILITY_FOREWARN)) {
                    ctx->battleMons[battlerId].forewarnFlag = TRUE;
                    int battlerIdCheck;
                    int index;
                    u16 moveNo;
                    u32 power;
                    int hp;
                    u32 powerTemp;

                    powerTemp = 0;
                    hp = 0;

                    for (battlerIdCheck = 0; battlerIdCheck < maxBattlers; battlerIdCheck++) {
                        if (BattleSystem_GetFieldSide(battleSystem, battlerId) != BattleSystem_GetFieldSide(battleSystem, battlerIdCheck) && ctx->battleMons[battlerIdCheck].hp) {
                            hp += ctx->battleMons[battlerIdCheck].hp;
                            for (index = 0; index < MAX_MON_MOVES; index++) {
                                moveNo = ctx->battleMons[battlerIdCheck].moves[index];
                                power = ctx->trainerAIData.moveData[moveNo].power;
                                switch (power) {
                                case 1:
                                    switch (ctx->trainerAIData.moveData[moveNo].effect) {
                                    case MOVE_EFFECT_ONE_HIT_KO:
                                        if (powerTemp < 150 || (powerTemp == 150 && (BattleSystem_Random(battleSystem) & 1))) {
                                            powerTemp = 150;
                                            ctx->moveTemp = moveNo;
                                        }
                                        break;
                                    case MOVE_EFFECT_COUNTER:
                                    case MOVE_EFFECT_MIRROR_COAT:
                                    case MOVE_EFFECT_METAL_BURST:
                                        if (powerTemp < 120 || ((powerTemp == 120) && (BattleSystem_Random(battleSystem) & 1))) {
                                            powerTemp = 120;
                                            ctx->moveTemp = moveNo;
                                        }
                                        break;
                                    default:
                                        if (powerTemp < 80 || ((powerTemp == 80) && (BattleSystem_Random(battleSystem) & 1))) {
                                            powerTemp = 80;
                                            ctx->moveTemp = moveNo;
                                        }
                                        break;
                                    }
                                    break;
                                default:
                                    if (powerTemp < power || ((powerTemp == power) && (BattleSystem_Random(battleSystem) & 1))) {
                                        powerTemp = power;
                                        ctx->moveTemp = moveNo;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    if (powerTemp) {
                        ctx->battlerIdTemp = battlerId;
                        script = BATTLE_SUBSCRIPT_FOREWARN;
                        flag = TRUE;
                    } else if (hp) {
                        j = Battler_GetRandomOpposingBattlerId(battleSystem, ctx, battlerId);
                        index = GetBattlerLearnedMoveCount(battleSystem, ctx, j);
                        ctx->moveTemp = ctx->battleMons[j].moves[BattleSystem_Random(battleSystem) % index];
                        ctx->battlerIdTemp = battlerId;
                        script = BATTLE_SUBSCRIPT_FOREWARN;
                        flag = TRUE;
                    }
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 7: // Frisk
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].friskFlag && ctx->battleMons[battlerId].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_FRISK) {
                    ctx->battleMons[battlerId].friskFlag = TRUE;
                    if (BattleSystem_GetBattleType(battleSystem) & BATTLE_TYPE_DOUBLES) {
                        int battlerIdTargets[2];

                        battlerIdTargets[0] = BattleSystem_GetOpponentBattler(battleSystem, battlerId, 0);
                        battlerIdTargets[1] = BattleSystem_GetOpponentBattler(battleSystem, battlerId, 2);

                        if (ctx->battleMons[battlerIdTargets[0]].hp && ctx->battleMons[battlerIdTargets[0]].item && ctx->battleMons[battlerIdTargets[1]].hp && ctx->battleMons[battlerIdTargets[1]].item) {
                            ctx->itemTemp = ctx->battleMons[battlerIdTargets[BattleSystem_Random(battleSystem) & 1]].item;
                            flag = TRUE;
                        } else if (ctx->battleMons[battlerIdTargets[0]].hp && ctx->battleMons[battlerIdTargets[0]].item) {
                            ctx->itemTemp = ctx->battleMons[battlerIdTargets[0]].item;
                            flag = TRUE;
                        } else if (ctx->battleMons[battlerIdTargets[1]].hp && ctx->battleMons[battlerIdTargets[1]].item) {
                            ctx->itemTemp = ctx->battleMons[battlerIdTargets[1]].item;
                            flag = TRUE;
                        }
                    } else if (ctx->battleMons[battlerId ^ 1].hp && ctx->battleMons[battlerId ^ 1].item) {
                        ctx->itemTemp = ctx->battleMons[battlerId ^ 1].item;
                        flag = TRUE;
                    }
                }
                if (flag == TRUE) {
                    ctx->battlerIdTemp = battlerId;
                    script = BATTLE_SUBSCRIPT_FRISK;
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 8: // Slow Start
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].slowStartFlag && ctx->battleMons[battlerId].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_SLOW_START && ctx->totalTurns <= ctx->battleMons[battlerId].moveEffectData.slowStartTurns) {
                    ctx->battleMons[battlerId].slowStartFlag = TRUE;
                    ctx->battlerIdTemp = battlerId;
                    script = BATTLE_SUBSCRIPT_SLOW_START;
                    flag = TRUE;
                    break;
                }
                if (!ctx->battleMons[battlerId].slowStartEnded && ctx->battleMons[battlerId].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_SLOW_START && (ctx->totalTurns - ctx->battleMons[battlerId].moveEffectData.slowStartTurns) == 5) {
                    ctx->battleMons[battlerId].slowStartEnded = TRUE;
                    ctx->battlerIdTemp = battlerId;
                    script = BATTLE_SUBSCRIPT_SLOW_START_END;
                    flag = TRUE;
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 9: // Mold Breaker
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].moldBreakerFlag && ctx->battleMons[battlerId].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_MOLD_BREAKER) {
                    ctx->battleMons[battlerId].moldBreakerFlag = TRUE;
                    ctx->battlerIdTemp = battlerId;
                    script = BATTLE_SUBSCRIPT_MOLD_BREAKER;
                    flag = TRUE;
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 10: // Pressure
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (!ctx->battleMons[battlerId].pressureFlag && ctx->battleMons[battlerId].hp && GetBattlerAbility(ctx, battlerId) == ABILITY_PRESSURE) {
                    ctx->battleMons[battlerId].pressureFlag = TRUE;
                    ctx->battlerIdTemp = battlerId;
                    script = BATTLE_SUBSCRIPT_PRESSURE;
                    flag = TRUE;
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 11: // Air Lock and Cloud Nine
            if (Battler_CheckWeatherFormChange(battleSystem, ctx, &script) == TRUE) {
                flag = TRUE;
            } else {
                ctx->sendOutState++;
            }
            break;
        case BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE: // Amulet coin
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (GetItemVar(ctx, ctx->battleMons[battlerId].item, ITEM_VAR_HOLD_EFFECT) == HOLD_EFFECT_MONEY_UP) {
                    ctx->prizeMoneyValue = 2;
                }
            }
            ctx->sendOutState++;
            break;
        case 13: // Status healed on entry
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (CheckStatusHealAbility(battleSystem, ctx, battlerId, 1) == TRUE) {
                    script = BATTLE_SUBSCRIPT_ABILITY_FORBIDS_STATUS;
                    flag = TRUE;
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 14: // Held item activated on entry
            for (i = 0; i < maxBattlers; i++) {
                battlerId = ctx->turnOrder[i];
                if (CheckUseHeldItem(battleSystem, ctx, battlerId, (u32 *)&script) == TRUE) {
                    ctx->battlerIdTemp = battlerId;
                    flag = TRUE;
                    break;
                }
            }
            if (i == maxBattlers) {
                ctx->sendOutState++;
            }
            break;
        case 15: // end
            ctx->sendOutState = 0;
            flag = 2;
            break;
        }
    } while (!flag);

    return script;
}

int Battler_GetRandomOpposingBattlerId(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    u32 battleType;
    int battlerIdTarget;
    int battlerIdTargets[2];
    int i;

    battleType = BattleSystem_GetBattleType(battleSystem);

    if (battleType & BATTLE_TYPE_DOUBLES) {
        battlerIdTargets[0] = BattleSystem_GetOpponentBattler(battleSystem, battlerId, 0);
        battlerIdTargets[1] = BattleSystem_GetOpponentBattler(battleSystem, battlerId, 2);
        i = BattleSystem_Random(battleSystem) & 1;
        battlerIdTarget = battlerIdTargets[i];
        if (!ctx->battleMons[battlerIdTarget].hp) {
            battlerIdTarget = battlerIdTargets[i ^ 1];
        }
    } else {
        battlerIdTarget = battlerId ^ 1;
    }

    return battlerIdTarget;
}

BOOL CheckAbilityEffectOnHit(BattleSystem *battleSystem, BattleContext *ctx, int *script) {
    BOOL ret = FALSE;

    if (ctx->battlerIdTarget == BATTLER_NONE) {
        return ret;
    }

    if (BattlerCheckSubstitute(ctx, ctx->battlerIdTarget) == TRUE) {
        return ret;
    }

    switch (GetBattlerAbility(ctx, ctx->battlerIdTarget)) {
    case ABILITY_STATIC:
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && !ctx->battleMons[ctx->battlerIdAttacker].status && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1) && (BattleSystem_Random(battleSystem) % 10 < 3)) {
            ctx->statChangeType = 3;
            ctx->battlerIdStatChange = ctx->battlerIdAttacker;
            ctx->battlerIdTemp = ctx->battlerIdTarget;
            *script = BATTLE_SUBSCRIPT_PARALYZE;
            ret = TRUE;
        }
        break;
    case ABILITY_COLOR_CHANGE: {
        u8 moveType;

        if (GetBattlerAbility(ctx, ctx->battlerIdAttacker) == ABILITY_NORMALIZE) {
            moveType = TYPE_NORMAL;
        } else if (ctx->moveType) {
            moveType = ctx->moveType;
        } else {
            moveType = ctx->trainerAIData.moveData[ctx->moveNoCur].type;
        }

        if (ctx->battleMons[ctx->battlerIdTarget].hp && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && ctx->moveNoCur != MOVE_STRUGGLE && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && ctx->trainerAIData.moveData[ctx->moveNoCur].power && GetBattlerVar(ctx, ctx->battlerIdTarget, BMON_DATA_TYPE_1, NULL) != moveType && GetBattlerVar(ctx, ctx->battlerIdTarget, BMON_DATA_TYPE_2, NULL) != moveType) {
            *script = BATTLE_SUBSCRIPT_COLOR_CHANGE;
            ctx->msgTemp = moveType;
            ret = TRUE;
        }
        break;
    }
    case ABILITY_ROUGH_SKIN:
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && GetBattlerAbility(ctx, ctx->battlerIdAttacker) != ABILITY_MAGIC_GUARD && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1)) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp * -1, 8);
            ctx->battlerIdTemp = ctx->battlerIdAttacker;
            *script = BATTLE_SUBSCRIPT_ROUGH_SKIN;
            ret = TRUE;
        }
        break;
    case ABILITY_EFFECT_SPORE:
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && !ctx->battleMons[ctx->battlerIdAttacker].status && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1) && (BattleSystem_Random(battleSystem) % 10 < 3)) {
            switch (BattleSystem_Random(battleSystem) % 3) {
            case 0:
            default:
                *script = BATTLE_SUBSCRIPT_POISON;
                break;
            case 1:
                *script = BATTLE_SUBSCRIPT_PARALYZE;
                break;
            case 2:
                *script = BATTLE_SUBSCRIPT_FALL_ASLEEP;
                break;
            }
            ctx->statChangeType = 3;
            ctx->battlerIdStatChange = ctx->battlerIdAttacker;
            ctx->battlerIdTemp = ctx->battlerIdTarget;
            ret = TRUE;
        }
        break;
    case ABILITY_POISON_POINT:
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && !ctx->battleMons[ctx->battlerIdAttacker].status && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1) && (BattleSystem_Random(battleSystem) % 10 < 3)) {
            ctx->statChangeType = 3;
            ctx->battlerIdStatChange = ctx->battlerIdAttacker;
            ctx->battlerIdTemp = ctx->battlerIdTarget;
            *script = BATTLE_SUBSCRIPT_POISON;
            ret = TRUE;
        }
        break;
    case ABILITY_FLAME_BODY:
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && !ctx->battleMons[ctx->battlerIdAttacker].status && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1) && ((BattleSystem_Random(battleSystem) % 10) < 3)) {
            ctx->statChangeType = 3;
            ctx->battlerIdStatChange = ctx->battlerIdAttacker;
            ctx->battlerIdTemp = ctx->battlerIdTarget;
            *script = BATTLE_SUBSCRIPT_BURN;
            ret = TRUE;
        }
        break;
    case ABILITY_CUTE_CHARM:
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && !(ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_ATTRACT) && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_TURN) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1) && ctx->battleMons[ctx->battlerIdTarget].hp && ((BattleSystem_Random(battleSystem) % 10) < 3)) {
            ctx->statChangeType = 3;
            ctx->battlerIdStatChange = ctx->battlerIdAttacker;
            ctx->battlerIdTemp = ctx->battlerIdTarget;
            *script = BATTLE_SUBSCRIPT_INFATUATE;
            ret = TRUE;
        }
        break;
    case ABILITY_AFTERMATH:
        if (ctx->battlerIdTarget == ctx->battlerIdFainted && GetBattlerAbility(ctx, ctx->battlerIdAttacker) != ABILITY_MAGIC_GUARD && !CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_DAMP) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && ctx->battleMons[ctx->battlerIdAttacker].hp && !(ctx->moveStatusFlag & MOVE_STATUS_FAIL) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1)) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp * -1, 4);
            ctx->battlerIdTemp = ctx->battlerIdAttacker;
            *script = BATTLE_SUBSCRIPT_AFTERMATH;
            ret = TRUE;
        }
        break;
    default:
        break;
    }
    return ret;
}

BOOL CheckStatusHealAbility(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, int flag) {
    BOOL ret = FALSE;

    switch (GetBattlerAbility(ctx, battlerId)) {
    case ABILITY_IMMUNITY:
        if (ctx->battleMons[battlerId].status & STATUS_POISON_ALL) {
            ctx->msgTemp = 1;
            ret = TRUE;
        }
        break;
    case ABILITY_OWN_TEMPO:
        if (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION) {
            ctx->msgTemp = 5;
            ret = TRUE;
        }
        break;
    case ABILITY_LIMBER:
        if (ctx->battleMons[battlerId].status & STATUS_PARALYSIS) {
            ctx->msgTemp = 3;
            ret = TRUE;
        }
        break;
    case ABILITY_INSOMNIA:
    case ABILITY_VITAL_SPIRIT:
        if (ctx->battleMons[battlerId].status & STATUS_SLEEP) {
            ctx->msgTemp = 0;
            ret = TRUE;
        }
        break;
    case ABILITY_WATER_VEIL:
        if (ctx->battleMons[battlerId].status & STATUS_BURN) {
            ctx->msgTemp = 2;
            ret = TRUE;
        }
        break;
    case ABILITY_MAGMA_ARMOR:
        if (ctx->battleMons[battlerId].status & STATUS_FREEZE) {
            ctx->msgTemp = 4;
            ret = TRUE;
        }
        break;
    case ABILITY_OBLIVIOUS:
        if (ctx->battleMons[battlerId].status2 & STATUS2_ATTRACT) {
            ctx->msgTemp = 6;
            ret = TRUE;
        }
        break;
    case ABILITY_UNBURDEN:
        // resets the item flag in the case where the Pokemon acquires an item via Thief or Trick
        if (ctx->battleMons[battlerId].item) {
            ctx->battleMons[battlerId].moveEffectData.knockOffFlag = TRUE;
        }
        break;
    }
    if (ret == TRUE) {
        ctx->battlerIdTemp = battlerId;
        ctx->abilityTemp = GetBattlerAbility(ctx, battlerId);
        if (!flag) {
            ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, 221);
            ctx->commandNext = ctx->command;
            ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
        }
    }

    return ret;
}

BOOL CheckStatusHealSwitch(BattleContext *ctx, int ability, int status) {
    BOOL ret = FALSE;

    switch (ability) {
    case ABILITY_IMMUNITY:
        if (status & STATUS_POISON_ALL) {
            ret = TRUE;
        }
        break;
    case ABILITY_LIMBER:
        if (status & STATUS_PARALYSIS) {
            ret = TRUE;
        }
        break;
    case ABILITY_INSOMNIA:
    case ABILITY_VITAL_SPIRIT:
        if (status & STATUS_SLEEP) {
            ret = TRUE;
        }
        break;
    case ABILITY_WATER_VEIL:
        if (status & STATUS_BURN) {
            ret = TRUE;
        }
        break;
    case ABILITY_MAGMA_ARMOR:
        if (status & STATUS_FREEZE) {
            ret = TRUE;
        }
        break;
    }

    return ret;
}

BOOL TrySyncronizeStatus(BattleSystem *battleSystem, BattleContext *ctx, ControllerCommand command) {
    BOOL ret = FALSE;
    int script = BATTLE_SUBSCRIPT_NONE;

    if (ctx->battlerIdTarget != BATTLER_NONE && GetBattlerAbility(ctx, ctx->battlerIdTarget) == ABILITY_SYNCHRONIZE && ctx->battlerIdTarget == ctx->battlerIdStatChange && (ctx->battleStatus & BATTLE_STATUS_SYNCRONIZE)) {
        ctx->battlerIdTemp = ctx->battlerIdTarget;
        ctx->battlerIdStatChange = ctx->battlerIdAttacker;
        ret = TRUE;
    } else if (GetBattlerAbility(ctx, ctx->battlerIdAttacker) == ABILITY_SYNCHRONIZE && ctx->battlerIdAttacker == ctx->battlerIdStatChange && (ctx->battleStatus & BATTLE_STATUS_SYNCRONIZE)) {
        ctx->battlerIdTemp = ctx->battlerIdAttacker;
        ctx->battlerIdStatChange = ctx->battlerIdTarget;
        ret = TRUE;
    }

    if (ret == TRUE) {
        if (ctx->battleMons[ctx->battlerIdTemp].status & STATUS_POISON_ALL) {
            script = BATTLE_SUBSCRIPT_POISON;
        } else if (ctx->battleMons[ctx->battlerIdTemp].status & STATUS_BURN) {
            script = BATTLE_SUBSCRIPT_BURN;
        } else if (ctx->battleMons[ctx->battlerIdTemp].status & STATUS_PARALYSIS) {
            script = BATTLE_SUBSCRIPT_PARALYZE;
        }
        if (script) {
            ctx->statChangeType = 3;
            ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, script);
            ctx->commandNext = command;
            ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
            return ret;
        }
    }

    ret = Battler_CheckWeatherFormChange(battleSystem, ctx, &script);
    if (ret == TRUE) {
        ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, script);
        ctx->commandNext = command;
        ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
        return ret;
    }

    if (ctx->battlerIdTarget != BATTLER_NONE && GetBattlerHeldItemEffect(ctx, ctx->battlerIdTarget) == HOLD_EFFECT_RECIPROCATE_INFAT && ctx->battlerIdTarget == ctx->battlerIdStatChange && (ctx->selfTurnData[ctx->battlerIdTarget].statusFlags & 4)) {
        ctx->battlerIdTemp = ctx->battlerIdTarget;
        ctx->battlerIdStatChange = ctx->battlerIdAttacker;
        ret = TRUE;
    } else if (GetBattlerHeldItemEffect(ctx, ctx->battlerIdAttacker) == HOLD_EFFECT_RECIPROCATE_INFAT && ctx->battlerIdAttacker == ctx->battlerIdStatChange && (ctx->selfTurnData[ctx->battlerIdAttacker].statusFlags & 4)) {
        ctx->battlerIdTemp = ctx->battlerIdAttacker;
        ctx->battlerIdStatChange = ctx->battlerIdTarget;
        ret = TRUE;
    }

    if (ret == TRUE) {
        script = BATTLE_SUBSCRIPT_INFATUATE;
        ctx->statChangeType = 5;
        ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, script);
        ctx->commandNext = command;
        ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
        return ret;
    }

    return FALSE;
}

BOOL TryUseHeldItem(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;
    int script;
    int item;
    int boost;

    item = GetBattlerHeldItemEffect(ctx, battlerId);
    boost = GetHeldItemModifier(ctx, battlerId, 0);

    if (ctx->battleMons[battlerId].hp) {
        switch (item) {
        case HOLD_EFFECT_HP_RESTORE: // oran berry, berry juice
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = boost;
                script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_PCT_RESTORE: // sitrus berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp * boost, 100);
                script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PRZ_RESTORE: // cheri berry
            if (ctx->battleMons[battlerId].status & STATUS_PARALYSIS) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_PRZ_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_SLP_RESTORE: // chesto berry
            if (ctx->battleMons[battlerId].status & STATUS_SLEEP) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_SLP_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PSN_RESTORE: // pecha berry
            if (ctx->battleMons[battlerId].status & STATUS_POISON_ALL) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_PSN_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_BRN_RESTORE: // rawst berry
            if (ctx->battleMons[battlerId].status & STATUS_BURN) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_BRN_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_FRZ_RESTORE: // aspear berry
            if (ctx->battleMons[battlerId].status & STATUS_FREEZE) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_FRZ_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PP_RESTORE: // leppa berry
        {
            int index;
            for (index = 0; index < MAX_MON_MOVES; index++) {
                if (ctx->battleMons[battlerId].moves[index] && !ctx->battleMons[battlerId].movePPCur[index]) {
                    break;
                }
            }
            if (index != MAX_MON_MOVES) {
                BattleMon_AddVar(&ctx->battleMons[battlerId], BMON_DATA_CUR_PP_1 + index, boost);
                CopyBattleMonToPartyMon(battleSystem, ctx, battlerId);
                ctx->moveTemp = ctx->battleMons[battlerId].moves[index];
                script = BATTLE_SUBSCRIPT_HELD_ITEM_PP_RESTORE;
                ret = TRUE;
            }
            break;
        }
        case HOLD_EFFECT_CONFUSE_RESTORE: // persim berry
            if (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_CNF_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_STATUS_RESTORE: // lum berry
            if ((ctx->battleMons[battlerId].status & STATUS_ALL) || (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION)) {
                if (ctx->battleMons[battlerId].status & STATUS_PARALYSIS) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_PRZ_RESTORE;
                }
                if (ctx->battleMons[battlerId].status & STATUS_SLEEP) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_SLP_RESTORE;
                }
                if (ctx->battleMons[battlerId].status & STATUS_POISON_ALL) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_PSN_RESTORE;
                }
                if (ctx->battleMons[battlerId].status & STATUS_BURN) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_BRN_RESTORE;
                }
                if (ctx->battleMons[battlerId].status & STATUS_FREEZE) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_FRZ_RESTORE;
                }
                if (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_CNF_RESTORE;
                }
                if ((ctx->battleMons[battlerId].status & STATUS_ALL) && (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION)) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_MULTI_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_SPICY: // figy berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 0;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_SPICY) == -1) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_DRY: // wiki berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 1;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_DRY) == -1) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_SWEET: // mago berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 2;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_SWEET) == -1) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_BITTER: // aguav berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 3;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_BITTER) == -1) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_SOUR: // iappapa berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 4;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_SOUR) == -1) {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_ATK_UP: // liechi berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[1] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 1;
                script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_DEF_UP: // ganlon berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[2] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 2;
                script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_SPEED_UP: // salac berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[3] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 3;
                script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_SPATK_UP: // petaya berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[4] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 4;
                script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_SPDEF_UP: // apicot berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[5] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 5;
                script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_CRITRATE_UP: // apicot berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && !(ctx->battleMons[battlerId].status2 & STATUS2_FOCUS_ENERGY)) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_CRIT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_RANDOM_UP: // starf berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost) {
                int stat;
                for (stat = 0; stat < 5; stat++) {
                    if (ctx->battleMons[battlerId].statChanges[1 + stat] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                        break;
                    }
                }
                if (stat != 5) {
                    do {
                        stat = BattleSystem_Random(battleSystem) % 5;
                    } while (ctx->battleMons[battlerId].statChanges[1 + stat] == BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE);
                    ctx->msgTemp = stat + 1;
                    script = BATTLE_SUBSCRIPT_HELD_ITEM_SHARPLY_RAISE_STAT;
                    ret = TRUE;
                }
            }
            break;
        case HOLD_EFFECT_STATDOWN_RESTORE: // white herb
        {
            int stat;
            for (stat = 0; stat < 8; stat++) {
                if (ctx->battleMons[battlerId].statChanges[stat] < 6) {
                    ctx->battleMons[battlerId].statChanges[stat] = 6;
                    ret = TRUE;
                }
            }
            if (ret == TRUE) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_STATDOWN_RESTORE;
            }
            break;
        }
        case HOLD_EFFECT_HEAL_INFATUATION: // mental herb
            if (ctx->battleMons[battlerId].status2 & STATUS2_ATTRACT) {
                ctx->msgTemp = 6;
                script = BATTLE_SUBSCRIPT_HELD_ITEM_HEAL_INFATUATION;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_ACC_UP: // micle berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= (ctx->battleMons[battlerId].maxHp / boost)) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_TEMP_ACC_UP;
                ret = TRUE;
            }
            break;
        default:
            break;
        }
        if (ret == TRUE) {
            ctx->battlerIdTemp = battlerId;
            ctx->itemTemp = GetBattlerHeldItem(ctx, battlerId);
            ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, script);
            ctx->commandNext = ctx->command;
            ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
        }
    }
    return ret;
}

BOOL CheckItemGradualHPRestore(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;
    int script;
    int item;

    item = GetBattlerHeldItemEffect(ctx, battlerId);
    GetHeldItemModifier(ctx, battlerId, 0);

    if (ctx->battleMons[battlerId].hp) {
        switch (item) {
        case HOLD_EFFECT_HP_RESTORE_GRADUAL: // leftovers
            if (ctx->battleMons[battlerId].hp < ctx->battleMons[battlerId].maxHp) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, 16);
                script = BATTLE_SUBSCRIPT_RESTORE_A_LITTLE_HP;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_PSN_TYPE: // black sludge
            if (GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_1, NULL) == TYPE_POISON || GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_2, NULL) == TYPE_POISON) {
                if (ctx->battleMons[battlerId].hp < ctx->battleMons[battlerId].maxHp) {
                    ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, 16);
                    script = BATTLE_SUBSCRIPT_RESTORE_A_LITTLE_HP;
                    ret = TRUE;
                }
            } else if (GetBattlerAbility(ctx, battlerId) != ABILITY_MAGIC_GUARD) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp * -1, 8);
                script = BATTLE_SUBSCRIPT_LOSE_HP_FROM_ITEM_WITH_MESSAGE;
                ret = TRUE;
            }
            break;
        default:
            break;
        }
        if (ret == TRUE) {
            ctx->battlerIdTemp = battlerId;
            ctx->itemTemp = GetBattlerHeldItem(ctx, battlerId);
            ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, script);
            ctx->commandNext = ctx->command;
            ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
        }
    }
    return ret;
}

BOOL CheckUseHeldItem(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, u32 *script) {
    BOOL ret = FALSE;
    int item;
    int boost;

    item = GetBattlerHeldItemEffect(ctx, battlerId);
    boost = GetHeldItemModifier(ctx, battlerId, 0);

    if (ctx->battleMons[battlerId].hp) {
        switch (item) {
        case HOLD_EFFECT_HP_RESTORE: // oran berry, berry juice
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = boost;
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_PCT_RESTORE: // sitrus berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp * boost, 100);
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PRZ_RESTORE: // cheri berry
            if (ctx->battleMons[battlerId].status & STATUS_PARALYSIS) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_PRZ_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_SLP_RESTORE: // chesto berry
            if (ctx->battleMons[battlerId].status & STATUS_SLEEP) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_SLP_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PSN_RESTORE: // pecha berry
            if (ctx->battleMons[battlerId].status & STATUS_POISON_ALL) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_PSN_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_BRN_RESTORE: // rawst berry
            if (ctx->battleMons[battlerId].status & STATUS_BURN) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_BRN_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_FRZ_RESTORE: // aspear berry
            if (ctx->battleMons[battlerId].status & STATUS_FREEZE) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_FRZ_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PP_RESTORE: // leppa berry
        {
            int index;
            for (index = 0; index < MAX_MON_MOVES; index++) {
                if (ctx->battleMons[battlerId].moves[index] && !ctx->battleMons[battlerId].movePPCur[index]) {
                    break;
                }
            }
            if (index != MAX_MON_MOVES) {
                BattleMon_AddVar(&ctx->battleMons[battlerId], BMON_DATA_CUR_PP_1 + index, boost);
                CopyBattleMonToPartyMon(battleSystem, ctx, battlerId);
                ctx->moveTemp = ctx->battleMons[battlerId].moves[index];
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_PP_RESTORE;
                ret = TRUE;
            }
            break;
        }
        case HOLD_EFFECT_CONFUSE_RESTORE: // persim berry
            if (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_CNF_RESTORE;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_STATUS_RESTORE: // lum berry
            if ((ctx->battleMons[battlerId].status & STATUS_ALL) || (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION)) {
                if (ctx->battleMons[battlerId].status & STATUS_PARALYSIS) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_PRZ_RESTORE;
                }
                if (ctx->battleMons[battlerId].status & STATUS_SLEEP) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_SLP_RESTORE;
                }
                if (ctx->battleMons[battlerId].status & STATUS_POISON_ALL) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_PSN_RESTORE;
                }
                if (ctx->battleMons[battlerId].status & STATUS_BURN) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_BRN_RESTORE;
                }
                if (ctx->battleMons[battlerId].status & STATUS_FREEZE) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_FRZ_RESTORE;
                }
                if (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_CNF_RESTORE;
                }
                if ((ctx->battleMons[battlerId].status & STATUS_ALL) && (ctx->battleMons[battlerId].status2 & STATUS2_CONFUSION)) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_MULTI_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_STATDOWN_RESTORE: // white herb
        {
            int stat;
            for (stat = 0; stat < 8; stat++) {
                if (ctx->battleMons[battlerId].statChanges[stat] < 6) {
                    ctx->battleMons[battlerId].statChanges[stat] = 6;
                    ret = TRUE;
                }
            }
            if (ret == TRUE) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_STATDOWN_RESTORE;
            }
            break;
        }
        case HOLD_EFFECT_HEAL_INFATUATION: // mental herb
            if (ctx->battleMons[battlerId].status2 & STATUS2_ATTRACT) {
                ctx->msgTemp = 6;
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_HEAL_INFATUATION;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_ACC_UP: // micle berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= (ctx->battleMons[battlerId].maxHp / boost)) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_TEMP_ACC_UP;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_SPICY: // figy berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 0;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_SPICY) == -1) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_DRY: // wiki berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 1;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_DRY) == -1) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_SWEET: // mago berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 2;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_SWEET) == -1) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_BITTER: // aguav berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 3;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_BITTER) == -1) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_HP_RESTORE_SOUR: // iappapa berry
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / 2) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp, boost);
                ctx->msgTemp = 4;
                if (GetFlavorPreferenceFromPID(ctx->battleMons[battlerId].personality, FLAVOR_SOUR) == -1) {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
                } else {
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
                }
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_ATK_UP: // liechi berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[1] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 1;
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_DEF_UP: // ganlon berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[2] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 2;
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_SPEED_UP: // salac berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[3] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 3;
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_SPATK_UP: // petaya berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[4] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 4;
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_SPDEF_UP: // apicot berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && ctx->battleMons[battlerId].statChanges[5] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                ctx->msgTemp = 5;
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_CRITRATE_UP: // apicot berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost && !(ctx->battleMons[battlerId].status2 & STATUS2_FOCUS_ENERGY)) {
                *script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_CRIT;
                ret = TRUE;
            }
            break;
        case HOLD_EFFECT_PINCH_RANDOM_UP: // starf berry
            if (GetBattlerAbility(ctx, battlerId) == ABILITY_GLUTTONY) {
                boost /= 2;
            }
            if (ctx->battleMons[battlerId].hp <= ctx->battleMons[battlerId].maxHp / boost) {
                int stat;
                for (stat = 0; stat < 5; stat++) {
                    if (ctx->battleMons[battlerId].statChanges[1 + stat] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                        break;
                    }
                }
                if (stat != 5) {
                    do {
                        stat = BattleSystem_Random(battleSystem) % 5;
                    } while (ctx->battleMons[battlerId].statChanges[1 + stat] == BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE);
                    ctx->msgTemp = stat + 1;
                    *script = BATTLE_SUBSCRIPT_HELD_ITEM_SHARPLY_RAISE_STAT;
                    ret = TRUE;
                }
            }
            break;
        default:
            break;
        }
        if (ret == TRUE) {
            ctx->itemTemp = GetBattlerHeldItem(ctx, battlerId);
        }
    }

    return ret;
}

BOOL TryHeldItemNegativeEffect(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;
    int script;
    int item = GetBattlerHeldItemEffect(ctx, battlerId);
    int boost = GetHeldItemModifier(ctx, battlerId, 0);

    if (ctx->battleMons[battlerId].hp) {
        switch (item) {
        case HOLD_EFFECT_PSN_USER: // toxic orb
            ctx->battlerIdStatChange = battlerId;
            ctx->statChangeType = 5;
            script = BATTLE_SUBSCRIPT_BADLY_POISON;
            ret = TRUE;
            break;
        case HOLD_EFFECT_BRN_USER: // flame orb
            ctx->battlerIdStatChange = battlerId;
            ctx->statChangeType = 5;
            script = BATTLE_SUBSCRIPT_BURN;
            ret = TRUE;
            break;
        case HOLD_EFFECT_DMG_USER_CONTACT_XFR: // sticky barb
            if (GetBattlerAbility(ctx, battlerId) != ABILITY_MAGIC_GUARD) {
                ctx->hpCalc = DamageDivide(ctx->battleMons[battlerId].maxHp * -1, boost);
                script = BATTLE_SUBSCRIPT_LOSE_HP_FROM_ITEM_WITH_MESSAGE;
                ret = TRUE;
            }
            break;
        default:
            break;
        }
        if (ret == TRUE) {
            ctx->battlerIdTemp = battlerId;
            ctx->itemTemp = GetBattlerHeldItem(ctx, battlerId);
            ReadBattleScriptFromNarc(ctx, NARC_a_0_0_1, script);
            ctx->commandNext = ctx->command;
            ctx->command = CONTROLLER_COMMAND_RUN_SCRIPT;
        }
    }
    return ret;
}

u16 GetBattlerHeldItem(BattleContext *ctx, int battlerId) {
    if (GetBattlerAbility(ctx, battlerId) == ABILITY_KLUTZ) {
        return ITEM_NONE;
    }
    if (ctx->battleMons[battlerId].moveEffectData.embargoFlag) {
        return ITEM_NONE;
    }
    return ctx->battleMons[battlerId].item;
}

BOOL BattleContext_IsActionDone(BattleContext *ctx, int battlerId) {
    return ctx->playerActions[battlerId].command == CONTROLLER_COMMAND_40;
}

BOOL CheckItemEffectOnHit(BattleSystem *battleSystem, BattleContext *ctx, int *script) {
    BOOL ret = FALSE;
    int item;
    int boost;
    int side;

    if (ctx->battlerIdTarget == BATTLER_NONE) {
        return ret;
    }

    if (BattlerCheckSubstitute(ctx, ctx->battlerIdTarget) == TRUE) {
        return ret;
    }

    item = GetBattlerHeldItemEffect(ctx, ctx->battlerIdTarget);
    boost = GetHeldItemModifier(ctx, ctx->battlerIdTarget, 0);
    side = BattleSystem_GetFieldSide(battleSystem, ctx->battlerIdAttacker);

    switch (item) {
    case HOLD_EFFECT_DMG_USER_CONTACT_XFR: // sticky barb
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && !(ctx->battleMons[ctx->battlerIdAttacker].item) && !(ctx->fieldSideConditionData[side].battlerBitKnockedOffItem & MaskOfFlagNo(ctx->selectedMonIndex[ctx->battlerIdAttacker])) && ctx->moveNoCur != MOVE_KNOCK_OFF && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1)) {
            *script = BATTLE_SUBSCRIPT_TRANSFER_STICKY_BARB;
            ret = TRUE;
        }
        break;
    case HOLD_EFFECT_RECOIL_PHYSICAL: // jacoba berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && GetBattlerAbility(ctx, ctx->battlerIdAttacker) != ABILITY_MAGIC_GUARD && !(ctx->battleStatus2 & BATTLE_STATUS2_UTURN) && ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp * -1, boost);
            *script = BATTLE_SUBSCRIPT_HELD_ITEM_RECOIL_WHEN_HIT;
            ret = TRUE;
        }
        break;
    case HOLD_EFFECT_RECOIL_SPECIAL: // rowap berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp && GetBattlerAbility(ctx, ctx->battlerIdAttacker) != ABILITY_MAGIC_GUARD && ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp * -1, boost);
            *script = BATTLE_SUBSCRIPT_HELD_ITEM_RECOIL_WHEN_HIT;
            ret = TRUE;
        }
        break;
    case HOLD_EFFECT_HP_RESTORE_SE: // enigma berry
        if (ctx->battleMons[ctx->battlerIdTarget].hp && (ctx->moveStatusFlag & MOVE_STATUS_SUPER_EFFECTIVE)) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdTarget].maxHp, boost);
            *script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
            ctx->battlerIdTemp = ctx->battlerIdTarget;
            ctx->itemTemp = ctx->battleMons[ctx->battlerIdTarget].item;
            ret = TRUE;
        }
        break;
    default:
        break;
    }

    return ret;
}

int GetBattlerHeldItemEffect(BattleContext *ctx, int battlerId) {
    u16 itemNo = GetBattlerHeldItem(ctx, battlerId);
    return GetItemVar(ctx, itemNo, ITEM_VAR_HOLD_EFFECT);
}

int GetHeldItemModifier(BattleContext *ctx, int battlerId, int flag) {
    u16 itemNo;

    switch (flag) {
    case 0:
        itemNo = GetBattlerHeldItem(ctx, battlerId);
        break;
    case 2:
        if (ctx->battleMons[battlerId].moveEffectData.embargoFlag) {
            return 0;
        }
    case 1:
        itemNo = ctx->battleMons[battlerId].item;
        break;
    }

    return GetItemVar(ctx, itemNo, ITEM_VAR_MODIFIER);
}

int GetNaturalGiftPower(BattleContext *ctx, int battlerId) {
    u16 itemNo = GetBattlerHeldItem(ctx, battlerId);
    return GetItemVar(ctx, itemNo, ITEM_NATURAL_GIFT_POWER);
}

int GetNaturalGiftType(BattleContext *ctx, int battlerId) {
    u16 itemNo = GetBattlerHeldItem(ctx, battlerId);
    return GetItemVar(ctx, itemNo, ITEM_NATURAL_GIFT_TYPE);
}

int GetHeldItemStealBerryEffect(BattleContext *ctx, int battlerId) {
    u16 itemNo = ctx->battleMons[battlerId].item;
    return GetItemVar(ctx, itemNo, ITEM_VAR_8);
}

int GetHeldItemFlingEffect(BattleContext *ctx, int battlerId) {
    if (ctx->battleMons[battlerId].moveEffectData.embargoFlag) {
        return 0;
    }

    return GetItemVar(ctx, ctx->battleMons[battlerId].item, ITEM_VAR_9);
}

int GetHeldItemFlingPower(BattleContext *ctx, int battlerId) {
    if (ctx->battleMons[battlerId].moveEffectData.embargoFlag) {
        return 0;
    }

    return GetItemVar(ctx, ctx->battleMons[battlerId].item, ITEM_VAR_10);
}

BOOL BattlerCanSwitch(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;

    if (GetBattlerHeldItemEffect(ctx, battlerId) == HOLD_EFFECT_SWITCH) {
        return FALSE;
    }

    if ((ctx->battleMons[battlerId].status2 & (STATUS2_BIND | STATUS2_MEAN_LOOK)) || (ctx->battleMons[battlerId].moveEffectFlags & MOVE_EFFECT_FLAG_INGRAIN)) {
        ret = TRUE;
    }

    if ((GetBattlerAbility(ctx, battlerId) != ABILITY_SHADOW_TAG && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_OPPOSING_SIDE_HP, battlerId, ABILITY_SHADOW_TAG)) || ((GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_1, NULL) == TYPE_STEEL || GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_2, NULL) == TYPE_STEEL) && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_OPPOSING_SIDE_HP, battlerId, ABILITY_MAGNET_PULL))) {
        ret = TRUE;
    }

    if (((GetBattlerAbility(ctx, battlerId) != ABILITY_LEVITATE && ctx->battleMons[battlerId].moveEffectData.magnetRiseTurns == 0 && GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_1, NULL) != TYPE_FLYING && GetBattlerVar(ctx, battlerId, BMON_DATA_TYPE_2, NULL) != TYPE_FLYING) || GetBattlerHeldItemEffect(ctx, battlerId) == HOLD_EFFECT_SPEED_DOWN_GROUNDED || (ctx->fieldCondition & FIELD_CONDITION_GRAVITY)) && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_OPPOSING_SIDE_HP, battlerId, ABILITY_ARENA_TRAP)) {
        ret = TRUE;
    }

    return ret;
}

BOOL TryEatOpponentBerry(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;
    int script = BATTLE_SUBSCRIPT_NONE;
    int item = GetHeldItemStealBerryEffect(ctx, battlerId);
    int mod = GetHeldItemModifier(ctx, battlerId, 1);

    if (BattlerCheckSubstitute(ctx, ctx->battlerIdTarget) == TRUE) {
        return FALSE;
    }

    switch (item) {
    case STEAL_EFFECT_RESTORE_HP: // oran berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp != ctx->battleMons[ctx->battlerIdAttacker].maxHp) {
            ctx->hpCalc = mod;
            script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_RESTORE_HP_PRCT: // sitrus berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp != ctx->battleMons[ctx->battlerIdAttacker].maxHp) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp * mod, 100);
            script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_CURE_PARALYSIS: // cheri berry
        if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_PARALYSIS) {
            script = BATTLE_SUBSCRIPT_HELD_ITEM_PRZ_RESTORE;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_CURE_SLEEP: // chesto berry
        if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_SLEEP) {
            script = BATTLE_SUBSCRIPT_HELD_ITEM_SLP_RESTORE;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_CURE_POISON: // pecha berry
        if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_POISON_ALL) {
            script = BATTLE_SUBSCRIPT_HELD_ITEM_PSN_RESTORE;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_CURE_BURN: // rawst berry
        if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_BURN) {
            script = BATTLE_SUBSCRIPT_HELD_ITEM_BRN_RESTORE;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_CURE_FREEZE: // aspear berry
        if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_FREEZE) {
            script = BATTLE_SUBSCRIPT_HELD_ITEM_FRZ_RESTORE;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_RESTORE_PP: // leppa berry
    {
        int ppCalc;
        int index;
        int max = 0;
        int maxIndex;
        for (index = 0; index < MAX_MON_MOVES; index++) {
            if (ctx->battleMons[ctx->battlerIdAttacker].moves[index]) {
                ppCalc = GetMoveMaxPP(ctx->battleMons[ctx->battlerIdAttacker].moves[index], ctx->battleMons[ctx->battlerIdAttacker].movePP[index]) - ctx->battleMons[ctx->battlerIdAttacker].movePPCur[index];
                if (ppCalc > max) {
                    max = ppCalc;
                    maxIndex = index;
                }
            }
        }

        BattleMon_AddVar(&ctx->battleMons[ctx->battlerIdAttacker], BMON_DATA_CUR_PP_1 + maxIndex, mod);
        CopyBattleMonToPartyMon(battleSystem, ctx, ctx->battlerIdAttacker);
        ctx->moveTemp = ctx->battleMons[ctx->battlerIdAttacker].moves[maxIndex];
        script = BATTLE_SUBSCRIPT_HELD_ITEM_PP_RESTORE;
        ret = TRUE;
        break;
    }
    case STEAL_EFFECT_CURE_CONFUSION: // persim berry
        if (ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_CONFUSION) {
            script = BATTLE_SUBSCRIPT_HELD_ITEM_CNF_RESTORE;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_CURE_ALL: // lum berry
        if ((ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_ALL) || (ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_CONFUSION)) {
            if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_PARALYSIS) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_PRZ_RESTORE;
            }
            if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_SLEEP) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_SLP_RESTORE;
            }
            if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_POISON_ALL) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_PSN_RESTORE;
            }
            if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_BURN) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_BRN_RESTORE;
            }
            if (ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_FREEZE) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_FRZ_RESTORE;
            }
            if (ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_CONFUSION) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_CNF_RESTORE;
            }
            if ((ctx->battleMons[ctx->battlerIdAttacker].status & STATUS_ALL) && (ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_CONFUSION)) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_MULTI_RESTORE;
            }
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_RESTORE_SPICY: // figy berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp != ctx->battleMons[ctx->battlerIdAttacker].maxHp) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp, mod);
            ctx->msgTemp = 0;
            if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdAttacker].personality, FLAVOR_SPICY) == -1) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
            } else {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
            }
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_RESTORE_DRY: // wiki berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp != ctx->battleMons[ctx->battlerIdAttacker].maxHp) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp, mod);
            ctx->msgTemp = 1;
            if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdAttacker].personality, FLAVOR_DRY) == -1) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
            } else {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
            }
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_RESTORE_SWEET: // mago berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp != ctx->battleMons[ctx->battlerIdAttacker].maxHp) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp, mod);
            ctx->msgTemp = 2;
            if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdAttacker].personality, FLAVOR_SWEET) == -1) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
            } else {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
            }
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_RESTORE_BITTER: // aguav berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp != ctx->battleMons[ctx->battlerIdAttacker].maxHp) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp, mod);
            ctx->msgTemp = 3;
            if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdAttacker].personality, FLAVOR_BITTER) == -1) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
            } else {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
            }
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_RESTORE_SOUR: // iappapa berry
        if (ctx->battleMons[ctx->battlerIdAttacker].hp != ctx->battleMons[ctx->battlerIdAttacker].maxHp) {
            ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp, mod);
            ctx->msgTemp = 4;
            if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdAttacker].personality, FLAVOR_SOUR) == -1) {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_DISLIKE_FLAVOR;
            } else {
                script = BATTLE_SUBSCRIPT_HELD_ITEM_HP_RESTORE;
            }
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_ATK_UP: // liechi berry
        if (ctx->battleMons[ctx->battlerIdAttacker].statChanges[1] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 1;
            script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_DEF_UP: // ganlon berry
        if (ctx->battleMons[ctx->battlerIdAttacker].statChanges[2] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 2;
            script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_SPEED_UP: // salac berry
        if (ctx->battleMons[ctx->battlerIdAttacker].statChanges[3] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 3;
            script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_SPATK_UP: // petaya berry
        if (ctx->battleMons[ctx->battlerIdAttacker].statChanges[4] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 4;
            script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_SPDEF_UP: // apicot berry
        if (ctx->battleMons[ctx->battlerIdAttacker].statChanges[5] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 5;
            script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_STAT;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_RANDOM_UP: // starf berry
    {
        int stat;
        for (stat = 0; stat < 5; stat++) {
            if (ctx->battleMons[ctx->battlerIdAttacker].statChanges[1 + stat] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                break;
            }
        }
        if (stat != 5) {
            do {
                stat = BattleSystem_Random(battleSystem) % 5;
            } while (ctx->battleMons[ctx->battlerIdAttacker].statChanges[1 + stat] == BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE);
            ctx->msgTemp = stat + 1;
            script = BATTLE_SUBSCRIPT_HELD_ITEM_SHARPLY_RAISE_STAT;
        }
        ret = TRUE;
        break;
    }
    case STEAL_EFFECT_CRITRATE_UP: // apicot berry
        if (!(ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_FOCUS_ENERGY)) {
            script = BATTLE_SUBSCRIPT_HELD_ITEM_RAISE_CRIT;
        }
        ret = TRUE;
        break;
    case STEAL_EFFECT_ACC_UP: // micle berry
        script = BATTLE_SUBSCRIPT_HELD_ITEM_TEMP_ACC_UP;
        ret = TRUE;
        break;
    default:
        if (ItemIdIsBerry(ctx->battleMons[battlerId].item) == TRUE) {
            ret = TRUE;
        }
        break;
    }
    if (ret == TRUE) {
        if (GetBattlerAbility(ctx, ctx->battlerIdAttacker) == ABILITY_KLUTZ || (ctx->battleMons[ctx->battlerIdAttacker].moveEffectFlags & MOVE_EFFECT_FLAG_EMBARGO)) {
            ctx->tempData = 0;
        } else {
            ctx->tempData = script;
        }
        ctx->itemTemp = ctx->battleMons[battlerId].item;
        ctx->selfTurnData[ctx->battlerIdAttacker].statusFlags |= (1 << 1);
    }

    return ret;
}

BOOL TryFling(BattleSystem *battleSystem, BattleContext *ctx, int battlerId) {
    int item = GetHeldItemFlingEffect(ctx, battlerId);
    int mod = GetHeldItemModifier(ctx, battlerId, 2);

    ctx->movePower = GetHeldItemFlingPower(ctx, battlerId);
    ctx->flingScript = 0;
    ctx->statChangeType = 0;

    if (!ctx->movePower) {
        return FALSE;
    }

    switch (item) {
    case STEAL_EFFECT_RESTORE_HP: // oran berry
        ctx->flingData = mod;
        ctx->flingScript = 198;
        break;
    case STEAL_EFFECT_RESTORE_HP_PRCT: // sitrus berry
        ctx->flingData = DamageDivide(ctx->battleMons[ctx->battlerIdTarget].maxHp * mod, 100);
        ctx->flingScript = 198;
        break;
    case STEAL_EFFECT_CURE_PARALYSIS: // cheri berry
        if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_PARALYSIS) {
            ctx->flingScript = 199;
        }
        break;
    case STEAL_EFFECT_CURE_SLEEP: // chesto berry
        if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_SLEEP) {
            ctx->flingScript = 200;
        }
        break;
    case STEAL_EFFECT_CURE_POISON: // pecha berry
        if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_POISON_ALL) {
            ctx->flingScript = 201;
        }
        break;
    case STEAL_EFFECT_CURE_BURN: // rawst berry
        if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_BURN) {
            ctx->flingScript = 202;
        }
        break;
    case STEAL_EFFECT_CURE_FREEZE: // aspear berry
        if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_FREEZE) {
            ctx->flingScript = 203;
        }
        break;
    case STEAL_EFFECT_RESTORE_PP: // leppa berry
    {
        int ppCalc;
        int index;
        int max = 0;
        int maxIndex;
        for (index = 0; index < MAX_MON_MOVES; index++) {
            if (ctx->battleMons[ctx->battlerIdTarget].moves[index]) {
                ppCalc = GetMoveMaxPP(ctx->battleMons[ctx->battlerIdTarget].moves[index], ctx->battleMons[ctx->battlerIdTarget].movePP[index]) - ctx->battleMons[ctx->battlerIdTarget].movePPCur[index];
                if (ppCalc > max) {
                    max = ppCalc;
                    maxIndex = index;
                }
            }
        }
        if (max) {
            BattleMon_AddVar(&ctx->battleMons[ctx->battlerIdTarget], BMON_DATA_CUR_PP_1 + maxIndex, mod);
            CopyBattleMonToPartyMon(battleSystem, ctx, ctx->battlerIdTarget);
            ctx->moveTemp = ctx->battleMons[ctx->battlerIdTarget].moves[maxIndex];
            ctx->flingScript = 204;
        }
        break;
    }
    case STEAL_EFFECT_CURE_CONFUSION: // persim berry
        if (ctx->battleMons[ctx->battlerIdTarget].status2 & STATUS2_CONFUSION) {
            ctx->flingScript = 205;
        }
        break;
    case STEAL_EFFECT_CURE_ALL: // lum berry
        if ((ctx->battleMons[ctx->battlerIdTarget].status & STATUS_ALL) || (ctx->battleMons[ctx->battlerIdTarget].status2 & STATUS2_CONFUSION)) {
            if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_PARALYSIS) {
                ctx->flingScript = 199;
            }
            if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_SLEEP) {
                ctx->flingScript = 200;
            }
            if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_POISON_ALL) {
                ctx->flingScript = 201;
            }
            if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_BURN) {
                ctx->flingScript = 202;
            }
            if (ctx->battleMons[ctx->battlerIdTarget].status & STATUS_FREEZE) {
                ctx->flingScript = 203;
            }
            if (ctx->battleMons[ctx->battlerIdTarget].status2 & STATUS2_CONFUSION) {
                ctx->flingScript = 205;
            }
            if ((ctx->battleMons[ctx->battlerIdTarget].status & STATUS_ALL) && (ctx->battleMons[ctx->battlerIdTarget].status2 & STATUS2_CONFUSION)) {
                ctx->flingScript = 206;
            }
        }
        break;
    case STEAL_EFFECT_RESTORE_SPICY: // figy berry
        ctx->flingData = DamageDivide(ctx->battleMons[ctx->battlerIdTarget].maxHp, mod);
        ctx->msgTemp = 0;
        if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdTarget].personality, FLAVOR_SPICY) == -1) {
            ctx->flingScript = 207;
        } else {
            ctx->flingScript = 198;
        }
        break;
    case STEAL_EFFECT_RESTORE_DRY: // wiki berry
        ctx->flingData = DamageDivide(ctx->battleMons[ctx->battlerIdTarget].maxHp, mod);
        ctx->msgTemp = 1;
        if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdTarget].personality, FLAVOR_DRY) == -1) {
            ctx->flingScript = 207;
        } else {
            ctx->flingScript = 198;
        }
        break;
    case STEAL_EFFECT_RESTORE_SWEET: // mago berry
        ctx->flingData = DamageDivide(ctx->battleMons[ctx->battlerIdTarget].maxHp, mod);
        ctx->msgTemp = 2;
        if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdTarget].personality, FLAVOR_SWEET) == -1) {
            ctx->flingScript = 207;
        } else {
            ctx->flingScript = 198;
        }
        break;
    case STEAL_EFFECT_RESTORE_BITTER: // aguav berry
        ctx->flingData = DamageDivide(ctx->battleMons[ctx->battlerIdTarget].maxHp, mod);
        ctx->msgTemp = 3;
        if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdTarget].personality, FLAVOR_BITTER) == -1) {
            ctx->flingScript = 207;
        } else {
            ctx->flingScript = 198;
        }
        break;
    case STEAL_EFFECT_RESTORE_SOUR: // iappapa berry
        ctx->flingData = DamageDivide(ctx->battleMons[ctx->battlerIdTarget].maxHp, mod);
        ctx->msgTemp = 4;
        if (GetFlavorPreferenceFromPID(ctx->battleMons[ctx->battlerIdTarget].personality, FLAVOR_SOUR) == -1) {
            ctx->flingScript = 207;
        } else {
            ctx->flingScript = 198;
        }
        break;
    case STEAL_EFFECT_RESET_STATS: // white herb
    {
        int stat;
        for (stat = 0; stat < 8; stat++) {
            if (ctx->battleMons[ctx->battlerIdTarget].statChanges[stat] < 6) {
                ctx->battleMons[ctx->battlerIdTarget].statChanges[stat] = 6;
                ctx->flingScript = 211;
            }
        }
    } break;
    case STEAL_EFFECT_CURE_INFATUATION: // mental herb
        if (ctx->battleMons[ctx->battlerIdTarget].status2 & STATUS2_ATTRACT) {
            ctx->msgTemp = 6;
            ctx->flingScript = 212;
        }
        break;
    case STEAL_EFFECT_FLINCH: // kings rock, razor fang
        ctx->battlerIdStatChange = battlerId;
        ctx->statChangeType = 2;
        ctx->flingScript = 14;
        break;
    case STEAL_EFFECT_PARALYZE: // light ball
        ctx->battlerIdStatChange = battlerId;
        ctx->statChangeType = 2;
        ctx->flingScript = 31;
        break;
    case STEAL_EFFECT_POISON: // poison barb
        ctx->battlerIdStatChange = battlerId;
        ctx->statChangeType = 2;
        ctx->flingScript = 22;
        break;
    case STEAL_EFFECT_BAD_POISON: // toxic orb
        ctx->battlerIdStatChange = battlerId;
        ctx->statChangeType = 2;
        ctx->flingScript = 47;
        break;
    case STEAL_EFFECT_BURN: // flame orb
        ctx->battlerIdStatChange = battlerId;
        ctx->statChangeType = 2;
        ctx->flingScript = 25;
        break;
    case STEAL_EFFECT_ATK_UP: // liechi berry
        if (ctx->battleMons[ctx->battlerIdTarget].statChanges[1] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 1;
            ctx->flingScript = 208;
        }
        break;
    case STEAL_EFFECT_DEF_UP: // ganlon berry
        if (ctx->battleMons[ctx->battlerIdTarget].statChanges[2] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 2;
            ctx->flingScript = 208;
        }
        break;
    case STEAL_EFFECT_SPEED_UP: // salac berry
        if (ctx->battleMons[ctx->battlerIdTarget].statChanges[3] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 3;
            ctx->flingScript = 208;
        }
        break;
    case STEAL_EFFECT_SPATK_UP: // petaya berry
        if (ctx->battleMons[ctx->battlerIdTarget].statChanges[4] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 4;
            ctx->flingScript = 208;
        }
        break;
    case STEAL_EFFECT_SPDEF_UP: // apicot berry
        if (ctx->battleMons[ctx->battlerIdTarget].statChanges[5] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
            ctx->msgTemp = 5;
            ctx->flingScript = 208;
        }
        break;
    case STEAL_EFFECT_RANDOM_UP: // starf berry
    {
        int stat;
        for (stat = 0; stat < 5; stat++) {
            if (ctx->battleMons[ctx->battlerIdTarget].statChanges[1 + stat] < BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE) {
                break;
            }
        }
        if (stat != 5) {
            do {
                stat = BattleSystem_Random(battleSystem) % 5;
            } while (ctx->battleMons[ctx->battlerIdTarget].statChanges[1 + stat] == BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE);
            ctx->msgTemp = stat + 1;
            ctx->flingScript = 210;
        }
        break;
    }
    case STEAL_EFFECT_CRITRATE_UP: // apicot berry
        if (!(ctx->battleMons[ctx->battlerIdTarget].status2 & STATUS2_FOCUS_ENERGY)) {
            ctx->flingScript = 209;
        }
        break;
    case STEAL_EFFECT_ACC_UP: // micle berry
        ctx->flingScript = 265;
        break;
    default:
        break;
    }

    if (ctx->battleMons[ctx->battlerIdTarget].moveEffectFlags & MOVE_EFFECT_FLAG_EMBARGO) {
        ctx->flingScript = 0;
    } else {
        ctx->itemTemp = ctx->battleMons[battlerId].item;
        if (!ctx->statChangeType && ctx->flingScript) {
            ctx->selfTurnData[ctx->battlerIdAttacker].statusFlags |= (1 << 1);
        }
        ctx->battlerIdTemp = ctx->battlerIdTarget;
    }

    return TRUE;
}

void BattleContext_UpdateMetronomeItem(BattleSystem *battleSystem, BattleContext *ctx) {
    if (GetBattlerHeldItemEffect(ctx, ctx->battlerIdAttacker) == HOLD_EFFECT_BOOST_REPEATED) {
        if (!(ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_RAMPAGE) && !(ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_UPROAR) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_MOVE_HIT) && !(ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_LOCKED_INTO_MOVE)) {
            if (ctx->moveNoMetronome[ctx->battlerIdAttacker] == ctx->moveNoTemp) {
                if (ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.metronomeTurns < 10) {
                    ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.metronomeTurns++;
                }
            } else {
                ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.metronomeTurns = 0;
                ctx->moveNoMetronome[ctx->battlerIdAttacker] = ctx->moveNoTemp;
            }
        }
    } else {
        ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.metronomeTurns = 0;
    }
}

void BattleContext_UndoMetronomeItemOnFail(BattleSystem *battleSystem, BattleContext *ctx) {
    if (GetBattlerHeldItemEffect(ctx, ctx->battlerIdAttacker) == HOLD_EFFECT_BOOST_REPEATED) {
        if ((ctx->moveStatusFlag & MOVE_STATUS_FAIL) && ctx->moveNoMetronome[ctx->battlerIdAttacker] == ctx->moveNoTemp && ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.metronomeTurns && !(ctx->selfTurnData[ctx->battlerIdAttacker].rolloutCount) && !(ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_RAMPAGE) && !(ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_UPROAR) && !(ctx->battleStatus & BATTLE_STATUS_CHARGE_MOVE_HIT) && !(ctx->battleMons[ctx->battlerIdAttacker].status2 & STATUS2_LOCKED_INTO_MOVE)) {
            ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.metronomeTurns--;
        }
    } else {
        ctx->battleMons[ctx->battlerIdAttacker].moveEffectData.metronomeTurns = 0;
    }
}

// Related to send out Pokemon crys..?
int BattleContext_GetLowHpOrStatusCode(BattleContext *ctx, int battlerId, int battlerType, BOOL encounter) {
    int ret;
    int color;
    BOOL half;

    if (encounter == TRUE && (battlerType == 2 || battlerType == 3)) {
        half = TRUE;
    } else {
        half = FALSE;
    }

    ret = 0;

    if (half == TRUE) {
        ret = 0;
    }

    color = CalculateHpBarColor(ctx->battleMons[battlerId].hp, ctx->battleMons[battlerId].maxHp, 48);

    if ((ctx->battleMons[battlerId].status & STATUS_ALL) || (color != 4 && color != 3)) {
        ret = 11;
    }

    return ret;
}

BOOL Battler_CanSelectAction(BattleContext *ctx, int battlerId) {
    BOOL ret = TRUE;

    if ((ctx->battleMons[battlerId].status2 & STATUS2_RECHARGE) || (ctx->battleMons[battlerId].status2 & STATUS2_RAMPAGE) || (ctx->battleMons[battlerId].status2 & STATUS2_UPROAR) || (ctx->battleMons[battlerId].status2 & STATUS2_LOCKED_INTO_MOVE)) {
        ret = FALSE;
    }

    return ret;
}

void BattleSystem_SetCaughtMonCatchData(BattleSystem *battleSystem, BattleContext *ctx, Pokemon *mon) {
    PlayerProfile *profile = BattleSystem_GetPlayerProfile(battleSystem, BATTLER_PLAYER);
    int location = BattleSystem_GetLocation(battleSystem);
    int terrain = BattleSystem_GetTerrainId(battleSystem);
    int ballId;

    if (BattleSystem_GetBattleType(battleSystem) & BATTLE_TYPE_PAL_PARK) {
        ballId = BallToItemId(BattleSystem_GetMonBall(battleSystem, mon));
    } else {
        ballId = ctx->itemTemp;
    }

    MonSetCatchData(mon, profile, ballId, location, terrain, HEAP_ID_BATTLE);
}

u8 BattleBuffer_GetNext(BattleContext *ctx, int battlerId) {
    return ctx->battleBuffer[battlerId][0];
}

BOOL BattlerCheckSubstitute(BattleContext *ctx, int battlerId) {
    BOOL ret = FALSE;

    if (ctx->selfTurnData[battlerId].statusFlags & (1 << 3)) {
        ret = TRUE;
    }

    return ret;
}

BOOL BattleContext_IsAttackerPlayerOT(BattleSystem *battleSystem, BattleContext *ctx) {
    PlayerProfile *profile = BattleSystem_GetPlayerProfile(battleSystem, BATTLER_PLAYER);
    u32 trainerId = PlayerProfile_GetTrainerID(profile);
    u32 gender = PlayerProfile_GetTrainerGender(profile);
    const u16 *name = PlayerProfile_GetNamePtr(profile);

    if (trainerId == ctx->battleMons[ctx->battlerIdAttacker].otid && gender == ctx->battleMons[ctx->battlerIdAttacker].otGender && !StringNotEqualN(name, &ctx->battleMons[ctx->battlerIdAttacker].otName[0], PLAYER_NAME_LENGTH)) {
        return TRUE;
    }

    return FALSE;
}

BOOL BattleSystem_IsPlayerOT(BattleSystem *battleSystem, Pokemon *mon) {
    PlayerProfile *profile = BattleSystem_GetPlayerProfile(battleSystem, BATTLER_PLAYER);
    u32 trainerId = PlayerProfile_GetTrainerID(profile);
    u32 gender = PlayerProfile_GetTrainerGender(profile);
    const u16 *name = PlayerProfile_GetNamePtr(profile);
    u16 otName[8];

    GetMonData(mon, MON_DATA_OT_NAME, otName);

    if (trainerId == GetMonData(mon, MON_DATA_OT_ID, NULL) && gender == GetMonData(mon, MON_DATA_OT_GENDER, NULL) && !StringNotEqualN(name, otName, PLAYER_NAME_LENGTH)) {
        return TRUE;
    }

    return FALSE;
}

BOOL Battler_CheckWeatherFormChange(BattleSystem *battleSystem, BattleContext *ctx, int *script) {
    int i;
    int form;
    BOOL ret = FALSE;

    for (i = 0; i < BattleSystem_GetMaxBattlers(battleSystem); i++) {
        ctx->battlerIdTemp = ctx->turnOrder[i];
        if (ctx->battleMons[ctx->battlerIdTemp].species == SPECIES_CASTFORM && ctx->battleMons[ctx->battlerIdTemp].hp && GetBattlerAbility(ctx, ctx->battlerIdTemp) == ABILITY_FORECAST) {
            if (!CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_CLOUD_NINE) && !CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_AIR_LOCK)) {
                if (!(ctx->fieldCondition & FIELD_CONDITION_WEATHER_CASTFORM) && ctx->battleMons[ctx->battlerIdTemp].type1 != TYPE_NORMAL && ctx->battleMons[ctx->battlerIdTemp].type2 != TYPE_NORMAL) {
                    ctx->battleMons[ctx->battlerIdTemp].type1 = TYPE_NORMAL;
                    ctx->battleMons[ctx->battlerIdTemp].type2 = TYPE_NORMAL;
                    ctx->battleMons[ctx->battlerIdTemp].form = (u8)CASTFORM_NORMAL;
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                } else if ((ctx->fieldCondition & FIELD_CONDITION_SUN_ALL) && ctx->battleMons[ctx->battlerIdTemp].type1 != TYPE_FIRE && ctx->battleMons[ctx->battlerIdTemp].type2 != TYPE_FIRE) {
                    ctx->battleMons[ctx->battlerIdTemp].type1 = TYPE_FIRE;
                    ctx->battleMons[ctx->battlerIdTemp].type2 = TYPE_FIRE;
                    ctx->battleMons[ctx->battlerIdTemp].form = (u8)CASTFORM_SUNNY;
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                } else if ((ctx->fieldCondition & FIELD_CONDITION_RAIN_ALL) && ctx->battleMons[ctx->battlerIdTemp].type1 != TYPE_WATER && ctx->battleMons[ctx->battlerIdTemp].type2 != TYPE_WATER) {
                    ctx->battleMons[ctx->battlerIdTemp].type1 = TYPE_WATER;
                    ctx->battleMons[ctx->battlerIdTemp].type2 = TYPE_WATER;
                    ctx->battleMons[ctx->battlerIdTemp].form = (u8)CASTFORM_RAINY;
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                } else if ((ctx->fieldCondition & FIELD_CONDITION_HAIL_ALL) && ctx->battleMons[ctx->battlerIdTemp].type1 != TYPE_ICE && ctx->battleMons[ctx->battlerIdTemp].type2 != TYPE_ICE) {
                    ctx->battleMons[ctx->battlerIdTemp].type1 = TYPE_ICE;
                    ctx->battleMons[ctx->battlerIdTemp].type2 = TYPE_ICE;
                    ctx->battleMons[ctx->battlerIdTemp].form = (u8)CASTFORM_SNOWY;
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                }
            } else if (ctx->battleMons[ctx->battlerIdTemp].type1 != TYPE_NORMAL && ctx->battleMons[ctx->battlerIdTemp].type2 != TYPE_NORMAL) {
                ctx->battleMons[ctx->battlerIdTemp].type1 = TYPE_NORMAL;
                ctx->battleMons[ctx->battlerIdTemp].type2 = TYPE_NORMAL;
                ctx->battleMons[ctx->battlerIdTemp].form = (u8)CASTFORM_NORMAL;
                *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                ret = TRUE;
                break;
            }
        }
        if (ctx->battleMons[ctx->battlerIdTemp].species == SPECIES_CHERRIM && ctx->battleMons[ctx->battlerIdTemp].hp) {
            if (!CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_CLOUD_NINE) && !CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_AIR_LOCK)) {
                if (!(ctx->fieldCondition & FIELD_CONDITION_WEATHER_CASTFORM) && ctx->battleMons[ctx->battlerIdTemp].form == (u8)CHERRIM_SUNNY) {
                    ctx->battleMons[ctx->battlerIdTemp].form = (u8)CHERRIM_CLOUDY;
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                } else if ((ctx->fieldCondition & FIELD_CONDITION_SUN_ALL) && ctx->battleMons[ctx->battlerIdTemp].form == (u8)CHERRIM_CLOUDY) {
                    ctx->battleMons[ctx->battlerIdTemp].form = (u8)CHERRIM_SUNNY;
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                } else if ((ctx->fieldCondition & FIELD_CONDITION_RAIN_ALL) && ctx->battleMons[ctx->battlerIdTemp].form == (u8)CHERRIM_SUNNY) {
                    ctx->battleMons[ctx->battlerIdTemp].form = (u8)CHERRIM_CLOUDY;
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                } else if ((ctx->fieldCondition & FIELD_CONDITION_HAIL_ALL) && ctx->battleMons[ctx->battlerIdTemp].form == (u8)CHERRIM_SUNNY) {
                    ctx->battleMons[ctx->battlerIdTemp].form = (u8)CHERRIM_CLOUDY;
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                }
            } else if (ctx->battleMons[ctx->battlerIdTemp].form == (u8)CHERRIM_SUNNY) {
                ctx->battleMons[ctx->battlerIdTemp].form = (u8)CHERRIM_CLOUDY;
                *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                ret = TRUE;
                break;
            }
        }
        if (ctx->battleMons[ctx->battlerIdTemp].species == SPECIES_ARCEUS && ctx->battleMons[ctx->battlerIdTemp].hp && GetBattlerAbility(ctx, ctx->battlerIdTemp) == ABILITY_MULTITYPE) {
            form = GetArceusTypeByHeldItemEffect(GetItemAttr(ctx->battleMons[ctx->battlerIdTemp].item, ITEMATTR_HOLD_EFFECT, HEAP_ID_BATTLE));
            if (ctx->battleMons[ctx->battlerIdTemp].form != form) {
                ctx->battleMons[ctx->battlerIdTemp].form = form;
                *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                ret = TRUE;
                break;
            }
        }
        if (ctx->battleMons[ctx->battlerIdTemp].species == SPECIES_GIRATINA && ctx->battleMons[ctx->battlerIdTemp].hp && ctx->battleMons[ctx->battlerIdTemp].form == GIRATINA_ORIGIN) {
            if ((ctx->battleMons[ctx->battlerIdTemp].status2 & STATUS2_TRANSFORM) || (!(BattleSystem_GetBattleSpecial(battleSystem) & BATTLE_SPECIAL_DISTORTION_WORLD) && ctx->battleMons[ctx->battlerIdTemp].item != ITEM_GRISEOUS_ORB)) {
                if (ctx->battleMons[ctx->battlerIdTemp].status2 & STATUS2_TRANSFORM) {
                    Pokemon *mon2;
                    int battlerIdTarget;
                    int dat;

                    mon2 = AllocMonZeroed(HEAP_ID_BATTLE);

                    if (BattleSystem_GetBattleType(battleSystem) & BATTLE_TYPE_DOUBLES) {
                        battlerIdTarget = ctx->playerActions[ctx->battlerIdTemp].battlerIdTarget;
                    } else {
                        battlerIdTarget = ctx->battlerIdTemp ^ 1;
                    }
                    CopyPokemonToPokemon(BattleSystem_GetPartyMon(battleSystem, battlerIdTarget, ctx->selectedMonIndex[battlerIdTarget]), mon2);
                    dat = 0;
                    SetMonData(mon2, MON_DATA_HELD_ITEM, &dat);
                    dat = (u8)GIRATINA_ALTERED;
                    SetMonData(mon2, MON_DATA_FORM, &dat);
                    Mon_UpdateGiratinaForm(mon2);
                    ctx->battleMons[ctx->battlerIdTemp].atk = GetMonData(mon2, MON_DATA_ATK, NULL);
                    ctx->battleMons[ctx->battlerIdTemp].def = GetMonData(mon2, MON_DATA_DEF, NULL);
                    ctx->battleMons[ctx->battlerIdTemp].speed = GetMonData(mon2, MON_DATA_SPEED, NULL);
                    ctx->battleMons[ctx->battlerIdTemp].spAtk = GetMonData(mon2, MON_DATA_SP_ATK, NULL);
                    ctx->battleMons[ctx->battlerIdTemp].spDef = GetMonData(mon2, MON_DATA_SP_DEF, NULL);
                    ctx->battleMons[ctx->battlerIdTemp].ability = GetMonData(mon2, MON_DATA_ABILITY, NULL);
                    ctx->battleMons[ctx->battlerIdTemp].form = GIRATINA_ALTERED;
                    ctx->battleStatus2 |= BATTLE_STATUS2_FORM_CHANGE;
                    BattleController_EmitBattleMonToPartyMonCopy(battleSystem, ctx, ctx->battlerIdTemp);
                    Heap_Free(mon2);
                    *script = BATTLE_SUBSCRIPT_FORM_CHANGE;
                    ret = TRUE;
                    break;
                } else {
                    *script = BATTLE_SUBSCRIPT_GIRATINA_FORM_CHANGE;
                    ret = TRUE;
                    break;
                }
            }
        }
    }

    return ret;
}

void BattleSystem_InitPartyOrder(BattleSystem *battleSystem, BattleContext *ctx) {
    int battlerId;
    int index;

    for (battlerId = 0; battlerId < BattleSystem_GetMaxBattlers(battleSystem); battlerId++) {
        for (index = 0; index < 6; index++) {
            ctx->partyOrder[battlerId][index] = index;
        }
        BattleSystem_MoveMonToFrontOfPartyOrder(battleSystem, ctx, battlerId, ctx->selectedMonIndex[battlerId]);
    }
}

void BattleSystem_MoveMonToFrontOfPartyOrder(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, u8 selectedMonIndex) {
    int index;
    int dat;
    int flag;
    u32 battleType = BattleSystem_GetBattleType(battleSystem);

    if (((battleType & BATTLE_TYPE_DOUBLES) && !(battleType & (BATTLE_TYPE_MULTI | BATTLE_TYPE_TAG))) || ((battleType & BATTLE_TYPE_TAG) && !(BattleSystem_GetBattlerType(battleSystem, battlerId) & 1))) {
        if (BattleSystem_GetBattlerType(battleSystem, battlerId) == 4 || BattleSystem_GetBattlerType(battleSystem, battlerId) == 5) {
            flag = 1;
        } else {
            flag = 0;
        }
        battlerId &= 1;
    } else {
        flag = 0;
    }

    for (index = 0; index < 6; index++) {
        if (ctx->partyOrder[battlerId][index] == selectedMonIndex) {
            break;
        }
    }

    dat = ctx->partyOrder[battlerId][flag];
    ctx->partyOrder[battlerId][flag] = ctx->partyOrder[battlerId][index];
    ctx->partyOrder[battlerId][index] = dat;
}

typedef struct MoveDamageCalc {
    u16 species;
    s16 hp;
    u16 maxHp;
    u16 unused;
    int item;
    int mod;
    u32 status;
    u8 ability;
    u8 gender;
    u8 type1;
    u8 type2;
} MoveDamageCalc;

static const u8 sTypeEnhancingItems[][2] = {
    { HOLD_EFFECT_STRENGTHEN_BUG,      TYPE_BUG      },
    { HOLD_EFFECT_STRENGTHEN_STEEL,    TYPE_STEEL    },
    { HOLD_EFFECT_STRENGTHEN_GROUND,   TYPE_GROUND   },
    { HOLD_EFFECT_STRENGTHEN_ROCK,     TYPE_ROCK     },
    { HOLD_EFFECT_STRENGTHEN_GRASS,    TYPE_GRASS    },
    { HOLD_EFFECT_STRENGTHEN_DARK,     TYPE_DARK     },
    { HOLD_EFFECT_STRENGTHEN_FIGHT,    TYPE_FIGHTING },
    { HOLD_EFFECT_STRENGTHEN_ELECTRIC, TYPE_ELECTRIC },
    { HOLD_EFFECT_STRENGTHEN_WATER,    TYPE_WATER    },
    { HOLD_EFFECT_STRENGTHEN_FLYING,   TYPE_FLYING   },
    { HOLD_EFFECT_STRENGTHEN_POISON,   TYPE_POISON   },
    { HOLD_EFFECT_STRENGTHEN_ICE,      TYPE_ICE      },
    { HOLD_EFFECT_STRENGTHEN_GHOST,    TYPE_GHOST    },
    { HOLD_EFFECT_STRENGTHEN_PSYCHIC,  TYPE_PSYCHIC  },
    { HOLD_EFFECT_STRENGTHEN_FIRE,     TYPE_FIRE     },
    { HOLD_EFFECT_STRENGTHEN_DRAGON,   TYPE_DRAGON   },
    { HOLD_EFFECT_STRENGTHEN_NORMAL,   TYPE_NORMAL   },
    { HOLD_EFFECT_ARCEUS_FIRE,         TYPE_FIRE     },
    { HOLD_EFFECT_ARCEUS_WATER,        TYPE_WATER    },
    { HOLD_EFFECT_ARCEUS_ELECTRIC,     TYPE_ELECTRIC },
    { HOLD_EFFECT_ARCEUS_GRASS,        TYPE_GRASS    },
    { HOLD_EFFECT_ARCEUS_ICE,          TYPE_ICE      },
    { HOLD_EFFECT_ARCEUS_FIGHTING,     TYPE_FIGHTING },
    { HOLD_EFFECT_ARCEUS_POISON,       TYPE_POISON   },
    { HOLD_EFFECT_ARCEUS_GROUND,       TYPE_GROUND   },
    { HOLD_EFFECT_ARCEUS_FLYING,       TYPE_FLYING   },
    { HOLD_EFFECT_ARCEUS_PSYCHIC,      TYPE_PSYCHIC  },
    { HOLD_EFFECT_ARCEUS_BUG,          TYPE_BUG      },
    { HOLD_EFFECT_ARCEUS_ROCK,         TYPE_ROCK     },
    { HOLD_EFFECT_ARCEUS_GHOST,        TYPE_GHOST    },
    { HOLD_EFFECT_ARCEUS_DRAGON,       TYPE_DRAGON   },
    { HOLD_EFFECT_ARCEUS_DARK,         TYPE_DARK     },
    { HOLD_EFFECT_ARCEUS_STEEL,        TYPE_STEEL    }
};

static const u8 sStatChangeTable[][2] = {
    { 10, 40 },
    { 10, 35 },
    { 10, 30 },
    { 10, 25 },
    { 10, 20 },
    { 10, 15 },
    { 10, 10 },
    { 15, 10 },
    { 20, 10 },
    { 25, 10 },
    { 30, 10 },
    { 35, 10 },
    { 40, 10 }
};

static const u16 sPunchingMoves[] = {
    MOVE_ICE_PUNCH,
    MOVE_FIRE_PUNCH,
    MOVE_THUNDER_PUNCH,
    MOVE_MACH_PUNCH,
    MOVE_FOCUS_PUNCH,
    MOVE_DIZZY_PUNCH,
    MOVE_DYNAMIC_PUNCH,
    MOVE_HAMMER_ARM,
    MOVE_MEGA_PUNCH,
    MOVE_COMET_PUNCH,
    MOVE_METEOR_MASH,
    MOVE_SHADOW_PUNCH,
    MOVE_DRAIN_PUNCH,
    MOVE_BULLET_PUNCH,
    MOVE_SKY_UPPERCUT
};

int CalcMoveDamage(BattleSystem *battleSystem, BattleContext *ctx, u32 moveNo, u32 sideCondition, u32 fieldCondition, u16 power, u8 type, u8 battlerIdAttacker, u8 battlerIdTarget, u8 crit) {
    int i;
    s32 dmg = 0;
    s32 dmg2 = 0;
    u8 moveType;
    u8 moveCategory;
    u16 monAtk;
    u16 monDef;
    u16 monSpAtk;
    u16 monSpDef;
    s8 statChangeAtk;
    s8 statChangeDef;
    s8 statChangeSpAtk;
    s8 statChangeSpDef;
    u8 level;
    u16 movePower;
    u16 item;
    u32 battleType;
    MoveDamageCalc calcAttacker;
    MoveDamageCalc calcTarget;

    GF_ASSERT(crit == 1 || crit > 1);

    monAtk = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_ATK, NULL);
    monDef = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_DEF, NULL);
    monSpAtk = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_SPATK, NULL);
    monSpDef = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_SPDEF, NULL);
    statChangeAtk = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_STAT_CHANGE_ATK, NULL) - 6;
    statChangeDef = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_STAT_CHANGE_DEF, NULL) - 6;
    statChangeSpAtk = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_STAT_CHANGE_SPATK, NULL) - 6;
    statChangeSpDef = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_STAT_CHANGE_SPDEF, NULL) - 6;
    level = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_LEVEL, NULL);
    calcAttacker.species = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_SPECIES, NULL);
    calcTarget.species = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_SPECIES, NULL);
    calcAttacker.hp = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_HP, NULL);
    calcTarget.hp = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_HP, NULL);
    calcAttacker.maxHp = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_MAXHP, NULL);
    calcTarget.maxHp = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_MAXHP, NULL);
    calcAttacker.status = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_STATUS, NULL);
    calcTarget.status = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_STATUS, NULL);
    calcAttacker.ability = GetBattlerAbility(ctx, battlerIdAttacker);
    calcTarget.ability = GetBattlerAbility(ctx, battlerIdTarget);
    calcAttacker.gender = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_GENDER, NULL);
    calcTarget.gender = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_GENDER, NULL);
    calcAttacker.type1 = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_TYPE_1, NULL);
    calcTarget.type1 = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_TYPE_1, NULL);
    calcAttacker.type2 = GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_TYPE_2, NULL);
    calcTarget.type2 = GetBattlerVar(ctx, battlerIdTarget, BMON_DATA_TYPE_2, NULL);

    item = GetBattlerHeldItem(ctx, battlerIdAttacker);
    calcAttacker.item = GetItemVar(ctx, item, ITEM_VAR_HOLD_EFFECT);
    calcAttacker.mod = GetItemVar(ctx, item, ITEM_VAR_MODIFIER);

    item = GetBattlerHeldItem(ctx, battlerIdTarget);
    calcTarget.item = GetItemVar(ctx, item, ITEM_VAR_HOLD_EFFECT);
    calcTarget.mod = GetItemVar(ctx, item, ITEM_VAR_MODIFIER);

    battleType = BattleSystem_GetBattleType(battleSystem);

    if (power == 0) {
        movePower = ctx->trainerAIData.moveData[moveNo].power;
    } else {
        movePower = power;
    }

    if (calcAttacker.ability == ABILITY_NORMALIZE) {
        moveType = TYPE_NORMAL;
    } else if (type == 0) {
        moveType = ctx->trainerAIData.moveData[moveNo].type;
    } else {
        moveType = type & 0x3F;
    }

    GF_ASSERT(ctx->powerMultiplier >= 10);
    movePower = movePower * ctx->powerMultiplier / 10;

    if ((ctx->battleMons[battlerIdAttacker].moveEffectFlags & MOVE_EFFECT_FLAG_CHARGE) && moveType == TYPE_ELECTRIC) {
        movePower *= 2;
    }

    if (ctx->turnData[battlerIdAttacker].helpingHandFlag) {
        movePower = movePower * 15 / 10;
    }

    if (calcAttacker.ability == ABILITY_TECHNICIAN && moveNo != MOVE_STRUGGLE && movePower <= 60) {
        movePower = movePower * 15 / 10;
    }

    moveCategory = ctx->trainerAIData.moveData[moveNo].category;

    if (calcAttacker.ability == ABILITY_HUGE_POWER || calcAttacker.ability == ABILITY_PURE_POWER) {
        monAtk *= 2;
    }

    if (calcAttacker.ability == ABILITY_SLOW_START && (int)(BattleContext_Get(battleSystem, ctx, 3, 0) - GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_SLOW_START_TURN_NUMBER, NULL)) < 5) {
        monAtk /= 2;
    }

    for (i = 0; i < NELEMS(sTypeEnhancingItems); i++) {
        if (calcAttacker.item == sTypeEnhancingItems[i][0] && moveType == sTypeEnhancingItems[i][1]) {
            movePower = movePower * (100 + calcAttacker.mod) / 100;
            break;
        }
    }

    if (calcAttacker.item == HOLD_EFFECT_CHOICE_ATK) {
        monAtk = monAtk * 150 / 100;
    }
    if (calcAttacker.item == HOLD_EFFECT_CHOICE_SPATK) {
        monSpAtk = monSpAtk * 150 / 100;
    }

    if (calcAttacker.item == HOLD_EFFECT_LATI_SPECIAL && !(battleType & BATTLE_TYPE_FRONTIER) && (calcAttacker.species == SPECIES_LATIOS || calcAttacker.species == SPECIES_LATIAS)) {
        monSpAtk = monSpAtk * 150 / 100;
    }

    if (calcTarget.item == HOLD_EFFECT_LATI_SPECIAL && !(battleType & BATTLE_TYPE_FRONTIER) && (calcTarget.species == SPECIES_LATIOS || calcTarget.species == SPECIES_LATIAS)) {
        monSpDef = monSpDef * 150 / 100;
    }

    if (calcAttacker.item == HOLD_EFFECT_CLAMPERL_SPATK && calcAttacker.species == SPECIES_CLAMPERL) {
        monSpAtk *= 2;
    }

    if (calcTarget.item == HOLD_EFFECT_CLAMPERL_SPDEF && calcTarget.species == SPECIES_CLAMPERL) {
        monSpDef *= 2;
    }

    if (calcAttacker.item == HOLD_EFFECT_PIKA_SPATK_UP && calcAttacker.species == SPECIES_PIKACHU) {
        movePower *= 2;
    }

    if (calcTarget.item == HOLD_EFFECT_DITTO_DEF_UP && calcTarget.species == SPECIES_DITTO) {
        monDef *= 2;
    }

    if (calcAttacker.item == HOLD_EFFECT_CUBONE_ATK_UP && (calcAttacker.species == SPECIES_CUBONE || calcAttacker.species == SPECIES_MAROWAK)) {
        monAtk *= 2;
    }

    if (calcAttacker.item == HOLD_EFFECT_DIALGA_BOOST && (moveType == TYPE_DRAGON || moveType == TYPE_STEEL) && calcAttacker.species == SPECIES_DIALGA) {
        movePower = movePower * (100 + calcAttacker.mod) / 100;
    }

    if (calcAttacker.item == HOLD_EFFECT_PALKIA_BOOST && (moveType == TYPE_DRAGON || moveType == TYPE_WATER) && calcAttacker.species == SPECIES_PALKIA) {
        movePower = movePower * (100 + calcAttacker.mod) / 100;
    }

    if (calcAttacker.item == HOLD_EFFECT_GIRATINA_BOOST && (moveType == TYPE_DRAGON || moveType == TYPE_GHOST) && !(GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_STATUS2, NULL) & STATUS2_TRANSFORM) && calcAttacker.species == SPECIES_GIRATINA) {
        movePower = movePower * (100 + calcAttacker.mod) / 100;
    }

    if (calcAttacker.item == HOLD_EFFECT_POWER_UP_PHYS && moveCategory == CATEGORY_PHYSICAL) {
        movePower = movePower * (100 + calcAttacker.mod) / 100;
    }

    if (calcAttacker.item == HOLD_EFFECT_POWER_UP_SPEC && moveCategory == CATEGORY_SPECIAL) {
        movePower = movePower * (100 + calcAttacker.mod) / 100;
    }

    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_THICK_FAT) == TRUE && (moveType == TYPE_FIRE || moveType == TYPE_ICE)) {
        movePower /= 2;
    }

    if (calcAttacker.ability == ABILITY_HUSTLE) {
        monAtk = monAtk * 150 / 100;
    }

    if (calcAttacker.ability == ABILITY_GUTS && calcAttacker.status) {
        monAtk = monAtk * 150 / 100;
    }

    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_MARVEL_SCALE) == TRUE && calcTarget.status) {
        monDef = monDef * 150 / 100;
    }

    if (calcAttacker.ability == ABILITY_PLUS && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_SAME_SIDE_HP, battlerIdAttacker, ABILITY_MINUS)) {
        monSpAtk = monSpAtk * 150 / 100;
    }

    if (calcAttacker.ability == ABILITY_MINUS && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_SAME_SIDE_HP, battlerIdAttacker, ABILITY_PLUS)) {
        monSpAtk = monSpAtk * 150 / 100;
    }

    if (moveType == TYPE_ELECTRIC && CheckMoveEffectOnField(battleSystem, ctx, MOVE_EFFECT_FLAG_MUD_SPORT)) {
        movePower /= 2;
    }

    if (moveType == TYPE_FIRE && CheckMoveEffectOnField(battleSystem, ctx, MOVE_EFFECT_FLAG_WATER_SPORT)) {
        movePower /= 2;
    }

    if (moveType == TYPE_GRASS && calcAttacker.ability == ABILITY_OVERGROW && calcAttacker.hp <= calcAttacker.maxHp / 3) {
        movePower = movePower * 150 / 100;
    }

    if (moveType == TYPE_FIRE && calcAttacker.ability == ABILITY_BLAZE && calcAttacker.hp <= calcAttacker.maxHp / 3) {
        movePower = movePower * 150 / 100;
    }

    if (moveType == TYPE_WATER && calcAttacker.ability == ABILITY_TORRENT && calcAttacker.hp <= calcAttacker.maxHp / 3) {
        movePower = movePower * 150 / 100;
    }

    if (moveType == TYPE_BUG && calcAttacker.ability == ABILITY_SWARM && calcAttacker.hp <= calcAttacker.maxHp / 3) {
        movePower = movePower * 150 / 100;
    }

    if (moveType == TYPE_FIRE && CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_HEATPROOF) == TRUE) {
        movePower /= 2;
    }

    if (moveType == TYPE_FIRE && CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_DRY_SKIN) == TRUE) {
        movePower = movePower * 125 / 100;
    }

    if (calcAttacker.ability == ABILITY_SIMPLE) {
        statChangeAtk *= 2;
        if (statChangeAtk < -6) {
            statChangeAtk = -6;
        }
        if (statChangeAtk > 6) {
            statChangeAtk = 6;
        }
        statChangeSpAtk *= 2;
        if (statChangeSpAtk < -6) {
            statChangeSpAtk = -6;
        }
        if (statChangeSpAtk > 6) {
            statChangeSpAtk = 6;
        }
    }

    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_SIMPLE) == TRUE) {
        statChangeDef *= 2;
        if (statChangeDef < -6) {
            statChangeDef = -6;
        }
        if (statChangeDef > 6) {
            statChangeDef = 6;
        }
        statChangeSpDef *= 2;
        if (statChangeSpDef < -6) {
            statChangeSpDef = -6;
        }
        if (statChangeSpDef > 6) {
            statChangeSpDef = 6;
        }
    }

    if (CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_UNAWARE) == TRUE) {
        statChangeAtk = 0;
        statChangeSpAtk = 0;
    }
    if (calcAttacker.ability == ABILITY_UNAWARE) {
        statChangeDef = 0;
        statChangeSpDef = 0;
    }

    statChangeAtk += 6;
    statChangeDef += 6;
    statChangeSpAtk += 6;
    statChangeSpDef += 6;

    if (calcAttacker.ability == ABILITY_RIVALRY && calcAttacker.gender == calcTarget.gender && calcAttacker.gender != MON_GENDERLESS && calcTarget.gender != MON_GENDERLESS) {
        movePower = movePower * 125 / 100;
    }
    if (calcAttacker.ability == ABILITY_RIVALRY && calcAttacker.gender != calcTarget.gender && calcAttacker.gender != MON_GENDERLESS && calcTarget.gender != MON_GENDERLESS) {
        movePower = movePower * 75 / 100;
    }

    for (i = 0; i < NELEMS(sPunchingMoves); i++) {
        if (sPunchingMoves[i] == moveNo && calcAttacker.ability == ABILITY_IRON_FIST) {
            movePower = movePower * BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE / 10;
            break;
        }
    }

    if (!CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_CLOUD_NINE) && !CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_AIR_LOCK)) {
        if ((fieldCondition & FIELD_CONDITION_SUN_ALL) && calcAttacker.ability == ABILITY_SOLAR_POWER) {
            monSpAtk = monSpAtk * 15 / 10;
        }
        if ((fieldCondition & FIELD_CONDITION_SANDSTORM_ALL) && (calcTarget.type1 == TYPE_ROCK || calcTarget.type2 == TYPE_ROCK)) {
            monSpDef = monSpDef * 15 / 10;
        }
        if ((fieldCondition & FIELD_CONDITION_SUN_ALL) && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_SAME_SIDE_HP, battlerIdAttacker, ABILITY_FLOWER_GIFT)) {
            monAtk = monAtk * 15 / 10;
        }
        if ((fieldCondition & FIELD_CONDITION_SUN_ALL) && GetBattlerAbility(ctx, battlerIdAttacker) != ABILITY_MOLD_BREAKER && CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_SAME_SIDE_HP, battlerIdTarget, ABILITY_FLOWER_GIFT)) {
            monSpDef = monSpDef * 15 / 10;
        }
    }

    if (ctx->trainerAIData.moveData[moveNo].effect == MOVE_EFFECT_HALVE_DEFENSE) {
        monDef /= 2;
    }

    if (moveCategory == CATEGORY_PHYSICAL) {
        if (crit > 1) {
            if (statChangeAtk > 6) {
                dmg = monAtk * sStatChangeTable[statChangeAtk][0] / sStatChangeTable[statChangeAtk][1];
            } else {
                dmg = monAtk;
            }
        } else {
            dmg = monAtk * sStatChangeTable[statChangeAtk][0] / sStatChangeTable[statChangeAtk][1];
        }

        dmg *= movePower;
        dmg *= ((level * 2 / 5) + 2);

        if (crit > 1) {
            if (statChangeDef < 6) {
                dmg2 = monDef * sStatChangeTable[statChangeDef][0] / sStatChangeTable[statChangeDef][1];
            } else {
                dmg2 = monDef;
            }
        } else {
            dmg2 = monDef * sStatChangeTable[statChangeDef][0] / sStatChangeTable[statChangeDef][1];
        }

        dmg /= dmg2;
        dmg /= 50;

        if ((calcAttacker.status & STATUS_BURN) && calcAttacker.ability != ABILITY_GUTS) {
            dmg /= 2;
        }

        if ((sideCondition & SIDE_CONDITION_REFLECT) && crit == 1 && ctx->trainerAIData.moveData[moveNo].effect != MOVE_EFFECT_REMOVE_SCREENS) {
            if ((battleType & BATTLE_TYPE_DOUBLES) && GetMonsHitCount(battleSystem, ctx, 1, battlerIdTarget) == 2) {
                dmg = dmg * 2 / 3;
            } else {
                dmg /= 2;
            }
        }
    } else if (moveCategory == CATEGORY_SPECIAL) {
        if (crit > 1) {
            if (statChangeSpAtk > 6) {
                dmg = monSpAtk * sStatChangeTable[statChangeSpAtk][0] / sStatChangeTable[statChangeSpAtk][1];
            } else {
                dmg = monSpAtk;
            }
        } else {
            dmg = monSpAtk * sStatChangeTable[statChangeSpAtk][0] / sStatChangeTable[statChangeSpAtk][1];
        }

        dmg *= movePower;
        dmg *= ((level * 2 / 5) + 2);

        if (crit > 1) {
            if (statChangeSpDef < 6) {
                dmg2 = monSpDef * sStatChangeTable[statChangeSpDef][0] / sStatChangeTable[statChangeSpDef][1];
            } else {
                dmg2 = monSpDef;
            }
        } else {
            dmg2 = monSpDef * sStatChangeTable[statChangeSpDef][0] / sStatChangeTable[statChangeSpDef][1];
        }

        dmg /= dmg2;
        dmg /= 50;

        if ((sideCondition & SIDE_CONDITION_LIGHT_SCREEN) && crit == 1 && ctx->trainerAIData.moveData[moveNo].effect != MOVE_EFFECT_REMOVE_SCREENS) {
            if ((battleType & BATTLE_TYPE_DOUBLES) && GetMonsHitCount(battleSystem, ctx, 1, battlerIdTarget) == 2) {
                dmg = dmg * 2 / 3;
            } else {
                dmg /= 2;
            }
        }
    }

    if ((battleType & BATTLE_TYPE_DOUBLES) && ctx->trainerAIData.moveData[moveNo].range == RANGE_ADJACENT_OPPONENTS && GetMonsHitCount(battleSystem, ctx, 1, battlerIdTarget) == 2) {
        dmg = dmg * 3 / 4;
    }
    if ((battleType & BATTLE_TYPE_DOUBLES) && ctx->trainerAIData.moveData[moveNo].range == RANGE_ALL_ADJACENT && GetMonsHitCount(battleSystem, ctx, 0, battlerIdTarget) >= 2) {
        dmg = dmg * 3 / 4;
    }

    if (!CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_CLOUD_NINE) && !CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_AIR_LOCK)) {
        if (fieldCondition & FIELD_CONDITION_RAIN_ALL) {
            switch (moveType) {
            case TYPE_FIRE:
                dmg /= 2;
                break;
            case TYPE_WATER:
                dmg = dmg * 15 / 10;
                break;
            }
        }

        if ((fieldCondition & FIELD_CONDITION_WEATHER_NO_SUN) && moveNo == MOVE_SOLAR_BEAM) {
            dmg /= 2;
        }
        if (fieldCondition & FIELD_CONDITION_SUN_ALL) {
            switch (moveType) {
            case TYPE_FIRE:
                dmg = dmg * 15 / 10;
                break;
            case TYPE_WATER:
                dmg /= 2;
                break;
            }
        }
    }

    if (GetBattlerVar(ctx, battlerIdAttacker, BMON_DATA_FLASH_FIRE, NULL) && moveType == TYPE_FIRE) {
        dmg = dmg * 15 / 10;
    }

    return dmg + 2;
}

int ApplyDamageRange(BattleSystem *battleSystem, BattleContext *ctx, int damage) {
    if (damage) {
        damage *= (100 - (BattleSystem_Random(battleSystem) % 16));
        damage /= 100;
        if (!damage) {
            damage = 1;
        }
    }
    return damage;
}

static const u8 sCritChance[] = {
    16, 8, 4, 3, 2
};

u32 TryCriticalHit(BattleSystem *battleSystem, BattleContext *ctx, int battlerIdAttacker, int battlerIdTarget, int critCnt, u32 sideCondition) {
    u16 critUp;
    int item;
    u16 species;
    u32 status2;
    u32 moveEffect;
    int ret = 1;
    int ability;

    item = GetItemVar(ctx, GetBattlerHeldItem(ctx, battlerIdAttacker), ITEM_VAR_HOLD_EFFECT);
    species = ctx->battleMons[battlerIdAttacker].species;
    status2 = ctx->battleMons[battlerIdAttacker].status2;
    moveEffect = ctx->battleMons[battlerIdTarget].moveEffectFlags;
    ability = ctx->battleMons[battlerIdAttacker].ability;

    critUp = (((status2 & STATUS2_FOCUS_ENERGY) != 0) * 2) + (item == HOLD_EFFECT_CRITRATE_UP) + critCnt + (ability == ABILITY_SUPER_LUCK) + 2 * ((item == HOLD_EFFECT_CHANSEY_CRITRATE_UP) && (species == SPECIES_CHANSEY)) + 2 * ((item == HOLD_EFFECT_FARFETCHD_CRITRATE_UP) && (species == SPECIES_FARFETCHD));

    if (critUp > 4) {
        critUp = 4;
    }

    if ((BattleSystem_Random(battleSystem) % sCritChance[critUp]) == 0) {
        if (!CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_BATTLE_ARMOR) && !CheckBattlerAbilityIfNotIgnored(ctx, battlerIdAttacker, battlerIdTarget, ABILITY_SHELL_ARMOR) && !(sideCondition & SIDE_CONDITION_LUCKY_CHANT) && !(moveEffect & MOVE_EFFECT_FLAG_LUCKY_CHANT)) {
            ret = 2;
        }
    }

    if ((ret == 2) && GetBattlerAbility(ctx, battlerIdAttacker) == ABILITY_SNIPER) {
        ret = 3;
    }

    return ret;
}

static const u16 sMetronomeUnuseableMoves[] = {
    MOVE_METRONOME,
    MOVE_STRUGGLE,
    MOVE_SKETCH,
    MOVE_MIMIC,
    MOVE_CHATTER,
    0xFFFE,
    MOVE_SLEEP_TALK,
    MOVE_ASSIST,
    MOVE_MIRROR_MOVE,
    MOVE_COUNTER,
    MOVE_MIRROR_COAT,
    MOVE_PROTECT,
    MOVE_DETECT,
    MOVE_ENDURE,
    MOVE_DESTINY_BOND,
    MOVE_THIEF,
    MOVE_FOLLOW_ME,
    MOVE_SNATCH,
    MOVE_HELPING_HAND,
    MOVE_COVET,
    MOVE_TRICK,
    MOVE_FOCUS_PUNCH,
    MOVE_FEINT,
    MOVE_COPYCAT,
    MOVE_ME_FIRST,
    MOVE_SWITCHEROO,
    0xFFFF
};

BOOL CheckLegalMimicMove(u16 moveNo) {
    int i = 0;

    do {
        if (sMetronomeUnuseableMoves[i] == moveNo) {
            break;
        }
        i++;
    } while (sMetronomeUnuseableMoves[i] != 0xFFFE);

    return sMetronomeUnuseableMoves[i] == 0xFFFE;
}

BOOL CheckLegalMetronomeMove(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, u16 moveNo) {
    int i = 0;

    if (BattleContext_CheckMoveUnuseableInGravity(battleSystem, ctx, battlerId, moveNo) == TRUE || BattleContext_CheckMoveHealBlocked(battleSystem, ctx, battlerId, moveNo) == TRUE) {
        return FALSE;
    }

    do {
        if (moveNo == sMetronomeUnuseableMoves[i]) {
            break;
        }
        i++;
    } while (sMetronomeUnuseableMoves[i] != 0xFFFF);

    return sMetronomeUnuseableMoves[i] == 0xFFFF;
}

static const u16 sEncoreFailMoves[] = {
    MOVE_TRANSFORM,
    MOVE_MIMIC,
    MOVE_SKETCH,
    MOVE_MIRROR_MOVE,
    MOVE_ENCORE,
    MOVE_STRUGGLE
};

BOOL IsMoveEncored(BattleContext *ctx, u16 moveNo) {
    int i = 0;

    do {
        if (ctx->trainerAIData.moveData[sEncoreFailMoves[i]].effect == ctx->trainerAIData.moveData[moveNo].effect) {
            break;
        }
        i++;
    } while (i < NELEMS(sEncoreFailMoves));

    return i == NELEMS(sEncoreFailMoves);
}

static const u16 sMeFirstUnuseableMoves[] = {
    MOVE_COUNTER,
    MOVE_MIRROR_COAT,
    MOVE_THIEF,
    MOVE_COVET,
    MOVE_FOCUS_PUNCH,
    MOVE_CHATTER
};

BOOL CheckLegalMeFirstMove(BattleContext *ctx, u16 moveNo) {
    int i = 0;

    do {
        if (ctx->trainerAIData.moveData[sMeFirstUnuseableMoves[i]].effect == ctx->trainerAIData.moveData[moveNo].effect) {
            break;
        }
        i++;
    } while (i < NELEMS(sMeFirstUnuseableMoves));

    return i == NELEMS(sMeFirstUnuseableMoves);
}

s32 GetItemVar(BattleContext *ctx, u16 itemNo, u16 var) {
    ItemData *itemData;
    u32 index = GetItemIndexMapping(itemNo, 0);
    itemData = GetItemDataPtrFromArray(ctx->trainerAIData.itemData, index);

    return GetItemAttr_PreloadedItemData(itemData, var);
}

int BattleSystem_GetFirstBattlerOnSide(BattleSystem *battleSystem, BattleContext *ctx, int side) {
    int battlerId;
    int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    for (battlerId = 0; battlerId < maxBattlers; battlerId++) {
        if (BattleSystem_GetFieldSide(battleSystem, battlerId) == side) {
            break;
        }
    }

    return battlerId;
}

void SortExecutionOrderBySpeed(BattleSystem *battleSystem, BattleContext *ctx) {
    int i, j;
    int battlerId1;
    int battlerId2;
    int flag;
    int maxBattlers = BattleSystem_GetMaxBattlers(battleSystem);

    for (i = 0; i < maxBattlers - 1; i++) {
        for (j = i + 1; j < maxBattlers; j++) {
            battlerId1 = ctx->executionOrder[i];
            battlerId2 = ctx->executionOrder[j];
            if (ctx->playerActions[battlerId1].inputSelection == ctx->playerActions[battlerId2].inputSelection) {
                if (ctx->playerActions[battlerId1].inputSelection != BATTLE_INPUT_FIGHT) {
                    flag = 1;
                } else {
                    flag = 0;
                }
                if (CheckSortSpeed(battleSystem, ctx, battlerId1, battlerId2, flag)) {
                    ctx->executionOrder[i] = battlerId2;
                    ctx->executionOrder[j] = battlerId1;
                }
            }
        }
    }
}

static const int sSubstituteStatusEffects[] = {
    15, 16, 17, 18, 19, 20, 21, 22, 25, 26
};

BOOL CheckStatusEffectsSubstitute(BattleContext *ctx, int battlerId, int status) {
    int i;
    BOOL ret = FALSE;

    if ((ctx->battleMons[battlerId].status2 & STATUS2_SUBSTITUTE) || (ctx->battleMons[battlerId].moveEffectFlags & MOVE_EFFECT_FLAG_HIDE_SUBSTITUTE)) {
        for (i = 0; i < NELEMS(sSubstituteStatusEffects); i++) {
            if (sSubstituteStatusEffects[i] == status) {
                ret = TRUE;
                break;
            }
        }
    } else {
        ret = TRUE;
    }

    return ret;
}

BOOL CheckItemEffectOnUTurn(BattleSystem *battleSystem, BattleContext *ctx, int *script) {
    BOOL ret = FALSE;
    int itemAttacker = GetBattlerHeldItemEffect(ctx, ctx->battlerIdAttacker);
    int modAttacker = GetHeldItemModifier(ctx, ctx->battlerIdAttacker, 0);
    int itemTarget = GetBattlerHeldItemEffect(ctx, ctx->battlerIdTarget);
    int modTarget = GetHeldItemModifier(ctx, ctx->battlerIdTarget, 0);
    int side = BattleSystem_GetFieldSide(battleSystem, ctx->battlerIdAttacker);

    if (itemAttacker == HOLD_EFFECT_HP_RESTORE_ON_DMG && (ctx->battleStatus & BATTLE_STATUS_MOVE_SUCCESSFUL) && (ctx->selfTurnData[ctx->battlerIdAttacker].shellBellDamage) && (ctx->battlerIdAttacker != ctx->battlerIdTarget) && (ctx->battleMons[ctx->battlerIdAttacker].hp < ctx->battleMons[ctx->battlerIdAttacker].maxHp) && ctx->battleMons[ctx->battlerIdAttacker].hp) {
        ctx->hpCalc = DamageDivide(ctx->selfTurnData[ctx->battlerIdAttacker].shellBellDamage * -1, modAttacker);
        ctx->battlerIdTemp = ctx->battlerIdAttacker;
        *script = BATTLE_SUBSCRIPT_RESTORE_A_LITTLE_HP;
        ret = TRUE;
    }

    if (itemAttacker == HOLD_EFFECT_HP_DRAIN_ON_ATK && GetBattlerAbility(ctx, ctx->battlerIdAttacker) != ABILITY_MAGIC_GUARD && (ctx->battleStatus & BATTLE_STATUS_MOVE_SUCCESSFUL) && ctx->trainerAIData.moveData[ctx->moveNoCur].category != CATEGORY_STATUS && ctx->battleMons[ctx->battlerIdAttacker].hp) {
        ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp * -1, 10);
        ctx->battlerIdTemp = ctx->battlerIdAttacker;
        *script = BATTLE_SUBSCRIPT_LOSE_HP_FROM_ITEM;
        ret = TRUE;
    }

    if (itemTarget == HOLD_EFFECT_RECOIL_PHYSICAL && ctx->battleMons[ctx->battlerIdAttacker].hp && GetBattlerAbility(ctx, ctx->battlerIdAttacker) != ABILITY_MAGIC_GUARD && ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage) {
        ctx->hpCalc = DamageDivide(ctx->battleMons[ctx->battlerIdAttacker].maxHp * -1, modTarget);
        *script = BATTLE_SUBSCRIPT_HELD_ITEM_RECOIL_WHEN_HIT;
        ret = TRUE;
    }

    if (itemTarget == HOLD_EFFECT_DMG_USER_CONTACT_XFR && ctx->battleMons[ctx->battlerIdAttacker].hp && !ctx->battleMons[ctx->battlerIdAttacker].item && !(ctx->fieldSideConditionData[side].battlerBitKnockedOffItem & MaskOfFlagNo(ctx->selectedMonIndex[ctx->battlerIdAttacker])) && (ctx->selfTurnData[ctx->battlerIdTarget].physicalDamage || ctx->selfTurnData[ctx->battlerIdTarget].specialDamage) && (ctx->trainerAIData.moveData[ctx->moveNoCur].unkB & 1)) {
        *script = BATTLE_SUBSCRIPT_TRANSFER_STICKY_BARB;
        ret = TRUE;
    }

    return ret;
}

void CheckIgnorePressure(BattleContext *ctx, int battlerIdAttacker, int battlerIdTarget) {
    if (battlerIdTarget != BATTLER_NONE && GetBattlerAbility(ctx, battlerIdTarget) == ABILITY_PRESSURE && ctx->battleMons[battlerIdAttacker].movePPCur[ctx->movePos[battlerIdAttacker]]) {
        ctx->battleMons[battlerIdAttacker].movePPCur[ctx->movePos[battlerIdAttacker]]--;
    }
}

BOOL BattleController_TryEmitExitRecording(BattleSystem *battleSystem, BattleContext *ctx) {
    if (BattleSystem_IsRecordingPaused(battleSystem)) {
        ctx->command = CONTROLLER_COMMAND_43;
        return TRUE;
    }
    return FALSE;
}

int BattleContext_Get(BattleSystem *battleSystem, BattleContext *ctx, int var, int battlerId) {
    switch (var) {
    case 0:
        return ctx->fieldSideConditionFlags[BattleSystem_GetFieldSide(battleSystem, battlerId)];
    case 1:
        return ctx->fieldSideConditionData[BattleSystem_GetFieldSide(battleSystem, battlerId)].mistTurns;
    case 2:
        return ctx->selectedMonIndex[battlerId];
    case 3:
        return ctx->totalTurns;
    case 4:
        return ctx->levelUpMons;
    case 5:
        return ctx->safariRunAttempts;
    case 6:
        return ctx->totalTimesFainted[battlerId];
    case 7:
        return ctx->totalDamage[battlerId];
    case 8:
        return (int)ctx->playerActions[battlerId].command;
    case 9:
        return ctx->trainerAIData.battlerIdTarget;
    case 10:
        return ctx->switchInFlag;
    case 11:
        return ctx->trainerAIData.selectedTarget[battlerId];
    case BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE:
        return ctx->playerActions[battlerId].unk8;
    case 13:
        return (int)ctx->command;
    case 14:
        return (int)ctx->commandNext;
    }

    GF_ASSERT(FALSE);
    return 0;
}

void BattleContext_Set(BattleSystem *battleSystem, BattleContext *ctx, int var, int battlerId, int data) {
    switch (var) {
    case 0:
        ctx->fieldSideConditionFlags[BattleSystem_GetFieldSide(battleSystem, battlerId)] = data;
        break;
    case 1:
        ctx->fieldSideConditionData[BattleSystem_GetFieldSide(battleSystem, battlerId)].mistTurns = data;
        break;
    case 2:
        ctx->selectedMonIndex[battlerId] = data;
        break;
    case 3:
        ctx->totalTurns = data;
        break;
    case 9:
        ctx->trainerAIData.battlerIdTarget = data;
        break;
    case 11:
        ctx->trainerAIData.selectedTarget[battlerId] = data;
        break;
    default:
        GF_ASSERT(FALSE);
    }
}

static const int sMoveStatusChangeScripts[145] = {
    BATTLE_SUBSCRIPT_NONE,
    BATTLE_SUBSCRIPT_FALL_ASLEEP,
    BATTLE_SUBSCRIPT_POISON,
    BATTLE_SUBSCRIPT_BURN,
    BATTLE_SUBSCRIPT_FREEZE,
    BATTLE_SUBSCRIPT_PARALYZE,
    BATTLE_SUBSCRIPT_BADLY_POISON,
    BATTLE_SUBSCRIPT_CONFUSE,
    BATTLE_SUBSCRIPT_FLINCH_MON,
    BATTLE_SUBSCRIPT_REST,
    BATTLE_SUBSCRIPT_UPROAR,
    BATTLE_SUBSCRIPT_PAY_DAY,
    BATTLE_SUBSCRIPT_VANISH_ON_CHARGE_TURN,
    BATTLE_SUBSCRIPT_BIND_START,
    BATTLE_SUBSCRIPT_RECOIL_1_4,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_RECHARGE_TURN,
    BATTLE_SUBSCRIPT_SET_RAGE_FLAG,
    BATTLE_SUBSCRIPT_STEAL_ITEM,
    BATTLE_SUBSCRIPT_MEAN_LOOK,
    BATTLE_SUBSCRIPT_NIGHTMARE_START,
    BATTLE_SUBSCRIPT_BOOST_ALL_STATS,
    BATTLE_SUBSCRIPT_RAPID_SPIN,
    BATTLE_SUBSCRIPT_HEAL_TARGET_PARALYSIS,
    BATTLE_SUBSCRIPT_USER_ATK_AND_DEF_DOWN_1_STAGE,
    BATTLE_SUBSCRIPT_RECOIL_1_3,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_UPDATE_STAT_STAGE,
    BATTLE_SUBSCRIPT_THRASH,
    BATTLE_SUBSCRIPT_KNOCK_OFF,
    BATTLE_SUBSCRIPT_USER_DEF_AND_SPDEF_UP_1_STAGE,
    BATTLE_SUBSCRIPT_USER_ATK_AND_DEF_UP_1_STAGE,
    BATTLE_SUBSCRIPT_TARGET_ATK_AND_DEF_DOWN_1_STAGE,
    BATTLE_SUBSCRIPT_USER_SPATK_AND_SPDEF_UP_1_STAGE,
    BATTLE_SUBSCRIPT_USER_ATK_AND_SPEED_UP_1_STAGE,
    BATTLE_SUBSCRIPT_DRAIN_HALF_DAMAGE_DEALT,
    BATTLE_SUBSCRIPT_DREAM_EATER,
    BATTLE_SUBSCRIPT_RESET_ALL_STAT_STAGES,
    BATTLE_SUBSCRIPT_BIDE_START,
    BATTLE_SUBSCRIPT_STRUGGLE,
    BATTLE_SUBSCRIPT_CONVERSION,
    BATTLE_SUBSCRIPT_RECOVER_HALF_MAX_HP,
    BATTLE_SUBSCRIPT_LIGHT_SCREEN,
    BATTLE_SUBSCRIPT_REFLECT,
    BATTLE_SUBSCRIPT_MIST,
    BATTLE_SUBSCRIPT_FOCUS_ENERGY,
    BATTLE_SUBSCRIPT_MIMIC,
    BATTLE_SUBSCRIPT_LEECH_SEED_START,
    BATTLE_SUBSCRIPT_DISABLE_START,
    BATTLE_SUBSCRIPT_ENCORE_START,
    BATTLE_SUBSCRIPT_PAIN_SPLIT,
    BATTLE_SUBSCRIPT_CONVERSION_2,
    BATTLE_SUBSCRIPT_LOCK_ON,
    BATTLE_SUBSCRIPT_SKETCH,
    BATTLE_SUBSCRIPT_FEINT,
    BATTLE_SUBSCRIPT_DESTINY_BOND,
    BATTLE_SUBSCRIPT_REDUCE_TARGET_PP,
    BATTLE_SUBSCRIPT_PROTECT,
    BATTLE_SUBSCRIPT_HEAL_BELL,
    BATTLE_SUBSCRIPT_TRY_SUBSTITUTE,
    BATTLE_SUBSCRIPT_FORCE_TARGET_TO_SWITCH_OR_FLEE,
    BATTLE_SUBSCRIPT_TRANSFORM_INTO_TARGET,
    BATTLE_SUBSCRIPT_MINIMIZE,
    BATTLE_SUBSCRIPT_CURSE_NORMAL,
    BATTLE_SUBSCRIPT_CURSE_GHOST,
    BATTLE_SUBSCRIPT_PRINT_MESSAGE_AND_PLAY_ANIMATION,
    BATTLE_SUBSCRIPT_FORESIGHT,
    BATTLE_SUBSCRIPT_PERISH_SONG_START,
    BATTLE_SUBSCRIPT_WEATHER_START,
    BATTLE_SUBSCRIPT_SWAGGER,
    BATTLE_SUBSCRIPT_INFATUATE,
    BATTLE_SUBSCRIPT_SAFEGUARD_START,
    BATTLE_SUBSCRIPT_PRESENT_HEAL,
    BATTLE_SUBSCRIPT_MAGNITUDE,
    BATTLE_SUBSCRIPT_BATON_PASS,
    BATTLE_SUBSCRIPT_BELLY_DRUM,
    BATTLE_SUBSCRIPT_TELEPORT,
    BATTLE_SUBSCRIPT_FUTURE_SIGHT_START,
    BATTLE_SUBSCRIPT_STOCKPILE,
    BATTLE_SUBSCRIPT_SWALLOW,
    BATTLE_SUBSCRIPT_TORMENT_START,
    BATTLE_SUBSCRIPT_FLATTER,
    BATTLE_SUBSCRIPT_MEMENTO,
    BATTLE_SUBSCRIPT_CHARGE,
    BATTLE_SUBSCRIPT_TAUNT_START,
    BATTLE_SUBSCRIPT_EXCHANGE_ITEMS,
    BATTLE_SUBSCRIPT_COPY_ABILITY,
    BATTLE_SUBSCRIPT_BREAK_SCREENS,
    BATTLE_SUBSCRIPT_YAWN,
    BATTLE_SUBSCRIPT_EXCHANGE_ABILITIES,
    BATTLE_SUBSCRIPT_RECOVER_PSN_PRZ_BRN,
    BATTLE_SUBSCRIPT_ROOST,
    BATTLE_SUBSCRIPT_HEAL_TARGET_SLEEP,
    BATTLE_SUBSCRIPT_GRAVITY_START,
    BATTLE_SUBSCRIPT_MIRACLE_EYE,
    BATTLE_SUBSCRIPT_HEALING_WISH,
    BATTLE_SUBSCRIPT_TAILWIND_START,
    BATTLE_SUBSCRIPT_USER_DEF_AND_SPDEF_DOWN_1_STAGE,
    BATTLE_SUBSCRIPT_USER_SWAP_ATK_AND_DEF,
    BATTLE_SUBSCRIPT_SUPPRESS_TARGET_ABILITY,
    BATTLE_SUBSCRIPT_LUCKY_CHANT_START,
    BATTLE_SUBSCRIPT_EXCHANGE_ATK_AND_SPATK_STAGES,
    BATTLE_SUBSCRIPT_EXCHANGE_DEF_AND_SPDEF_STAGES,
    BATTLE_SUBSCRIPT_GIVE_TARGET_INSOMNIA,
    BATTLE_SUBSCRIPT_EXCHANGE_ALL_STAT_STAGES,
    BATTLE_SUBSCRIPT_RECOIL_1_3_CHANCE_TO_BURN,
    BATTLE_SUBSCRIPT_DEFOG,
    BATTLE_SUBSCRIPT_HEAL_BLOCK_START,
    BATTLE_SUBSCRIPT_ATTACK_THEN_SWITCH_OUT,
    BATTLE_SUBSCRIPT_EMBARGO_START,
    BATTLE_SUBSCRIPT_PLUCK,
    BATTLE_SUBSCRIPT_FLING,
    BATTLE_SUBSCRIPT_RECOIL_1_3_CHANCE_TO_PARALYZE,
    BATTLE_SUBSCRIPT_RECOIL_1_2,
    BATTLE_SUBSCRIPT_BURN_OR_FLINCH,
    BATTLE_SUBSCRIPT_FREEZE_OR_FLINCH,
    BATTLE_SUBSCRIPT_PARALYZE_OR_FLINCH,
    BATTLE_SUBSCRIPT_CHATTER,
    BATTLE_SUBSCRIPT_LUNAR_DANCE,
    BATTLE_SUBSCRIPT_GIVE_TARGET_OWN_STATUS
};

static int GetMoveStatusChangeScript(BattleContext *ctx, int statChangeType, u32 flag) {
    ctx->statChangeType = statChangeType;
    ctx->statChangeParam = flag & (0x7FFFFF);
    ctx->statChangeFlag = flag & (0xFF800000);

    if (flag & (1 << 30)) {
        ctx->battlerIdStatChange = ctx->battlerIdAttacker;
    } else if (flag & (1 << 31)) {
        ctx->battlerIdStatChange = ctx->battlerIdTarget;
    } else if ((flag & (1 << 29)) || (flag & (1 << 28))) {
        ctx->battlerIdStatChange = BATTLER_PLAYER;
    }

    GF_ASSERT(NELEMS(sMoveStatusChangeScripts) > (flag & (0x7FFFFF)));

    return sMoveStatusChangeScripts[flag & (0x7FFFFF)];
}

static int ApplyTypeMultiplier(BattleContext *ctx, int battlerId, int typeEffectiveness, int damage, int moveDamage, u32 *flag) {
    if (!(ctx->battleStatus & BATTLE_STATUS_IGNORE_TYPE_EFFECTIVENESS) && !(ctx->battleStatus & BATTLE_STATUS_IGNORE_TYPE_IMMUNITY) && damage) {
        damage = DamageDivide(damage * typeEffectiveness, 10);
    }

    switch (typeEffectiveness) {
    case TYPE_MUL_NO_EFFECT:
        *flag |= MOVE_STATUS_NO_EFFECT;
        *flag &= ~MOVE_STATUS_NOT_VERY_EFFECTIVE;
        *flag &= ~MOVE_STATUS_SUPER_EFFECTIVE;
        break;
    case TYPE_MUL_NOT_EFFECTIVE:
        if (moveDamage) {
            if (*flag & MOVE_STATUS_SUPER_EFFECTIVE) {
                *flag &= ~MOVE_STATUS_SUPER_EFFECTIVE;
            } else {
                *flag |= MOVE_STATUS_NOT_VERY_EFFECTIVE;
            }
        }
        break;
    case TYPE_MUL_SUPER_EFFECTIVE:
        if (moveDamage) {
            if (*flag & MOVE_STATUS_NOT_VERY_EFFECTIVE) {
                *flag &= ~MOVE_STATUS_NOT_VERY_EFFECTIVE;
            } else {
                *flag |= MOVE_STATUS_SUPER_EFFECTIVE;
            }
        }
        break;
    }

    return damage;
}

static int CheckChargeMoveHitTurn(BattleContext *ctx, int moveNo) {
    switch (ctx->trainerAIData.moveData[moveNo].effect) {
    case MOVE_EFFECT_BIDE:
    case MOVE_EFFECT_CHARGE_TURN_HIGH_CRIT:
    case MOVE_EFFECT_CHARGE_TURN_HIGH_CRIT_FLINCH:
    case MOVE_EFFECT_CHARGE_TURN_DEF_UP:
    case MOVE_EFFECT_151:
    case MOVE_EFFECT_FLY:
    case MOVE_EFFECT_DIVE:
    case MOVE_EFFECT_DIG:
    case MOVE_EFFECT_BOUNCE:
    case MOVE_EFFECT_FLINCH_BURN_HIT:
        return ctx->battleStatus & BATTLE_STATUS_CHARGE_MOVE_HIT;
    }

    return TRUE;
}

static u8 Battler_GetType(BattleContext *ctx, int battlerId, int var) {
    u8 type;

    if (var == BMON_DATA_TYPE_1) {
        type = ctx->battleMons[battlerId].type1;
    } else if (var == BMON_DATA_TYPE_2) {
        type = ctx->battleMons[battlerId].type2;
    } else {
        GF_ASSERT(FALSE);
    }

    if (ctx->battleMons[battlerId].species == SPECIES_ARCEUS && ctx->battleMons[battlerId].ability == ABILITY_MULTITYPE) {
        switch (GetItemVar(ctx, ctx->battleMons[battlerId].item, ITEM_VAR_HOLD_EFFECT)) {
        case HOLD_EFFECT_ARCEUS_FIRE:
            type = TYPE_FIRE;
            break;
        case HOLD_EFFECT_ARCEUS_WATER:
            type = TYPE_WATER;
            break;
        case HOLD_EFFECT_ARCEUS_ELECTRIC:
            type = TYPE_ELECTRIC;
            break;
        case HOLD_EFFECT_ARCEUS_GRASS:
            type = TYPE_GRASS;
            break;
        case HOLD_EFFECT_ARCEUS_ICE:
            type = TYPE_ICE;
            break;
        case HOLD_EFFECT_ARCEUS_FIGHTING:
            type = TYPE_FIGHTING;
            break;
        case HOLD_EFFECT_ARCEUS_POISON:
            type = TYPE_POISON;
            break;
        case HOLD_EFFECT_ARCEUS_GROUND:
            type = TYPE_GROUND;
            break;
        case HOLD_EFFECT_ARCEUS_FLYING:
            type = TYPE_FLYING;
            break;
        case HOLD_EFFECT_ARCEUS_PSYCHIC:
            type = TYPE_PSYCHIC;
            break;
        case HOLD_EFFECT_ARCEUS_BUG:
            type = TYPE_BUG;
            break;
        case HOLD_EFFECT_ARCEUS_ROCK:
            type = TYPE_ROCK;
            break;
        case HOLD_EFFECT_ARCEUS_GHOST:
            type = TYPE_GHOST;
            break;
        case HOLD_EFFECT_ARCEUS_DRAGON:
            type = TYPE_DRAGON;
            break;
        case HOLD_EFFECT_ARCEUS_DARK:
            type = TYPE_DARK;
            break;
        case HOLD_EFFECT_ARCEUS_STEEL:
            type = TYPE_STEEL;
            break;
        default:
            type = TYPE_NORMAL;
            break;
        }
    }

    return type;
}

static void TrainerAIData_ClearMoves(BattleContext *ctx, u8 battlerId) {
    for (int i = 0; i < MAX_MON_MOVES; i++) {
        ctx->trainerAIData.moves[battlerId][i] = MOVE_NONE;
    }
}

static void TrainerAIData_ClearAbility(BattleContext *ctx, u8 battlerId) {
    ctx->trainerAIData.abilities[battlerId] = ABILITY_NONE;
}

static void TrainerAIData_ClearHeldItem(BattleContext *ctx, u8 battlerId) {
    ctx->trainerAIData.heldItems[battlerId] = ITEM_NONE;
}

static int ChooseTraceTarget(BattleSystem *battleSystem, BattleContext *ctx, int battlerIdTarget1, int battlerIdTarget2) {
    int ret = BATTLER_NONE;

    if (ctx->battleMons[battlerIdTarget1].ability != ABILITY_FORECAST && ctx->battleMons[battlerIdTarget1].ability != ABILITY_TRACE && ctx->battleMons[battlerIdTarget1].ability != ABILITY_MULTITYPE && ctx->battleMons[battlerIdTarget1].hp && ctx->battleMons[battlerIdTarget2].hp && ctx->battleMons[battlerIdTarget2].ability != ABILITY_FORECAST && ctx->battleMons[battlerIdTarget2].ability != ABILITY_TRACE && ctx->battleMons[battlerIdTarget2].ability != ABILITY_MULTITYPE) {
        if (BattleSystem_Random(battleSystem) & 1) {
            ret = battlerIdTarget2;
        } else {
            ret = battlerIdTarget1;
        }
    } else if (ctx->battleMons[battlerIdTarget1].ability != ABILITY_FORECAST && ctx->battleMons[battlerIdTarget1].ability != ABILITY_TRACE && ctx->battleMons[battlerIdTarget1].hp && ctx->battleMons[battlerIdTarget1].ability != ABILITY_MULTITYPE) {
        ret = battlerIdTarget1;
    } else if (ctx->battleMons[battlerIdTarget2].ability != ABILITY_FORECAST && ctx->battleMons[battlerIdTarget2].ability != ABILITY_TRACE && ctx->battleMons[battlerIdTarget2].hp && ctx->battleMons[battlerIdTarget2].ability != ABILITY_MULTITYPE) {
        ret = battlerIdTarget2;
    }

    return ret;
}

static const u16 sFixedDamageMoveEffects[] = {
    MOVE_EFFECT_40_DAMAGE_FLAT,
    MOVE_EFFECT_LEVEL_DAMAGE_FLAT,
    MOVE_EFFECT_RANDOM_DAMAGE_1_TO_150_LEVEL,
    MOVE_EFFECT_COUNTER,
    MOVE_EFFECT_MIRROR_COAT,
    MOVE_EFFECT_METAL_BURST
};

static BOOL IsFixedDamageMove(BattleContext *ctx, int moveNo) {
    for (int i = 0; i < NELEMS(sFixedDamageMoveEffects); i++) {
        if (sFixedDamageMoveEffects[i] == ctx->trainerAIData.moveData[moveNo].effect) {
            return TRUE;
        }
    }

    return FALSE;
}

static int GetDynamicMoveType(BattleSystem *battleSystem, BattleContext *ctx, int battlerId, int moveNo) {
    int type;

    switch (moveNo) {
    case MOVE_NATURAL_GIFT:
        type = GetNaturalGiftType(ctx, battlerId);
        break;
    case MOVE_JUDGMENT:
        switch (GetBattlerHeldItemEffect(ctx, battlerId)) {
        case HOLD_EFFECT_ARCEUS_FIGHTING:
            type = TYPE_FIGHTING;
            break;
        case HOLD_EFFECT_ARCEUS_FLYING:
            type = TYPE_FLYING;
            break;
        case HOLD_EFFECT_ARCEUS_POISON:
            type = TYPE_POISON;
            break;
        case HOLD_EFFECT_ARCEUS_GROUND:
            type = TYPE_GROUND;
            break;
        case HOLD_EFFECT_ARCEUS_ROCK:
            type = TYPE_ROCK;
            break;
        case HOLD_EFFECT_ARCEUS_BUG:
            type = TYPE_BUG;
            break;
        case HOLD_EFFECT_ARCEUS_GHOST:
            type = TYPE_GHOST;
            break;
        case HOLD_EFFECT_ARCEUS_STEEL:
            type = TYPE_STEEL;
            break;
        case HOLD_EFFECT_ARCEUS_FIRE:
            type = TYPE_FIRE;
            break;
        case HOLD_EFFECT_ARCEUS_WATER:
            type = TYPE_WATER;
            break;
        case HOLD_EFFECT_ARCEUS_GRASS:
            type = TYPE_GRASS;
            break;
        case HOLD_EFFECT_ARCEUS_ELECTRIC:
            type = TYPE_ELECTRIC;
            break;
        case HOLD_EFFECT_ARCEUS_PSYCHIC:
            type = TYPE_PSYCHIC;
            break;
        case HOLD_EFFECT_ARCEUS_ICE:
            type = TYPE_ICE;
            break;
        case HOLD_EFFECT_ARCEUS_DRAGON:
            type = TYPE_DRAGON;
            break;
        case HOLD_EFFECT_ARCEUS_DARK:
            type = TYPE_DARK;
            break;
        default:
            type = TYPE_NORMAL;
            break;
        }
        break;
    case MOVE_HIDDEN_POWER:
        type = (ctx->battleMons[battlerId].hpIV & 1) | ((ctx->battleMons[battlerId].atkIV & 1) << 1) | ((ctx->battleMons[battlerId].defIV & 1) << 2) | ((ctx->battleMons[battlerId].speedIV & 1) << 3) | ((ctx->battleMons[battlerId].spAtkIV & 1) << 4) | ((ctx->battleMons[battlerId].spDefIV & 1) << 5);

        type = (type * 15 / 63) + 1;

        if (type >= TYPE_MYSTERY) {
            type++;
        }
        break;
    case MOVE_WEATHER_BALL:
        if (!CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_CLOUD_NINE) && !CheckAbilityActive(battleSystem, ctx, CHECK_ABILITY_ALL_HP, 0, ABILITY_AIR_LOCK)) {
            if (ctx->fieldCondition & FIELD_CONDITION_WEATHER) {
                if (ctx->fieldCondition & FIELD_CONDITION_RAIN_ALL) {
                    type = TYPE_WATER;
                }
                if (ctx->fieldCondition & FIELD_CONDITION_SANDSTORM_ALL) {
                    type = TYPE_ROCK;
                }
                if (ctx->fieldCondition & FIELD_CONDITION_SUN_ALL) {
                    type = TYPE_FIRE;
                }
                if (ctx->fieldCondition & FIELD_CONDITION_HAIL_ALL) {
                    type = TYPE_ICE;
                }
                // BUG: If the weather is foggy, then type doesn't get set properly before being returned
            }
        }
        break;
    default:
        type = TYPE_NORMAL;
        break;
    }

    return type;
}
