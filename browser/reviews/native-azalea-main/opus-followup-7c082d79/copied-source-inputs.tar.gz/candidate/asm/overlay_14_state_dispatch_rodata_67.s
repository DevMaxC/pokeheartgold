#include "constants/pokemon.h"
	.include "asm/macros.inc"
	.public PCBox_Exit
	.public PCBox_Init
	.public PCBox_Main
	.public _021E5982
	.public _021E59C6
	.public _021E59FA
	.public _021E5A08
	.public _021E5A0C
	.public _021E5A10
	.public _021E5A30
	.public _021E5A5C
	.public _021E5A68
	.public _021E5A6C
	.public _021E5BE0
	.public _021E5BE4
	.public _021E5BE8
	.public _021E5BEC
	.public _021E5BF0
	.public _021E5BF4
	.public _021E5BF8
	.public _021E5BFC
	.public _021E5E70
	.public _021E5EC4
	.public _021E5ECC
	.public _021E5EE4
	.public _021E5EF4
	.public _021E5EF8
	.public _021E5F68
	.public _021E5F8A
	.public _021E5FB8
	.public _021E5FC0
	.public _021E5FF0
	.public _021E6020
	.public _021E602C
	.public _021E603E
	.public _021E6044
	.public _021E6064
	.public _021E6088
	.public _021E60BE
	.public _021E60CE
	.public _021E60D4
	.public _021E60EC
	.public _021E60F0
	.public _021E60F8
	.public _021E610E
	.public _021E6350
	.public _021E63BC
	.public _021E63CA
	.public _021E63F2
	.public _021E6406
	.public _021E6410
	.public _021E6432
	.public _021E6446
	.public _021E6456
	.public _021E6462
	.public _021E6492
	.public _021E64BE
	.public _021E64CA
	.public _021E6510
	.public _021E6540
	.public _021E6544
	.public _021E6556
	.public _021E655E
	.public _021E6564
	.public _021E65BC
	.public _021E65C0
	.public _021E65DA
	.public _021E6604
	.public _021E661A
	.public _021E662A
	.public _021E6634
	.public _021E6650
	.public _021E665E
	.public _021E6674
	.public _021E66DE
	.public _021E66F0
	.public _021E670A
	.public _021E6744
	.public _021E6760
	.public _021E676E
	.public _021E6780
	.public _021E6802
	.public _021E680A
	.public _021E6810
	.public _021E682A
	.public _021E6868
	.public _021E6876
	.public _021E688C
	.public _021E68F6
	.public _021E6908
	.public _021E6940
	.public _021E6944
	.public _021E694C
	.public _021E695E
	.public _021E6980
	.public _021E6984
	.public _021E699C
	.public _021E69C4
	.public _021E69D6
	.public _021E6A02
	.public _021E6A14
	.public _021E6A36
	.public _021E6A54
	.public _021E6A66
	.public _021E6A8A
	.public _021E6A9C
	.public _021E6ABA
	.public _021E6ACE
	.public _021E6AEC
	.public _021E6B0A
	.public _021E6B26
	.public _021E6B40
	.public _021E6B44
	.public _021E6B88
	.public _021E6B98
	.public _021E6BB2
	.public _021E6BBC
	.public _021E6BEE
	.public _021E6C08
	.public _021E6C6A
	.public _021E6C74
	.public _021E6CA8
	.public _021E6CC4
	.public _021E6D14
	.public gBugContestSwapMonStateFuncs
	.public _021E6D66
	.public _021E6DAE
	.public _021E6DC2
	.public _021E6DE0
	.public _021E6E06
	.public _021E6E20
	.public _021E6E34
	.public _021E6E44
	.public _021E6E68
	.public gHallOfFameShowcaseHitboxes
	.public _021E6E9C
	.public _021E6ED2
	.public _021E6EE6
	.public _021E6EFA
	.public _021E6F1A
	.public _021E6F38
	.public _021E6F58
	.public _021E6F7A
	.public _021E6FA0
	.public _021E6FD2
	.public _021E6FF2
	.public _021E702C
	.public _021E7030
	.public _021E704C
	.public _021E706C
	.public _021E708C
	.public _021E70AC
	.public _021E70BA
	.public _021E70D0
	.public _021E70F4
	.public _021E7118
	.public _021E7132
	.public _021E7158
	.public _021E7168
	.public _021E7176
	.public _021E719A
	.public _021E71A8
	.public _021E71B2
	.public _021E71C0
	.public _021E71C4
	.public _021E71CC
	.public _021E71D6
	.public _021E71E4
	.public _021E722E
	.public _021E7254
	.public _021E725C
	.public _021E7260
	.public _021E7270
	.public _021E7274
	.public _021E728E
	.public _021E7292
	.public _021E72C2
	.public _021E72CE
	.public _021E72E0
	.public _021E72EA
	.public _021E72FE
	.public _021E7328
	.public _021E732E
	.public _021E7340
	.public _021E7350
	.public _021E7354
	.public _021E743C
	.public _021E7444
	.public _021E7448
	.public _021E7460
	.public _021E7462
	.public _021E746C
	.public _021E7482
	.public _021E74EC
	.public _021E7534
	.public _021E7584
	.public _021E75BA
	.public _021E75C2
	.public _021E75CA
	.public _021E75DC
	.public _021E75E6
	.public _021E75F0
	.public _021E7658
	.public _021E76AC
	.public _021E776E
	.public _021E7786
	.public _021E77BC
	.public _021E7800
	.public _021E7804
	.public _021E785A
	.public _021E7874
	.public _021E7886
	.public _021E788A
	.public _021E78A4
	.public _021E78A8
	.public _021E78C6
	.public _021E78CA
	.public _021E7928
	.public _021E792C
	.public _021E793E
	.public _021E795C
	.public _021E7978
	.public _021E7980
	.public _021E798E
	.public _021E79A4
	.public _021E79A8
	.public _021E79B6
	.public _021E79CA
	.public _021E79E2
	.public _021E79F6
	.public _021E7A04
	.public _021E7A4C
	.public _021E7A52
	.public _021E7A84
	.public _021E7A8C
	.public _021E7AB2
	.public _021E7ABA
	.public _021E7B00
	.public _021E7B22
	.public _021E7B28
	.public _021E7B32
	.public _021E7B40
	.public _021E7B44
	.public _021E7B56
	.public _021E7B5A
	.public _021E7B94
	.public _021E7BA0
	.public _021E7C62
	.public _021E7C88
	.public _021E7CB2
	.public _021E7CC4
	.public _021E7D06
	.public _021E7D3E
	.public _021E7D88
	.public _021E7DE0
	.public _021E7DE2
	.public _021E7DF4
	.public _021E7DFE
	.public _021E7E3C
	.public _021E7F46
	.public _021E7FB4
	.public _021E7FE8
	.public _021E801A
	.public _021E8120
	.public _021E8126
	.public _021E8134
	.public _021E8194
	.public _021E819A
	.public _021E81A2
	.public _021E81B0
	.public _021E8366
	.public _021E839E
	.public _021E83CE
	.public _021E83FE
	.public _021E8454
	.public _021E849E
	.public _021E84C4
	.public _021E850E
	.public _021E851E
	.public _021E852C
	.public _021E8540
	.public _021E855E
	.public _021E85FE
	.public _021E8662
	.public _021E8846
	.public _021E8848
	.public _021E886C
	.public _021E8870
	.public _021E889E
	.public _021E88A0
	.public _021E88F2
	.public _021E8928
	.public _021E8968
	.public _021E8976
	.public _021E897A
	.public _021E89EE
	.public _021E8A06
	.public _021E8A74
	.public _021E8A78
	.public _021E8AA0
	.public _021E8AA8
	.public _021E8AC0
	.public _021E8B10
	.public _021E8B14
	.public _021E8B18
	.public _021E8B38
	.public _021E8B7C
	.public _021E8BF4
	.public _021E8C24
	.public _021E8C40
	.public _021E8C6E
	.public _021E8C86
	.public _021E8CCC
	.public _021E8D0C
	.public _021E8D14
	.public _021E8D18
	.public _021E8D1C
	.public _021E8D5C
	.public _021E8D6C
	.public _021E8D78
	.public _021E8D84
	.public _021E8DA8
	.public _021E8DFA
	.public _021E8E0E
	.public _021E8E44
	.public _021E8E46
	.public _021E8E6A
	.public _021E8E84
	.public _021E8EA8
	.public _021E8EC6
	.public _021E8ED8
	.public _021E8F1E
	.public _021E8F4A
	.public _021E8F62
	.public _021E8F96
	.public _021E8FA0
	.public _021E8FB8
	.public _021E8FC0
	.public _021E8FC4
	.public _021E8FC8
	.public _021E8FCC
	.public _021E8FD0
	.public _021E900A
	.public _021E900C
	.public _021E903C
	.public _021E9058
	.public _021E9076
	.public _021E90A4
	.public _021E90B2
	.public _021E90F8
	.public _021E913C
	.public _021E9148
	.public _021E914E
	.public _021E9180
	.public _021E9188
	.public _021E918C
	.public _021E9190
	.public _021E91B2
	.public _021E91C4
	.public _021E91DC
	.public _021E91F2
	.public _021E9218
	.public _021E922E
	.public _021E9248
	.public _021E927E
	.public _021E92A6
	.public _021E92CC
	.public _021E92D8
	.public _021E9362
	.public _021E9390
	.public _021E939C
	.public _021E9428
	.public _021E944A
	.public _021E94A4
	.public _021E94B8
	.public _021E9512
	.public _021E9526
	.public _021E953C
	.public _021E9550
	.public _021E958C
	.public _021E95C4
	.public _021E95D8
	.public _021E95E8
	.public _021E95FE
	.public _021E9614
	.public _021E965A
	.public _021E9672
	.public _021E9682
	.public _021E96A2
	.public _021E96E6
	.public _021E96F2
	.public _021E9708
	.public _021E972E
	.public _021E9776
	.public _021E97BC
	.public _021E97DA
	.public _021E97FC
	.public _021E9844
	.public _021E988A
	.public _021E98A2
	.public _021E9914
	.public _021E9932
	.public _021E9956
	.public _021E996C
	.public _021E999C
	.public _021E99B2
	.public _021E99D6
	.public _021E99EC
	.public _021E9A1E
	.public _021E9A52
	.public _021E9A80
	.public _021E9A8C
	.public _021E9A9C
	.public _021E9AA0
	.public _021E9ABA
	.public _021E9B0E
	.public _021E9B44
	.public _021E9B68
	.public _021E9B8A
	.public _021E9B9C
	.public _021E9BE2
	.public _021E9C14
	.public _021E9C44
	.public _021E9C4E
	.public _021E9C70
	.public _021E9C78
	.public _021E9C7C
	.public _021E9C80
	.public _021E9C84
	.public _021E9CBC
	.public _021E9CC8
	.public _021E9CDA
	.public _021E9CDE
	.public _021E9CF8
	.public _021E9D28
	.public _021E9D5E
	.public _021E9D72
	.public _021E9D78
	.public _021E9DCA
	.public _021E9DEA
	.public _021E9E30
	.public _021E9E4A
	.public _021E9E80
	.public _021E9E8C
	.public _021E9EBA
	.public _021E9ED8
	.public _021E9EE2
	.public _021E9F04
	.public _021E9F0C
	.public _021E9F10
	.public _021E9F14
	.public _021E9F18
	.public _021E9F1C
	.public _021E9F72
	.public _021E9F94
	.public _021E9F98
	.public _021E9FCA
	.public _021E9FD2
	.public _021E9FE8
	.public _021E9FF0
	.public _021EA036
	.public _021EA05C
	.public _021EA060
	.public _021EA064
	.public _021EA07A
	.public _021EA092
	.public _021EA0B2
	.public _021EA0CA
	.public _021EA10A
	.public _021EA12A
	.public _021EA142
	.public _021EA164
	.public _021EA17A
	.public _021EA192
	.public _021EA1AE
	.public _021EA1EC
	.public _021EA250
	.public _021EA27A
	.public _021EA282
	.public _021EA292
	.public _021EA2A4
	.public _021EA2DA
	.public _021EA2EA
	.public _021EA2FA
	.public _021EA36E
	.public _021EA374
	.public _021EA396
	.public _021EA3B0
	.public _021EA3D6
	.public _021EA3DC
	.public _021EA3FE
	.public _021EA404
	.public _021EA41E
	.public _021EA442
	.public _021EA448
	.public _021EA48A
	.public _021EA4BA
	.public _021EA4C0
	.public _021EA4C4
	.public _021EA50E
	.public _021EA51A
	.public _021EA530
	.public _021EA55A
	.public _021EA56A
	.public _021EA588
	.public _021EA5BC
	.public _021EA5D4
	.public _021EA5EC
	.public _021EA5F6
	.public _021EA608
	.public _021EA632
	.public _021EA642
	.public _021EA65C
	.public _021EA664
	.public _021EA66C
	.public _021EA670
	.public _021EA68A
	.public _021EA6A4
	.public _021EA6AA
	.public _021EA6C8
	.public _021EA71A
	.public _021EA720
	.public _021EA724
	.public _021EA73A
	.public _021EA766
	.public _021EA774
	.public _021EA7AC
	.public _021EA7BA
	.public _021EA7DC
	.public _021EA7E8
	.public _021EA7EA
	.public _021EA7FE
	.public _021EA844
	.public _021EA852
	.public _021EA86A
	.public _021EA87C
	.public _021EA8A6
	.public _021EA8C8
	.public _021EA8E8
	.public _021EA90C
	.public _021EA914
	.public _021EA91C
	.public _021EA920
	.public _021EA924
	.public sNintendoWfcUnusedGlobal
	.public _021EA94E
	.public _021EA970
	.public _021EA98A
	.public _021EA9A6
	.public _021EA9BA
	.public _021EA9D2
	.public _021EA9F6
	.public _021EA9FC
	.public _021EAA00
	.public _021EAA1E
	.public _021EAA2A
	.public _021EAA36
	.public _021EAA5A
	.public _021EAA76
	.public _021EAA86
	.public _021EAA98
	.public _021EAACE
	.public _021EAADE
	.public _021EAAEC
	.public _021EAB4E
	.public _021EAB6C
	.public _021EAB76
	.public _021EAB84
	.public _021EAB94
	.public _021EABCA
	.public _021EABEC
	.public _021EAC10
	.public _021EAC20
	.public _021EAC48
	.public _021EAC52
	.public _021EAC70
	.public _021EAC80
	.public _021EAC98
	.public _021EACBC
	.public _021EACCC
	.public _021EACD0
	.public _021EAD10
	.public _021EAD26
	.public _021EAD50
	.public _021EAD60
	.public _021EAD6C
	.public _021EAD6E
	.public _021EAD80
	.public _021EADA4
	.public _021EADD0
	.public _021EADE4
	.public _021EADF6
	.public _021EAE0E
	.public _021EAE44
	.public _021EAE4E
	.public _021EAE60
	.public _021EAE7E
	.public _021EAE90
	.public _021EAEBA
	.public _021EAECA
	.public _021EAEE8
	.public _021EAEF0
	.public _021EAEF8
	.public _021EAEFC
	.public _021EAF00
	.public _021EAF04
	.public _021EAF20
	.public _021EAF6A
	.public _021EAF70
	.public _021EAF84
	.public _021EAF88
	.public _021EAFA4
	.public _021EAFA8
	.public _021EB08C
	.public _021EB0C8
	.public _021EB0CC
	.public _021EB0D0
	.public _021EB0D4
	.public _021EB0D8
	.public _021EB0DC
	.public _021EB0E0
	.public _021EB164
	.public _021EB168
	.public _021EB16C
	.public _021EB186
	.public _021EB1A0
	.public _021EB1B2
	.public _021EB1BC
	.public _021EB1D6
	.public _021EB1DC
	.public _021EB1F6
	.public _021EB20A
	.public _021EB210
	.public _021EB214
	.public _021EB230
	.public _021EB24C
	.public _021EB268
	.public _021EB26C
	.public _021EB270
	.public _021EB274
	.public _021EB278
	.public _021EB28C
	.public _021EB2A4
	.public _021EB2BA
	.public _021EB2E4
	.public _021EB2E8
	.public _021EB30A
	.public _021EB312
	.public _021EB342
	.public _021EB35A
	.public _021EB366
	.public _021EB37A
	.public _021EB384
	.public _021EB3D8
	.public _021EB3F4
	.public _021EB470
	.public _021EB490
	.public _021EB4A4
	.public _021EB4B8
	.public _021EB4D0
	.public _021EB4DA
	.public _021EB4DC
	.public _021EB4E6
	.public _021EB4E8
	.public _021EB4F0
	.public _021EB4F2
	.public _021EB506
	.public _021EB530
	.public _021EB55A
	.public _021EB56C
	.public _021EB58C
	.public _021EB5A2
	.public _021EB5BA
	.public _021EB5D0
	.public _021EB5E2
	.public _021EB5F4
	.public _021EB606
	.public _021EB63A
	.public _021EB666
	.public _021EB66C
	.public _021EB66E
	.public _021EB684
	.public _021EB69A
	.public _021EB6B8
	.public _021EB6C8
	.public _021EB6E0
	.public _021EB6E4
	.public _021EB6E8
	.public _021EB6EC
	.public _021EB6F0
	.public _021EB6F4
	.public _021EB6F8
	.public _021EB6FC
	.public _021EB700
	.public _021EB704
	.public _021EB714
	.public _021EB72A
	.public _021EB748
	.public _021EB750
	.public _021EB79E
	.public _021EB7A4
	.public _021EB7A8
	.public _021EB7AC
	.public _021EB7E0
	.public _021EB800
	.public _021EB81E
	.public _021EB83C
	.public _021EB854
	.public _021EB856
	.public _021EB880
	.public _021EB892
	.public _021EB8AC
	.public _021EB8B0
	.public _021EB8B4
	.public _021EB8B8
	.public _021EB8BC
	.public _021EB8EC
	.public _021EB90E
	.public _021EB934
	.public _021EB944
	.public _021EB954
	.public _021EB980
	.public _021EB984
	.public _021EB9A4
	.public _021EB9BE
	.public _021EB9D4
	.public _021EBA0A
	.public _021EBA2E
	.public _021EBA4A
	.public _021EBA7E
	.public _021EBA8C
	.public _021EBA8E
	.public _021EBAA6
	.public _021EBAB8
	.public _021EBACC
	.public _021EBAD8
	.public _021EBADC
	.public _021EBAE0
	.public _021EBAE4
	.public _021EBAE8
	.public _021EBB2C
	.public _021EBB38
	.public _021EBB62
	.public _021EBB70
	.public _021EBB8C
	.public _021EBBBA
	.public _021EBBD2
	.public _021EBBEA
	.public _021EBBF6
	.public _021EBC04
	.public _021EBC24
	.public _021EBC66
	.public _021EBC72
	.public _021EBC90
	.public _021EBC9C
	.public _021EBCD6
	.public _021EBD2A
	.public _021EBD42
	.public _021EBD50
	.public _021EBD6A
	.public _021EBD74
	.public _021EBD78
	.public _021EBD80
	.public _021EBD82
	.public _021EBD9E
	.public _021EBDB0
	.public _021EBDBC
	.public _021EBDC0
	.public _021EBDC4
	.public _021EBDC8
	.public _021EBDE4
	.public _021EBE24
	.public _021EBE28
	.public _021EBE90
	.public _021EBEA0
	.public _021EBEAC
	.public _021EBEB4
	.public _021EBEC4
	.public _021EBED4
	.public _021EBEE4
	.public _021EBEF4
	.public _021EBF04
	.public _021EBF14
	.public _021EBF4C
	.public _021EBF60
	.public _021EBF72
	.public _021EBF78
	.public _021EBF80
	.public _021EBF84
	.public _021EBF88
	.public _021EBF94
	.public _021EBF98
	.public _021EBFF8
	.public _021EC03C
	.public _021EC070
	.public _021EC090
	.public _021EC0CE
	.public _021EC0E4
	.public _021EC0E8
	.public _021EC112
	.public _021EC120
	.public _021EC124
	.public _021EC1A2
	.public _021EC1BE
	.public _021EC200
	.public _021EC22A
	.public _021EC234
	.public _021EC238
	.public _021EC254
	.public _021EC29E
	.public _021EC2E4
	.public _021EC2E8
	.public _021EC328
	.public _021EC332
	.public _021EC340
	.public _021EC3A4
	.public _021EC3C8
	.public _021EC42A
	.public _021EC44A
	.public _021EC4B4
	.public _021EC4D4
	.public _021EC4F6
	.public _021EC512
	.public _021EC51C
	.public _021EC51E
	.public _021EC528
	.public _021EC530
	.public _021EC532
	.public _021EC550
	.public _021EC566
	.public _021EC57E
	.public _021EC594
	.public _021EC5A6
	.public _021EC5B8
	.public _021EC5CA
	.public _021EC5E2
	.public _021EC600
	.public _021EC610
	.public _021EC622
	.public _021EC65C
	.public _021EC674
	.public _021EC692
	.public _021EC69A
	.public _021EC6EE
	.public _021EC6F4
	.public _021EC6F8
	.public _021EC6FC
	.public _021EC700
	.public _021EC704
	.public _021EC708
	.public _021EC70C
	.public _021EC72C
	.public _021EC762
	.public _021EC7AE
	.public _021EC7D0
	.public _021EC838
	.public _021EC84A
	.public _021EC850
	.public _021EC8A2
	.public _021EC8C8
	.public _021EC8CC
	.public _021EC928
	.public _021EC960
	.public _021EC97A
	.public _021EC97E
	.public _021EC9CC
	.public _021ECA02
	.public _021ECA1C
	.public _021ECA20
	.public _021ECA64
	.public _021ECA68
	.public _021ECA7C
	.public _021ECA90
	.public _021ECAA4
	.public _021ECAAC
	.public _021ECAAE
	.public _021ECAB8
	.public _021ECABA
	.public _021ECAC0
	.public _021ECAC2
	.public _021ECAC4
	.public _021ECADA
	.public _021ECAF0
	.public _021ECB06
	.public _021ECB1C
	.public _021ECB32
	.public _021ECB48
	.public _021ECB9C
	.public _021ECBB6
	.public _021ECBBA
	.public _021ECC0C
	.public _021ECC26
	.public _021ECC2A
	.public _021ECC30
	.public _021ECC34
	.public _021ECC38
	.public _021ECC3C
	.public _021ECC40
	.public _021ECC6A
	.public _021ECCA8
	.public _021ECCC4
	.public _021ECCE6
	.public _021ECCFE
	.public _021ECD1A
	.public _021ECD3C
	.public _021ECD70
	.public _021ECD98
	.public _021ECD9C
	.public _021ECDA0
	.public _021ECDA4
	.public _021ECDE0
	.public _021ECE04
	.public _021ECE20
	.public _021ECE2C
	.public _021ECE3A
	.public _021ECE82
	.public _021ECEAA
	.public _021ECECE
	.public _021ECF0E
	.public _021ECF28
	.public _021ECF32
	.public _021ECF40
	.public _021ECF50
	.public _021ECF54
	.public _021ECF88
	.public _021ECF9E
	.public _021ECFC0
	.public _021ECFC2
	.public _021ED022
	.public _021ED06C
	.public _021ED0B2
	.public _021ED0EE
	.public _021ED108
	.public _021ED112
	.public _021ED142
	.public _021ED15C
	.public _021ED17E
	.public _021ED192
	.public _021ED19C
	.public _021ED1A0
	.public _021ED1A4
	.public _021ED1A8
	.public _021ED1DA
	.public _021ED206
	.public _021ED210
	.public _021ED238
	.public _021ED28A
	.public _021ED2A6
	.public _021ED2B0
	.public _021ED2D8
	.public _021ED340
	.public _021ED34C
	.public _021ED358
	.public _021ED370
	.public _021ED388
	.public _021ED3A0
	.public _021ED3BC
	.public _021ED410
	.public _021ED42C
	.public _021ED43C
	.public _021ED454
	.public _021ED45E
	.public _021ED460
	.public _021ED468
	.public _021ED46A
	.public _021ED47A
	.public _021ED48A
	.public _021ED49A
	.public _021ED4AA
	.public _021ED4BA
	.public _021ED4CA
	.public _021ED4DC
	.public _021ED4EC
	.public _021ED514
	.public _021ED526
	.public _021ED542
	.public _021ED55E
	.public _021ED57C
	.public _021ED584
	.public _021ED58E
	.public _021ED5A0
	.public _021ED5A4
	.public _021ED5A8
	.public _021ED5AC
	.public _021ED5DA
	.public _021ED5FC
	.public _021ED608
	.public _021ED61C
	.public _021ED628
	.public _021ED64C
	.public _021ED66E
	.public _021ED676
	.public _021ED6C0
	.public _021ED6CC
	.public _021ED71A
	.public _021ED72A
	.public _021ED734
	.public _021ED758
	.public _021ED75C
	.public _021ED7B0
	.public _021ED7B4
	.public _021ED7D8
	.public _021ED81C
	.public _021ED846
	.public _021ED856
	.public _021ED860
	.public _021ED872
	.public _021ED884
	.public _021ED896
	.public _021ED8A8
	.public _021ED8BC
	.public _021ED8CE
	.public _021ED8E0
	.public _021ED8F8
	.public _021ED902
	.public _021ED914
	.public _021ED918
	.public _021ED91C
	.public _021ED93C
	.public _021ED95C
	.public _021ED968
	.public _021ED98E
	.public _021ED996
	.public _021ED9A8
	.public _021ED9E8
	.public _021EDA18
	.public _021EDA36
	.public _021EDA96
	.public _021EDAB8
	.public _021EDB1C
	.public _021EDB3C
	.public _021EDB50
	.public _021EDB64
	.public _021EDB76
	.public _021EDB80
	.public _021EDB82
	.public _021EDB8C
	.public _021EDB8E
	.public _021EDB96
	.public _021EDB98
	.public _021EDBAA
	.public _021EDBB0
	.public _021EDBBC
	.public _021EDBD2
	.public _021EDBEC
	.public _021EDBFE
	.public _021EDC32
	.public _021EDC4E
	.public _021EDC84
	.public _021EDCBA
	.public _021EDCD0
	.public _021EDCEA
	.public _021EDCFA
	.public _021EDD12
	.public _021EDD24
	.public _021EDD50
	.public _021EDD6C
	.public _021EDD82
	.public _021EDD9C
	.public _021EDDA4
	.public _021EDDA8
	.public _021EDDAC
	.public _021EDDB0
	.public _021EDDB4
	.public _021EDDB8
	.public _021EDDBC
	.public _021EDDC0
	.public _021EDDC4
	.public _021EDE12
	.public _021EDE18
	.public _021EDE1C
	.public _021EDE6C
	.public _021EDE84
	.public _021EDF00
	.public _021EDF04
	.public _021EDF24
	.public _021EDF66
	.public _021EDF72
	.public _021EDF8C
	.public _021EDFEC
	.public _021EE012
	.public _021EE084
	.public _021EE0A4
	.public _021EE0C6
	.public _021EE0DE
	.public _021EE0E8
	.public _021EE0F2
	.public _021EE0FA
	.public _021EE0FC
	.public _021EE10E
	.public _021EE124
	.public _021EE13E
	.public _021EE150
	.public _021EE18A
	.public _021EE1A0
	.public _021EE1AA
	.public _021EE1C0
	.public _021EE1D0
	.public _021EE1E8
	.public _021EE1FA
	.public _021EE24E
	.public _021EE254
	.public _021EE258
	.public _021EE25C
	.public _021EE260
	.public _021EE264
	.public _021EE268
	.public _021EE29A
	.public _021EE2D2
	.public _021EE2FA
	.public _021EE320
	.public _021EE324
	.public _021EE330
	.public _021EE334
	.public _021EE37C
	.public _021EE3C4
	.public _021EE3EE
	.public _021EE402
	.public _021EE40C
	.public _021EE416
	.public _021EE420
	.public _021EE42A
	.public _021EE434
	.public _021EE43E
	.public _021EE448
	.public _021EE45A
	.public _021EE46A
	.public _021EE472
	.public _021EE48A
	.public _021EE494
	.public _021EE4A4
	.public _021EE4A8
	.public _021EE4D4
	.public _021EE4E0
	.public _021EE4F8
	.public _021EE574
	.public _021EE5A0
	.public _021EE5C4
	.public _021EE5E4
	.public _021EE604
	.public _021EE62E
	.public _021EE650
	.public _021EE65C
	.public _021EE660
	.public _021EE680
	.public _021EE6C8
	.public _021EE6CC
	.public _021EE6F4
	.public _021EE78E
	.public _021EE7AC
	.public _021EE7B0
	.public _021EE8CE
	.public _021EE94A
	.public _021EE956
	.public _021EE976
	.public _021EE98A
	.public _021EE99E
	.public _021EE9AE
	.public _021EE9B8
	.public _021EE9BA
	.public _021EE9C4
	.public _021EE9C6
	.public _021EE9CE
	.public _021EE9EC
	.public _021EEA20
	.public _021EEA54
	.public _021EEA66
	.public _021EEA78
	.public _021EEA8A
	.public _021EEABE
	.public _021EEACC
	.public _021EEAEC
	.public _021EEB08
	.public _021EEB1E
	.public _021EEB2C
	.public _021EEB3C
	.public _021EEB54
	.public _021EEB66
	.public _021EEB7C
	.public _021EEB8A
	.public _021EEB92
	.public _021EEBD6
	.public _021EEBDC
	.public _021EEBE0
	.public _021EEBE4
	.public _021EEBE8
	.public _021EEBEC
	.public _021EEBF0
	.public _021EEBF4
	.public _021EEBF8
	.public _021EEC30
	.public _021EEC72
	.public _021EEC7C
	.public _021EEC88
	.public _021EED0C
	.public _021EED20
	.public _021EED24
	.public _021EED48
	.public _021EEDAE
	.public _021EEDB4
	.public _021EEDEA
	.public _021EEDF8
	.public _021EEE78
	.public _021EEE82
	.public _021EEE90
	.public _021EEEA8
	.public _021EEED0
	.public _021EEEE6
	.public _021EEF30
	.public _021EEF46
	.public _021EEFA6
	.public _021EEFCA
	.public _021EEFE2
	.public _021EF01C
	.public _021EF020
	.public _021EF038
	.public _021EF092
	.public _021EF0DE
	.public _021EF13E
	.public _021EF17C
	.public _021EF180
	.public _021EF184
	.public _021EF188
	.public _021EF18C
	.public _021EF1E8
	.public _021EF200
	.public _021EF244
	.public _021EF28C
	.public _021EF2C4
	.public _021EF2DE
	.public _021EF2E2
	.public _021EF31C
	.public _021EF352
	.public _021EF36C
	.public _021EF370
	.public _021EF3B4
	.public _021EF3B8
	.public _021EF3CC
	.public _021EF3E0
	.public _021EF3F4
	.public _021EF3FC
	.public _021EF3FE
	.public _021EF408
	.public _021EF40A
	.public _021EF410
	.public _021EF412
	.public _021EF414
	.public _021EF42A
	.public _021EF440
	.public _021EF456
	.public _021EF46C
	.public _021EF482
	.public _021EF498
	.public _021EF4EC
	.public _021EF506
	.public _021EF50A
	.public _021EF55C
	.public _021EF576
	.public _021EF57A
	.public _021EF5A6
	.public _021EF5E4
	.public _021EF600
	.public _021EF622
	.public _021EF63A
	.public _021EF64C
	.public _021EF66E
	.public _021EF6A2
	.public _021EF6C4
	.public _021EF6C8
	.public _021EF6CC
	.public _021EF6D0
	.public _021EF718
	.public _021EF776
	.public _021EF784
	.public _021EF7DE
	.public _021EF838
	.public _021EF85E
	.public _021EF898
	.public _021EF89C
	.public _021EF8A0
	.public _021EF8A4
	.public _021EF8A8
	.public _021EF908
	.public _021EF918
	.public _021EF91C
	.public _021EF956
	.public _021EF95E
	.public _021EF970
	.public _021EF978
	.public _021EF988
	.public _021EF990
	.public _021EF9A0
	.public _021EF9B0
	.public _021EF9B4
	.public _021EF9B8
	.public _021EFA12
	.public _021EFA5C
	.public _021EFAA8
	.public _021EFAC8
	.public _021EFB48
	.public _021EFB4C
	.public _021EFB50
	.public _021EFB54
	.public _021EFB58
	.public _021EFB5C
	.public _021EFB60
	.public _021EFBBC
	.public _021EFC26
	.public _021EFC32
	.public _021EFC52
	.public _021EFC74
	.public _021EFC88
	.public _021EFC92
	.public _021EFC9C
	.public _021EFCA4
	.public _021EFCA6
	.public _021EFCB8
	.public _021EFCCA
	.public _021EFCE2
	.public _021EFCF0
	.public _021EFD00
	.public _021EFD12
	.public _021EFD4C
	.public _021EFD64
	.public _021EFD72
	.public _021EFD7A
	.public _021EFDC4
	.public _021EFDC8
	.public _021EFDCC
	.public _021EFDD0
	.public _021EFDD4
	.public _021EFDD8
	.public _021EFDDC
	.public _021EFDE0
	.public _021EFE10
	.public _021EFE6C
	.public _021EFE7A
	.public _021EFE98
	.public _021EFEB0
	.public _021EFEF0
	.public _021EFEF4
	.public _021EFEF8
	.public _021EFEFC
	.public _021EFF14
	.public _021EFF6E
	.public _021EFFBA
	.public _021F0006
	.public _021F0046
	.public _021F0084
	.public _021F0088
	.public _021F008C
	.public _021F0090
	.public _021F0094
	.public _021F0098
	.public _021F009C
	.public _021F00FC
	.public _021F011C
	.public _021F0134
	.public _021F0160
	.public _021F01B4
	.public _021F01D4
	.public _021F0266
	.public _021F026C
	.public _021F0278
	.public _021F0288
	.public _021F029C
	.public _021F029E
	.public _021F0302
	.public _021F0310
	.public _021F0324
	.public _021F0326
	.public _021F038A
	.public _021F0398
	.public _021F03F2
	.public _021F0414
	.public _021F0482
	.public _021F048C
	.public _021F04BA
	.public _021F04D0
	.public _021F052C
	.public _021F0590
	.public _021F05E4
	.public _021F0606
	.public _021F0620
	.public _021F062A
	.public _021F065C
	.public _021F0674
	.public _021F068A
	.public _021F0692
	.public _021F06EE
	.public _021F0710
	.public _021F072A
	.public _021F0742
	.public _021F074C
	.public _021F077A
	.public _021F0790
	.public _021F07EC
	.public _021F0838
	.public _021F0876
	.public _021F0890
	.public _021F08B8
	.public _021F08D0
	.public _021F08FA
	.public _021F0948
	.public _021F096A
	.public _021F0998
	.public _021F09B8
	.public _021F09D0
	.public _021F09DA
	.public _021F09E4
	.public _021F09FA
	.public _021F0A04
	.public _021F0A26
	.public _021F0A3A
	.public _021F0A6E
	.public _021F0A7C
	.public _021F0AA8
	.public _021F0AD4
	.public _021F0B30
	.public _021F0B5E
	.public _021F0C48
	.public _021F0C54
	.public _021F0C84
	.public _021F0CD4
	.public _021F0D10
	.public _021F0D2A
	.public _021F0D54
	.public _021F0D6A
	.public _021F0D6C
	.public _021F0D96
	.public _021F0DEA
	.public _021F0E40
	.public _021F0E4E
	.public _021F0E9E
	.public _021F0EB2
	.public _021F0ED4
	.public _021F0EE0
	.public _021F0EE4
	.public _021F0F08
	.public _021F0F42
	.public _021F0F5A
	.public _021F0F6A
	.public _021F0F74
	.public _021F0F8A
	.public _021F0F90
	.public _021F0F9C
	.public _021F0FA2
	.public _021F0FC4
	.public _021F0FCA
	.public _021F0FEC
	.public _021F0FF0
	.public _021F0FFC
	.public _021F1000
	.public _021F101A
	.public _021F1020
	.public _021F104E
	.public _021F108C
	.public _021F10B0
	.public _021F10D8
	.public _021F10FC
	.public _021F1124
	.public _021F1162
	.public _021F116C
	.public _021F11F4
	.public _021F123C
	.public _021F1242
	.public _021F1256
	.public _021F125E
	.public _021F1298
	.public _021F1314
	.public _021F1318
	.public _021F1348
	.public _021F1370
	.public _021F138E
	.public _021F13A0
	.public _021F13A4
	.public _021F13A8
	.public _021F13AC
	.public _021F13EE
	.public _021F1410
	.public _021F1444
	.public _021F1482
	.public _021F1488
	.public _021F148C
	.public _021F14F8
	.public _021F14FC
	.public _021F1500
	.public _021F153C
	.public _021F1566
	.public _021F156C
	.public _021F1578
	.public _021F157C
	.public _021F15B4
	.public _021F15C0
	.public _021F15C4
	.public _021F15D6
	.public _021F15D8
	.public _021F1650
	.public _021F1658
	.public _021F1674
	.public _021F167C
	.public _021F1684
	.public _021F168A
	.public _021F16E2
	.public _021F16F8
	.public _021F170C
	.public _021F172C
	.public _021F173E
	.public _021F1752
	.public _021F1772
	.public _021F1784
	.public _021F1798
	.public _021F17BE
	.public _021F17D0
	.public _021F17F8
	.public _021F17FC
	.public _021F1800
	.public _021F1804
	.public _021F189C
	.public _021F18A8
	.public _021F18AC
	.public _021F18F2
	.public _021F1900
	.public _021F190E
	.public _021F1932
	.public _021F198A
	.public _021F19A4
	.public _021F19E4
	.public _021F19E8
	.public _021F19EC
	.public _021F1A4E
	.public _021F1A6A
	.public _021F1A78
	.public _021F1ADE
	.public _021F1AF8
	.public _021F1B38
	.public _021F1B3C
	.public _021F1B40
	.public _021F1B44
	.public _021F1B48
	.public _021F1B7C
	.public _021F1BE2
	.public _021F1BF0
	.public _021F1BF4
	.public _021F1BF8
	.public _021F1BFC
	.public _021F1C00
	.public _021F1C2E
	.public _021F1C34
	.public _021F1C48
	.public _021F1CA0
	.public _021F1CBA
	.public _021F1CD4
	.public _021F1CD8
	.public _021F1D58
	.public _021F1D64
	.public _021F1D68
	.public _021F1DAE
	.public _021F1DBC
	.public _021F1DCA
	.public _021F1DD6
	.public _021F1E46
	.public _021F1E52
	.public _021F1E6C
	.public _021F1EAC
	.public _021F1EB0
	.public _021F1EB4
	.public _021F1EF6
	.public _021F1EFA
	.public _021F1F04
	.public _021F1F1C
	.public _021F1F20
	.public _021F1F40
	.public _021F1F7E
	.public _021F1F96
	.public _021F1FB6
	.public _021F1FC4
	.public _021F1FCE
	.public _021F1FD8
	.public _021F1FE0
	.public _021F1FF0
	.public _021F1FFA
	.public _021F2004
	.public _021F2008
	.public _021F200C
	.public _021F2096
	.public _021F20A4
	.public _021F20B2
	.public _021F20BC
	.public _021F20C0
	.public _021F20F0
	.public _021F212A
	.public _021F216C
	.public _021F21A8
	.public _021F21AC
	.public _021F21B0
	.public _021F21CC
	.public _021F21FA
	.public _021F2202
	.public _021F221C
	.public _021F223E
	.public _021F2254
	.public _021F226A
	.public _021F232C
	.public _021F23EC
	.public _021F2460
	.public _021F2462
	.public _021F2488
	.public _021F248C
	.public _021F2506
	.public _021F250E
	.public _021F252C
	.public _021F2530
	.public _021F254C
	.public _021F2554
	.public _021F255E
	.public _021F2570
	.public _021F2618
	.public _021F2620
	.public _021F2628
	.public _021F2630
	.public _021F2638
	.public _021F268C
	.public _021F26A4
	.public _021F26AA
	.public _021F26EC
	.public _021F2730
	.public _021F2768
	.public _021F2774
	.public _021F27A2
	.public _021F27AC
	.public _021F27C8
	.public _021F27D0
	.public _021F280C
	.public _021F2814
	.public _021F2854
	.public _021F2894
	.public _021F28E6
	.public _021F28F4
	.public _021F28F8
	.public _021F2966
	.public _021F2974
	.public _021F2978
	.public _021F29CE
	.public _021F29D8
	.public _021F2A14
	.public _021F2A30
	.public _021F2A5C
	.public _021F2A70
	.public _021F2A98
	.public _021F2AB4
	.public _021F2B5C
	.public _021F2B60
	.public _021F2B64
	.public _021F2C00
	.public _021F2C0A
	.public _021F2C92
	.public _021F2D18
	.public _021F2D2E
	.public _021F2D3A
	.public _021F2D40
	.public _021F2DB8
	.public _021F2DBC
	.public _021F2DC0
	.public _021F2DE4
	.public _021F2DF4
	.public _021F2E10
	.public _021F2E56
	.public _021F2E6C
	.public _021F2E70
	.public _021F2E74
	.public _021F2F1A
	.public _021F2F26
	.public _021F2F4E
	.public _021F2F7C
	.public _021F2F80
	.public _021F2F84
	.public _021F2FB4
	.public _021F2FD2
	.public _021F2FD4
	.public _021F2FD8
	.public _021F2FEC
	.public _021F3028
	.public _021F3030
	.public _021F303C
	.public _021F3040
	.public _021F3054
	.public _021F3096
	.public _021F309E
	.public _021F30A8
	.public _021F30AC
	.public _021F30C0
	.public _021F3102
	.public _021F310A
	.public _021F3114
	.public _021F3118
	.public _021F312C
	.public _021F3174
	.public _021F317C
	.public _021F3188
	.public _021F318C
	.public _021F31B4
	.public _021F31C2
	.public _021F31CA
	.public _021F31DC
	.public _021F31F8
	.public _021F3200
	.public _021F320C
	.public _021F3228
	.public _021F3232
	.public _021F3236
	.public _021F32AA
	.public _021F32D0
	.public _021F32D4
	.public _021F32D8
	.public _021F32DC
	.public _021F330C
	.public _021F334C
	.public _021F3350
	.public _021F339E
	.public _021F33AC
	.public _021F33D6
	.public _021F33E4
	.public _021F3436
	.public _021F3454
	.public _021F3460
	.public _021F3468
	.public _021F346C
	.public _021F3480
	.public _021F3484
	.public _021F349A
	.public _021F349C
	.public _021F34B0
	.public _021F34C4
	.public _021F34D4
	.public _021F34D8
	.public _021F35AC
	.public _021F35B0
	.public _021F35B4
	.public _021F35B8
	.public _021F360C
	.public _021F3610
	.public _021F3658
	.public _021F365A
	.public _021F36D4
	.public _021F36D8
	.public _021F3710
	.public _021F37E0
	.public _021F37E4
	.public _021F37E8
	.public _021F37EC
	.public _021F37F0
	.public _021F383C
	.public _021F3840
	.public _021F3940
	.public _021F3968
	.public _021F39E0
	.public _021F3A00
	.public _021F3A3A
	.public _021F3AA0
	.public _021F3AC0
	.public _021F3B1E
	.public _021F3B24
	.public _021F3B28
	.public _021F3B2C
	.public _021F3B30
	.public _021F3B34
	.public _021F3B38
	.public _021F3B48
	.public _021F3B80
	.public _021F3BB6
	.public _021F3BB8
	.public _021F3BBC
	.public _021F3CA4
	.public _021F3CA8
	.public _021F3CAC
	.public _021F3CB0
	.public _021F3D04
	.public _021F3D08
	.public _021F3D98
	.public _021F3DD2
	.public _021F3DE0
	.public _021F3DE4
	.public _021F3E64
	.public _021F3E68
	.public _021F3E6C
	.public _021F3F48
	.public _021F3F4C
	.public _021F3F50
	.public _021F3F54
	.public _021F3F58
	.public _021F3F5C
	.public _021F3F60
	.public _021F3F64
	.public _021F3F68
	.public _021F3F7C
	.public _021F3FAA
	.public _021F3FDA
	.public _021F402C
	.public _021F4048
	.public _021F40C0
	.public _021F40C4
	.public _021F40C8
	.public _021F40CC
	.public _021F40D0
	.public _021F40D4
	.public _021F40D8
	.public _021F40E4
	.public _021F40F6
	.public _021F40F8
	.public _021F40FC
	.public _021F4164
	.public _021F4170
	.public _021F41A2
	.public _021F41D4
	.public _021F41D8
	.public _021F41DC
	.public _021F41E0
	.public _021F41F0
	.public _021F426C
	.public _021F4270
	.public _021F4274
	.public _021F428A
	.public _021F4296
	.public _021F429C
	.public _021F42E4
	.public _021F42E8
	.public _021F42F8
	.public _021F4378
	.public _021F437C
	.public _021F4392
	.public _021F439E
	.public _021F43A4
	.public _021F43EC
	.public _021F43F0
	.public _021F4420
	.public _021F4424
	.public _021F44AC
	.public _021F44B0
	.public _021F44C0
	.public _021F44FE
	.public _021F4558
	.public _021F4560
	.public _021F4598
	.public _021F4628
	.public _021F4660
	.public _021F46AC
	.public _021F46D0
	.public _021F46D8
	.public _021F46DE
	.public _021F46E4
	.public _021F46EC
	.public _021F46F2
	.public _021F4718
	.public _021F471C
	.public _021F47B0
	.public _021F47B4
	.public _021F47C2
	.public _021F4808
	.public _021F4870
	.public _021F4878
	.public _021F493C
	.public _021F4954
	.public _021F49C4
	.public _021F49CE
	.public _021F49F8
	.public _021F4A1C
	.public _021F4A5C
	.public _021F4A60
	.public _021F4A76
	.public _021F4A8A
	.public _021F4AF0
	.public _021F4AFA
	.public _021F4AFC
	.public _021F4B24
	.public _021F4B4A
	.public _021F4B84
	.public _021F4B88
	.public _021F4B8C
	.public _021F4C1C
	.public _021F4C98
	.public _021F4C9C
	.public _021F4CDA
	.public _021F4D08
	.public _021F4D0C
	.public _021F4E5C
	.public _021F4E60
	.public _021F4E64
	.public _021F4E76
	.public _021F4E9C
	.public _021F4ECC
	.public _021F4EE2
	.public _021F4EFC
	.public _021F4F06
	.public _021F4F44
	.public _021F4F56
	.public _021F4F66
	.public _021F5044
	.public _021F5050
	.public _021F509C
	.public _021F5104
	.public _021F5110
	.public _021F5162
	.public _021F5182
	.public _021F518C
	.public _021F5208
	.public _021F5218
	.public _021F5264
	.public _021F527E
	.public _021F5288
	.public _021F52D4
	.public _021F52EE
	.public _021F52F8
	.public _021F5340
	.public _021F535A
	.public _021F5364
	.public _021F541E
	.public _021F5422
	.public _021F5472
	.public _021F5486
	.public _021F553A
	.public _021F5546
	.public _021F5558
	.public _021F555C
	.public _021F5560
	.public _021F557C
	.public _021F557E
	.public _021F5612
	.public _021F5618
	.public _021F561C
	.public _021F5668
	.public _021F5714
	.public _021F57B4
	.public _021F58B4
	.public _021F58FC
	.public _021F590E
	.public _021F5918
	.public _021F5948
	.public _021F594C
	.public _021F599A
	.public _021F59AA
	.public _021F5A9A
	.public _021F5AFE
	.public _021F5B2A
	.public _021F5B8E
	.public _021F5BD4
	.public _021F5C16
	.public _021F5C1E
	.public _021F5C5A
	.public _021F5C6E
	.public _021F5C80
	.public _021F5DB8
	.public _021F5E4A
	.public _021F5E90
	.public _021F5EA8
	.public _021F5F0E
	.public _021F5F56
	.public _021F5F8A
	.public _021F5F90
	.public _021F5F96
	.public _021F5FB6
	.public _021F603C
	.public _021F613E
	.public _021F6164
	.public _021F6184
	.public _021F61AE
	.public _021F61B6
	.public _021F61C6
	.public _021F61EA
	.public _021F6200
	.public _021F6204
	.public _021F62E0
	.public _021F62F8
	.public _021F6310
	.public _021F6388
	.public _021F6404
	.public _021F6542
	.public _021F65D8
	.public _021F6624
	.public _021F6650
	.public _021F6684
	.public _021F6694
	.public _021F66E4
	.public _021F66FA
	.public _021F672C
	.public _021F6738
	.public _021F6764
	.public _021F678C
	.public _021F67AC
	.public _021F67C6
	.public _021F67D4
	.public _021F67D8
	.public _021F67F4
	.public _021F6810
	.public _021F6814
	.public _021F6830
	.public _021F6834
	.public _021F6836
	.public _021F684E
	.public _021F6852
	.public _021F6854
	.public _021F6858
	.public _021F6872
	.public _021F6880
	.public _021F6884
	.public _021F68A0
	.public _021F68A4
	.public _021F68A8
	.public _021F68AC
	.public _021F68B0
	.public _021F68B2
	.public _021F68D6
	.public _021F68E6
	.public _021F68F8
	.public _021F690A
	.public _021F690E
	.public _021F6912
	.public _021F6916
	.public _021F6918
	.public _021F6924
	.public _021F6948
	.public _021F695E
	.public _021F6962
	.public _021F6966
	.public _021F696A
	.public _021F696E
	.public _021F6972
	.public _021F6984
	.public _021F6988
	.public _021F698C
	.public _021F6990
	.public _021F6994
	.public _021F6996
	.public _021F69E8
	.public _021F69EC
	.public _021F6A10
	.public _021F6A1C
	.public _021F6A20
	.public _021F6A2C
	.public _021F6A30
	.public _021F6A3C
	.public _021F6A40
	.public _021F6A5E
	.public _021F6A66
	.public _021F6A6A
	.public _021F6A6E
	.public _021F6A72
	.public _021F6A74
	.public _021F6AB4
	.public _021F6AB8
	.public _021F6ABC
	.public _021F6B04
	.public _021F6B08
	.public _021F6B0C
	.public _021F6B26
	.public _021F6B88
	.public _021F6BA0
	.public _021F6C0C
	.public _021F6C14
	.public _021F6C18
	.public _021F6C32
	.public _021F6C36
	.public _021F6C6C
	.public _021F6C70
	.public _021F6C7E
	.public _021F6CB4
	.public _021F6D04
	.public _021F6D10
	.public _021F6D30
	.public _021F6D3A
	.public _021F6D56
	.public _021F6D64
	.public _021F6D7C
	.public _021F6D84
	.public _021F6DC0
	.public _021F6DD6
	.public _021F6DDE
	.public _021F6E1A
	.public _021F6E4A
	.public _021F6E60
	.public _021F6E64
	.public _021F6E8A
	.public _021F6ED8
	.public _021F6EE0
	.public _021F6EE4
	.public _021F6EFE
	.public _021F6F02
	.public _021F6F32
	.public _021F6F48
	.public _021F6F4C
	.public _021F6F5A
	.public _021F6F92
	.public _021F6FDC
	.public _021F6FFC
	.public _021F7008
	.public _021F700C
	.public _021F7042
	.public _021F704E
	.public _021F7052
	.public _021F7060
	.public _021F7074
	.public _021F7076
	.public _021F70A0
	.public _021F70DE
	.public _021F7118
	.public _021F7170
	.public _021F7178
	.public _021F717C
	.public _021F7180
	.public _021F71A8
	.public _021F71B0
	.public _021F71BC
	.public _021F71C4
	.public _021F71CC
	.public _021F71D0
	.public _021F71EE
	.public _021F71FC
	.public _021F7214
	.public _021F721C
	.public _021F7258
	.public _021F726E
	.public _021F7276
	.public _021F72B2
	.public _021F72E8
	.public _021F72FC
	.public _021F7300
	.public _021F7304
	.public _021F731C
	.public _021F7338
	.public _021F733C
	.public _021F735E
	.public _021F73D0
	.public _021F73DC
	.public _021F73E0
	.public _021F7414
	.public _021F7418
	.public _021F742C
	.public _021F742E
	.public _021F747E
	.public _021F7492
	.public _021F74A8
	.public _021F74AC
	.public _021F74F4
	.public _021F7514
	.public _021F7520
	.public _021F7524
	.public _021F755A
	.public _021F7566
	.public _021F756A
	.public _021F7578
	.public _021F757E
	.public _021F75A8
	.public _021F760C
	.public _021F7618
	.public _021F761C
	.public _021F7650
	.public _021F7654
	.public _021F765A
	.public _021F7684
	.public _021F76A8
	.public _021F76EE
	.public _021F76FC
	.public _021F771C
	.public _021F7726
	.public _021F7742
	.public _021F7750
	.public _021F7768
	.public _021F7770
	.public _021F77AC
	.public _021F77C2
	.public _021F77CA
	.public _021F7806
	.public _021F7836
	.public _021F784C
	.public _021F7850
	.public _021F7876
	.public _021F789C
	.public _021F78E4
	.public _021F78F4
	.public _021F7914
	.public _021F791E
	.public _021F793A
	.public _021F7948
	.public _021F7960
	.public _021F7998
	.public _021F79AE
	.public _021F79E6
	.public _021F7A0C
	.public _021F7A20
	.public _021F7A24
	.public _021F7A28
	.public _021F7A4E
	.public _021F7B24
	.public _021F7B34
	.public _021F7B4C
	.public _021F7B58
	.public _021F7B92
	.public _021F7BA2
	.public _021F7BB0
	.public _021F7BB4
	.public _021F7BB8
	.public sPCBoxSlotGridRect
	.public PCBox_VBlankCallback
	.public PCBox_UpdateDetailPanel
	.public PCBox_SetUpdateFunc
	.public PCBox_SetPendingUpdateFunc
	.public PCBox_StartPendingUpdateFunc
	.public PCBox_SetGfxBanks
	.public PCBox_InitBgLayers
	.public PCBox_FreeBgLayers
	.public PCBox_LoadBgGraphics
	.public PCBox_CreateMsgResources
	.public PCBox_DestroyMsgResources
	.public PCBox_LoadWindowGraphics
	.public PCBox_CreatePaletteData
	.public PCBox_FreePaletteData
	.public PCBox_SetBlendEnabled
	.public PCBox_CreateYesNoPrompt
	.public PCBox_DestroyYesNoPrompt
	.public PCBox_ShowYesNoPrompt
	.public PCBox_AnimatePaletteFlash
	.public PCBox_SaveMenuInputState
	.public PCBox_GetSlotMonData
	.public PCBox_SetSlotMonData
	.public PCBox_GetSlotBoxMon
	.public PCBox_DeleteSlotMon
	.public PCBox_SwapBoxAndPartyMon
	.public PCBox_MoveBoxMonToParty
	.public PCBox_MovePartyMonToBox
	.public PCBox_SwapPartyMons
	.public PCBox_MovePartyMonToEnd
	.public PCBox_MoveBoxMonToOtherBox
	.public PCBox_MovePartyMonToOtherBox
	.public PCBox_ApplyMonMove
	.public PCBox_GetTargetBoxId
	.public PCBox_PartyHasOtherUsableMon
	.public PCBox_UpdateArceusGiratinaForm
	.public PCBox_RevertShayminFormOnMove
	.public PCBox_AnimateMonMove
	.public PCBox_AnimateSelectedSlotMoveEntry
	.public PCBox_AnimateMoveEntries
	.public PCBox_CanMoveMon
	.public PCBox_CanMovePartyMonToEmptySlot
	.public PCBox_CanSwapHeldItems
	.public PCBox_SetupMoveEntryToSlot
	.public PCBox_SetupMoveEntryToSprite
	.public PCBox_SetupMonSwapEntries
	.public PCBox_SetupMonMove
	.public PCBox_SetupDepositMoveEntries
	.public PCBox_SetupMonMoveToPartyEnd
	.public PCBox_GetMoveEntryTarget
	.public PCBox_SetupPartyShiftAfterRelease
	.public PCBox_ApplyMoveEntryIcons
	.public PCBox_GetReleaseCheckMoveIndex
	.public PCBox_StartReleaseMoveCheck
	.public PCBox_FreeReleaseMoveCheck
	.public PCBox_RunReleaseMoveCheck
	.public PCBox_CreateMonInfo
	.public PCBox_FreeMonInfo
	.public PCBox_DrawMonInfo
	.public PCBox_DrawMonItemInfo
	.public PCBox_ShowSlotMonInfo
	.public PCBox_RedrawSlotMonInfo
	.public PCBox_ClearMonInfo
	.public PCBox_ClearMonInfoAndSelection
	.public PCBox_LoadWallpaperChars
	.public PCBox_LoadWallpaperPalette
	.public PCBox_LoadWallpaperTilemap
	.public PCBox_LoadWallpaper
	.public PCBox_LoadScrolledWallpaper
	.public PCBox_SwapWallpaper
	.public PCBox_GetWallpaperGfxIndex
	.public PCBox_IsPointInRect
	.public PCBox_GetTouchedBoxSlot
	.public PCBox_GetTouchedPartySlot
	.public PCBox_GetTouchedTrayBox
	.public PCBox_StartHeldItemMove
	.public PCBox_StartHeldItemMoveWithIcon
	.public PCBox_StartHeldItemMoveFromDropTarget
	.public PCBox_UpdateHeldItemMove
	.public PCBox_UpdateHeldItemMoveWithIcon
	.public PCBox_UpdateHeldItemMoveNoIcon
	.public PCBox_InitPanels
	.public PCBox_FreePanels
	.public PCBox_LoadPanelTilemap
	.public PCBox_DrawMarkingMenuEntry
	.public PCBox_DrawMarkingMenu
	.public PCBox_ToggleMarking
	.public PCBox_SlideInMarkingMenu
	.public PCBox_SlideOutMarkingMenu
	.public PCBox_PlacePartyPanelLeft
	.public PCBox_PlacePartyPanelRight
	.public PCBox_ClearPartyPanelTiles
	.public PCBox_PlacePartyPanelLeftHidden
	.public PCBox_PlacePartyPanelRightHidden
	.public PCBox_SlideInPartyPanel
	.public PCBox_SlideOutPartyPanel
	.public PCBox_LowerPartyPanel
	.public PCBox_RaisePartyPanel
	.public PCBox_ShiftPartyPanelAndReturnButtonRight
	.public PCBox_ShiftPartyPanelRight
	.public PCBox_ShiftPartyPanelAndReturnButtonLeft
	.public PCBox_ShiftPartyPanelLeft
	.public PCBox_UpdatePartyPanelSlide
	.public PCBox_UpdatePartyPanelMove
	.public PCBox_LoadPartyPanelTilemap
	.public PCBox_SlideInWallpaperList
	.public PCBox_SlideOutWallpaperList
	.public PCBox_ShowPartyButton
	.public PCBox_HidePartyButton
	.public PCBox_SlideOutPartyButton
	.public PCBox_SlideInPartyButton
	.public PCBox_ShowTrayTab
	.public PCBox_HideTrayTab
	.public PCBox_SlideOutTrayTab
	.public PCBox_SlideInTrayTab
	.public PCBox_ShowReturnButton
	.public PCBox_ShowExitButton
	.public PCBox_HideReturnButton
	.public PCBox_SlideOutReturnButton
	.public PCBox_SlideInReturnButton
	.public PCBox_IsMenuExitButtonShown
	.public PCBox_HidePartyButtonAndTrayTab
	.public PCBox_HideActionMenu
	.public PCBox_ShowActionMenu
	.public PCBox_ResetActionMenu
	.public PCBox_SlideInActionMenu
	.public PCBox_SlideOutActionMenu
	.public PCBox_UpdateActionMenuSlide
	.public PCBox_IsActionMenuOpen
	.public PCBox_SlideInTitlePanel
	.public PCBox_SlideOutTitlePanel
	.public PCBox_HideChangeBoxButton
	.public PCBox_SlideInChangeBoxButton
	.public PCBox_SlideOutChangeBoxButton
	.public PCBox_IsChangeBoxButtonShown
	.public PCBox_HideSummaryButton
	.public PCBox_ShowSummaryButton
	.public PCBox_SlideInSummaryButton
	.public PCBox_SlideOutSummaryButton
	.public PCBox_IsSummaryButtonShown
	.public PCBox_ShowBoxTray
	.public PCBox_SlideInBoxTray
	.public PCBox_SlideOutBoxTray
	.public PCBox_ShowBoxMenuPanels
	.public PCBox_ShowBoxTrayAndMenu
	.public PCBox_SlideInBoxMenu
	.public PCBox_SlideOutBoxMenu
	.public PCBox_HideBottomButtons
	.public PCBox_SlideInMovesPanel
	.public PCBox_SlideOutMovesPanel
	.public PCBox_ShowMovesPanel
	.public PCBox_HideMovesPanel
	.public PCBox_SlideInItemInfoPanel
	.public PCBox_SlideOutItemInfoPanel
	.public PCBox_ShowItemInfoPanel
	.public PCBox_HideItemInfoPanel
	.public PCBox_DrawMarkings
	.public PCBox_StartSummaryApp
	.public PCBox_EndSummaryApp
	.public PCBox_StartBagApp
	.public PCBox_EndBagApp
	.public PCBox_StartNamingScreenApp
	.public PCBox_EndNamingScreenApp
	.public PCBox_UpdateMoveModeBoxDrag
	.public PCBox_UpdateMoveModePartyDrag
	.public PCBox_UpdateBoxTrayDrag
	.public PCBox_AnimatePartyShiftAfterRelease
	.public PCBox_AnimateMoveToPartyEnd
	.public PCBox_AnimateMoveToFirstEmptySlot
	.public PCBox_UpdateScrollToPrevBox
	.public PCBox_UpdateScrollToNextBox
	.public PCBox_WaitActionMenuSlide
	.public PCBox_WaitActionMenuAndButtonsSlide
	.public PCBox_UpdateMarkingMenuSlide
	.public PCBox_WaitBottomButtonsSlide
	.public PCBox_WaitPartyPanelSlide
	.public PCBox_WaitPartyPanelAndActionMenuSlide
	.public PCBox_WaitPartyPanelSlideFunc
	.public PCBox_UpdateBoxTraySlideIn
	.public PCBox_UpdateBoxTraySlideOut
	.public PCBox_WaitReturnButtonSlide
	.public PCBox_WaitActionMenuThenTitleSlide
	.public PCBox_WaitTitlePanelSlide
	.public PCBox_UpdateBoxMenuSlide
	.public PCBox_WaitBoxMenuThenWallpaperList
	.public PCBox_WaitWallpaperListSlideOut
	.public PCBox_AnimateDepositBoxSelectOpen
	.public PCBox_AnimateDepositBoxSelectClose
	.public PCBox_WaitSummaryOutChangeBoxIn
	.public PCBox_WaitTrayButtonsSlide
	.public PCBox_WaitChangeBoxOutSummaryIn
	.public PCBox_WaitTitleAndReturnButtonSlide
	.public PCBox_UpdateDepositDrag
	.public PCBox_UpdateWithdrawDrag
	.public PCBox_UpdateCursorSlide
	.public PCBox_WaitSelectWithActionMenu
	.public PCBox_WaitSelectWithActionMenuAndButtons
	.public PCBox_WaitDeselectThenReturnButton
	.public PCBox_WaitDeselectThenButtons
	.public PCBox_AttachIconToCursor
	.public PCBox_AnimateTrayPickUp
	.public PCBox_AnimateTrayDrop
	.public PCBox_WaitItemModeSelect
	.public PCBox_UpdateItemModeBoxDrag
	.public PCBox_WaitItemModeDeselect
	.public PCBox_AnimateSwappedItemMove
	.public PCBox_UpdateItemTrayDrag
	.public PCBox_AnimateTraySwappedItemMove
	.public PCBox_AnimateTrayItemPickUp
	.public PCBox_AnimateTrayItemDrop
	.public PCBox_AnimateTrayItemReturn
	.public PCBox_UpdateItemModePartyDrag
	.public PCBox_AnimatePartySwappedItemMove
	.public PCBox_RunStateMachine
	.public PCBox_State_Init
	.public PCBox_State_Exit
	.public PCBox_State_WaitFade
	.public PCBox_State_WaitPaletteBuffers
	.public PCBox_State_Delay
	.public PCBox_State_WaitUpdateFunc
	.public PCBox_State_WaitButton
	.public PCBox_State_HandleYesNo
	.public PCBox_State_WaitPaletteFlash
	.public PCBox_State_StartSubApp
	.public PCBox_State_RunSubApp
	.public PCBox_State_Start
	.public PCBox_State_MoveModeInput
	.public PCBox_State_ApplyMonMove
	.public PCBox_State_ReturnToActionMenu
	.public PCBox_State_ReturnFromSummary
	.public PCBox_State_ReturnFromNamingScreen
	.public PCBox_State_GiveItemFromBag
	.public PCBox_State_PrintItemHeld
	.public PCBox_State_MarkingChosen
	.public PCBox_State_OpenMarkingMenu
	.public PCBox_State_SetupMarkingMenuInput
	.public PCBox_State_MarkingMenuInput
	.public PCBox_State_FinishCloseMarkingMenu
	.public PCBox_State_TryRelease
	.public PCBox_State_ReleaseMoveCheck
	.public PCBox_State_PrintReleased
	.public PCBox_State_PrintByeBye
	.public PCBox_State_RemoveReleasedMon
	.public PCBox_State_EndPartyReleaseShift
	.public PCBox_State_ReleaseCameBack
	.public PCBox_State_PrintWorried
	.public PCBox_State_CancelRelease
	.public PCBox_State_ResumeDepositInput
	.public PCBox_State_OpenPartyPanel
	.public PCBox_State_SetupPartyPanelInput
	.public PCBox_State_MoveModePartyInput
	.public PCBox_State_SlideOutPartyPanel
	.public PCBox_State_PartyPanelClosed
	.public PCBox_State_EndMoveModePartyDrag
	.public PCBox_State_SetupBoxTrayInput
	.public PCBox_State_BoxTrayInput
	.public PCBox_State_EndBoxTrayDrag
	.public PCBox_State_EndTrayHoldingDrop
	.public PCBox_State_ResumeBoxTrayInput
	.public PCBox_State_OpenTrayBesideParty
	.public PCBox_State_SetupPartyInputAfterTray
	.public PCBox_State_OpenTrayFromBox
	.public PCBox_State_SlideInTrayPartyPanel
	.public PCBox_State_SlideOutTray
	.public PCBox_State_TrayClosed
	.public PCBox_State_ReturnToBoxFromTray
	.public PCBox_State_BoxMenuInput
	.public PCBox_State_HideButtonsForBoxMenu
	.public PCBox_State_OpenBoxMenuTray
	.public PCBox_State_ShowBoxMenuExitButton
	.public PCBox_State_OpenBoxMenu
	.public PCBox_State_SetupBoxMenuInput
	.public PCBox_State_CloseBoxMenu
	.public PCBox_State_SlideOutBoxMenu
	.public PCBox_State_CloseBoxMenuTray
	.public PCBox_State_BoxMenuClosed
	.public PCBox_State_OpenWallpaperMenu
	.public PCBox_State_ShowWallpaperMenuTitle
	.public PCBox_State_SetupWallpaperMenuInput
	.public PCBox_State_WallpaperMenuInput
	.public PCBox_State_CloseWallpaperMenu
	.public PCBox_State_SlideOutWallpaperList
	.public PCBox_State_ReturnToBoxMenu
	.public PCBox_State_ApplyWallpaper
	.public PCBox_State_WallpaperFadeOut
	.public PCBox_State_WallpaperFadeIn
	.public PCBox_State_ResumeBoxInput
	.public PCBox_State_ResumeMoveModePartyInput
	.public PCBox_State_WithdrawInput
	.public PCBox_State_ReturnToWithdrawInput
	.public PCBox_State_SlideInWithdrawParty
	.public PCBox_State_StartWithdrawMove
	.public PCBox_State_EndWithdrawMove
	.public PCBox_State_WithdrawPartyClosed
	.public PCBox_State_EndWithdrawDrag
	.public PCBox_State_ResumeWithdrawInput
	.public PCBox_State_DepositInput
	.public PCBox_State_TryDeposit
	.public PCBox_State_ReturnFromDepositError
	.public PCBox_State_ShowDepositBoxSelect
	.public PCBox_State_ShowDepositTitle
	.public PCBox_State_SetupDepositBoxInput
	.public PCBox_State_DepositBoxInput
	.public PCBox_State_CancelDepositBoxSelect
	.public PCBox_State_HideDepositExitButton
	.public PCBox_State_HideDepositBoxSelect
	.public PCBox_State_DepositBoxSelectClosed
	.public PCBox_State_ConfirmDepositBox
	.public PCBox_State_CheckDepositBox
	.public PCBox_State_ShiftPartyForDeposit
	.public PCBox_State_SwitchBox
	.public PCBox_State_StartDepositMove
	.public PCBox_State_EndDepositMove
	.public PCBox_State_ShowDepositReturnButton
	.public PCBox_State_ResetDepositInput
	.public PCBox_State_EndDepositDrag
	.public PCBox_State_EndCursorSlideToMoveMode
	.public PCBox_State_EndCursorSlideToBoxTray
	.public PCBox_State_EndCursorSlideToMoveModeParty
	.public PCBox_State_EndCursorSlideToDeposit
	.public PCBox_State_EndCursorSlideToDepositPrompt
	.public PCBox_State_EndCursorSlideToDepositBox
	.public PCBox_State_EndCursorSlideToMarkingMenu
	.public PCBox_State_EndCursorSlideToBoxMenu
	.public PCBox_State_EndCursorSlideToWallpaperMenu
	.public PCBox_State_EndCursorSlideToWithdraw
	.public PCBox_State_EndCursorSlideToWithdrawPrompt
	.public PCBox_State_ItemModeInput
	.public PCBox_State_CloseItemMessage
	.public PCBox_State_EndCursorSlideToItemMode
	.public PCBox_State_AskPutAwayItem
	.public PCBox_State_WaitPutAwayItem
	.public PCBox_State_CancelPutAwayItem
	.public PCBox_State_EndItemCommand
	.public PCBox_State_ItemModePrintEggCantHoldItem
	.public PCBox_State_ItemModePrintItemHeld
	.public PCBox_State_EndItemModeBoxDrag
	.public PCBox_State_SwapHeldItems
	.public PCBox_State_DropSwappedItem
	.public PCBox_State_FinishItemSwap
	.public PCBox_State_ItemModeBoxTrayInput
	.public PCBox_State_EndCursorSlideToItemModeTray
	.public PCBox_State_EndItemTrayDrag
	.public PCBox_State_ApplyItemTrayDrop
	.public PCBox_State_FinishItemTrayDrop
	.public PCBox_State_ResumeItemModeTrayInput
	.public PCBox_State_ItemTrayHoldingInput
	.public PCBox_State_EndCursorSlideToItemTrayHolding
	.public PCBox_State_ApplyItemTrayHoldingDrop
	.public PCBox_State_ItemModePartyInput
	.public PCBox_State_EndCursorSlideToItemModeParty
	.public PCBox_State_EndItemModePartyDrag
	.public PCBox_State_SwapPartyHeldItems
	.public PCBox_State_ResumeItemModePartyInput
	.public PCBox_State_DropSwappedPartyItem
	.public PCBox_State_FinishPartyItemSwap
	.public PCBox_State_ResumeItemModePartyAfterMail
	.public PCBox_State_PrintEggCantHoldItem
	.public PCBox_State_PrintMailCantBeTaken
	.public PCBox_StartFadeIn
	.public PCBox_StartFadeOut
	.public PCBox_WaitForUpdateFunc
	.public PCBox_WaitForPendingUpdateFunc
	.public PCBox_ShowYesNo
	.public PCBox_StartSubApp
	.public PCBox_ScrollToPrevBox
	.public PCBox_ScrollToNextBox
	.public PCBox_StartMoveModeBoxDrag
	.public PCBox_StartWithdrawDrag
	.public PCBox_SelectWithdrawMon
	.public PCBox_SelectMoveModeBoxMon
	.public PCBox_StartMoveModePartyDrag
	.public PCBox_StartDepositDrag
	.public PCBox_SelectDepositMon
	.public PCBox_SelectMoveModePartyMon
	.public PCBox_StartBoxTrayDrag
	.public PCBox_AllocMoveWork
	.public PCBox_FreeMoveWork
	.public PCBox_HandleItemCommand
	.public PCBox_CloseMarkingMenu
	.public PCBox_StartMarking
	.public PCBox_StartRelease
	.public PCBox_OpenPartyPanel
	.public PCBox_ClosePartyPanel
	.public PCBox_ShowPartyPanelLeft
	.public PCBox_ShowPartyPanelRight
	.public PCBox_ShowDepositPartyPanel
	.public PCBox_OpenTrayFromPartyPanel
	.public PCBox_CloseTrayToPartyPanel
	.public PCBox_OpenTrayFromBox
	.public PCBox_CloseTray
	.public PCBox_HideInfoPanelAndWait
	.public PCBox_SelectTrayBox
	.public PCBox_HideChangeBoxButtonAndWait
	.public PCBox_JumpToTrayBox
	.public PCBox_ChangeTrayPage
	.public PCBox_OpenBoxTray
	.public PCBox_CloseBoxTray
	.public PCBox_ShowExitButtonAndWait
	.public PCBox_SlideOutReturnButtonAndWait
	.public PCBox_CloseActionMenuAndWait
	.public PCBox_StartBoxMenu
	.public PCBox_SelectBoxMenuBox
	.public PCBox_ChangeBoxMenuPage
	.public PCBox_ChangeWallpaperPage
	.public PCBox_SelectWallpaperInPage
	.public PCBox_ConfirmWallpaperChoice
	.public PCBox_TryWithdraw
	.public PCBox_StartDeposit
	.public PCBox_SelectDepositBox
	.public PCBox_ChangeDepositBoxPage
	.public PCBox_CancelDepositBoxSelect
	.public PCBox_ConfirmDepositBox
	.public PCBox_PickUpTrayMon
	.public PCBox_DropTrayMon
	.public PCBox_SelectItemModeBoxMon
	.public PCBox_StartItemModeBoxDrag
	.public PCBox_StartItemTrayDrag
	.public PCBox_PickUpTrayItem
	.public PCBox_ReturnTrayItem
	.public PCBox_DropTrayItem
	.public PCBox_SelectItemModePartyMon
	.public PCBox_StartItemModePartyDrag
	.public PCBox_HandleBagGiveCommand
	.public PCBox_AllocHeldItemMove
	.public PCBox_FreeHeldItemMove
	.public PCBox_State_BoxTrayHoldingInput
	.public PCBox_State_EndCursorSlideToBoxTrayHolding
	.public PCBox_TakeHeldItemToBag
	.public PCBox_ConfirmRelease
	.public PCBox_PutAwayHeldItem
	.public PCBox_ConfirmExit
	.public PCBox_CancelExit
	.public PCBox_FlashPanel
	.public PCBox_StartCellPaletteFlash
	.public PCBox_FlashMarkingMenuButton
	.public PCBox_FlashPartyPanelButton
	.public PCBox_DimForExitPrompt
	.public PCBox_State_AskExit
	.public PCBox_State_AskContinue
	.public PCBox_State_ChooseParty
	.public PCBox_State_ChooseTrayTab
	.public PCBox_State_ChooseMoveFromBox
	.public PCBox_State_ChooseSummary
	.public PCBox_State_ChooseItem
	.public PCBox_State_ChooseMarking
	.public PCBox_State_ChooseMarkingDone
	.public PCBox_State_ChooseRelease
	.public PCBox_State_CloseMoveModeActionMenu
	.public PCBox_State_PartyChooseTray
	.public PCBox_State_CloseMoveModePartyActionMenu
	.public PCBox_State_ChoosePartyPanelExit
	.public PCBox_State_ChooseTrayBox
	.public PCBox_State_ChooseTrayExit
	.public PCBox_State_BoxMenuSwitchBox
	.public PCBox_State_ChooseWallpaper
	.public PCBox_State_ChooseRename
	.public PCBox_State_SwitchBoxForWallpaper
	.public PCBox_State_ChooseWallpaperMenuExit
	.public PCBox_State_ChooseWithdraw
	.public PCBox_State_CloseWithdrawActionMenu
	.public PCBox_State_ChooseDeposit
	.public PCBox_State_CloseDepositActionMenu
	.public PCBox_State_ItemModeChooseParty
	.public PCBox_State_ItemModeChooseTrayTab
	.public PCBox_State_ChooseBagGive
	.public PCBox_State_CloseItemModeActionMenu
	.public PCBox_State_ItemModeChooseTrayBox
	.public PCBox_State_ItemModePartyChooseTray
	.public PCBox_State_CloseItemModePartyActionMenu
	.public PCBox_InitSprites
	.public PCBox_FreeSprites
	.public PCBox_TickSprites
	.public PCBox_SetSpriteAnim
	.public PCBox_IsSpriteAnimated
	.public PCBox_SetSpriteVisible
	.public PCBox_IsSpriteVisible
	.public PCBox_SetSpritePriority
	.public PCBox_SetSpriteDrawPriority
	.public PCBox_SetSpriteTranslucent
	.public PCBox_InitSpriteSystem
	.public PCBox_FreeSpriteSystem
	.public PCBox_LoadSpriteResources
	.public PCBox_CreateSprites
	.public PCBox_DeleteSprite
	.public PCBox_DeleteAllSprites
	.public PCBox_LoadSpriteCharsMain
	.public PCBox_LoadSpriteCharsSub
	.public PCBox_LoadMonIconResources
	.public PCBox_CreateMonIconSprites
	.public PCBox_LoadMonIconChars
	.public PCBox_LoadBoxIconImages
	.public PCBox_SetIconImage
	.public PCBox_LoadMonIcon
	.public PCBox_RefreshSlotIcon
	.public PCBox_LoadBoxIcons
	.public PCBox_LoadPartyIcons
	.public PCBox_GetSlotPosition
	.public PCBox_PlacePartyIconsLeftHidden
	.public PCBox_PlacePartyIconsRightHidden
	.public PCBox_PlacePartyIconsLeft
	.public PCBox_PlacePartyIconsRight
	.public PCBox_SetIconLayer
	.public PCBox_SetMovingIconPriority
	.public PCBox_ScrollBoxIcons
	.public PCBox_UpdatePartyIconPositions
	.public PCBox_StartReleaseScale
	.public PCBox_UpdateReleaseShrink
	.public PCBox_UpdateReleaseGrow
	.public PCBox_EndReleaseShrink
	.public PCBox_ResetSpriteAffine
	.public PCBox_SetIconRangeTranslucent
	.public PCBox_SetIconsTranslucent
	.public PCBox_SetSlotIconTranslucent
	.public PCBox_UpdateSlotIconItemTranslucency
	.public PCBox_LoadMonPicResources
	.public PCBox_CreateMonPicSprites
	.public PCBox_LoadMonPic
	.public PCBox_ShowMonPic
	.public PCBox_LoadItemIconResources
	.public PCBox_CreateItemIconSprites
	.public PCBox_LoadHeldItemIcon
	.public PCBox_LoadInfoItemIcon
	.public PCBox_SetHeldItemIconAffine
	.public PCBox_SetHeldItemIconPosition
	.public PCBox_MoveHeldItemIconToSlot
	.public PCBox_PlaceHeldItemIconAtSlot
	.public PCBox_CreateHeldItemIconOutline
	.public PCBox_ShowHeldItemIconOutline
	.public PCBox_UpdateHeldItemIconOutline
	.public PCBox_UpdateInfoItemIconPosition
	.public PCBox_LoadTypeIconResources
	.public PCBox_CreateTypeIconSprites
	.public PCBox_LoadTypeIcon
	.public PCBox_DrawTypeIcons
	.public PCBox_LoadUiSpriteResources
	.public PCBox_CreateUiSprites
	.public PCBox_CreateSelectedIconOutline
	.public PCBox_HideSelectedIconOutline
	.public PCBox_SetSelectedIconOutlineVisible
	.public PCBox_UpdateSelectedIconOutline
	.public PCBox_LoadTrayBoxResources
	.public PCBox_CreateTrayBoxSprites
	.public PCBox_LoadWallpaperListResources
	.public PCBox_CreateWallpaperListSprites
	.public PCBox_SetBoxArrowsVisible
	.public PCBox_PlaceWallpaperMenuTextObj
	.public PCBox_SetupWallpaperMenuSprites
	.public PCBox_MoveWallpaperMenuSprites
	.public PCBox_UpdateCurrentWallpaperMarker
	.public PCBox_UpdateWallpaperCursor
	.public PCBox_LoadWallpaperThumbnails
	.public PCBox_ColorWallpaperThumbnail
	.public PCBox_PlaceTrayTextObjs
	.public PCBox_SetupBoxTraySprites
	.public PCBox_MoveBoxTraySprites
	.public PCBox_UpdateCurrentBoxMarker
	.public PCBox_UpdateTrayCursor
	.public PCBox_GetTrayBoxPosition
	.public PCBox_DrawBoxThumbnail
	.public PCBox_DrawAllBoxThumbnails
	.public PCBox_LoadTrayPageThumbnails
	.public PCBox_RefreshTrayBoxThumbnail
	.public PCBox_DrawBoxThumbnailMons
	.public PCBox_PlaceSpriteOnTop
	.public PCBox_SetupDepositBoxSprites
	.public PCBox_HideBoxTraySprites
	.public PCBox_CreateTrayTextObjs
	.public PCBox_DestroyTrayTextObjs
	.public PCBox_CopyWindowToTextObj
	.public PCBox_AddWindows
	.public PCBox_RemoveWindows
	.public PCBox_PrintAligned
	.public PCBox_PrintMsg
	.public PCBox_PrintExpandedMsg
	.public PCBox_PrintSpeciesName
	.public PCBox_PrintNickname
	.public PCBox_PrintLevel
	.public PCBox_PrintGender
	.public PCBox_PrintDexNumber
	.public PCBox_PrintNature
	.public PCBox_PrintAbility
	.public PCBox_PrintHeldItem
	.public PCBox_PrintMonInfo
	.public PCBox_ClearMonInfoWindows
	.public PCBox_DrawMoveWindows
	.public PCBox_PrintItemNameAndDesc
	.public PCBox_PrintModeTitle
	.public PCBox_PrintInfoLabels
	.public PCBox_DrawBoxNameOnWallpaper
	.public PCBox_DrawTrayBoxNameAndCount
	.public PCBox_DrawWallpaperName
	.public PCBox_DrawButtonWindow
	.public PCBox_PrintWindowMessage
	.public PCBox_DrawPartyButton
	.public PCBox_DrawTabWindow
	.public PCBox_DrawTrayTab
	.public PCBox_DrawReturnButton
	.public PCBox_DrawExitButton
	.public PCBox_DrawMenuExitButton
	.public PCBox_DrawActionMenu
	.public PCBox_DrawBagGiveButton
	.public PCBox_DrawChangeBoxButton
	.public PCBox_DrawChangeBoxTitle
	.public PCBox_DrawBoxMenu
	.public PCBox_DrawChangeWallpaperTitle
	.public PCBox_DrawDepositTitle
	.public PCBox_SetPanelWindowFrame
	.public PCBox_AttachWindowToPanel
	.public PCBox_AttachPanelWindows
	.public PCBox_AttachPartyButtonWindow
	.public PCBox_AttachTrayTabWindow
	.public PCBox_AttachReturnButtonWindow
	.public PCBox_AttachMenuExitButtonWindow
	.public PCBox_PrintCenteredLabel
	.public PCBox_DrawConfirmCancel
	.public PCBox_PrintPartyPanelSwitchLabel
	.public PCBox_PrintPartyPanelExitLabel
	.public PCBox_AttachMarkingMenuWindows
	.public PCBox_AttachPartyPanelLabelWindow
	.public PCBox_DrawSummaryButton
	.public PCBox_LoadBoxMessages
	.public PCBox_DrawMessageFrame
	.public PCBox_CloseMessageWindow
	.public PCBox_ClearWindowFrameNoTransfer
	.public PCBox_ClearWindowFrame
	.public PCBox_PrintMessage
	.public PCBox_PrintExitPrompt
	.public PCBox_PrintTakeItemPrompt
	.public PCBox_PrintMailCantBeTaken
	.public PCBox_PrintMailCantBeMoved
	.public PCBox_PrintTookItem
	.public PCBox_PrintBagFull
	.public PCBox_PrintItemHeld
	.public PCBox_PrintTouchTheMark
	.public PCBox_PrintReleaseMessage
	.public PCBox_PrintMenuPrompt
	.public PCBox_PrintMonActionMessage
	.public PCBox_PrintItemActionMessage
	.public PCBox_PrintPanelHint
	.public PCBox_DrawWindowFrame
	.public PCBox_FindTouchedBoxSlot
	.public PCBox_FindTouchedPartySlot
	.public PCBox_FindTouchedTrayPartySlot
	.public PCBox_CreateModeGridInput
	.public PCBox_CreateGridInput
	.public PCBox_FreeGridInput
	.public PCBox_PlaceCursorOnGridInput
	.public PCBox_GridOnButton
	.public PCBox_GridOnSwitchToTouchMode
	.public PCBox_GridOnKeyMove
	.public PCBox_GridOnTouch
	.public PCBox_GetDepositMenuInput
	.public PCBox_DepositGridOnButton
	.public PCBox_DepositBoxGridOnButton
	.public PCBox_DepositBoxGridOnKeyMove
	.public PCBox_DepositBoxGridOnTouch
	.public PCBox_GetWithdrawMenuInput
	.public PCBox_WithdrawGridOnButton
	.public PCBox_WithdrawGridOnTouch
	.public PCBox_GetMoveModeMenuInput
	.public PCBox_MoveModeGridOnButton
	.public PCBox_MoveModeGridOnKeyMove
	.public PCBox_MoveModeGridOnTouch
	.public PCBox_GetBoxTrayInput
	.public PCBox_TrayGridOnButton
	.public PCBox_TrayGridOnKeyMove
	.public PCBox_TrayGridOnTouch
	.public PCBox_GetTrayHoldingInput
	.public PCBox_GetMoveModePartyMenuInput
	.public PCBox_MoveModePartyGridOnButton
	.public PCBox_MoveModePartyGridOnKeyMove
	.public PCBox_GetItemModeMenuInput
	.public PCBox_ItemModeGridOnButton
	.public PCBox_ItemModeGridOnKeyMove
	.public PCBox_ItemModeGridOnTouch
	.public PCBox_GetItemModePartyMenuInput
	.public PCBox_ItemModePartyGridOnButton
	.public PCBox_ItemModePartyGridOnKeyMove
	.public PCBox_BoxMenuGridOnButton
	.public PCBox_BoxMenuGridOnKeyMove
	.public PCBox_BoxMenuGridOnTouch
	.public PCBox_WallpaperGridOnButton
	.public PCBox_WallpaperGridOnKeyMove
	.public PCBox_WallpaperGridOnTouch
	.public PCBox_GetItemTrayHoldingInput
	.public PCBox_StartCursorSlide
	.public PCBox_IsSummaryShortcutPressed
	.public sPCBoxReleaseCheckMoves
	.public gPCBoxGraphicsModes
	.public sPCBoxTrayRects
	.public sPCBoxPartyDropRects
	.public sPCBoxTrayPartyDropRects
	.public sPCBoxBgTemplate0
	.public sPCBoxBgTemplate1
	.public sPCBoxBgTemplate4
	.public sPCBoxBgTemplate2
	.public sPCBoxBgTemplate3
	.public sPCBoxBgTemplate5
	.public sPCBoxBgTemplate6
	.public sPCBoxGfxBanks
	.public sPCBoxSummaryPages
	.public sPCBoxBagPockets
	.public sPCBoxDepositMenu
	.public sPCBoxWithdrawMenu
	.public sPCBoxMoveMenu
	.public sPCBoxSubApps
	.public sPCBoxYesNoHandlers
	.public sPCBoxYesNoNoHandlers
	.public sPCBoxStateTable
	.public sPCBoxTrayCursorX
	.public sPCBoxOutlineOffsetsX
	.public sPCBoxOutlineOffsetsY
	.public sPCBoxThumbnailTiles
	.public sPCBoxPartyIconOffsets
	.public sPCBoxMonPicRect
	.public gPCBoxOamCharTransferParam
	.public sPCBoxPartySlotPositions
	.public ov14_021F80BE
	.public gPCBoxSpriteResourceCounts
	.public gPCBoxOamManagerParam
	.public sPCBoxMonIconSpriteTemplate
	.public sPCBoxTrayBoxSpriteTemplate
	.public sPCBoxWallpaperListSpriteTemplate
	.public sPCBoxUiSprite0Template
	.public sPCBoxUiSprite1Template
	.public sPCBoxMonPicSprite2Template
	.public sPCBoxMonPicSprite3Template
	.public sPCBoxUiSprite4Template
	.public sPCBoxUiSprite5Template
	.public sPCBoxUiSprite6Template
	.public sPCBoxUiSprite7Template
	.public sPCBoxUiSprite8Template
	.public sPCBoxUiSprite9Template
	.public sPCBoxUiSprite10Template
	.public sPCBoxItemIconSpriteTemplate
	.public sPCBoxItemIconSprite12Template
	.public sPCBoxTypeIconSprite13Template
	.public sPCBoxTypeIconSprite14Template
	.public sPCBoxWindowTemplates
	.public sPCBoxPartyHitboxes
	.public sPCBoxTrayPartyHitboxes
	.public sPCBoxSlotHitboxes
	.public sPCBoxSummaryShortcutHitbox
	.public sPCBoxWallpaperGridCallbacks
	.public sPCBoxWithdrawGridCallbacks
	.public sPCBoxDepositGridCallbacks
	.public sPCBoxDepositBoxGridCallbacks
	.public sPCBoxBoxMenuGridCallbacks
	.public sPCBoxMoveModePartyGridCallbacks
	.public sPCBoxTrayGridCallbacks
	.public sPCBoxMoveModeGridCallbacks
	.public sPCBoxMarkingGridCallbacks
	.public sPCBoxItemModePartyGridCallbacks
	.public sPCBoxItemModeGridCallbacks
	.public sPCBoxMarkingGridHitboxes
	.public sPCBoxWallpaperGridHitboxes
	.public sPCBoxItemModePartyGridHitboxes
	.public sPCBoxDepositBoxGridHitboxes
	.public sPCBoxDepositGridHitboxes
	.public sPCBoxBoxMenuGridHitboxes
	.public sPCBoxMoveModePartyGridHitboxes
	.public sPCBoxMarkingGridDpadBoxes
	.public sPCBoxWallpaperGridDpadBoxes
	.public sPCBoxDepositBoxGridDpadBoxes
	.public sPCBoxItemModePartyGridDpadBoxes
	.public sPCBoxBoxMenuGridDpadBoxes
	.public sPCBoxDepositGridDpadBoxes
	.public sPCBoxMoveModePartyGridDpadBoxes
	.public sPCBoxGridLayouts
	.public sPCBoxItemModeGridHitboxes
	.public sPCBoxWithdrawGridHitboxes
	.public sPCBoxMoveModeGridHitboxes
	.public sPCBoxTrayGridHitboxes
	.public sPCBoxItemModeGridDpadBoxes
	.public sPCBoxWithdrawGridDpadBoxes
	.public sPCBoxMoveModeGridDpadBoxes
	.public sPCBoxTrayGridDpadBoxes
	.include "overlay_14.inc"
	.include "global.inc"

	.rodata

sPCBoxSlotGridRect:
	.byte 0x08, 0x9F, 0x28, 0x9F

sPCBoxReleaseCheckMoves: ; 0x021F7BC0
	.byte 0x39, 0x00, 0xAF, 0x01, 0x7F, 0x00, 0x13, 0x00

gPCBoxGraphicsModes: ; 0x021F7BC8
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxTrayRects: ; 0x021F7BD8
	.byte 0x1F, 0x36, 0x0F, 0x26, 0x41, 0x58, 0x0F, 0x26
	.byte 0x63, 0x7A, 0x0F, 0x26, 0x85, 0x9C, 0x0F, 0x26, 0xA7, 0xBE, 0x0F, 0x26, 0xC9, 0xE0, 0x0F, 0x26

sPCBoxPartyDropRects: ; 0x021F7BF0
	.byte 0x1A, 0x39, 0x3A, 0x51, 0x3E, 0x5D, 0x42, 0x59, 0x1A, 0x39, 0x5A, 0x71, 0x3E, 0x5D, 0x62, 0x79
	.byte 0x1A, 0x39, 0x7A, 0x91, 0x3E, 0x5D, 0x82, 0x99

sPCBoxTrayPartyDropRects: ; 0x021F7C08
	.byte 0xB2, 0xD1, 0x3A, 0x51, 0xD6, 0xF5, 0x42, 0x59
	.byte 0xB2, 0xD1, 0x5A, 0x71, 0xD6, 0xF5, 0x62, 0x79, 0xB2, 0xD1, 0x7A, 0x91, 0xD6, 0xF5, 0x82, 0x99

sPCBoxBgTemplate0: ; 0x021F7C20
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1F, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxBgTemplate1: ; 0x021F7C3C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x04
	.byte 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxBgTemplate4: ; 0x021F7C58
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x04, 0x00, 0x01, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sPCBoxBgTemplate2: ; 0x021F7C74
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1D, 0x02, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxBgTemplate3: ; 0x021F7C90
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x1B, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxBgTemplate5: ; 0x021F7CAC
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x00
	.byte 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxBgTemplate6: ; 0x021F7CC8
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1D, 0x06, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sPCBoxGfxBanks: ; 0x021F7CE4
	.byte 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x60, 0x00, 0x00, 0x00

sPCBoxSummaryPages: ; 0x021F7D0C
	.byte 0x00, 0x01, 0x02, 0x03
	.byte 0x04, 0x00, 0x00, 0x00

sPCBoxBagPockets: ; 0x021F7D14
	.byte 0x00, 0x01, 0x02, 0x03, 0x04, 0x06, 0x07, 0xFF

sPCBoxDepositMenu: ; 0x021F7D1C
	.byte 0x46, 0x00, 0x00, 0x00
	.byte 0x41, 0x00, 0x00, 0x00, 0x43, 0x00, 0x00, 0x00, 0x44, 0x00, 0x00, 0x00

sPCBoxWithdrawMenu: ; 0x021F7D2C
	.byte 0x45, 0x00, 0x00, 0x00
	.byte 0x41, 0x00, 0x00, 0x00, 0x43, 0x00, 0x00, 0x00, 0x44, 0x00, 0x00, 0x00

sPCBoxMoveMenu: ; 0x021F7D3C
	.byte 0x3D, 0x00, 0x01, 0x00
	.byte 0x41, 0x00, 0x00, 0x00, 0x42, 0x00, 0x00, 0x00, 0x43, 0x00, 0x00, 0x00, 0x44, 0x00, 0x00, 0x00

sPCBoxSubApps: ; 0x021F7D50
	.word PCBox_StartSummaryApp, PCBox_EndSummaryApp, 0x0000000F
	.word PCBox_StartBagApp, PCBox_EndBagApp, 0x00000011
	.word PCBox_StartNamingScreenApp, PCBox_EndNamingScreenApp, 0x00000010

sPCBoxYesNoHandlers: ; 0x021F7D74
	.word PCBox_TakeHeldItemToBag

sPCBoxYesNoNoHandlers: ; 0x021F7D78
	.word PCBox_State_ReturnToActionMenu
	.word PCBox_ConfirmRelease
	.word PCBox_State_CancelRelease
	.word PCBox_PutAwayHeldItem
	.word PCBox_State_CancelPutAwayItem
	.word PCBox_ConfirmExit
	.word PCBox_CancelExit
	.word PCBox_CancelExit
	.word PCBox_ConfirmExit

sPCBoxStateTable: ; 0x021F7D9C
	.word PCBox_State_Init
	.word PCBox_State_Exit
	.word PCBox_State_WaitFade
	.word PCBox_State_WaitPaletteBuffers
	.word PCBox_State_Delay
	.word PCBox_State_WaitUpdateFunc
	.word PCBox_State_WaitButton
	.word PCBox_State_HandleYesNo
	.word PCBox_State_WaitPaletteFlash
	.word PCBox_State_StartSubApp
	.word PCBox_State_RunSubApp
	.word PCBox_State_Start
	.word PCBox_State_MoveModeInput
	.word PCBox_State_ApplyMonMove
	.word PCBox_State_ReturnToActionMenu
	.word PCBox_State_ReturnFromSummary
	.word PCBox_State_ReturnFromNamingScreen
	.word PCBox_State_GiveItemFromBag
	.word PCBox_State_PrintItemHeld
	.word PCBox_State_MarkingChosen
	.word PCBox_State_OpenMarkingMenu
	.word PCBox_State_SetupMarkingMenuInput
	.word PCBox_State_MarkingMenuInput
	.word PCBox_State_FinishCloseMarkingMenu
	.word PCBox_State_EndCursorSlideToMarkingMenu
	.word PCBox_State_TryRelease
	.word PCBox_State_ReleaseMoveCheck
	.word PCBox_State_PrintReleased
	.word PCBox_State_PrintByeBye
	.word PCBox_State_RemoveReleasedMon
	.word PCBox_State_ReleaseCameBack
	.word PCBox_State_PrintWorried
	.word PCBox_State_CancelRelease
	.word PCBox_State_EndPartyReleaseShift
	.word PCBox_State_OpenPartyPanel
	.word PCBox_State_SetupPartyPanelInput
	.word PCBox_State_MoveModePartyInput
	.word PCBox_State_SlideOutPartyPanel
	.word PCBox_State_PartyPanelClosed
	.word PCBox_State_EndMoveModePartyDrag
	.word PCBox_State_SetupBoxTrayInput
	.word PCBox_State_BoxTrayInput
	.word PCBox_State_EndBoxTrayDrag
	.word PCBox_State_EndTrayHoldingDrop
	.word PCBox_State_ResumeBoxTrayInput
	.word PCBox_State_OpenTrayBesideParty
	.word PCBox_State_SetupPartyInputAfterTray
	.word PCBox_State_OpenTrayFromBox
	.word PCBox_State_SlideInTrayPartyPanel
	.word PCBox_State_SlideOutTray
	.word PCBox_State_TrayClosed
	.word PCBox_State_ReturnToBoxFromTray
	.word PCBox_State_HideButtonsForBoxMenu
	.word PCBox_State_OpenBoxMenuTray
	.word PCBox_State_ShowBoxMenuExitButton
	.word PCBox_State_OpenBoxMenu
	.word PCBox_State_SetupBoxMenuInput
	.word PCBox_State_CloseBoxMenu
	.word PCBox_State_SlideOutBoxMenu
	.word PCBox_State_CloseBoxMenuTray
	.word PCBox_State_BoxMenuClosed
	.word PCBox_State_BoxMenuInput
	.word PCBox_State_EndCursorSlideToBoxMenu
	.word PCBox_State_OpenWallpaperMenu
	.word PCBox_State_ShowWallpaperMenuTitle
	.word PCBox_State_SetupWallpaperMenuInput
	.word PCBox_State_WallpaperMenuInput
	.word PCBox_State_CloseWallpaperMenu
	.word PCBox_State_SlideOutWallpaperList
	.word PCBox_State_ReturnToBoxMenu
	.word PCBox_State_ApplyWallpaper
	.word PCBox_State_WallpaperFadeOut
	.word PCBox_State_WallpaperFadeIn
	.word PCBox_State_EndCursorSlideToWallpaperMenu
	.word PCBox_State_EndCursorSlideToMoveMode
	.word PCBox_State_EndCursorSlideToBoxTray
	.word PCBox_State_EndCursorSlideToMoveModeParty
	.word PCBox_State_ResumeBoxInput
	.word PCBox_State_ResumeMoveModePartyInput
	.word PCBox_State_PrintEggCantHoldItem
	.word PCBox_State_PrintMailCantBeTaken
	.word PCBox_State_WithdrawInput
	.word PCBox_State_ReturnToWithdrawInput
	.word PCBox_State_SlideInWithdrawParty
	.word PCBox_State_StartWithdrawMove
	.word PCBox_State_EndWithdrawMove
	.word PCBox_State_WithdrawPartyClosed
	.word PCBox_State_EndWithdrawDrag
	.word PCBox_State_EndCursorSlideToWithdraw
	.word PCBox_State_EndCursorSlideToWithdrawPrompt
	.word PCBox_State_ResumeWithdrawInput
	.word PCBox_State_DepositInput
	.word PCBox_State_TryDeposit
	.word PCBox_State_ReturnFromDepositError
	.word PCBox_State_ShowDepositBoxSelect
	.word PCBox_State_ShowDepositTitle
	.word PCBox_State_SetupDepositBoxInput
	.word PCBox_State_DepositBoxInput
	.word PCBox_State_CancelDepositBoxSelect
	.word PCBox_State_HideDepositExitButton
	.word PCBox_State_HideDepositBoxSelect
	.word PCBox_State_DepositBoxSelectClosed
	.word PCBox_State_ConfirmDepositBox
	.word PCBox_State_CheckDepositBox
	.word PCBox_State_ShiftPartyForDeposit
	.word PCBox_State_SwitchBox
	.word PCBox_State_StartDepositMove
	.word PCBox_State_EndDepositMove
	.word PCBox_State_ShowDepositReturnButton
	.word PCBox_State_ResetDepositInput
	.word PCBox_State_EndDepositDrag
	.word PCBox_State_EndCursorSlideToDeposit
	.word PCBox_State_EndCursorSlideToDepositPrompt
	.word PCBox_State_EndCursorSlideToDepositBox
	.word PCBox_State_ResumeDepositInput
	.word PCBox_State_BoxTrayHoldingInput
	.word PCBox_State_EndCursorSlideToBoxTrayHolding
	.word PCBox_State_ItemModeInput
	.word PCBox_State_EndCursorSlideToItemMode
	.word PCBox_State_CloseItemMessage
	.word PCBox_State_AskPutAwayItem
	.word PCBox_State_WaitPutAwayItem
	.word PCBox_State_CancelPutAwayItem
	.word PCBox_State_EndItemCommand
	.word PCBox_State_ItemModePrintEggCantHoldItem
	.word PCBox_State_ItemModePrintItemHeld
	.word PCBox_State_EndItemModeBoxDrag
	.word PCBox_State_SwapHeldItems
	.word PCBox_State_DropSwappedItem
	.word PCBox_State_FinishItemSwap
	.word PCBox_State_ItemModeBoxTrayInput
	.word PCBox_State_EndCursorSlideToItemModeTray
	.word PCBox_State_EndItemTrayDrag
	.word PCBox_State_ApplyItemTrayDrop
	.word PCBox_State_FinishItemTrayDrop
	.word PCBox_State_ResumeItemModeTrayInput
	.word PCBox_State_ItemTrayHoldingInput
	.word PCBox_State_EndCursorSlideToItemTrayHolding
	.word PCBox_State_ApplyItemTrayHoldingDrop
	.word PCBox_State_ItemModePartyInput
	.word PCBox_State_EndCursorSlideToItemModeParty
	.word PCBox_State_EndItemModePartyDrag
	.word PCBox_State_SwapPartyHeldItems
	.word PCBox_State_ResumeItemModePartyInput
	.word PCBox_State_DropSwappedPartyItem
	.word PCBox_State_FinishPartyItemSwap
	.word PCBox_State_ResumeItemModePartyAfterMail
	.word PCBox_State_AskExit
	.word PCBox_State_AskContinue
	.word PCBox_State_ChooseParty
	.word PCBox_State_ChooseTrayTab
	.word PCBox_State_ChooseSummary
	.word PCBox_State_ChooseItem
	.word PCBox_State_ChooseMarking
	.word PCBox_State_ChooseMarkingDone
	.word PCBox_State_ChooseRelease
	.word PCBox_State_CloseMoveModeActionMenu
	.word PCBox_State_PartyChooseTray
	.word PCBox_State_CloseMoveModePartyActionMenu
	.word PCBox_State_ChoosePartyPanelExit
	.word PCBox_State_ChooseTrayBox
	.word PCBox_State_ChooseTrayExit
	.word PCBox_State_BoxMenuSwitchBox
	.word PCBox_State_ChooseWallpaper
	.word PCBox_State_ChooseRename
	.word PCBox_State_SwitchBoxForWallpaper
	.word PCBox_State_ChooseWallpaperMenuExit
	.word PCBox_State_ChooseWithdraw
	.word PCBox_State_CloseWithdrawActionMenu
	.word PCBox_State_ChooseDeposit
	.word PCBox_State_CloseDepositActionMenu
	.word PCBox_State_ItemModeChooseParty
	.word PCBox_State_ItemModeChooseTrayTab
	.word PCBox_State_ChooseBagGive
	.word PCBox_State_CloseItemModeActionMenu
	.word PCBox_State_ItemModeChooseTrayBox
	.word PCBox_State_ItemModePartyChooseTray
	.word PCBox_State_CloseItemModePartyActionMenu
	.word PCBox_State_ChooseMoveFromBox

sPCBoxTrayCursorX: ; 0x021F8068
	.byte 0x50, 0x60, 0x70, 0x90, 0xA0, 0xB0, 0x00, 0x00

sPCBoxOutlineOffsetsX: ; 0x021F8070
	.byte 0x01, 0xFF, 0x00, 0x00, 0x01, 0x01, 0xFF, 0xFF

sPCBoxOutlineOffsetsY: ; 0x021F8078
	.byte 0x00, 0x00, 0x01, 0xFF, 0x01, 0xFF, 0x01, 0xFF

sPCBoxThumbnailTiles: ; 0x021F8080
	.byte 0x0E, 0x0F, 0x05, 0x02, 0x0D, 0x0C, 0x06, 0x0B, 0x0A, 0x09, 0x00, 0x00

sPCBoxPartyIconOffsets: ; 0x021F808C
	.byte 0x18, 0x10, 0x40, 0x18
	.byte 0x18, 0x30, 0x40, 0x38, 0x18, 0x50, 0x40, 0x58

sPCBoxMonPicRect: ; 0x021F8098
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x0A, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00

gPCBoxOamCharTransferParam: ; 0x021F80A8
	.byte 0x45, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x00, 0x40, 0x00, 0x00, 0x10, 0x00, 0x10, 0x00, 0x10, 0x00, 0x10, 0x00

sPCBoxPartySlotPositions: ; 0x021F80BC
	.byte 0x28, 0x00

ov14_021F80BE: ; 0x021F80BE
	.byte 0xD0, 0x00
	.byte 0x50, 0x00, 0xD8, 0x00, 0x28, 0x00, 0xF0, 0x00, 0x50, 0x00, 0xF8, 0x00, 0x28, 0x00, 0x10, 0x01
	.byte 0x50, 0x00, 0x18, 0x01

gPCBoxSpriteResourceCounts: ; 0x021F80D4
	.byte 0x35, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00
	.byte 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gPCBoxOamManagerParam: ; 0x021F80EC
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00

sPCBoxMonIconSpriteTemplate: ; 0x021F810C
	.byte 0x18, 0x00, 0x30, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0xF9, 0xC0, 0x00, 0x00, 0xF9, 0xC0, 0x00, 0x00, 0xF9, 0xC0, 0x00, 0x00, 0xF9, 0xC0, 0x00, 0x00
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxTrayBoxSpriteTemplate: ; 0x021F8140
	.byte 0x2B, 0x00, 0xEB, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x23, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFD, 0xC0, 0x00, 0x00
	.byte 0xFD, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sPCBoxWallpaperListSpriteTemplate: ; 0x021F8174
	.byte 0x3B, 0x00, 0xEB, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x29, 0xC1, 0x00, 0x00, 0x00, 0xC1, 0x00, 0x00
	.byte 0xFE, 0xC0, 0x00, 0x00, 0xFE, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite0Template: ; 0x021F81A8
	.byte 0x0C, 0x00, 0x1C, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x2D, 0xC1, 0x00, 0x00
	.byte 0x01, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite1Template: ; 0x021F81DC
	.byte 0x9C, 0x00, 0x1C, 0x00
	.byte 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x2D, 0xC1, 0x00, 0x00, 0x01, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxMonPicSprite2Template: ; 0x021F8210
	.byte 0x8C, 0x00, 0x64, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x1D, 0xC1, 0x00, 0x00, 0xFA, 0xC0, 0x00, 0x00, 0xFA, 0xC0, 0x00, 0x00
	.byte 0xFA, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sPCBoxMonPicSprite3Template: ; 0x021F8244
	.byte 0x8C, 0x00, 0x64, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x1E, 0xC1, 0x00, 0x00, 0xFB, 0xC0, 0x00, 0x00
	.byte 0xFA, 0xC0, 0x00, 0x00, 0xFA, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite4Template: ; 0x021F8278
	.byte 0x0C, 0x00, 0xEB, 0xFF, 0x00, 0x00, 0x01, 0x00
	.byte 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x2D, 0xC1, 0x00, 0x00
	.byte 0x01, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite5Template: ; 0x021F82AC
	.byte 0xF4, 0x00, 0xEB, 0xFF
	.byte 0x00, 0x00, 0x03, 0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x2D, 0xC1, 0x00, 0x00, 0x01, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite6Template: ; 0x021F82E0
	.byte 0x2B, 0x00, 0xEB, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x2D, 0xC1, 0x00, 0x00, 0x01, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00
	.byte 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite7Template: ; 0x021F8314
	.byte 0x80, 0x00, 0xD8, 0xFF, 0x00, 0x00, 0x05, 0x00, 0x05, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x2D, 0xC1, 0x00, 0x00, 0x01, 0xC1, 0x00, 0x00
	.byte 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite8Template: ; 0x021F8348
	.byte 0x80, 0x00, 0xE4, 0xFF, 0x00, 0x00, 0x06, 0x00
	.byte 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x2D, 0xC1, 0x00, 0x00
	.byte 0x01, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite9Template: ; 0x021F837C
	.byte 0x80, 0x00, 0x80, 0x00
	.byte 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x2D, 0xC1, 0x00, 0x00, 0x01, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxUiSprite10Template: ; 0x021F83B0
	.byte 0x80, 0x00, 0xA0, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x2D, 0xC1, 0x00, 0x00, 0x01, 0xC1, 0x00, 0x00, 0xFF, 0xC0, 0x00, 0x00
	.byte 0xFF, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sPCBoxItemIconSpriteTemplate: ; 0x021F83E4
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x1F, 0xC1, 0x00, 0x00, 0xFC, 0xC0, 0x00, 0x00
	.byte 0xFB, 0xC0, 0x00, 0x00, 0xFB, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxItemIconSprite12Template: ; 0x021F8418
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x20, 0xC1, 0x00, 0x00
	.byte 0xFD, 0xC0, 0x00, 0x00, 0xFB, 0xC0, 0x00, 0x00, 0xFB, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxTypeIconSprite13Template: ; 0x021F844C
	.byte 0xA0, 0x00, 0x30, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x21, 0xC1, 0x00, 0x00, 0xFE, 0xC0, 0x00, 0x00, 0xFC, 0xC0, 0x00, 0x00, 0xFC, 0xC0, 0x00, 0x00
	.byte 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sPCBoxTypeIconSprite14Template: ; 0x021F8480
	.byte 0xC2, 0x00, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x22, 0xC1, 0x00, 0x00, 0xFE, 0xC0, 0x00, 0x00, 0xFC, 0xC0, 0x00, 0x00
	.byte 0xFC, 0xC0, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sPCBoxWindowTemplates: ; 0x021F84B4
	.byte 0x04, 0x08, 0x05, 0x08, 0x02, 0x0F, 0x69, 0x00, 0x04, 0x01, 0x07, 0x08
	.byte 0x02, 0x0F, 0x79, 0x00, 0x04, 0x04, 0x09, 0x06, 0x02, 0x0F, 0x89, 0x00, 0x04, 0x01, 0x00, 0x1E
	.byte 0x03, 0x0F, 0x0F, 0x00, 0x04, 0x10, 0x05, 0x02, 0x02, 0x0F, 0x95, 0x00, 0x04, 0x01, 0x05, 0x06
	.byte 0x02, 0x0F, 0x99, 0x00, 0x04, 0x01, 0x0D, 0x08, 0x02, 0x0F, 0xA5, 0x00, 0x04, 0x01, 0x11, 0x0B
	.byte 0x02, 0x0F, 0xB5, 0x00, 0x04, 0x01, 0x15, 0x0C, 0x02, 0x0F, 0xCB, 0x00, 0x06, 0x01, 0x01, 0x0B
	.byte 0x02, 0x01, 0xEA, 0x03, 0x06, 0x01, 0x03, 0x0B, 0x02, 0x01, 0xD4, 0x03, 0x06, 0x01, 0x05, 0x0B
	.byte 0x02, 0x01, 0xBE, 0x03, 0x06, 0x01, 0x07, 0x0B, 0x02, 0x01, 0xA8, 0x03, 0x06, 0x01, 0x01, 0x0B
	.byte 0x02, 0x01, 0x92, 0x03, 0x06, 0x01, 0x03, 0x0B, 0x02, 0x01, 0x7C, 0x03, 0x06, 0x01, 0x05, 0x0B
	.byte 0x02, 0x01, 0x66, 0x03, 0x06, 0x01, 0x07, 0x0B, 0x02, 0x01, 0x50, 0x03, 0x04, 0x01, 0x0B, 0x08
	.byte 0x02, 0x0F, 0xE3, 0x00, 0x04, 0x01, 0x0F, 0x0B, 0x02, 0x0F, 0xF3, 0x00, 0x04, 0x01, 0x13, 0x0C
	.byte 0x02, 0x0F, 0x09, 0x01, 0x06, 0x01, 0x01, 0x0C, 0x02, 0x01, 0xE8, 0x03, 0x06, 0x04, 0x03, 0x1B
	.byte 0x06, 0x01, 0x2E, 0x03, 0x06, 0x01, 0x01, 0x0C, 0x02, 0x01, 0xD0, 0x03, 0x06, 0x04, 0x03, 0x1B
	.byte 0x06, 0x01, 0x8C, 0x02, 0x01, 0x00, 0x00, 0x0B, 0x03, 0x0C, 0xC7, 0x03, 0x01, 0x00, 0x00, 0x0B
	.byte 0x03, 0x02, 0xA6, 0x03, 0x01, 0x00, 0x00, 0x08, 0x03, 0x0C, 0x8E, 0x03, 0x01, 0x00, 0x00, 0x08
	.byte 0x03, 0x0C, 0x8E, 0x03, 0x01, 0x00, 0x00, 0x08, 0x03, 0x0C, 0x76, 0x03, 0x00, 0x00, 0x00, 0x0B
	.byte 0x03, 0x0C, 0x6D, 0x03, 0x00, 0x00, 0x00, 0x0B, 0x03, 0x0C, 0x4C, 0x03, 0x00, 0x00, 0x00, 0x0B
	.byte 0x03, 0x0C, 0x2B, 0x03, 0x00, 0x00, 0x00, 0x0B, 0x03, 0x0C, 0x0A, 0x03, 0x00, 0x00, 0x00, 0x0B
	.byte 0x03, 0x0C, 0xE9, 0x02, 0x00, 0x02, 0x0B, 0x07, 0x02, 0x01, 0x80, 0x03, 0x00, 0x02, 0x0F, 0x07
	.byte 0x02, 0x01, 0x72, 0x03, 0x01, 0x02, 0x0F, 0x07, 0x02, 0x01, 0x68, 0x03, 0x00, 0x02, 0x15, 0x1B
	.byte 0x02, 0x0B, 0xB3, 0x02, 0x00, 0x02, 0x01, 0x1B, 0x02, 0x0B, 0xB3, 0x02, 0x00, 0x02, 0x15, 0x13
	.byte 0x02, 0x0B, 0xB3, 0x02, 0x00, 0x02, 0x15, 0x1B, 0x02, 0x0B, 0x7D, 0x02, 0x00, 0x16, 0x10, 0x09
	.byte 0x04, 0x0C, 0x59, 0x02, 0x01, 0x00, 0x00, 0x11, 0x03, 0x0C, 0x35, 0x03, 0x01, 0x00, 0x00, 0x11
	.byte 0x03, 0x02, 0x02, 0x03

sPCBoxPartyHitboxes: ; 0x021F8614
	.byte 0x38, 0x4F, 0x1E, 0x35, 0x40, 0x57, 0x42, 0x59, 0x58, 0x6F, 0x1E, 0x35
	.byte 0x60, 0x77, 0x42, 0x59, 0x78, 0x8F, 0x1E, 0x35, 0x80, 0x97, 0x42, 0x59, 0xFF, 0x00, 0x00, 0x00

sPCBoxTrayPartyHitboxes: ; 0x021F8630
	.byte 0x38, 0x4F, 0xB6, 0xCD, 0x40, 0x57, 0xDA, 0xF1, 0x58, 0x6F, 0xB6, 0xCD, 0x60, 0x77, 0xDA, 0xF1
	.byte 0x78, 0x8F, 0xB6, 0xCD, 0x80, 0x97, 0xDA, 0xF1, 0xFF, 0x00, 0x00, 0x00

sPCBoxSlotHitboxes: ; 0x021F864C
	.byte 0x28, 0x3F, 0x0C, 0x23
	.byte 0x28, 0x3F, 0x24, 0x3B, 0x28, 0x3F, 0x3C, 0x53, 0x28, 0x3F, 0x54, 0x6B, 0x28, 0x3F, 0x6C, 0x83
	.byte 0x28, 0x3F, 0x84, 0x9B, 0x40, 0x57, 0x0C, 0x23, 0x40, 0x57, 0x24, 0x3B, 0x40, 0x57, 0x3C, 0x53
	.byte 0x40, 0x57, 0x54, 0x6B, 0x40, 0x57, 0x6C, 0x83, 0x40, 0x57, 0x84, 0x9B, 0x58, 0x6F, 0x0C, 0x23
	.byte 0x58, 0x6F, 0x24, 0x3B, 0x58, 0x6F, 0x3C, 0x53, 0x58, 0x6F, 0x54, 0x6B, 0x58, 0x6F, 0x6C, 0x83
	.byte 0x58, 0x6F, 0x84, 0x9B, 0x70, 0x87, 0x0C, 0x23, 0x70, 0x87, 0x24, 0x3B, 0x70, 0x87, 0x3C, 0x53
	.byte 0x70, 0x87, 0x54, 0x6B, 0x70, 0x87, 0x6C, 0x83, 0x70, 0x87, 0x84, 0x9B, 0x88, 0x9F, 0x0C, 0x23
	.byte 0x88, 0x9F, 0x24, 0x3B, 0x88, 0x9F, 0x3C, 0x53, 0x88, 0x9F, 0x54, 0x6B, 0x88, 0x9F, 0x6C, 0x83
	.byte 0x88, 0x9F, 0x84, 0x9B, 0xFF, 0x00, 0x00, 0x00

sPCBoxSummaryShortcutHitbox: ; 0x021F86C8
	.byte 0xA8, 0xBF, 0x00, 0x87

sPCBoxWallpaperGridCallbacks:
	.word PCBox_WallpaperGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_WallpaperGridOnKeyMove
	.word PCBox_WallpaperGridOnTouch

sPCBoxWithdrawGridCallbacks:
	.word PCBox_WithdrawGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_GridOnKeyMove
	.word PCBox_WithdrawGridOnTouch

sPCBoxDepositGridCallbacks:
	.word PCBox_DepositGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_GridOnKeyMove
	.word PCBox_GridOnTouch

sPCBoxDepositBoxGridCallbacks:
	.word PCBox_DepositBoxGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_DepositBoxGridOnKeyMove
	.word PCBox_DepositBoxGridOnTouch

sPCBoxBoxMenuGridCallbacks:
	.word PCBox_BoxMenuGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_BoxMenuGridOnKeyMove
	.word PCBox_BoxMenuGridOnTouch

sPCBoxMoveModePartyGridCallbacks:
	.word PCBox_MoveModePartyGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_MoveModePartyGridOnKeyMove
	.word PCBox_GridOnTouch

sPCBoxTrayGridCallbacks:
	.word PCBox_TrayGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_TrayGridOnKeyMove
	.word PCBox_TrayGridOnTouch

sPCBoxMoveModeGridCallbacks:
	.word PCBox_MoveModeGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_MoveModeGridOnKeyMove
	.word PCBox_MoveModeGridOnTouch

sPCBoxMarkingGridCallbacks:
	.word PCBox_GridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_GridOnKeyMove
	.word PCBox_GridOnTouch

sPCBoxItemModePartyGridCallbacks:
	.word PCBox_ItemModePartyGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_ItemModePartyGridOnKeyMove
	.word PCBox_GridOnTouch

sPCBoxItemModeGridCallbacks:
	.word PCBox_ItemModeGridOnButton
	.word PCBox_GridOnSwitchToTouchMode
	.word PCBox_ItemModeGridOnKeyMove
	.word PCBox_ItemModeGridOnTouch

sPCBoxMarkingGridHitboxes:
	.byte 0x3C, 0x4B, 0xBC, 0xCB
	.byte 0x3C, 0x4B, 0xDC, 0xEB, 0x54, 0x63, 0xBC, 0xCB, 0x54, 0x63, 0xDC, 0xEB, 0x6C, 0x7B, 0xBC, 0xCB
	.byte 0x6C, 0x7B, 0xDC, 0xEB, 0x82, 0x9D, 0xB2, 0xF5, 0xA2, 0xBD, 0xB2, 0xF5, 0xFF, 0x00, 0x00, 0x00

sPCBoxWallpaperGridHitboxes:
	.byte 0x17, 0x2E, 0x2F, 0x46, 0x17, 0x2E, 0x5D, 0x74, 0x17, 0x2E, 0x8B, 0xA2, 0x17, 0x2E, 0xB9, 0xD0
	.byte 0x17, 0x2E, 0x02, 0x17, 0x17, 0x2E, 0xE8, 0xFD, 0x70, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF
	.byte 0xFF, 0x00, 0x00, 0x00

sPCBoxItemModePartyGridHitboxes:
	.byte 0x38, 0x4F, 0x1E, 0x35, 0x40, 0x57, 0x42, 0x59, 0x58, 0x6F, 0x1E, 0x35
	.byte 0x60, 0x77, 0x42, 0x59, 0x78, 0x8F, 0x1E, 0x35, 0x80, 0x97, 0x42, 0x59, 0xA2, 0xBD, 0x1A, 0x5D
	.byte 0xA8, 0xBF, 0xC0, 0xFF, 0x88, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF, 0xFF, 0x00, 0x00, 0x00

sPCBoxDepositBoxGridHitboxes:
	.byte 0x47, 0x5E, 0x1F, 0x36, 0x47, 0x5E, 0x41, 0x58, 0x47, 0x5E, 0x63, 0x7A, 0x47, 0x5E, 0x85, 0x9C
	.byte 0x47, 0x5E, 0xA7, 0xBE, 0x47, 0x5E, 0xC9, 0xE0, 0x47, 0x5E, 0x01, 0x16, 0x47, 0x5E, 0xE9, 0xFE
	.byte 0x70, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF, 0xFF, 0x00, 0x00, 0x00

sPCBoxDepositGridHitboxes:
	.byte 0x38, 0x4F, 0x1E, 0x35
	.byte 0x40, 0x57, 0x42, 0x59, 0x58, 0x6F, 0x1E, 0x35, 0x60, 0x77, 0x42, 0x59, 0x78, 0x8F, 0x1E, 0x35
	.byte 0x80, 0x97, 0x42, 0x59, 0xA8, 0xBF, 0xC0, 0xFF, 0x40, 0x57, 0xA8, 0xFF, 0x58, 0x6F, 0xA8, 0xFF
	.byte 0x70, 0x87, 0xA8, 0xFF, 0x88, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF, 0xFF, 0x00, 0x00, 0x00

sPCBoxBoxMenuGridHitboxes:
	.byte 0x0F, 0x26, 0x1F, 0x36, 0x0F, 0x26, 0x41, 0x58, 0x0F, 0x26, 0x63, 0x7A, 0x0F, 0x26, 0x85, 0x9C
	.byte 0x0F, 0x26, 0xA7, 0xBE, 0x0F, 0x26, 0xC9, 0xE0, 0x0F, 0x26, 0x01, 0x16, 0x0F, 0x26, 0xE9, 0xFE
	.byte 0x40, 0x6F, 0xA8, 0xFF, 0x70, 0x87, 0xA8, 0xFF, 0x88, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF
	.byte 0xFF, 0x00, 0x00, 0x00

sPCBoxMoveModePartyGridHitboxes:
	.byte 0x38, 0x4F, 0x1E, 0x35, 0x40, 0x57, 0x42, 0x59, 0x58, 0x6F, 0x1E, 0x35
	.byte 0x60, 0x77, 0x42, 0x59, 0x78, 0x8F, 0x1E, 0x35, 0x80, 0x97, 0x42, 0x59, 0xA2, 0xBD, 0x1A, 0x5D
	.byte 0xA8, 0xBF, 0xC0, 0xFF, 0x28, 0x3F, 0xA8, 0xFF, 0x40, 0x57, 0xA8, 0xFF, 0x58, 0x6F, 0xA8, 0xFF
	.byte 0x70, 0x87, 0xA8, 0xFF, 0x88, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF, 0xFF, 0x00, 0x00, 0x00

sPCBoxMarkingGridDpadBoxes:
	.byte 0xCC, 0x38, 0x00, 0x00, 0x00, 0x02, 0x00, 0x01, 0xEC, 0x38, 0x00, 0x00, 0x01, 0x03, 0x00, 0x01
	.byte 0xCC, 0x50, 0x00, 0x00, 0x00, 0x04, 0x02, 0x03, 0xEC, 0x50, 0x00, 0x00, 0x01, 0x05, 0x02, 0x03
	.byte 0xCC, 0x68, 0x00, 0x00, 0x02, 0x06, 0x04, 0x05, 0xEC, 0x68, 0x00, 0x00, 0x03, 0x06, 0x04, 0x05
	.byte 0xD4, 0x82, 0x00, 0x00, 0x84, 0x07, 0x06, 0x06, 0xD4, 0xA2, 0x00, 0x00, 0x06, 0x07, 0x07, 0x07

sPCBoxWallpaperGridDpadBoxes:
	.byte 0x3B, 0x1F, 0x00, 0x00, 0x00, 0x06, 0x03, 0x01, 0x69, 0x1F, 0x00, 0x00, 0x01, 0x06, 0x00, 0x02
	.byte 0x97, 0x1F, 0x00, 0x00, 0x02, 0x06, 0x01, 0x03, 0xC5, 0x1F, 0x00, 0x00, 0x03, 0x06, 0x02, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x04, 0x04, 0x04, 0x04, 0x00, 0x00, 0x00, 0x00, 0x05, 0x05, 0x05, 0x05
	.byte 0xD4, 0x70, 0x00, 0x00, 0x00, 0x07, 0x06, 0x06, 0xE0, 0xA8, 0x00, 0x00, 0x06, 0x07, 0x07, 0x07

sPCBoxDepositBoxGridDpadBoxes:
	.byte 0x2B, 0x53, 0x00, 0x00, 0x00, 0x08, 0x05, 0x01, 0x4D, 0x53, 0x00, 0x00, 0x01, 0x08, 0x00, 0x02
	.byte 0x6F, 0x53, 0x00, 0x00, 0x02, 0x08, 0x01, 0x03, 0x91, 0x53, 0x00, 0x00, 0x03, 0x08, 0x02, 0x04
	.byte 0xB3, 0x53, 0x00, 0x00, 0x04, 0x08, 0x03, 0x05, 0xD5, 0x53, 0x00, 0x00, 0x05, 0x08, 0x04, 0x00
	.byte 0x0C, 0x53, 0x00, 0x00, 0x06, 0x06, 0x06, 0x06, 0xF4, 0x53, 0x00, 0x00, 0x07, 0x07, 0x07, 0x07
	.byte 0xD4, 0x70, 0x00, 0x00, 0x00, 0x09, 0x08, 0x08, 0xE0, 0xA8, 0x00, 0x00, 0x08, 0x09, 0x09, 0x09

sPCBoxItemModePartyGridDpadBoxes:
	.byte 0x28, 0x34, 0x00, 0x00, 0x04, 0x02, 0x00, 0x01, 0x50, 0x3C, 0x00, 0x00, 0x05, 0x03, 0x00, 0x02
	.byte 0x28, 0x54, 0x00, 0x00, 0x00, 0x04, 0x01, 0x03, 0x50, 0x5C, 0x00, 0x00, 0x01, 0x05, 0x02, 0x04
	.byte 0x28, 0x74, 0x00, 0x00, 0x02, 0x06, 0x03, 0x05, 0x50, 0x7C, 0x00, 0x00, 0x03, 0x06, 0x04, 0x06
	.byte 0x3C, 0xA2, 0x00, 0x00, 0x85, 0x07, 0x05, 0x07, 0xE0, 0xA8, 0x00, 0x00, 0x06, 0x07, 0x06, 0x07
	.byte 0xD4, 0x88, 0x00, 0x00, 0x09, 0x09, 0x08, 0x08, 0xE0, 0xA8, 0x00, 0x00, 0x08, 0x08, 0x09, 0x09

sPCBoxBoxMenuGridDpadBoxes:
	.byte 0x2B, 0x17, 0x00, 0x00, 0x00, 0x08, 0x05, 0x01, 0x4D, 0x17, 0x00, 0x00, 0x01, 0x08, 0x00, 0x02
	.byte 0x6F, 0x17, 0x00, 0x00, 0x02, 0x08, 0x01, 0x03, 0x91, 0x17, 0x00, 0x00, 0x03, 0x08, 0x02, 0x04
	.byte 0xB3, 0x17, 0x00, 0x00, 0x04, 0x08, 0x03, 0x05, 0xD5, 0x17, 0x00, 0x00, 0x05, 0x08, 0x04, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x06, 0x06, 0x06, 0x06, 0x00, 0x00, 0x00, 0x00, 0x07, 0x07, 0x07, 0x07
	.byte 0xD4, 0x40, 0x00, 0x00, 0x00, 0x09, 0x08, 0x08, 0xD4, 0x70, 0x00, 0x00, 0x08, 0x0A, 0x09, 0x09
	.byte 0xD4, 0x88, 0x00, 0x00, 0x09, 0x0B, 0x0A, 0x0A, 0xE0, 0xA8, 0x00, 0x00, 0x0A, 0x0B, 0x0B, 0x0B

sPCBoxDepositGridDpadBoxes:
	.byte 0x28, 0x34, 0x00, 0x00, 0x06, 0x02, 0x00, 0x01, 0x50, 0x3C, 0x00, 0x00, 0x06, 0x03, 0x00, 0x02
	.byte 0x28, 0x54, 0x00, 0x00, 0x00, 0x04, 0x01, 0x03, 0x50, 0x5C, 0x00, 0x00, 0x01, 0x05, 0x02, 0x04
	.byte 0x28, 0x74, 0x00, 0x00, 0x02, 0x06, 0x03, 0x05, 0x50, 0x7C, 0x00, 0x00, 0x03, 0x06, 0x04, 0x06
	.byte 0xE0, 0xA8, 0x00, 0x00, 0x85, 0x00, 0x05, 0x06, 0xD4, 0x40, 0x00, 0x00, 0x0B, 0x08, 0x07, 0x07
	.byte 0xD4, 0x58, 0x00, 0x00, 0x07, 0x09, 0x08, 0x08, 0xD4, 0x70, 0x00, 0x00, 0x08, 0x0A, 0x09, 0x09
	.byte 0xD4, 0x88, 0x00, 0x00, 0x09, 0x0B, 0x0A, 0x0A, 0xE0, 0xA8, 0x00, 0x00, 0x0A, 0x07, 0x0B, 0x0B

sPCBoxMoveModePartyGridDpadBoxes:
	.byte 0x28, 0x34, 0x00, 0x00, 0x07, 0x02, 0x00, 0x01, 0x50, 0x3C, 0x00, 0x00, 0x07, 0x03, 0x00, 0x02
	.byte 0x28, 0x54, 0x00, 0x00, 0x00, 0x04, 0x01, 0x03, 0x50, 0x5C, 0x00, 0x00, 0x01, 0x05, 0x02, 0x04
	.byte 0x28, 0x74, 0x00, 0x00, 0x02, 0x06, 0x03, 0x05, 0x50, 0x7C, 0x00, 0x00, 0x03, 0x06, 0x04, 0x06
	.byte 0x3C, 0xA2, 0x00, 0x00, 0x85, 0x07, 0x05, 0x07, 0xE0, 0xA8, 0x00, 0x00, 0x06, 0x00, 0x06, 0x07
	.byte 0xD4, 0x28, 0x00, 0x00, 0x0D, 0x09, 0x08, 0x08, 0xD4, 0x40, 0x00, 0x00, 0x08, 0x0A, 0x09, 0x09
	.byte 0xD4, 0x58, 0x00, 0x00, 0x09, 0x0B, 0x0A, 0x0A, 0xD4, 0x70, 0x00, 0x00, 0x0A, 0x0C, 0x0B, 0x0B
	.byte 0xD4, 0x88, 0x00, 0x00, 0x0B, 0x0D, 0x0C, 0x0C, 0xE0, 0xA8, 0x00, 0x00, 0x0C, 0x08, 0x0D, 0x0D

sPCBoxGridLayouts: ; 0x021F8B10
	.word sPCBoxDepositGridHitboxes, sPCBoxDepositGridDpadBoxes, sPCBoxDepositGridCallbacks
	.word sPCBoxDepositBoxGridHitboxes, sPCBoxDepositBoxGridDpadBoxes, sPCBoxDepositBoxGridCallbacks
	.word sPCBoxWithdrawGridHitboxes, sPCBoxWithdrawGridDpadBoxes, sPCBoxWithdrawGridCallbacks
	.word sPCBoxMoveModeGridHitboxes, sPCBoxMoveModeGridDpadBoxes, sPCBoxMoveModeGridCallbacks
	.word sPCBoxTrayGridHitboxes, sPCBoxTrayGridDpadBoxes, sPCBoxTrayGridCallbacks
	.word sPCBoxMoveModePartyGridHitboxes, sPCBoxMoveModePartyGridDpadBoxes, sPCBoxMoveModePartyGridCallbacks
	.word sPCBoxItemModeGridHitboxes, sPCBoxItemModeGridDpadBoxes, sPCBoxItemModeGridCallbacks
	.word sPCBoxItemModePartyGridHitboxes, sPCBoxItemModePartyGridDpadBoxes, sPCBoxItemModePartyGridCallbacks
	.word sPCBoxMarkingGridHitboxes, sPCBoxMarkingGridDpadBoxes, sPCBoxMarkingGridCallbacks
	.word sPCBoxBoxMenuGridHitboxes, sPCBoxBoxMenuGridDpadBoxes, sPCBoxBoxMenuGridCallbacks
	.word sPCBoxWallpaperGridHitboxes, sPCBoxWallpaperGridDpadBoxes, sPCBoxWallpaperGridCallbacks

sPCBoxItemModeGridHitboxes:
	.byte 0x28, 0x3F, 0x0C, 0x23, 0x28, 0x3F, 0x24, 0x3B, 0x28, 0x3F, 0x3C, 0x53
	.byte 0x28, 0x3F, 0x54, 0x6B, 0x28, 0x3F, 0x6C, 0x83, 0x28, 0x3F, 0x84, 0x9B, 0x40, 0x57, 0x0C, 0x23
	.byte 0x40, 0x57, 0x24, 0x3B, 0x40, 0x57, 0x3C, 0x53, 0x40, 0x57, 0x54, 0x6B, 0x40, 0x57, 0x6C, 0x83
	.byte 0x40, 0x57, 0x84, 0x9B, 0x58, 0x6F, 0x0C, 0x23, 0x58, 0x6F, 0x24, 0x3B, 0x58, 0x6F, 0x3C, 0x53
	.byte 0x58, 0x6F, 0x54, 0x6B, 0x58, 0x6F, 0x6C, 0x83, 0x58, 0x6F, 0x84, 0x9B, 0x70, 0x87, 0x0C, 0x23
	.byte 0x70, 0x87, 0x24, 0x3B, 0x70, 0x87, 0x3C, 0x53, 0x70, 0x87, 0x54, 0x6B, 0x70, 0x87, 0x6C, 0x83
	.byte 0x70, 0x87, 0x84, 0x9B, 0x88, 0x9F, 0x0C, 0x23, 0x88, 0x9F, 0x24, 0x3B, 0x88, 0x9F, 0x3C, 0x53
	.byte 0x88, 0x9F, 0x54, 0x6B, 0x88, 0x9F, 0x6C, 0x83, 0x88, 0x9F, 0x84, 0x9B, 0x11, 0x27, 0x1A, 0x8D
	.byte 0x11, 0x26, 0x01, 0x16, 0x11, 0x26, 0x91, 0xA6, 0xA8, 0xBF, 0x00, 0x57, 0xA8, 0xBF, 0x60, 0xB7
	.byte 0xA8, 0xBF, 0xC0, 0xFF, 0x88, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF, 0xFF, 0x00, 0x00, 0x00

sPCBoxWithdrawGridHitboxes:
	.byte 0x28, 0x3F, 0x0C, 0x23, 0x28, 0x3F, 0x24, 0x3B, 0x28, 0x3F, 0x3C, 0x53, 0x28, 0x3F, 0x54, 0x6B
	.byte 0x28, 0x3F, 0x6C, 0x83, 0x28, 0x3F, 0x84, 0x9B, 0x40, 0x57, 0x0C, 0x23, 0x40, 0x57, 0x24, 0x3B
	.byte 0x40, 0x57, 0x3C, 0x53, 0x40, 0x57, 0x54, 0x6B, 0x40, 0x57, 0x6C, 0x83, 0x40, 0x57, 0x84, 0x9B
	.byte 0x58, 0x6F, 0x0C, 0x23, 0x58, 0x6F, 0x24, 0x3B, 0x58, 0x6F, 0x3C, 0x53, 0x58, 0x6F, 0x54, 0x6B
	.byte 0x58, 0x6F, 0x6C, 0x83, 0x58, 0x6F, 0x84, 0x9B, 0x70, 0x87, 0x0C, 0x23, 0x70, 0x87, 0x24, 0x3B
	.byte 0x70, 0x87, 0x3C, 0x53, 0x70, 0x87, 0x54, 0x6B, 0x70, 0x87, 0x6C, 0x83, 0x70, 0x87, 0x84, 0x9B
	.byte 0x88, 0x9F, 0x0C, 0x23, 0x88, 0x9F, 0x24, 0x3B, 0x88, 0x9F, 0x3C, 0x53, 0x88, 0x9F, 0x54, 0x6B
	.byte 0x88, 0x9F, 0x6C, 0x83, 0x88, 0x9F, 0x84, 0x9B, 0x11, 0x27, 0x1A, 0x8D, 0x11, 0x26, 0x01, 0x16
	.byte 0x11, 0x26, 0x91, 0xA6, 0xA8, 0xBF, 0xC0, 0xFF, 0x40, 0x57, 0xA8, 0xFF, 0x58, 0x6F, 0xA8, 0xFF
	.byte 0x70, 0x87, 0xA8, 0xFF, 0x88, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF, 0xFF, 0x00, 0x00, 0x00

sPCBoxMoveModeGridHitboxes:
	.byte 0x28, 0x3F, 0x0C, 0x23, 0x28, 0x3F, 0x24, 0x3B, 0x28, 0x3F, 0x3C, 0x53, 0x28, 0x3F, 0x54, 0x6B
	.byte 0x28, 0x3F, 0x6C, 0x83, 0x28, 0x3F, 0x84, 0x9B, 0x40, 0x57, 0x0C, 0x23, 0x40, 0x57, 0x24, 0x3B
	.byte 0x40, 0x57, 0x3C, 0x53, 0x40, 0x57, 0x54, 0x6B, 0x40, 0x57, 0x6C, 0x83, 0x40, 0x57, 0x84, 0x9B
	.byte 0x58, 0x6F, 0x0C, 0x23, 0x58, 0x6F, 0x24, 0x3B, 0x58, 0x6F, 0x3C, 0x53, 0x58, 0x6F, 0x54, 0x6B
	.byte 0x58, 0x6F, 0x6C, 0x83, 0x58, 0x6F, 0x84, 0x9B, 0x70, 0x87, 0x0C, 0x23, 0x70, 0x87, 0x24, 0x3B
	.byte 0x70, 0x87, 0x3C, 0x53, 0x70, 0x87, 0x54, 0x6B, 0x70, 0x87, 0x6C, 0x83, 0x70, 0x87, 0x84, 0x9B
	.byte 0x88, 0x9F, 0x0C, 0x23, 0x88, 0x9F, 0x24, 0x3B, 0x88, 0x9F, 0x3C, 0x53, 0x88, 0x9F, 0x54, 0x6B
	.byte 0x88, 0x9F, 0x6C, 0x83, 0x88, 0x9F, 0x84, 0x9B, 0x11, 0x27, 0x1A, 0x8D, 0x11, 0x26, 0x01, 0x16
	.byte 0x11, 0x26, 0x91, 0xA6, 0xA8, 0xBF, 0x00, 0x57, 0xA8, 0xBF, 0x60, 0xB7, 0xA8, 0xBF, 0xC0, 0xFF
	.byte 0x28, 0x3F, 0xA8, 0xFF, 0x40, 0x57, 0xA8, 0xFF, 0x58, 0x6F, 0xA8, 0xFF, 0x70, 0x87, 0xA8, 0xFF
	.byte 0x88, 0x9F, 0xA8, 0xFF, 0xA8, 0xBF, 0xC0, 0xFF, 0xFF, 0x00, 0x00, 0x00

sPCBoxTrayGridHitboxes:
	.byte 0x28, 0x3F, 0x0C, 0x23
	.byte 0x28, 0x3F, 0x24, 0x3B, 0x28, 0x3F, 0x3C, 0x53, 0x28, 0x3F, 0x54, 0x6B, 0x28, 0x3F, 0x6C, 0x83
	.byte 0x28, 0x3F, 0x84, 0x9B, 0x40, 0x57, 0x0C, 0x23, 0x40, 0x57, 0x24, 0x3B, 0x40, 0x57, 0x3C, 0x53
	.byte 0x40, 0x57, 0x54, 0x6B, 0x40, 0x57, 0x6C, 0x83, 0x40, 0x57, 0x84, 0x9B, 0x58, 0x6F, 0x0C, 0x23
	.byte 0x58, 0x6F, 0x24, 0x3B, 0x58, 0x6F, 0x3C, 0x53, 0x58, 0x6F, 0x54, 0x6B, 0x58, 0x6F, 0x6C, 0x83
	.byte 0x58, 0x6F, 0x84, 0x9B, 0x70, 0x87, 0x0C, 0x23, 0x70, 0x87, 0x24, 0x3B, 0x70, 0x87, 0x3C, 0x53
	.byte 0x70, 0x87, 0x54, 0x6B, 0x70, 0x87, 0x6C, 0x83, 0x70, 0x87, 0x84, 0x9B, 0x88, 0x9F, 0x0C, 0x23
	.byte 0x88, 0x9F, 0x24, 0x3B, 0x88, 0x9F, 0x3C, 0x53, 0x88, 0x9F, 0x54, 0x6B, 0x88, 0x9F, 0x6C, 0x83
	.byte 0x88, 0x9F, 0x84, 0x9B, 0x38, 0x4F, 0xB6, 0xCD, 0x40, 0x57, 0xDA, 0xF1, 0x58, 0x6F, 0xB6, 0xCD
	.byte 0x60, 0x77, 0xDA, 0xF1, 0x78, 0x8F, 0xB6, 0xCD, 0x80, 0x97, 0xDA, 0xF1, 0xA2, 0xBD, 0xB2, 0xF5
	.byte 0x0F, 0x26, 0x1F, 0x36, 0x0F, 0x26, 0x41, 0x58, 0x0F, 0x26, 0x63, 0x7A, 0x0F, 0x26, 0x85, 0x9C
	.byte 0x0F, 0x26, 0xA7, 0xBE, 0x0F, 0x26, 0xC9, 0xE0, 0x0F, 0x26, 0x01, 0x16, 0x0F, 0x26, 0xE9, 0xFE
	.byte 0xA8, 0xBF, 0x00, 0x87, 0xFF, 0x00, 0x00, 0x00

sPCBoxItemModeGridDpadBoxes:
	.byte 0x18, 0x24, 0x00, 0x00, 0x1E, 0x06, 0x05, 0x01
	.byte 0x30, 0x24, 0x00, 0x00, 0x1E, 0x07, 0x00, 0x02, 0x48, 0x24, 0x00, 0x00, 0x1E, 0x08, 0x01, 0x03
	.byte 0x60, 0x24, 0x00, 0x00, 0x1E, 0x09, 0x02, 0x04, 0x78, 0x24, 0x00, 0x00, 0x1E, 0x0A, 0x03, 0x05
	.byte 0x90, 0x24, 0x00, 0x00, 0x1E, 0x0B, 0x04, 0x00, 0x18, 0x3C, 0x00, 0x00, 0x00, 0x0C, 0x0B, 0x07
	.byte 0x30, 0x3C, 0x00, 0x00, 0x01, 0x0D, 0x06, 0x08, 0x48, 0x3C, 0x00, 0x00, 0x02, 0x0E, 0x07, 0x09
	.byte 0x60, 0x3C, 0x00, 0x00, 0x03, 0x0F, 0x08, 0x0A, 0x78, 0x3C, 0x00, 0x00, 0x04, 0x10, 0x09, 0x0B
	.byte 0x90, 0x3C, 0x00, 0x00, 0x05, 0x11, 0x0A, 0x06, 0x18, 0x54, 0x00, 0x00, 0x06, 0x12, 0x11, 0x0D
	.byte 0x30, 0x54, 0x00, 0x00, 0x07, 0x13, 0x0C, 0x0E, 0x48, 0x54, 0x00, 0x00, 0x08, 0x14, 0x0D, 0x0F
	.byte 0x60, 0x54, 0x00, 0x00, 0x09, 0x15, 0x0E, 0x10, 0x78, 0x54, 0x00, 0x00, 0x0A, 0x16, 0x0F, 0x11
	.byte 0x90, 0x54, 0x00, 0x00, 0x0B, 0x17, 0x10, 0x0C, 0x18, 0x6C, 0x00, 0x00, 0x0C, 0x18, 0x17, 0x13
	.byte 0x30, 0x6C, 0x00, 0x00, 0x0D, 0x19, 0x12, 0x14, 0x48, 0x6C, 0x00, 0x00, 0x0E, 0x1A, 0x13, 0x15
	.byte 0x60, 0x6C, 0x00, 0x00, 0x0F, 0x1B, 0x14, 0x16, 0x78, 0x6C, 0x00, 0x00, 0x10, 0x1C, 0x15, 0x17
	.byte 0x90, 0x6C, 0x00, 0x00, 0x11, 0x1D, 0x16, 0x12, 0x18, 0x84, 0x00, 0x00, 0x12, 0xA1, 0x1D, 0x19
	.byte 0x30, 0x84, 0x00, 0x00, 0x13, 0xA1, 0x18, 0x1A, 0x48, 0x84, 0x00, 0x00, 0x14, 0xA1, 0x19, 0x1B
	.byte 0x60, 0x84, 0x00, 0x00, 0x15, 0xA1, 0x1A, 0x1C, 0x78, 0x84, 0x00, 0x00, 0x16, 0xA1, 0x1B, 0x1D
	.byte 0x90, 0x84, 0x00, 0x00, 0x17, 0xA1, 0x1C, 0x18, 0x54, 0x10, 0x00, 0x00, 0x21, 0x80, 0x1E, 0x1E
	.byte 0x00, 0x00, 0x00, 0x00, 0x1F, 0x1F, 0x1F, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x20, 0x20
	.byte 0x2C, 0xA8, 0x00, 0x00, 0x98, 0x1E, 0x21, 0x22, 0x8C, 0xA8, 0x00, 0x00, 0x98, 0x1E, 0x21, 0x23
	.byte 0xE0, 0xA8, 0x00, 0x00, 0x98, 0x1E, 0x22, 0x23, 0xD4, 0x88, 0x00, 0x00, 0x25, 0x25, 0x24, 0x24
	.byte 0xE0, 0xA8, 0x00, 0x00, 0x24, 0x24, 0x25, 0x25

sPCBoxWithdrawGridDpadBoxes:
	.byte 0x18, 0x24, 0x00, 0x00, 0x1E, 0x06, 0x05, 0x01
	.byte 0x30, 0x24, 0x00, 0x00, 0x1E, 0x07, 0x00, 0x02, 0x48, 0x24, 0x00, 0x00, 0x1E, 0x08, 0x01, 0x03
	.byte 0x60, 0x24, 0x00, 0x00, 0x1E, 0x09, 0x02, 0x04, 0x78, 0x24, 0x00, 0x00, 0x1E, 0x0A, 0x03, 0x05
	.byte 0x90, 0x24, 0x00, 0x00, 0x1E, 0x0B, 0x04, 0x00, 0x18, 0x3C, 0x00, 0x00, 0x00, 0x0C, 0x0B, 0x07
	.byte 0x30, 0x3C, 0x00, 0x00, 0x01, 0x0D, 0x06, 0x08, 0x48, 0x3C, 0x00, 0x00, 0x02, 0x0E, 0x07, 0x09
	.byte 0x60, 0x3C, 0x00, 0x00, 0x03, 0x0F, 0x08, 0x0A, 0x78, 0x3C, 0x00, 0x00, 0x04, 0x10, 0x09, 0x0B
	.byte 0x90, 0x3C, 0x00, 0x00, 0x05, 0x11, 0x0A, 0x06, 0x18, 0x54, 0x00, 0x00, 0x06, 0x12, 0x11, 0x0D
	.byte 0x30, 0x54, 0x00, 0x00, 0x07, 0x13, 0x0C, 0x0E, 0x48, 0x54, 0x00, 0x00, 0x08, 0x14, 0x0D, 0x0F
	.byte 0x60, 0x54, 0x00, 0x00, 0x09, 0x15, 0x0E, 0x10, 0x78, 0x54, 0x00, 0x00, 0x0A, 0x16, 0x0F, 0x11
	.byte 0x90, 0x54, 0x00, 0x00, 0x0B, 0x17, 0x10, 0x0C, 0x18, 0x6C, 0x00, 0x00, 0x0C, 0x18, 0x17, 0x13
	.byte 0x30, 0x6C, 0x00, 0x00, 0x0D, 0x19, 0x12, 0x14, 0x48, 0x6C, 0x00, 0x00, 0x0E, 0x1A, 0x13, 0x15
	.byte 0x60, 0x6C, 0x00, 0x00, 0x0F, 0x1B, 0x14, 0x16, 0x78, 0x6C, 0x00, 0x00, 0x10, 0x1C, 0x15, 0x17
	.byte 0x90, 0x6C, 0x00, 0x00, 0x11, 0x1D, 0x16, 0x12, 0x18, 0x84, 0x00, 0x00, 0x12, 0x21, 0x1D, 0x19
	.byte 0x30, 0x84, 0x00, 0x00, 0x13, 0x21, 0x18, 0x1A, 0x48, 0x84, 0x00, 0x00, 0x14, 0x21, 0x19, 0x1B
	.byte 0x60, 0x84, 0x00, 0x00, 0x15, 0x21, 0x1A, 0x1C, 0x78, 0x84, 0x00, 0x00, 0x16, 0x21, 0x1B, 0x1D
	.byte 0x90, 0x84, 0x00, 0x00, 0x17, 0x21, 0x1C, 0x18, 0x54, 0x10, 0x00, 0x00, 0x21, 0x80, 0x1E, 0x1E
	.byte 0x00, 0x00, 0x00, 0x00, 0x1F, 0x1F, 0x1F, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x20, 0x20
	.byte 0xE0, 0xA8, 0x00, 0x00, 0x98, 0x1E, 0x21, 0x21, 0xD4, 0x40, 0x00, 0x00, 0x26, 0x23, 0x22, 0x22
	.byte 0xD4, 0x58, 0x00, 0x00, 0x22, 0x24, 0x23, 0x23, 0xD4, 0x70, 0x00, 0x00, 0x23, 0x25, 0x24, 0x24
	.byte 0xD4, 0x88, 0x00, 0x00, 0x24, 0x26, 0x25, 0x25, 0xE0, 0xA8, 0x00, 0x00, 0x25, 0x22, 0x26, 0x26

sPCBoxMoveModeGridDpadBoxes:
	.byte 0x18, 0x24, 0x00, 0x00, 0x1E, 0x06, 0x05, 0x01, 0x30, 0x24, 0x00, 0x00, 0x1E, 0x07, 0x00, 0x02
	.byte 0x48, 0x24, 0x00, 0x00, 0x1E, 0x08, 0x01, 0x03, 0x60, 0x24, 0x00, 0x00, 0x1E, 0x09, 0x02, 0x04
	.byte 0x78, 0x24, 0x00, 0x00, 0x1E, 0x0A, 0x03, 0x05, 0x90, 0x24, 0x00, 0x00, 0x1E, 0x0B, 0x04, 0x00
	.byte 0x18, 0x3C, 0x00, 0x00, 0x00, 0x0C, 0x0B, 0x07, 0x30, 0x3C, 0x00, 0x00, 0x01, 0x0D, 0x06, 0x08
	.byte 0x48, 0x3C, 0x00, 0x00, 0x02, 0x0E, 0x07, 0x09, 0x60, 0x3C, 0x00, 0x00, 0x03, 0x0F, 0x08, 0x0A
	.byte 0x78, 0x3C, 0x00, 0x00, 0x04, 0x10, 0x09, 0x0B, 0x90, 0x3C, 0x00, 0x00, 0x05, 0x11, 0x0A, 0x06
	.byte 0x18, 0x54, 0x00, 0x00, 0x06, 0x12, 0x11, 0x0D, 0x30, 0x54, 0x00, 0x00, 0x07, 0x13, 0x0C, 0x0E
	.byte 0x48, 0x54, 0x00, 0x00, 0x08, 0x14, 0x0D, 0x0F, 0x60, 0x54, 0x00, 0x00, 0x09, 0x15, 0x0E, 0x10
	.byte 0x78, 0x54, 0x00, 0x00, 0x0A, 0x16, 0x0F, 0x11, 0x90, 0x54, 0x00, 0x00, 0x0B, 0x17, 0x10, 0x0C
	.byte 0x18, 0x6C, 0x00, 0x00, 0x0C, 0x18, 0x17, 0x13, 0x30, 0x6C, 0x00, 0x00, 0x0D, 0x19, 0x12, 0x14
	.byte 0x48, 0x6C, 0x00, 0x00, 0x0E, 0x1A, 0x13, 0x15, 0x60, 0x6C, 0x00, 0x00, 0x0F, 0x1B, 0x14, 0x16
	.byte 0x78, 0x6C, 0x00, 0x00, 0x10, 0x1C, 0x15, 0x17, 0x90, 0x6C, 0x00, 0x00, 0x11, 0x1D, 0x16, 0x12
	.byte 0x18, 0x84, 0x00, 0x00, 0x12, 0xA1, 0x1D, 0x19, 0x30, 0x84, 0x00, 0x00, 0x13, 0xA1, 0x18, 0x1A
	.byte 0x48, 0x84, 0x00, 0x00, 0x14, 0xA1, 0x19, 0x1B, 0x60, 0x84, 0x00, 0x00, 0x15, 0xA1, 0x1A, 0x1C
	.byte 0x78, 0x84, 0x00, 0x00, 0x16, 0xA1, 0x1B, 0x1D, 0x90, 0x84, 0x00, 0x00, 0x17, 0xA1, 0x1C, 0x18
	.byte 0x54, 0x10, 0x00, 0x00, 0x21, 0x80, 0x1E, 0x1E, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x1F, 0x1F, 0x1F
	.byte 0x00, 0x00, 0x00, 0x00, 0x20, 0x20, 0x20, 0x20, 0x2C, 0xA8, 0x00, 0x00, 0x98, 0x1E, 0x21, 0x22
	.byte 0x8C, 0xA8, 0x00, 0x00, 0x98, 0x1E, 0x21, 0x23, 0xE0, 0xA8, 0x00, 0x00, 0x98, 0x1E, 0x22, 0x23
	.byte 0xD4, 0x28, 0x00, 0x00, 0x29, 0x25, 0x24, 0x24, 0xD4, 0x40, 0x00, 0x00, 0x24, 0x26, 0x25, 0x25
	.byte 0xD4, 0x58, 0x00, 0x00, 0x25, 0x27, 0x26, 0x26, 0xD4, 0x70, 0x00, 0x00, 0x26, 0x28, 0x27, 0x27
	.byte 0xD4, 0x88, 0x00, 0x00, 0x27, 0x29, 0x28, 0x28, 0xE0, 0xA8, 0x00, 0x00, 0x28, 0x24, 0x29, 0x29
sPCBoxTrayGridDpadBoxes:
	.byte 0x18, 0x24, 0x00, 0x00, 0x25, 0x06, 0x1F, 0x01, 0x30, 0x24, 0x00, 0x00, 0x25, 0x07, 0x00, 0x02
	.byte 0x48, 0x24, 0x00, 0x00, 0x25, 0x08, 0x01, 0x03, 0x60, 0x24, 0x00, 0x00, 0x25, 0x09, 0x02, 0x04
	.byte 0x78, 0x24, 0x00, 0x00, 0x25, 0x0A, 0x03, 0x05, 0x90, 0x24, 0x00, 0x00, 0x25, 0x0B, 0x04, 0x9E
	.byte 0x18, 0x3C, 0x00, 0x00, 0x00, 0x0C, 0x1F, 0x07, 0x30, 0x3C, 0x00, 0x00, 0x01, 0x0D, 0x06, 0x08
	.byte 0x48, 0x3C, 0x00, 0x00, 0x02, 0x0E, 0x07, 0x09, 0x60, 0x3C, 0x00, 0x00, 0x03, 0x0F, 0x08, 0x0A
	.byte 0x78, 0x3C, 0x00, 0x00, 0x04, 0x10, 0x09, 0x0B, 0x90, 0x3C, 0x00, 0x00, 0x05, 0x11, 0x0A, 0x9E
	.byte 0x18, 0x54, 0x00, 0x00, 0x06, 0x12, 0x21, 0x0D, 0x30, 0x54, 0x00, 0x00, 0x07, 0x13, 0x0C, 0x0E
	.byte 0x48, 0x54, 0x00, 0x00, 0x08, 0x14, 0x0D, 0x0F, 0x60, 0x54, 0x00, 0x00, 0x09, 0x15, 0x0E, 0x10
	.byte 0x78, 0x54, 0x00, 0x00, 0x0A, 0x16, 0x0F, 0x11, 0x90, 0x54, 0x00, 0x00, 0x0B, 0x17, 0x10, 0xA0
	.byte 0x18, 0x6C, 0x00, 0x00, 0x0C, 0x18, 0x21, 0x13, 0x30, 0x6C, 0x00, 0x00, 0x0D, 0x19, 0x12, 0x14
	.byte 0x48, 0x6C, 0x00, 0x00, 0x0E, 0x1A, 0x13, 0x15, 0x60, 0x6C, 0x00, 0x00, 0x0F, 0x1B, 0x14, 0x16
	.byte 0x78, 0x6C, 0x00, 0x00, 0x10, 0x1C, 0x15, 0x17, 0x90, 0x6C, 0x00, 0x00, 0x11, 0x1D, 0x16, 0xA2
	.byte 0x18, 0x84, 0x00, 0x00, 0x12, 0x25, 0x23, 0x19, 0x30, 0x84, 0x00, 0x00, 0x13, 0x25, 0x18, 0x1A
	.byte 0x48, 0x84, 0x00, 0x00, 0x14, 0x25, 0x19, 0x1B, 0x60, 0x84, 0x00, 0x00, 0x15, 0x25, 0x1A, 0x1C
	.byte 0x78, 0x84, 0x00, 0x00, 0x16, 0x25, 0x1B, 0x1D, 0x90, 0x84, 0x00, 0x00, 0x17, 0x25, 0x1C, 0xA2
	.byte 0xC0, 0x34, 0x00, 0x00, 0x25, 0x20, 0x85, 0x1F, 0xE8, 0x3C, 0x00, 0x00, 0x25, 0x21, 0x1E, 0x80
	.byte 0xC0, 0x54, 0x00, 0x00, 0x1E, 0x22, 0x91, 0x21, 0xE8, 0x5C, 0x00, 0x00, 0x1F, 0x23, 0x20, 0x8C
	.byte 0xC0, 0x74, 0x00, 0x00, 0x20, 0x24, 0x97, 0x23, 0xE8, 0x7C, 0x00, 0x00, 0x21, 0x24, 0x22, 0x98
	.byte 0xD4, 0xA2, 0x00, 0x00, 0xA3, 0x25, 0x24, 0x24, 0x2B, 0x17, 0x00, 0x00, 0x18, 0x80, 0x2A, 0x26
	.byte 0x4D, 0x17, 0x00, 0x00, 0x18, 0x80, 0x25, 0x27, 0x6F, 0x17, 0x00, 0x00, 0x18, 0x80, 0x26, 0x28
	.byte 0x91, 0x17, 0x00, 0x00, 0x18, 0x80, 0x27, 0x29, 0xB3, 0x17, 0x00, 0x00, 0x18, 0x80, 0x28, 0x2A
	.byte 0xD5, 0x17, 0x00, 0x00, 0x18, 0x80, 0x29, 0x25, 0x00, 0x00, 0x00, 0x00, 0x2B, 0x2B, 0x2B, 0x2B
	.byte 0x00, 0x00, 0x00, 0x00, 0x2C, 0x2C, 0x2C, 0x2C, 0x44, 0xA8, 0x00, 0x00, 0x2D, 0x2D, 0x2D, 0x2D
