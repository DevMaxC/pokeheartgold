#include "constants/abilities.h"
#include "constants/species.h"
#include "constants/sndseq.h"
#include "constants/items.h"
#include "constants/pokemon.h"
#include "constants/std_script.h"
	.include "asm/macros.inc"
	.public CreateFieldEscapeRopeTaskEnv
	.public FieldMoveTask_CreateDigEnvironment
	.public FieldMoveTask_CreateTeleportEnvironment
	.public FieldSystem_FollowMonInteract
	.public FollowMon_ExpandInteractionMessage
	.public FollowMon_PlaceholdersSet
	.public FollowMon_TryPrintInteractionMessage
	.public PlayerStepEvent_RepelCounterDecrement
	.public PokecenterAnimCreate
	.public PokecenterAnimRun
	.public SafariDecoration_CreateArgs
	.public Task_FieldDig
	.public Task_FieldEscapeRope
	.public Task_FieldTeleport
	.public Task_FollowMonInteract
	.public _022487F4
	.public _02248804
	.public _02248818
	.public _02248824
	.public _02248838
	.public _02248844
	.public _0224885A
	.public _02248868
	.public _0224887C
	.public _02248892
	.public _0224889C
	.public _022488A8
	.public _022488BE
	.public _022488C8
	.public _022488D4
	.public _022488EA
	.public _022488F4
	.public _02248900
	.public _02248916
	.public _02248920
	.public _022489A2
	.public _022489DE
	.public _022489E6
	.public _02248A04
	.public _02248A16
	.public _02248A1E
	.public _02248A38
	.public _02248A4A
	.public _02248A52
	.public _02248A7A
	.public _02248AB8
	.public _02248AC0
	.public _02248ADC
	.public _02248AEE
	.public _02248AF6
	.public _02248B10
	.public _02248B22
	.public _02248B2A
	.public _02248B52
	.public _02248B8E
	.public _02248B96
	.public _02248BC2
	.public _02248BFE
	.public _02248C06
	.public _02248C2A
	.public _02248C92
	.public _02248D14
	.public _02248D2C
	.public _02248D88
	.public _02248DD0
	.public _02248DDA
	.public _02248DEC
	.public _02248DFC
	.public _02248E0C
	.public _02248F74
	.public _02248F78
	.public _02248F7C
	.public _02248F80
	.public _02248F84
	.public _02248FA0
	.public _02248FB2
	.public _02248FBE
	.public _02249006
	.public _02249018
	.public _0224902A
	.public _0224907A
	.public _02249080
	.public _022490E0
	.public _02249124
	.public _02249156
	.public _02249168
	.public _022491A2
	.public _022491E2
	.public _02249284
	.public _02249288
	.public _0224928C
	.public _022492B0
	.public _022492BA
	.public _02249302
	.public _02249314
	.public _02249326
	.public _0224934C
	.public _02249390
	.public _02249398
	.public _022493BA
	.public _022493C8
	.public _022493E6
	.public _022493F8
	.public _0224941C
	.public _02249440
	.public _02249490
	.public _022494AC
	.public _022494B8
	.public _022494BC
	.public _022494C0
	.public _02249538
	.public _02249580
	.public _0224958A
	.public _022495AC
	.public _022495B2
	.public _022495B4
	.public _022495FE
	.public _02249650
	.public _02249654
	.public _0224968C
	.public _022496B4
	.public _022496FE
	.public _0224970A
	.public _02249716
	.public _0224974E
	.public _0224976C
	.public _02249770
	.public _022497AC
	.public _02249802
	.public _02249834
	.public _02249850
	.public _02249854
	.public _0224986C
	.public _022498AC
	.public _022498B4
	.public _022498B8
	.public _022498EA
	.public _022498F6
	.public _02249902
	.public _0224993A
	.public _0224998A
	.public _022499AC
	.public _022499B2
	.public _022499B4
	.public _022499BE
	.public _022499E0
	.public _022499E6
	.public _022499E8
	.public _02249A02
	.public _02249A54
	.public _02249A58
	.public _02249A72
	.public _02249AC0
	.public _02249B02
	.public _02249B48
	.public _02249B7A
	.public _02249BA2
	.public _02249BB8
	.public _02249BD4
	.public _02249C06
	.public _02249C12
	.public _02249C1E
	.public _02249C4A
	.public _02249C6C
	.public _02249C92
	.public _02249C96
	.public _02249CAC
	.public _02249CBA
	.public _02249CC8
	.public _02249CEA
	.public _02249D14
	.public _02249D3C
	.public _02249D5A
	.public _02249D72
	.public _02249D7C
	.public _02249D8C
	.public _02249D96
	.public _02249DAE
	.public _02249DBE
	.public _02249DD2
	.public _02249DD4
	.public _02249DF0
	.public _02249DFA
	.public _02249E0A
	.public _02249E14
	.public _02249E32
	.public _02249E48
	.public _02249E56
	.public _02249E8A
	.public _02249E8C
	.public _02249EBE
	.public _02249F68
	.public _02249FD0
	.public _0224A024
	.public _0224A070
	.public _0224A07C
	.public _0224A196
	.public _0224A278
	.public _0224A27C
	.public _0224A280
	.public _0224A284
	.public _0224A294
	.public _0224A29E
	.public _0224A2AE
	.public _0224A2B8
	.public _0224A2C8
	.public _0224A2D2
	.public _0224A2E2
	.public _0224A2EC
	.public _0224A338
	.public _0224A384
	.public _0224A3BE
	.public _0224A3EA
	.public _0224A426
	.public _0224A4CC
	.public _0224A4E4
	.public _0224A510
	.public _0224A518
	.public _0224A520
	.public _0224A528
	.public _0224A554
	.public _0224A55C
	.public _0224A564
	.public _0224A644
	.public _0224A6BA
	.public _0224A6CC
	.public _0224A6E2
	.public _0224A6FC
	.public _0224A730
	.public _0224A748
	.public _0224A796
	.public _0224A79C
	.public _0224A7A0
	.public _0224A7A4
	.public _0224A7B4
	.public _0224A7D4
	.public _0224A80C
	.public _0224A8FE
	.public _0224A912
	.public _0224A91A
	.public _0224A922
	.public _0224A948
	.public _0224A95C
	.public _0224A964
	.public _0224A96C
	.public _0224A992
	.public _0224A9A6
	.public _0224A9AE
	.public _0224A9B6
	.public _0224A9E8
	.public _0224AA40
	.public _0224AA7C
	.public _0224AAD0
	.public _0224AB38
	.public _0224AB42
	.public _0224AB4E
	.public _0224AB88
	.public _0224ABB6
	.public _0224ABC0
	.public _0224AC00
	.public _0224AC10
	.public _0224AC20
	.public _0224ACD8
	.public _0224ACDC
	.public _0224AD00
	.public _0224AD4A
	.public _0224AD5C
	.public _0224AD6E
	.public _0224AD90
	.public _0224ADDA
	.public _0224ADE0
	.public _0224ADE4
	.public _0224ADE8
	.public _0224AF5C
	.public _0224AF60
	.public _0224AF64
	.public _0224AF68
	.public _0224AF6C
	.public _0224AF86
	.public _0224AF98
	.public _0224AFA4
	.public _0224AFEE
	.public _0224B000
	.public _0224B012
	.public _0224B03A
	.public _0224B07C
	.public _0224B082
	.public _0224B08E
	.public _0224B0B8
	.public _0224B0C8
	.public _0224B0D8
	.public _0224B0DC
	.public _0224B17C
	.public _0224B1C0
	.public _0224B1D2
	.public _0224B1E4
	.public _0224B20A
	.public _0224B25E
	.public _0224B272
	.public _0224B2BC
	.public _0224B3A8
	.public _0224B3AC
	.public _0224B3F4
	.public _0224B3F8
	.public _0224B40A
	.public _0224B410
	.public _0224B438
	.public _0224B462
	.public _0224B484
	.public _0224B48E
	.public _0224B490
	.public _0224B57C
	.public _0224B5DC
	.public _0224B64E
	.public _0224B6A0
	.public _0224B716
	.public _0224B720
	.public _0224B764
	.public _0224B782
	.public _0224B7C8
	.public _0224B824
	.public _0224B82C
	.public _0224B832
	.public _0224B854
	.public _0224B878
	.public _0224B888
	.public _0224B992
	.public _0224BA14
	.public _0224BA2E
	.public _0224BA42
	.public _0224BA50
	.public _0224BA6C
	.public _0224BA78
	.public _0224BA9C
	.public _0224BAB0
	.public _0224BAD4
	.public _0224BB0E
	.public _0224BB14
	.public _0224BB84
	.public _0224BB8C
	.public _0224BBAC
	.public _0224BBB8
	.public _0224BBC4
	.public _0224BBF6
	.public _0224BBF8
	.public _0224BC02
	.public _0224BC04
	.public _0224BC22
	.public _0224BC24
	.public _0224BC2E
	.public _0224BC30
	.public _0224BC66
	.public _0224BC98
	.public _0224BCFA
	.public _0224BD06
	.public _0224BD1E
	.public _0224BD42
	.public _0224BD64
	.public _0224BDA0
	.public _0224BDBA
	.public _0224BDC2
	.public _0224BDCC
	.public _0224BDD4
	.public _0224BDD8
	.public _0224BDDC
	.public _0224BDE0
	.public _0224BDE4
	.public _0224BE1A
	.public _0224BE20
	.public _0224BE40
	.public _0224BE4C
	.public _0224BE56
	.public _0224BE7C
	.public _0224BE7E
	.public _0224BE88
	.public _0224BE8A
	.public _0224BE9E
	.public _0224BED2
	.public _0224BEE0
	.public _0224BEE8
	.public _0224BF00
	.public _0224BF2C
	.public _0224BF3E
	.public _0224BF48
	.public _0224BF50
	.public _0224BF54
	.public _0224BFB4
	.public _0224BFBC
	.public _0224BFC8
	.public _0224BFD4
	.public _0224C006
	.public _0224C016
	.public _0224C01A
	.public _0224C032
	.public _0224C04E
	.public _0224C058
	.public _0224C092
	.public _0224C0A4
	.public _0224C0A8
	.public _0224C0AC
	.public _0224C0C8
	.public _0224C0F0
	.public _0224C100
	.public _0224C120
	.public _0224C138
	.public _0224C144
	.public _0224C148
	.public _0224C184
	.public _0224C190
	.public _0224C1A2
	.public _0224C1B4
	.public _0224C20C
	.public _0224C228
	.public _0224C230
	.public _0224C25A
	.public _0224C270
	.public _0224C29C
	.public _0224C2A0
	.public _0224C2A4
	.public _0224C2C6
	.public _0224C2D2
	.public _0224C2E8
	.public _0224C2FE
	.public _0224C31C
	.public _0224C330
	.public _0224C334
	.public _0224C34A
	.public _0224C358
	.public _0224C3A4
	.public _0224C3A8
	.public _0224C3D8
	.public _0224C3E0
	.public _0224C3F0
	.public _0224C3F8
	.public _0224C41E
	.public _0224C420
	.public _0224C42A
	.public _0224C456
	.public _0224C45C
	.public _0224C46E
	.public _0224C482
	.public _0224C494
	.public _0224C49E
	.public _0224C4A2
	.public _0224C4A8
	.public _0224C4AC
	.public _0224C4B0
	.public _0224C4EA
	.public _0224C534
	.public _0224C54E
	.public _0224C552
	.public _0224C584
	.public _0224C58C
	.public _0224C59C
	.public _0224C5A4
	.public _0224C5CA
	.public _0224C5CC
	.public _0224C5D6
	.public _0224C602
	.public _0224C608
	.public _0224C61A
	.public _0224C62E
	.public _0224C640
	.public _0224C64A
	.public _0224C64E
	.public _0224C654
	.public _0224C658
	.public _0224C65C
	.public _0224C670
	.public _0224C6D0
	.public _0224C6D4
	.public _0224C6D8
	.public _0224C6F0
	.public _0224C718
	.public _0224C750
	.public _0224C754
	.public _0224C758
	.public _0224C774
	.public _0224C79C
	.public _0224C7AC
	.public _0224C7D0
	.public _0224C80C
	.public _0224C818
	.public _0224C82A
	.public _0224C83C
	.public _0224C8B2
	.public _0224C8C4
	.public _0224C8C8
	.public _0224C8CC
	.public _0224C8E4
	.public _0224C90E
	.public _0224C928
	.public _0224C92E
	.public _0224C938
	.public _0224C954
	.public _0224C97C
	.public _0224C98C
	.public _0224C9B0
	.public _0224C9B4
	.public _0224C9F2
	.public _0224C9FE
	.public _0224CA18
	.public _0224CA24
	.public _0224CA34
	.public _0224CA6C
	.public _0224CA7E
	.public _0224CA9A
	.public _0224CAB4
	.public _0224CB06
	.public _0224CB14
	.public _0224CB30
	.public _0224CB34
	.public _0224CB44
	.public _0224CB48
	.public _0224CB58
	.public _0224CB5A
	.public _0224CB76
	.public _0224CBB4
	.public _0224CBEE
	.public _0224CC46
	.public _0224CC54
	.public _0224CC70
	.public _0224CC74
	.public _0224CC84
	.public _0224CC88
	.public _0224CC98
	.public _0224CC9A
	.public _0224CCB6
	.public _0224CCF4
	.public _0224CCFC
	.public _0224CD30
	.public _0224CD34
	.public _0224CE1C
	.public _0224CE24
	.public _0224CE44
	.public _0224CE50
	.public _0224CE5C
	.public _0224CE82
	.public _0224CE84
	.public _0224CE8E
	.public _0224CE90
	.public _0224CEBA
	.public _0224CF1C
	.public _0224CF28
	.public _0224CF40
	.public _0224CF64
	.public _0224CF76
	.public _0224CF94
	.public _0224CFAE
	.public _0224CFB6
	.public _0224CFC0
	.public _0224CFC8
	.public _0224CFCC
	.public _0224CFD0
	.public _0224CFD4
	.public _0224D010
	.public _0224D018
	.public _0224D01C
	.public _0224D020
	.public _0224D024
	.public _0224D028
	.public _0224D02C
	.public _0224D078
	.public _0224D080
	.public _0224D084
	.public _0224D088
	.public _0224D08C
	.public _0224D090
	.public _0224D094
	.public _0224D114
	.public _0224D13E
	.public _0224D160
	.public _0224D176
	.public _0224D18C
	.public _0224D1A6
	.public _0224D1C2
	.public _0224D1D8
	.public _0224D1E0
	.public _0224D228
	.public _0224D274
	.public _0224D284
	.public _0224D29A
	.public _0224D2B8
	.public _0224D2C4
	.public _0224D2D4
	.public _0224D2D8
	.public _0224D2E8
	.public _0224D2EC
	.public _0224D2F4
	.public _0224D30A
	.public _0224D354
	.public _0224D3A0
	.public _0224D3B0
	.public _0224D3C6
	.public _0224D3E4
	.public _0224D3F0
	.public _0224D400
	.public _0224D404
	.public _0224D414
	.public _0224D418
	.public _0224D420
	.public _0224D436
	.public _0224D464
	.public _0224D474
	.public _0224D4A4
	.public _0224D4AC
	.public _0224D50A
	.public _0224D522
	.public _0224D55E
	.public _0224D570
	.public _0224D574
	.public _0224D578
	.public _0224D57C
	.public _0224D586
	.public _0224D5A4
	.public _0224D5A8
	.public _0224D5B0
	.public _0224D640
	.public _0224D644
	.public _0224D654
	.public _0224D678
	.public _0224D688
	.public _0224D68C
	.public _0224D694
	.public _0224D6B0
	.public _0224D6D8
	.public _0224D6FC
	.public _0224D716
	.public _0224D73A
	.public _0224D75E
	.public _0224D794
	.public _0224D7F8
	.public _0224D806
	.public _0224D81C
	.public _0224D82C
	.public _0224D858
	.public _0224D870
	.public _0224D8B4
	.public _0224D8D8
	.public _0224D90C
	.public _0224D910
	.public _0224D920
	.public _0224D93C
	.public _0224D94C
	.public _0224D980
	.public _0224D986
	.public _0224D988
	.public _0224D994
	.public _0224D9B0
	.public _0224D9B4
	.public _0224D9BC
	.public _0224DA46
	.public _0224DA4E
	.public _0224DA5A
	.public _0224DA66
	.public _0224DA72
	.public _0224DA7C
	.public _0224DA9C
	.public _0224DAA0
	.public _0224DB2C
	.public _0224DB34
	.public _0224DB40
	.public _0224DB4C
	.public _0224DB58
	.public _0224DB62
	.public _0224DB84
	.public _0224DB88
	.public _0224DB98
	.public _0224DBB0
	.public _0224DBF4
	.public _0224DC12
	.public _0224DC1C
	.public _0224DC38
	.public _0224DC4C
	.public _0224DC50
	.public _0224DC54
	.public _0224DC60
	.public _0224DC70
	.public _0224DC74
	.public _0224DC84
	.public _0224DC88
	.public _0224DC90
	.public _0224DCA6
	.public _0224DCAC
	.public _0224DCE0
	.public _0224DD02
	.public _0224DD28
	.public _0224DD2C
	.public _0224DD30
	.public _0224DD34
	.public _0224DD48
	.public _0224DD58
	.public _0224DD72
	.public _0224DD84
	.public _0224DD88
	.public _0224DDBC
	.public _0224DDC2
	.public _0224DDC4
	.public _0224DDD0
	.public _0224DDEC
	.public _0224DDF0
	.public _0224DE00
	.public _0224DE04
	.public _0224DE0C
	.public _0224DE26
	.public _0224DE46
	.public _0224DE68
	.public _0224DE82
	.public _0224DEA6
	.public _0224DECA
	.public _0224DF00
	.public _0224DF5A
	.public _0224DF80
	.public _0224DF88
	.public _0224DF90
	.public _0224DF94
	.public _0224DFBC
	.public _0224DFC6
	.public _0224DFCA
	.public _0224DFF2
	.public _0224DFFA
	.public _0224E004
	.public _0224E010
	.public _0224E032
	.public _0224E04A
	.public _0224E068
	.public _0224E06C
	.public _0224E070
	.public _0224E08C
	.public _0224E0B4
	.public _0224E0B8
	.public _0224E0D0
	.public _0224E108
	.public _0224E114
	.public _0224E120
	.public _0224E130
	.public _0224E156
	.public _0224E1AA
	.public _0224E1C6
	.public _0224E1F6
	.public _0224E21E
	.public _0224E23C
	.public _0224E246
	.public _0224E256
	.public _0224E25E
	.public _0224E264
	.public _0224E268
	.public _0224E27E
	.public _0224E286
	.public _0224E28A
	.public _0224E28E
	.public _0224E292
	.public _0224E296
	.public _0224E2B2
	.public _0224E2BA
	.public _0224E2BE
	.public _0224E2C2
	.public _0224E2C6
	.public _0224E2CA
	.public _0224E2E8
	.public _0224E2F0
	.public _0224E2F4
	.public _0224E2F8
	.public _0224E2FC
	.public _0224E300
	.public _0224E312
	.public _0224E318
	.public _0224E33C
	.public _0224E33E
	.public _0224E38E
	.public _0224E39E
	.public _0224E3AE
	.public _0224E3BE
	.public _0224E3F8
	.public _0224E3FE
	.public _0224E40E
	.public _0224E414
	.public _0224E43C
	.public _0224E458
	.public _0224E468
	.public _0224E482
	.public _0224E490
	.public _0224E4BA
	.public _0224E4C4
	.public _0224E4D6
	.public _0224E4E6
	.public _0224E528
	.public _0224E52A
	.public _0224E584
	.public _0224E5D4
	.public _0224E606
	.public _0224E638
	.public _0224E672
	.public _0224E67C
	.public _0224E692
	.public _0224E706
	.public _0224E716
	.public _0224E726
	.public _0224E74E
	.public _0224E7D4
	.public _0224E80A
	.public _0224E810
	.public _0224E81C
	.public _0224E85C
	.public _0224E868
	.public _0224E870
	.public _0224E87E
	.public _0224E880
	.public _0224E8A4
	.public _0224E8F4
	.public _0224E904
	.public _0224E91C
	.public _0224E92A
	.public _0224E95C
	.public _0224E972
	.public _0224E984
	.public _0224E98A
	.public _0224E992
	.public _0224E99C
	.public _0224E99E
	.public _0224E9DC
	.public _0224E9EC
	.public _0224EA0A
	.public _0224EA18
	.public _0224EA56
	.public _0224EA5C
	.public _0224EA6A
	.public _0224EAAE
	.public _0224EABE
	.public _0224EAD6
	.public _0224EAE4
	.public _0224EB32
	.public _0224EB3E
	.public _0224EB44
	.public _0224EB7A
	.public _0224EB86
	.public _0224EB8E
	.public _0224EB96
	.public _0224EB98
	.public _0224EBD8
	.public _0224EBE8
	.public _0224EC04
	.public _0224EC12
	.public _0224EC50
	.public _0224EC56
	.public _0224EC64
	.public _0224ECA4
	.public _0224ECB4
	.public _0224ECD0
	.public _0224ECDE
	.public _0224ED2C
	.public _0224ED3A
	.public _0224ED4E
	.public _0224ED58
	.public _0224ED70
	.public _0224EDB4
	.public _0224EDC4
	.public _0224EDE0
	.public _0224EDEE
	.public _0224EE20
	.public _0224EE42
	.public _0224EE48
	.public _0224EE8E
	.public _0224EE96
	.public _0224EEAE
	.public _0224EEE6
	.public _0224EEEA
	.public _0224EEF2
	.public _0224EEFC
	.public _0224EF14
	.public _0224EF46
	.public _0224EF4A
	.public _0224EF58
	.public _0224EF60
	.public _0224EF68
	.public _0224EF78
	.public _0224EF8C
	.public _0224EF90
	.public _0224EFE2
	.public _0224EFF8
	.public _0224F00A
	.public _0224F018
	.public _0224F044
	.public _0224F100
	.public _0224F104
	.public _0224F124
	.public _0224F13E
	.public _0224F154
	.public _0224F15E
	.public _0224F16E
	.public _0224F194
	.public _0224F19C
	.public _0224F1B2
	.public _0224F1BA
	.public _0224F1D0
	.public _0224F1D8
	.public _0224F1EA
	.public _0224F200
	.public _0224F20E
	.public _0224F212
	.public _0224F22A
	.public _0224F23C
	.public _0224F24C
	.public _0224F25C
	.public _0224F26E
	.public _0224F280
	.public _0224F298
	.public _0224F2AA
	.public _0224F2C0
	.public _0224F2D2
	.public _0224F2E6
	.public _0224F2FA
	.public _0224F30C
	.public _0224F31E
	.public _0224F34E
	.public _0224F354
	.public _0224F380
	.public _0224F38A
	.public _0224F394
	.public _0224F39E
	.public _0224F3A2
	.public _0224F3B8
	.public _0224F3C4
	.public _0224F3D0
	.public _0224F3DC
	.public _0224F3E8
	.public _0224F3F2
	.public _0224F3FA
	.public _0224F410
	.public _0224F41C
	.public _0224F420
	.public _0224F474
	.public _0224F476
	.public _0224F490
	.public _0224F4B4
	.public _0224F4B8
	.public _0224F4FC
	.public _0224F52C
	.public _0224F536
	.public _0224F540
	.public _0224F568
	.public _0224F57A
	.public _0224F5A4
	.public _0224F5BE
	.public _0224F5C6
	.public _0224F5E8
	.public _0224F5EE
	.public _0224F5F4
	.public _0224F63A
	.public _0224F640
	.public _0224F664
	.public _0224F66E
	.public _0224F674
	.public _0224F67A
	.public _0224F680
	.public _0224F686
	.public _0224F68C
	.public _0224F6F4
	.public _0224F704
	.public _0224F714
	.public _0224F722
	.public _0224F744
	.public _0224F74C
	.public _0224F752
	.public _0224F758
	.public _0224F75E
	.public _0224F764
	.public _0224F77C
	.public _0224F782
	.public _0224F798
	.public _0224F7AE
	.public _0224F7D2
	.public _0224F7D6
	.public _0224F7DA
	.public _0224F7DE
	.public _0224F7E2
	.public _0224F7E6
	.public _0224F7EA
	.public _0224F7EE
	.public _0224F7F2
	.public _0224F7F6
	.public _0224F7FA
	.public _0224F7FE
	.public _0224F802
	.public _0224F806
	.public _0224F80A
	.public _0224F80E
	.public _0224F812
	.public _0224F816
	.public _0224F832
	.public _0224F840
	.public _0224F844
	.public _0224F848
	.public _0224F84C
	.public _0224F850
	.public _0224F854
	.public _0224F858
	.public _0224F85C
	.public _0224F87C
	.public _0224F8BE
	.public _0224F8CC
	.public _0224F8E4
	.public _0224F8E8
	.public _0224F8EC
	.public _0224F8F0
	.public _0224F8F8
	.public _0224F920
	.public _0224F92E
	.public _0224F93A
	.public _0224F93E
	.public _0224F962
	.public _0224F970
	.public _0224F97C
	.public _0224F980
	.public _0224F98C
	.public _0224F998
	.public _0224F9A8
	.public _0224F9CA
	.public _0224F9E8
	.public _0224FA06
	.public _0224FA1A
	.public _0224FA3E
	.public _0224FA50
	.public _0224FAA8
	.public _0224FABA
	.public _0224FAEE
	.public _0224FB1A
	.public _0224FB28
	.public _0224FB2C
	.public _0224FB30
	.public _0224FB34
	.public _0224FB38
	.public _0224FB3C
	.public _0224FB40
	.public _0224FB4E
	.public _0224FB74
	.public _0224FB82
	.public _0224FB92
	.public _0224FB98
	.public _0224FC00
	.public _0224FC04
	.public _0224FC6C
	.public _0224FC70
	.public _0224FC82
	.public _0224FC88
	.public _0224FD30
	.public _0224FD3E
	.public _0224FD70
	.public _0224FD72
	.public _0224FDBC
	.public _0224FDDC
	.public _0224FDEC
	.public _0224FE16
	.public _0224FE18
	.public _0224FE2C
	.public _0224FE32
	.public _0224FE38
	.public _0224FE3C
	.public _0224FE6C
	.public _0224FE9E
	.public _0224FEE0
	.public _0224FEFC
	.public _0224FF00
	.public _0224FF2C
	.public _0224FF34
	.public _0224FF3C
	.public _0224FF44
	.public _0224FF4C
	.public _0224FF54
	.public _0224FFA8
	.public _0224FFC6
	.public _0224FFCC
	.public _0224FFD0
	.public _0224FFD4
	.public _0224FFE4
	.public _0224FFF6
	.public _02250000
	.public _02250016
	.public _0225002A
	.public _02250034
	.public _02250040
	.public _02250082
	.public _02250094
	.public _02250098
	.public _022500AE
	.public _02250102
	.public _02250108
	.public _0225010C
	.public _0225012A
	.public _02250136
	.public _02250142
	.public _0225015C
	.public _02250178
	.public _0225018E
	.public _02250198
	.public _022501A2
	.public _022501BE
	.public _022501C6
	.public _022501DE
	.public _02250218
	.public _02250246
	.public _02250270
	.public _02250272
	.public _022502BA
	.public _022502C4
	.public _0225030A
	.public _02250314
	.public _02250332
	.public _02250336
	.public _02250364
	.public _02250372
	.public _02250378
	.public _02250392
	.public _0225039E
	.public _022503A2
	.public _022503A6
	.public _022503AA
	.public _022503AE
	.public _022503B2
	.public _022503BA
	.public _02250404
	.public _02250412
	.public _02250418
	.public _0225047E
	.public _02250484
	.public _02250488
	.public _0225048C
	.public _02250490
	.public _02250494
	.public _02250498
	.public _0225049C
	.public _02250538
	.public _02250542
	.public _02250576
	.public _0225057E
	.public _0225058C
	.public _02250590
	.public _022505A4
	.public _022505BA
	.public _022505C2
	.public _022505CE
	.public _022505DA
	.public _022505E6
	.public _022505F2
	.public _022505FE
	.public _0225060A
	.public _02250612
	.public _0225061A
	.public _02250622
	.public _02250638
	.public _0225064E
	.public _02250656
	.public _02250662
	.public _0225066E
	.public _0225067A
	.public _0225068A
	.public _0225069C
	.public _022506AE
	.public _022506BA
	.public _022506C2
	.public _022506CE
	.public _022506E2
	.public _022506F4
	.public _022506FE
	.public _02250706
	.public _0225070E
	.public _0225071A
	.public _02250722
	.public _0225072A
	.public _02250732
	.public _02250760
	.public _0225076C
	.public _0225077C
	.public _022507AC
	.public _022507B0
	.public _022507E0
	.public _022507E4
	.public _02250814
	.public _0225081E
	.public _0225082E
	.public _0225084C
	.public _02250874
	.public _0225089A
	.public _022508A0
	.public _022508AA
	.public _022508B0
	.public _022508D4
	.public _022508FC
	.public _02250908
	.public _02250910
	.public _0225099A
	.public _022509AE
	.public _022509CE
	.public _02250A2C
	.public _02250A3A
	.public _02250A44
	.public _02250A4C
	.public _02250A50
	.public _02250A54
	.public _02250A58
	.public _02250A5C
	.public _02253E20
	.public SpriteGfxManager_Init
	.public SpriteGfxManager_Free
	.public SpriteGfxManager_LoadChar
	.public SpriteGfxManager_TransferChar
	.public SpriteGfxManager_ReleaseCharData
	.public SpriteGfxManager_LoadPltt
	.public SpriteGfxManager_TransferPltt
	.public SpriteGfxManager_ReleasePlttData
	.public SpriteGfxManager_LoadCell
	.public SpriteGfxManager_LoadAnim
	.public SpriteGfxManager_CreateSprite
	.public Sprite_CopyPositionVector
	.public FlyLanding_CreateFlyerSprite
	.public FlyLanding_CreateTrainerSprite
	.public FlyLandingEffect_Create
	.public FlyLandingEffect_GetStatus
	.public FlyLandingEffect_Init
	.public FlyLandingEffect_Delete
	.public FlyLandingEffect_Destroy
	.public FlyLandingEffect_Update
	.public FlyLandingEffect_Idle
	.public FlyLandingEffect_Start
	.public FlyLandingEffect_SwoopIn
	.public FlyLandingEffect_StartClimb
	.public FlyLandingEffect_Climb
	.public FlyLandingEffect_HideFlyer
	.public FlyLandingEffect_StartFlyAway
	.public FlyLandingEffect_FlyAway
	.public FlyLandingEffect_ShowPlayer
	.public FlyLandingEffect_Done
	.public FlyLanding_OpenNarc
	.public FieldMove_FadeInFromWhite
	.public FieldMove_FadeOutToWhite
	.public FieldMove_SetPlayerVisible
	.public FieldMoveCutIn_Start
	.public FieldMoveCutIn_StartFlyWithObject
	.public FieldMoveCutIn_IsFinished
	.public FieldMoveCutIn_Delete
	.public FieldMoveCutIn_New
	.public FieldMoveCutIn_Free
	.public Task_FieldMoveCutIn
	.public FieldMoveCutIn_StepLoadBannerGraphics
	.public FieldMoveCutIn_StepLoadSpriteGraphics
	.public FieldMoveCutIn_StepCreateSprites
	.public FieldMoveCutIn_StepInitWindow
	.public FieldMoveCutIn_StepWidenWindow
	.public FieldMoveCutIn_StepOpenWindow
	.public FieldMoveCutIn_StepWaitBeforeMon
	.public FieldMoveCutIn_StepMonSlideIn
	.public FieldMoveCutIn_StepMonSlowDown
	.public FieldMoveCutIn_StepWaitBeforeMonExit
	.public FieldMoveCutIn_StepMonSlideOut
	.public FieldMoveCutIn_StepCloseWindow
	.public FieldMoveCutIn_StepFreeBannerGraphics
	.public FieldMoveCutIn_StepFreeSpriteGraphics
	.public FieldMoveCutIn_StepEndWindow
	.public FieldMoveCutIn_StepFinish
	.public Task_FieldMoveCutInFly
	.public Task_FieldMoveCutInFlyWithObject
	.public FieldMoveCutIn_StepCreateFlySprites
	.public FieldMoveCutIn_StepCreateFlyTrainerSprite
	.public FieldMoveCutIn_StepFreeMonGraphics
	.public FieldMoveCutIn_StepLoadFlyGraphics
	.public FieldMoveCutIn_StepWaitFlyGraphics
	.public FieldMoveCutIn_StepStartFly
	.public FieldMoveCutIn_StepWaitTakeOff
	.public FieldMoveCutIn_StepWaitBeforeFlyAway
	.public FieldMoveCutIn_StepWaitBeforeFlyAwayWithObject
	.public FieldMoveCutIn_StepWaitFlyAway
	.public FieldMoveCutIn_StepCloseFlyWindow
	.public FieldMoveCutIn_StepWaitFlyEnd
	.public FieldMoveCutIn_StepWaitPaletteFade
	.public FieldMoveCutIn_StartSpriteTransfer
	.public FieldMoveCutIn_StartFlySpriteTransfer
	.public FieldMoveCutIn_EndSpriteTransfer
	.public Task_FieldMoveCutIn_TransferSprites
	.public Task_FieldMoveCutIn_ReleaseSpriteData
	.public Task_FieldMoveCutIn_TransferFlySprites
	.public Task_FieldMoveCutIn_ReleaseFlySpriteData
	.public FieldMoveCutIn_InitBannerGraphics
	.public FieldMoveCutIn_InitSpriteGraphics
	.public FieldMoveCutIn_FreeBannerGraphics
	.public FieldMoveCutIn_FreeSpriteGraphics
	.public FieldMoveCutIn_OpenNarc
	.public FieldMoveCutIn_LoadSpriteResources
	.public FieldMoveCutIn_FreeSpriteResources
	.public FieldMoveCutIn_DrawSprites
	.public FieldMoveCutIn_CreateSprite
	.public FieldMoveCutIn_CreateEffectSprite
	.public FieldMoveCutIn_CreateTrainerSprite
	.public CutInSprite_StartAnimation
	.public FieldMoveCutIn_CreateFlyerSprite
	.public FieldMoveCutIn_LoadFlyResources
	.public CutInBanner_LoadPalette
	.public CutInBanner_LoadChar
	.public CutInBanner_LoadScreen
	.public CutInBanner_Clear
	.public FieldMoveCutIn_StartWindow
	.public FieldMoveCutIn_EnableWindow
	.public FieldMoveCutIn_DisableWindow
	.public FieldMoveCutIn_SetWindowPlanes
	.public FieldMoveCutIn_SetWindowOutsidePlanes
	.public FieldMoveCutIn_SetWindowRect
	.public FieldMoveCutIn_CreateWindowTask
	.public FieldMoveCutIn_DestroyWindowTask
	.public Task_FieldMoveCutIn_UpdateWindow
	.public FieldMoveCutIn_GetMonPicIds
	.public FieldMoveCutIn_LoadMonChar
	.public FieldMoveCutIn_LoadMonPltt
	.public FieldMoveCutIn_AddMonCharResource
	.public FieldMoveCutIn_TransferMonChar
	.public FieldMoveCutIn_AddMonPlttResource
	.public FieldMoveCutIn_TransferMonPltt
	.public FieldMoveCutIn_FreeMonResources
	.public FieldMoveCutIn_CreateMonSprite
	.public FieldMoveCutIn_CreateScrollSprites
	.public FieldMoveCutIn_CreateScrollSprite
	.public CutInScrollSprite_Init
	.public CutInScrollSprite_Destroy
	.public CutInScrollSprite_Update
	.public CutInScrollSprite_Draw
	.public FieldMoveCutIn_CreateFlyer
	.public FieldMoveCutIn_GetFlyerStatus
	.public FieldMoveCutIn_DestroyFlyer
	.public CutInFlyer_Init
	.public CutInFlyer_Destroy
	.public CutInFlyer_Update
	.public CutInFlyer_Draw
	.public CutInFlyer_Hide
	.public FieldMoveCutIn_StartFlyerTakeOff
	.public CutInFlyer_TakeOff
	.public CutInFlyer_Idle
	.public FieldMoveCutIn_StartFlyerPickUp
	.public CutInFlyer_SwoopDown
	.public CutInFlyer_PickUpTrainer
	.public CutInFlyer_FlyAway
	.public CutInFlyer_Done
	.public FieldMoveCutIn_CreateTrainerJumpEffect
	.public TrainerJumpEffect_Stop
	.public TrainerJumpEffect_StartJump
	.public TrainerJumpEffect_StartHop
	.public TrainerJumpEffect_Init
	.public TrainerJumpEffect_Jump
	.public TrainerJumpEffect_Hop
	.public TrainerJumpEffect_Update
	.public FlyLanding_Start
	.public FlyLanding_IsDone
	.public FlyLanding_Delete
	.public Task_FlyLanding
	.public FlyLanding_SetPlayerVisible
	.public FlyLanding_LoadGraphics
	.public FlyLanding_CreateSprites
	.public FlyLanding_WaitLanding
	.public FlyLanding_FreeGraphics
	.public FlyLanding_Idle
	.public FlyLanding_AllocZeroed
	.public FieldMoveCutIn_SetPlayerVisible
	.public TrainerClipEffect_Init
	.public TrainerClipEffect_Update
	.public FieldMoveCutIn_CreateTrainerClipEffect
	.public FieldMoveCutIn_DestroyTrainerClipEffect
	.public FieldMoveCutIn_CreateModelEffect
	.public CutInModelEffect_Init
	.public CutInModelEffect_Destroy
	.public CutInModelEffect_Update
	.public CutInModelEffect_Draw
	.public FieldMoveCutIn_LoadModel
	.public FieldMoveCutIn_UnloadModel
	.public FieldMoveCutIn_StepShowOtherObject
	.public FieldMoveCutIn_StepWaitModelEffect
	.public Roamers_GetActiveRoamerBySpecies
	.public ElevatorAnimCreate
	.public ElevatorAnimRun
	.public PCProp_LoadAnimations
	.public PCProp_PlayPowerOnAnimation
	.public PCProp_PlayPowerOffAnimation
	.public FieldEscapeRope_SpinStart
	.public FieldEscapeRope_SpinAndFadeOut
	.public FieldEscapeRope_WaitFadeOut
	.public FieldEscapeRope_Warp
	.public FieldMoveTask_CreateArrivalEnvironment
	.public Task_FieldMoveArrival
	.public FieldMoveArrival_FadeIn
	.public FieldMoveArrival_WaitFadeIn
	.public FieldMoveArrival_Spin
	.public FieldMoveArrival_Finish
	.public FieldMove_ShowCutIn
	.public FieldMove_WaitCutIn
	.public FieldMoveTaskEnvironment_New
	.public FieldTeleport_FollowMonFlash
	.public FieldTeleport_FollowMonSpinStart
	.public FieldTeleport_FollowMonWaitSpin
	.public FieldTeleport_SpinStart
	.public FieldTeleport_SpinAndFadeOut
	.public FieldTeleport_WaitFadeOut
	.public FieldTeleport_Warp
	.public FieldDig_SinkStart
	.public FieldDig_DigHole
	.public FieldDig_SpinAndFadeOut
	.public FieldDig_WaitFadeOut
	.public FieldDig_Warp
	.public PrimoPassword_RotateBitsRight
	.public PrimoPassword_DecodeWallpaper
	.public PrimoPassword_DecodeCheck2
	.public PrimoPassword_CheckWallpaper
	.public PrimoPassword_Check2
	.public HallOfFame_StartBallAnim
	.public Task_HallOfFameBallAnim
	.public Field3dObject_SetPosInFrontOfMapObject
	.public Field3dObject_SetPosInFrontOfPlayer
	.public Field3dObject_SetPosAtPlayer
	.public FieldMoveEffectModel_Load
	.public FieldMoveEffectModel_Unload
	.public FieldMoveEffectModel_AnimateOnce
	.public FieldMoveEffectModel_AnimateLoop
	.public FieldMoveEffectModel_Draw
	.public CutEffect_InitAtPlayer
	.public CutEffect_InitAtFollower
	.public CutEffect_Destroy
	.public CutEffect_Update
	.public CutEffect_Render
	.public CutEffect_CreateAtPlayer
	.public CutEffect_CreateAtFollower
	.public CutEffect_Delete
	.public CutEffect_IsFinished
	.public RockSmashEffect_InitAtPlayer
	.public RockSmashEffect_InitAtFollower
	.public RockSmashEffect_Destroy
	.public RockSmashEffect_Update
	.public RockSmashEffect_Render
	.public RockSmashEffect_CreateAtPlayer
	.public RockSmashEffect_CreateAtFollower
	.public RockSmashEffect_Delete
	.public RockSmashEffect_IsFinished
	.public WaterfallEffect_Init
	.public WaterfallEffect_Destroy
	.public WaterfallEffect_Update
	.public WaterfallEffect_Render
	.public WaterfallEffect_Create
	.public WaterfallEffect_Delete
	.public WhirlpoolEffect_Init
	.public WhirlpoolEffect_Destroy
	.public WhirlpoolEffect_Update
	.public WhirlpoolEffect_Render
	.public WhirlpoolEffect_Create
	.public WhirlpoolEffect_Delete
	.public RockClimbDebris_SpawnPiece
	.public RockClimbDebris_UpdatePiece
	.public RockClimbDebris_InitPiece
	.public RockClimbDebris_FreePiece
	.public RockClimbDebris_UpdateOffsets
	.public RockClimbDebris_Spawn
	.public RockClimbDebris_UpdatePieces
	.public RockClimbDebris_Init
	.public RockClimbDebris_Destroy
	.public RockClimbDebris_Update
	.public RockClimbDebris_Render
	.public RockClimbDebris_Create
	.public RockClimbDebris_Delete
	.public HeadbuttEffect_InitAtPlayer
	.public HeadbuttEffect_InitAtFollower
	.public HeadbuttEffect_Destroy
	.public HeadbuttEffect_Update
	.public HeadbuttEffect_Render
	.public HeadbuttEffect_CreateAtPlayer
	.public HeadbuttEffect_CreateAtFollower
	.public HeadbuttEffect_Delete
	.public HeadbuttEffect_IsFinished
	.public RockDebris_Init
	.public RockDebris_InitWithFollower
	.public RockDebris_Destroy
	.public RockDebris_Update
	.public RockDebris_Render
	.public RockDebris_Create
	.public RockDebris_CreateWithFollower
	.public RockDebris_Delete
	.public RockDebris_SpawnPiece
	.public RockDebris_UpdatePiece
	.public RockDebris_InitPiece
	.public RockDebris_FreePiece
	.public RockDebris_Spawn
	.public RockDebris_UpdatePieces
	.public Task_ScriptFieldMoveEffect
	.public ScriptFieldMoveEffect_Start
	.public MapObjects_SwapPositions
	.public SwapPositions_CreateTaskEnv
	.public Task_SwapMapObjectPositions
	.public SwapPositions_GetStepTowards
	.public SwapPositions_GetFaceMovement
	.public SwapPositions_GetTurnAroundMovement
	.public SwapPositions_GetOppositeStep
	.public MapId_IsSafariZone
	.public SafariZone_GetAreaIndexAt
	.public FieldSystem_GetSafariAreaIndex
	.public FieldSystem_CanPlaceSafariObject
	.public SafariZone_CanPlaceObjectOnLand
	.public SafariZone_CanPlaceObjectOnWater
	.public SafariZone_IsWaterObjectPlacementUnlocked
	.public FieldSystem_CheckSafariObjectPlacement
	.public FieldSystem_GetFacingSafariObject
	.public SafariZone_FindSpotFor1x2Object
	.public SafariZone_FindSpotFor2x1Object
	.public SafariZone_FindSpotFor2x2Object
	.public SafariZone_CanPlaceObjectOn
	.public FollowMon_SelectInteraction
	.public FollowMon_GetSituation
	.public FollowMonRule_Matches
	.public FollowMonSituation_SetMonCondition
	.public FollowMonSituation_SetNearbyObjects
	.public FollowMonSituation_SetHiddenItems
	.public FollowMonSituation_SetWeather
	.public FollowMonSituation_SetTerrain
	.public FollowMonSituation_SetMapId
	.public FollowMonSituation_SetTimeOfDay
	.public FollowMonSituation_SetMood
	.public FollowMonSituation_SetBestPokeathlonStat
	.public FollowMonSituation_SetFacing
	.public FollowMonSituation_SetSpeciesAttr
	.public FollowMonSituation_ConvertType
	.public FollowMonSituation_ConvertItemPocket
	.public FollowMonInteraction_New
	.public FollowMonInteraction_LoadScript
	.public FollowMonInteraction_Delete
	.public FollowMonInteraction_Run
	.public FollowMonInteraction_StepHasMovement
	.public FollowMonInteraction_TryShowEmote
	.public FollowMonInteraction_PrintGiftMessage
	.public FollowMonInteraction_StepHasWait
	.public FollowMon_ExpandGiftMessage
	.public FollowMonMovement_ApplyOffset
	.public FollowMonMovement_PlaySound
	.public FollowMonMovement_ApplyFacing
	.public FollowMon_TryShakeGrass
	.public FollowMon_GetCoordsInDirection
	.public FollowMonMovement_Step
	.public FollowMonMovement_HasNextStep
	.public FollowMonInteraction_RunMovement
	.public FollowMon_ApplyInteractionEffects
	.public FollowMonRule_CheckFriendship
	.public FollowMonRule_CheckMood
	.public FollowMonRule_CheckSpeciesAttr
	.public FollowMonRule_CheckShinyLeaf
	.public FieldSystem_FirstAliveMonHasType
	.public FollowMon_JumpOnSpot
	.public Task_FollowMonJumpOnSpot
	.public FollowMon_StartGrowAndShrink
	.public Task_FollowMonGrowAndShrink
	.public sFlyLandingIdleSteps
	.public sCutInTrainerPlttFiles
	.public sCutInFlyerHideSteps
	.public sCutInTrainerCharFiles
	.public sCutInTrainerAnimFiles
	.public sCutInTrainerCellFiles
	.public sFlyLandingPhases
	.public sCutInFlyerTakeOffSteps
	.public sCutInFlyWithObjectTrainerPos
	.public sCutInFlyerPickUpPos
	.public sFlyLandingFlyerScale
	.public sCutInFlyerPickUpScale
	.public sCutInFlyerTrainerScale
	.public sCutInMonPos
	.public sCutInFlyerScale
	.public sFlyLandingSwoopCenter
	.public sFlyLandingTrainerScale
	.public sFlyLandingFlyAwayScale
	.public sCutInFlyerModeSteps
	.public sFlyLandingSwoopScale
	.public sFlyLandingFlyAwayCenter
	.public sCutInFlyerTakeOffOrigin
	.public sCutInFlyerTakeOffScale
	.public sCutInFlyTrainerPos
	.public sCutInTrainerPos
	.public sCutInFlyMonPos
	.public sCutInFlyerPickUpSteps
	.public sTrainerHopOffsets
	.public sTrainerClipEffectTemplate
	.public sFlyLandingEffectTemplate
	.public sCutInScrollSpriteEffectTemplate
	.public sCutInFlyerEffectTemplate
	.public sCutInModelEffectTemplate
	.public sTrainerJumpEffectTemplate
	.public sFlyLandingTaskSteps
	.public sFlyLandingSteps
	.public sFieldMoveCutInFlyWithObjectSteps
	.public sTrainerJumpOffsets
	.public sFieldMoveCutInSteps
	.public sFieldMoveCutInFlySteps
	.public sCutInScrollSpriteTemplates
	.public sPCPropModels
	.public sFieldMoveArrivalSteps
	.public sEscapeRopeSteps
	.public sDigWithFollowMonSteps
	.public sTeleportSteps
	.public sTeleportWithFollowMonSteps
	.public sDigSteps
	.public sTeleportFollowMonSpinMovement
	.public sEscapeRopeSpinMovement
	.public sDigHoleMovement
	.public sDigSinkMovement
	.public sEscapeRopeSpinStartMovement
	.public sArrivalSpinMovement
	.public sRideEffectFileIds
	.public sRockSmashEffectAtPlayerTemplate
	.public sWhirlpoolEffectTemplate
	.public sHeadbuttEffectAtFollowerTemplate
	.public sWaterfallEffectTemplate
	.public sRockClimbDebrisTemplate
	.public sCutEffectAtPlayerTemplate
	.public sRockSmashEffectAtFollowerTemplate
	.public sHeadbuttEffectAtPlayerTemplate
	.public sCutEffectAtFollowerTemplate
	.public sRockDebrisTemplate
	.public sRockDebrisWithFollowerTemplate
	.public sScriptFieldMoveEffectDeleteFuncs
	.public sScriptFieldMoveEffectCreateFuncs
	.public sScriptFieldMoveEffectIsFinishedFuncs
	.public gSafariZonePlacementOffsets
	.public sShinyLeafMasks
	.public sShinyLeafMonDataIds
	.public sFollowMonJumpOnSpotMovements
	.public sNatureGroups
	.public sFollowMonGrowScale
	.public sFollowMonShrinkScale
	.public sHealingMachineBallOffsets
	.public sHealingMachineBallOffsetsY
	.public sHealingMachineBallOffsetsZ
	.public sHallOfFameBallOffsets
	.public ov02_02253DDC
	.public ov02_02253DE0
	.public ov02_BattleExit_HandleRoamerAction
	.public ov02_RepelActiveRoamersFromMapNo
	.include "overlay_02.inc"
	.include "global.inc"

	.text
	.public FieldSystem_FollowMonInteract
	.public Sprite_CopyPositionVector
	.public FlyLandingEffect_GetStatus
	.public FlyLandingEffect_Destroy
	.public FlyLandingEffect_Idle
	.public FlyLandingEffect_Done
	.public FlyLanding_OpenNarc
	.public FieldMove_FadeInFromWhite
	.public FieldMove_FadeOutToWhite
	.public FieldMove_SetPlayerVisible
	.public FieldMoveCutIn_IsFinished
	.public FieldMoveCutIn_Delete
	.public FieldMoveCutIn_Free
	.public FieldMoveCutIn_StepLoadBannerGraphics
	.public FieldMoveCutIn_StepLoadSpriteGraphics
	.public FieldMoveCutIn_StepFreeBannerGraphics
	.public FieldMoveCutIn_StepFreeSpriteGraphics
	.public FieldMoveCutIn_StepEndWindow
	.public FieldMoveCutIn_StepFinish
	.public FieldMoveCutIn_StepFreeMonGraphics
	.public FieldMoveCutIn_StepLoadFlyGraphics
	.public FieldMoveCutIn_StepWaitFlyGraphics
	.public FieldMoveCutIn_StepStartFly
	.public FieldMoveCutIn_StepWaitTakeOff
	.public FieldMoveCutIn_StepWaitPaletteFade
	.public FieldMoveCutIn_StartSpriteTransfer
	.public FieldMoveCutIn_StartFlySpriteTransfer
	.public FieldMoveCutIn_EndSpriteTransfer
	.public FieldMoveCutIn_OpenNarc
	.public FieldMoveCutIn_DrawSprites
	.public CutInSprite_StartAnimation
	.public CutInBanner_Clear
	.public FieldMoveCutIn_StartWindow
	.public FieldMoveCutIn_EnableWindow
	.public FieldMoveCutIn_DisableWindow
	.public FieldMoveCutIn_SetWindowPlanes
	.public FieldMoveCutIn_SetWindowOutsidePlanes
	.public FieldMoveCutIn_SetWindowRect
	.public FieldMoveCutIn_CreateWindowTask
	.public FieldMoveCutIn_DestroyWindowTask
	.public FieldMoveCutIn_LoadMonPltt
	.public CutInScrollSprite_Destroy
	.public CutInScrollSprite_Draw
	.public FieldMoveCutIn_GetFlyerStatus
	.public FieldMoveCutIn_DestroyFlyer
	.public CutInFlyer_Destroy
	.public CutInFlyer_Draw
	.public CutInFlyer_Hide
	.public CutInFlyer_Idle
	.public CutInFlyer_Done
	.public TrainerJumpEffect_Stop
	.public TrainerJumpEffect_Init
	.public FlyLanding_Start
	.public FlyLanding_IsDone
	.public FlyLanding_Delete
	.public FlyLanding_SetPlayerVisible
	.public FlyLanding_Idle
	.public FlyLanding_AllocZeroed
	.public FieldMoveCutIn_SetPlayerVisible
	.public FieldMoveCutIn_DestroyTrainerClipEffect
	.public CutInModelEffect_Destroy
	.public CutInModelEffect_Draw
	.public PCProp_PlayPowerOnAnimation
	.public PCProp_PlayPowerOffAnimation
	.public FieldEscapeRope_Warp
	.public FieldMoveTask_CreateArrivalEnvironment
	.public FieldMove_WaitCutIn
	.public FieldMoveTaskEnvironment_New
	.public FieldTeleport_FollowMonFlash
	.public FieldDig_Warp
	.public Field3dObject_SetPosAtPlayer
	.public FieldMoveEffectModel_Draw
	.public CutEffect_Destroy
	.public CutEffect_Render
	.public CutEffect_CreateAtPlayer
	.public CutEffect_CreateAtFollower
	.public CutEffect_Delete
	.public CutEffect_IsFinished
	.public RockSmashEffect_Destroy
	.public RockSmashEffect_Render
	.public RockSmashEffect_CreateAtPlayer
	.public RockSmashEffect_CreateAtFollower
	.public RockSmashEffect_Delete
	.public RockSmashEffect_IsFinished
	.public WaterfallEffect_Create
	.public WaterfallEffect_Delete
	.public WhirlpoolEffect_Destroy
	.public WhirlpoolEffect_Update
	.public WhirlpoolEffect_Render
	.public WhirlpoolEffect_Create
	.public WhirlpoolEffect_Delete
	.public RockClimbDebris_Create
	.public RockClimbDebris_Delete
	.public HeadbuttEffect_Destroy
	.public HeadbuttEffect_Render
	.public HeadbuttEffect_CreateAtPlayer
	.public HeadbuttEffect_CreateAtFollower
	.public HeadbuttEffect_Delete
	.public HeadbuttEffect_IsFinished
	.public RockDebris_InitWithFollower
	.public RockDebris_Create
	.public RockDebris_CreateWithFollower
	.public RockDebris_Delete
	.public MapObjects_SwapPositions
	.public SwapPositions_CreateTaskEnv
	.public MapId_IsSafariZone
	.public SafariZone_GetAreaIndexAt
	.public FieldSystem_GetSafariAreaIndex
	.public SafariZone_CanPlaceObjectOnLand
	.public SafariZone_CanPlaceObjectOnWater
	.public FollowMonSituation_SetMapId
	.public FollowMonSituation_SetMood
	.public FollowMonInteraction_New
	.public FollowMonInteraction_Delete
	.public FollowMonInteraction_StepHasMovement
	.public FollowMonInteraction_StepHasWait
	.public FollowMon_StartGrowAndShrink


    .rodata

sFlyLandingIdleSteps:
	.word FlyLandingEffect_Idle

sCutInTrainerPlttFiles: ; 0x022532FC
	.byte 0x07, 0x00, 0x08, 0x00

sCutInFlyerHideSteps:
	.word CutInFlyer_Hide

sCutInTrainerCharFiles: ; 0x02253304
	.byte 0x11, 0x00, 0x14, 0x00, 0x17, 0x00

sCutInTrainerAnimFiles: ; 0x0225330A
	.byte 0x13, 0x00, 0x16, 0x00, 0x19, 0x00

sCutInTrainerCellFiles: ; 0x02253310
	.byte 0x12, 0x00, 0x15, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00

sFlyLandingPhases: ; 0x02253320
	.word sFlyLandingIdleSteps, sFlyLandingSteps, 0x01, 0x0F

sCutInFlyerTakeOffSteps:
	.word CutInFlyer_TakeOff, CutInFlyer_Idle, 0x00, 0x06
	.byte 0x01, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00

sCutInFlyWithObjectTrainerPos: ; 0x02253348
	.byte 0x00, 0x00, 0x08, 0x00, 0x00, 0x40, 0x05, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sCutInFlyerPickUpPos: ; 0x02253354
	.byte 0x00, 0x00, 0x08, 0x00, 0x00, 0x80, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

sFlyLandingFlyerScale: ; 0x02253360
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sCutInFlyerPickUpScale: ; 0x0225336C
	.byte 0x00, 0x14, 0x00, 0x00
	.byte 0x00, 0x14, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sCutInFlyerTrainerScale: ; 0x02253378
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sCutInMonPos: ; 0x02253384
	.byte 0x00, 0x80, 0x12, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

sCutInFlyerScale: ; 0x02253390
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sFlyLandingSwoopCenter: ; 0x0225339C
	.byte 0x00, 0x00, 0x08, 0x00
	.byte 0x00, 0xF0, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

sFlyLandingTrainerScale: ; 0x022533A8
	.byte 0x00, 0x20, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sFlyLandingFlyAwayScale: ; 0x022533B4
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sCutInFlyerModeSteps: ; 0x022533C0
	.word sCutInFlyerHideSteps
	.word sCutInFlyerTakeOffSteps
	.word sCutInFlyerPickUpSteps

sFlyLandingSwoopScale: ; 0x022533CC
	.byte 0x00, 0x20, 0x00, 0x00
	.byte 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sFlyLandingFlyAwayCenter: ; 0x022533D8
	.byte 0x00, 0x80, 0x08, 0x00, 0x00, 0xF0, 0x04, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sCutInFlyerTakeOffOrigin: ; 0x022533E4
	.byte 0x00, 0x80, 0x08, 0x00, 0x00, 0x80, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00

sCutInFlyerTakeOffScale: ; 0x022533F0
	.byte 0x00, 0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sCutInFlyTrainerPos: ; 0x022533FC
	.byte 0x00, 0x00, 0x08, 0x00
	.byte 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

sCutInTrainerPos: ; 0x02253408
	.byte 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x06, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sCutInFlyMonPos: ; 0x02253414
	.byte 0x00, 0x80, 0x12, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00

sCutInFlyerPickUpSteps:
	.word CutInFlyer_SwoopDown, CutInFlyer_PickUpTrainer, CutInFlyer_FlyAway, CutInFlyer_Done

sTrainerHopOffsets: ; 0x02253430
	.byte 0x00, 0xC0, 0xFF, 0xFF, 0x00, 0xA0, 0xFF, 0xFF, 0x00, 0x90, 0xFF, 0xFF, 0x00, 0x80, 0xFF, 0xFF

sTrainerClipEffectTemplate: ; 0x02253440
	.byte 0x08, 0x00, 0x00, 0x00
	.word TrainerClipEffect_Init
	.word FieldEffect_DefaultDestroy
	.word TrainerClipEffect_Update
	.word FieldEffect_DefaultDraw

sFlyLandingEffectTemplate: ; 0x02253454
	.byte 0x74, 0x00, 0x00, 0x00
	.word FlyLandingEffect_Init
	.word FlyLandingEffect_Destroy
	.word FlyLandingEffect_Update
	.word FieldEffect_DefaultDraw

sCutInScrollSpriteEffectTemplate: ; 0x02253468
	.byte 0x24, 0x00, 0x00, 0x00
	.word CutInScrollSprite_Init
	.word CutInScrollSprite_Destroy
	.word CutInScrollSprite_Update
	.word CutInScrollSprite_Draw

sCutInFlyerEffectTemplate: ; 0x0225347C
	.byte 0x68, 0x00, 0x00, 0x00
	.word CutInFlyer_Init
	.word CutInFlyer_Destroy
	.word CutInFlyer_Update
	.word CutInFlyer_Draw

sCutInModelEffectTemplate: ; 0x02253490
	.byte 0x0C, 0x00, 0x00, 0x00
	.word CutInModelEffect_Init
	.word CutInModelEffect_Destroy
	.word CutInModelEffect_Update
	.word CutInModelEffect_Draw

sTrainerJumpEffectTemplate: ; 0x022534A4
	.byte 0x24, 0x00, 0x00, 0x00
	.word TrainerJumpEffect_Init
	.word FieldEffect_DefaultDestroy
	.word TrainerJumpEffect_Update
	.word FieldEffect_DefaultDraw

sFlyLandingTaskSteps: ; 0x022534B8
	.word FlyLanding_SetPlayerVisible
	.word FlyLanding_LoadGraphics
	.word FlyLanding_CreateSprites
	.word FlyLanding_WaitLanding
	.word FlyLanding_FreeGraphics
	.word FlyLanding_Idle

sFlyLandingSteps:
	.word FlyLandingEffect_SwoopIn
	.word FlyLandingEffect_StartClimb
	.word FlyLandingEffect_Climb
	.word FlyLandingEffect_HideFlyer
	.word FlyLandingEffect_StartFlyAway
	.word FlyLandingEffect_FlyAway
	.word FlyLandingEffect_ShowPlayer
	.word FlyLandingEffect_Done

sFieldMoveCutInFlyWithObjectSteps: ; 0x022534F0
	.word FieldMoveCutIn_StepLoadSpriteGraphics
	.word FieldMoveCutIn_StepCreateFlyTrainerSprite
	.word FieldMoveCutIn_StepShowOtherObject
	.word FieldMoveCutIn_StepWaitModelEffect
	.word FieldMoveCutIn_StepLoadFlyGraphics
	.word FieldMoveCutIn_StepWaitFlyGraphics
	.word FieldMoveCutIn_StepWaitBeforeFlyAwayWithObject
	.word FieldMoveCutIn_StepWaitFlyAway
	.word FieldMoveCutIn_StepWaitFlyEnd
	.word FieldMoveCutIn_StepWaitPaletteFade
	.word FieldMoveCutIn_StepFreeSpriteGraphics
	.word FieldMoveCutIn_StepFinish

sTrainerJumpOffsets: ; 0x02253520
	.byte 0x00, 0x40, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0xC0, 0xFE, 0xFF, 0x00, 0x80, 0xFE, 0xFF
	.byte 0x00, 0x60, 0xFE, 0xFF, 0x00, 0x40, 0xFE, 0xFF, 0x00, 0x40, 0xFE, 0xFF, 0x00, 0x40, 0xFE, 0xFF
	.byte 0x00, 0x60, 0xFE, 0xFF, 0x00, 0x80, 0xFE, 0xFF, 0x00, 0xA0, 0xFE, 0xFF, 0x00, 0xC0, 0xFE, 0xFF

sFieldMoveCutInSteps: ; 0x02253550
	.word FieldMoveCutIn_StepLoadBannerGraphics
	.word FieldMoveCutIn_StepCreateSprites
	.word FieldMoveCutIn_StepInitWindow
	.word FieldMoveCutIn_StepWidenWindow
	.word FieldMoveCutIn_StepOpenWindow
	.word FieldMoveCutIn_StepWaitBeforeMon
	.word FieldMoveCutIn_StepMonSlideIn
	.word FieldMoveCutIn_StepMonSlowDown
	.word FieldMoveCutIn_StepWaitBeforeMonExit
	.word FieldMoveCutIn_StepMonSlideOut
	.word FieldMoveCutIn_StepCloseWindow
	.word FieldMoveCutIn_StepFreeBannerGraphics
	.word FieldMoveCutIn_StepEndWindow
	.word FieldMoveCutIn_StepFinish

sFieldMoveCutInFlySteps: ; 0x02253588
	.word FieldMoveCutIn_StepLoadBannerGraphics
	.word FieldMoveCutIn_StepCreateFlySprites
	.word FieldMoveCutIn_StepInitWindow
	.word FieldMoveCutIn_StepWidenWindow
	.word FieldMoveCutIn_StepOpenWindow
	.word FieldMoveCutIn_StepWaitBeforeMon
	.word FieldMoveCutIn_StepMonSlideIn
	.word FieldMoveCutIn_StepMonSlowDown
	.word FieldMoveCutIn_StepWaitBeforeMonExit
	.word FieldMoveCutIn_StepMonSlideOut
	.word FieldMoveCutIn_StepFreeMonGraphics
	.word FieldMoveCutIn_StepLoadFlyGraphics
	.word FieldMoveCutIn_StepWaitFlyGraphics
	.word FieldMoveCutIn_StepStartFly
	.word FieldMoveCutIn_StepWaitTakeOff
	.word FieldMoveCutIn_StepWaitBeforeFlyAway
	.word FieldMoveCutIn_StepWaitFlyAway
	.word FieldMoveCutIn_StepCloseFlyWindow
	.word FieldMoveCutIn_StepWaitFlyEnd
	.word FieldMoveCutIn_StepWaitPaletteFade
	.word FieldMoveCutIn_StepFreeBannerGraphics
	.word FieldMoveCutIn_StepEndWindow
	.word FieldMoveCutIn_StepFinish

sCutInScrollSpriteTemplates: ; 0x022535E4
	.byte 0x00, 0xF0, 0x00, 0x00, 0x00, 0xF0, 0x03, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x85, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC0, 0x04, 0x00, 0x00, 0x30, 0x04, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00
	.byte 0x00, 0xD0, 0x03, 0x00, 0x00, 0x80, 0x01, 0x00, 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x0F, 0x00, 0x00, 0x50, 0x04, 0x00, 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x02, 0x00, 0x00, 0xE0, 0x04, 0x00, 0x00, 0x80, 0x01, 0x00
	.byte 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x80, 0x04, 0x00, 0x00, 0xB0, 0x05, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0D, 0x00
	.byte 0x00, 0x60, 0x05, 0x00, 0x00, 0x80, 0x01, 0x00, 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x80, 0x03, 0x00, 0x00, 0x40, 0x07, 0x00, 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0xF0, 0x05, 0x00, 0x00, 0xD0, 0x06, 0x00, 0x00, 0x80, 0x01, 0x00
	.byte 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0xF0, 0x09, 0x00, 0x00, 0x40, 0x06, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x85, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x01, 0x00
	.byte 0x00, 0xE0, 0x07, 0x00, 0x00, 0x80, 0x01, 0x00, 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0xC0, 0x08, 0x00, 0x00, 0xD0, 0x07, 0x00, 0x00, 0x80, 0x01, 0x00, 0x80, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0xD0, 0x0D, 0x00, 0x00, 0xC0, 0x07, 0x00, 0x00, 0x80, 0x01, 0x00
	.byte 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00

sPCPropModels: ; 0x022536E8
	.byte 0x21, 0x00, 0x00, 0x00, 0x8A, 0x00, 0x00, 0x00

sFieldMoveArrivalSteps: ; 0x022536F0
	.word FieldMoveArrival_FadeIn
	.word FieldMoveArrival_WaitFadeIn
	.word FieldMoveArrival_Spin
	.word FieldMoveArrival_Finish

sEscapeRopeSteps: ; 0x02253700
	.word FieldEscapeRope_SpinStart
	.word FieldEscapeRope_SpinAndFadeOut
	.word FieldEscapeRope_WaitFadeOut
	.word FieldEscapeRope_Warp

sDigWithFollowMonSteps: ; 0x02253710
	.word FieldDig_SinkStart
	.word FieldDig_DigHole
	.word FieldDig_SpinAndFadeOut
	.word FieldDig_WaitFadeOut
	.word FieldDig_Warp

sTeleportSteps: ; 0x02253724
	.word FieldMove_ShowCutIn
	.word FieldMove_WaitCutIn
	.word FieldTeleport_SpinStart
	.word FieldTeleport_SpinAndFadeOut
	.word FieldTeleport_WaitFadeOut
	.word FieldTeleport_Warp

sTeleportWithFollowMonSteps: ; 0x0225373C
	.word FieldTeleport_FollowMonFlash
	.word FieldTeleport_FollowMonSpinStart
	.word FieldTeleport_FollowMonWaitSpin
	.word FieldTeleport_SpinAndFadeOut
	.word FieldTeleport_WaitFadeOut
	.word FieldTeleport_Warp

sDigSteps: ; 0x02253754
	.word FieldMove_ShowCutIn
	.word FieldMove_WaitCutIn
	.word FieldDig_SinkStart
	.word FieldDig_DigHole
	.word FieldDig_SpinAndFadeOut
	.word FieldDig_WaitFadeOut
	.word FieldDig_Warp

sTeleportFollowMonSpinMovement: ; 0x02253770
	.byte 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00
	.byte 0xFE, 0x00, 0x00, 0x00

sEscapeRopeSpinMovement: ; 0x02253794
	.byte 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
	.byte 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00
	.byte 0x02, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

sDigHoleMovement: ; 0x022537B8
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

sDigSinkMovement: ; 0x022537DC
	.byte 0x01, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x02, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x02, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x01, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

sEscapeRopeSpinStartMovement: ; 0x02253820
	.byte 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00
	.byte 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00
	.byte 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00
	.byte 0xFE, 0x00, 0x00, 0x00

sArrivalSpinMovement: ; 0x02253884
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00
	.byte 0x03, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x02, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x01, 0x00, 0x03, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x01, 0x00, 0x01, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x02, 0x00, 0x02, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x03, 0x00, 0x00, 0x00, 0x01, 0x00, 0x3C, 0x00, 0x04, 0x00, 0x03, 0x00, 0x01, 0x00
	.byte 0x3C, 0x00, 0x05, 0x00, 0x01, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

sRideEffectFileIds: ; 0x022538EC
	.byte 0x10, 0x0F, 0x0E, 0x0B
	.byte 0x0C, 0x09, 0xB4, 0x00, 0x00, 0x00, 0x0E, 0x01, 0x5A, 0x00, 0x00, 0x00

sRockSmashEffectAtPlayerTemplate: ; 0x022538FC
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word RockSmashEffect_InitAtPlayer
	.word RockSmashEffect_Destroy
	.word RockSmashEffect_Update
	.word RockSmashEffect_Render

sWhirlpoolEffectTemplate: ; 0x02253914
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word WhirlpoolEffect_Init
	.word WhirlpoolEffect_Destroy
	.word WhirlpoolEffect_Update
	.word WhirlpoolEffect_Render

sHeadbuttEffectAtFollowerTemplate: ; 0x0225392C
	.byte 0x00, 0x04, 0x00, 0x00, 0x14, 0x01, 0x00, 0x00
	.word HeadbuttEffect_InitAtFollower
	.word HeadbuttEffect_Destroy
	.word HeadbuttEffect_Update
	.word HeadbuttEffect_Render

sWaterfallEffectTemplate: ; 0x02253944
	.byte 0x00, 0x04, 0x00, 0x00, 0xCC, 0x01, 0x00, 0x00
	.word WaterfallEffect_Init
	.word WaterfallEffect_Destroy
	.word WaterfallEffect_Update
	.word WaterfallEffect_Render

sRockClimbDebrisTemplate: ; 0x0225395C
	.byte 0x00, 0x04, 0x00, 0x00, 0x10, 0x0D, 0x00, 0x00
	.word RockClimbDebris_Init
	.word RockClimbDebris_Destroy
	.word RockClimbDebris_Update
	.word RockClimbDebris_Render

sCutEffectAtPlayerTemplate: ; 0x02253974
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word CutEffect_InitAtPlayer
	.word CutEffect_Destroy
	.word CutEffect_Update
	.word CutEffect_Render

sRockSmashEffectAtFollowerTemplate: ; 0x0225398C
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word RockSmashEffect_InitAtFollower
	.word RockSmashEffect_Destroy
	.word RockSmashEffect_Update
	.word RockSmashEffect_Render

sHeadbuttEffectAtPlayerTemplate: ; 0x022539A4
	.byte 0x00, 0x04, 0x00, 0x00, 0x14, 0x01, 0x00, 0x00
	.word HeadbuttEffect_InitAtPlayer
	.word HeadbuttEffect_Destroy
	.word HeadbuttEffect_Update
	.word HeadbuttEffect_Render

sCutEffectAtFollowerTemplate: ; 0x022539BC
	.byte 0x00, 0x04, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00
	.word CutEffect_InitAtFollower
	.word CutEffect_Destroy
	.word CutEffect_Update
	.word CutEffect_Render

sRockDebrisTemplate: ; 0x022539D4
	.byte 0x00, 0x04, 0x00, 0x00, 0x9C, 0x0E, 0x00, 0x00
	.word RockDebris_Init
	.word RockDebris_Destroy
	.word RockDebris_Update
	.word RockDebris_Render

sRockDebrisWithFollowerTemplate: ; 0x022539EC
	.byte 0x00, 0x04, 0x00, 0x00, 0x9C, 0x0E, 0x00, 0x00
	.word RockDebris_InitWithFollower
	.word RockDebris_Destroy
	.word RockDebris_Update
	.word RockDebris_Render

sScriptFieldMoveEffectDeleteFuncs: ; 0x02253A04
	.word CutEffect_Delete
	.word RockSmashEffect_Delete
	.word RockSmashEffect_Delete
	.word CutEffect_Delete
	.word HeadbuttEffect_Delete
	.word HeadbuttEffect_Delete

sScriptFieldMoveEffectCreateFuncs: ; 0x02253A1C
	.word CutEffect_CreateAtPlayer
	.word RockSmashEffect_CreateAtPlayer
	.word RockSmashEffect_CreateAtFollower
	.word CutEffect_CreateAtFollower
	.word HeadbuttEffect_CreateAtPlayer
	.word HeadbuttEffect_CreateAtFollower

sScriptFieldMoveEffectIsFinishedFuncs: ; 0x02253A34
	.word CutEffect_IsFinished
	.word RockSmashEffect_IsFinished
	.word RockSmashEffect_IsFinished
	.word CutEffect_IsFinished
	.word HeadbuttEffect_IsFinished
	.word HeadbuttEffect_IsFinished

gSafariZonePlacementOffsets: ; 0x02253A4C
	.byte 0xFF, 0x01, 0xFF, 0x01
	.byte 0x01, 0xFF, 0x00, 0x00

sShinyLeafMasks: ; 0x02253A54
	.byte 0x01, 0x02, 0x04, 0x08, 0x10, 0x00, 0x00, 0x00

sShinyLeafMonDataIds: ; 0x02253A5C
	.byte 0xB5, 0x00, 0x00, 0x00
	.byte 0xB6, 0x00, 0x00, 0x00, 0xB7, 0x00, 0x00, 0x00, 0xB8, 0x00, 0x00, 0x00, 0xB9, 0x00, 0x00, 0x00

sFollowMonJumpOnSpotMovements: ; 0x02253A70
	.byte 0x49, 0x00, 0x01, 0x00, 0x30, 0x00, 0x01, 0x00, 0x3E, 0x00, 0x01, 0x00, 0x4A, 0x00, 0x01, 0x00
	.byte 0xFE, 0x00, 0x00, 0x00, 0x49, 0x00, 0x01, 0x00, 0x31, 0x00, 0x01, 0x00, 0x3E, 0x00, 0x01, 0x00
	.byte 0x4A, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00, 0x49, 0x00, 0x01, 0x00, 0x32, 0x00, 0x01, 0x00
	.byte 0x3E, 0x00, 0x01, 0x00, 0x4A, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00, 0x49, 0x00, 0x01, 0x00
	.byte 0x33, 0x00, 0x01, 0x00, 0x3E, 0x00, 0x01, 0x00, 0x4A, 0x00, 0x01, 0x00, 0xFE, 0x00, 0x00, 0x00

sNatureGroups: ; 0x02253AC0
	.byte 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x06, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x06, 0x00, 0x00, 0x00

sFollowMonGrowScale: ; 0x02253B24
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00

sFollowMonShrinkScale: ; 0x02253B30
	.byte 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00

	.data

sHealingMachineBallOffsets: ; 0x02253D90
	.byte 0x00, 0xB8, 0xFF, 0xFF

sHealingMachineBallOffsetsY: ; 0x02253D94
	.byte 0x00, 0xC0, 0x00, 0x00

sHealingMachineBallOffsetsZ: ; 0x02253D98
	.byte 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0x48, 0x00, 0x00
	.byte 0x00, 0xC0, 0x00, 0x00, 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xC0, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00
	.byte 0x00, 0xC0, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00

sHallOfFameBallOffsets: ; 0x02253DD8
	.byte 0x00, 0xB8, 0xFF, 0xFF

ov02_02253DDC: ; 0x02253DDC
	.byte 0x00, 0xC0, 0x00, 0x00

ov02_02253DE0: ; 0x02253DE0
	.byte 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0x48, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0xB8, 0xFF, 0xFF
	.byte 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00
	.byte 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB8, 0xFF, 0xFF, 0x00, 0xC0, 0x00, 0x00
	.byte 0x00, 0x48, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00
_02253E20:
