#include "constants/sndseq.h"
#include "constants/moves.h"
#include "constants/std_script.h"
#include "constants/species.h"
#include "constants/sprites.h"
#include "constants/maps.h"
#include "constants/mmodel.h"
#include "constants/items.h"
#include "msgdata/msg/msg_0096_D31R0201.h"
#include "msgdata/msg/msg_0066_D23R0102.h"
	.include "asm/macros.inc"
	.include "overlay_01_data_02208BFC.inc"
	.include "global.inc"

	.rodata

	.public defaultFieldEffectRenderers
defaultFieldEffectRenderers: ; 0x02208BFC
	.word 0x14
	.word 0x13
	.word 0x11
	.word 0x01
	.word 0x10
	.word 0x05
	.word 0x16
	.word 0x08
	.word 0x09
	.word 0x0A
	.word 0x0B
	.word 0x0C
	.word 0x0D
	.word 0x0F
	.word 0x12
	.word 0x00
	.word 0x02
	.word 0x03
	.word 0x04
	.word 0x0E
	.word 0x06
	.word 0x07
	.word 0x15
	.word 0x17

	.public gFieldEffectRenderers
gFieldEffectRenderers: ; 0x02208C5C
	.word 0x00000000, FieldShadow_New, FieldShadow_Free
	.word 0x00000001, Reflection_New, Reflection_Free
	.word 0x00000002, Footprints_New, Footprints_Free
	.word 0x00000003, WarpArrow_New, WarpArrow_Free
	.word 0x00000004, SurfMount_New, SurfMount_Free
	.word 0x00000005, RockClimb_New, RockClimb_Free
	.word 0x00000006, PuddleSplash_New, PuddleSplash_Free
	.word 0x00000007, MudSplash_New, MudSplash_Free
	.word 0x00000008, TallGrass_New, TallGrass_Free
	.word 0x00000009, EmoteMark_New, EmoteMark_Free
	.word 0x0000000A, ShallowWaterRipple_New, ShallowWaterRipple_Free
	.word 0x0000000B, GroundDust_New, GroundDust_Free
	.word 0x0000000C, VeryTallGrass_New, VeryTallGrass_Free
	.word 0x0000000D, UnusedBillboard_New, UnusedBillboard_Free
	.word 0x0000000E, HiddenObjectCover_New, HiddenObjectCover_Free
	.word 0x0000000F, TrainerReveal_New, TrainerReveal_Free
	.word 0x00000010, ApricornRegrowth_New, ApricornRegrowth_Free
	.word 0x00000011, FollowMonBall_New, FollowMonBall_Free
	.word 0x00000012, EmoteBubble_New, EmoteBubble_Free
	.word 0x00000013, FlashDarkness_New, FlashDarkness_Free
	.word 0x00000014, MapObjectModelList_New, MapObjectModelList_Free
	.word 0x00000015, UnionChatMarker_New, UnionChatMarker_Free
	.word 0x00000016, ShayminFormChange_New, ShayminFormChange_Free
	.word 0x00000017, 0x00000000, 0x00000000
