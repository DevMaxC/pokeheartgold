	.include "asm/macros.inc"
	.public _0223DE10
	.public _0223DE34
	.public _0223DE4C
	.public _0223DE5A
	.public _0223DE5C
	.public _0223DE84
	.public _0223DE90
	.public _0223DE94
	.public _0223DE98
	.public _0223DE9C
	.public _0223DEA0
	.public _0223DEA4
	.public _0223DECC
	.public _0223DEE0
	.public _0223DEF0
	.public _0223DF08
	.public _0223DF26
	.public _0223DF3C
	.public _0223DF52
	.public _0223DF56
	.public _0223DF78
	.public _0223DF84
	.public _0223DF94
	.public _0223DF96
	.public _0223DFAC
	.public _0223DFC4
	.public _0223DFDA
	.public _0223DFE6
	.public _0223E00E
	.public _0223E01A
	.public _0223E030
	.public _0223E050
	.public _0223E06E
	.public _0223E07A
	.public _0223E0A2
	.public _0223E0C0
	.public _0223E0CC
	.public _0223E0D6
	.public _0223E0D8
	.public _0223E0F6
	.public _0223E108
	.public _0223E11E
	.public _0223E12A
	.public _0223E152
	.public _0223E170
	.public _0223E17C
	.public _0223E1A0
	.public _0223E1A4
	.public _0223E1B6
	.public _0223E1D4
	.public _0223E1E0
	.public _0223E1F6
	.public _0223E204
	.public _0223E218
	.public _0223E230
	.public _0223E260
	.public _0223E27C
	.public _0223E29A
	.public _0223E2A8
	.public _0223E2CE
	.public _0223E308
	.public _0223E30C
	.public _0223E310
	.public _0223E314
	.public _0223E330
	.public _0223E33E
	.public _0223E352
	.public _0223E35A
	.public _0223E37A
	.public _0223E382
	.public _0223E390
	.public _0223E3AA
	.public _0223E3E6
	.public _0223E3EE
	.public _0223E3F0
	.public _0223E402
	.public _0223E426
	.public _0223E438
	.public _0223E450
	.public _0223E46A
	.public _0223E4A8
	.public _0223E4B6
	.public _0223E4CE
	.public _0223E4E2
	.public _0223E508
	.public _0223E510
	.public _0223E514
	.public _0223E518
	.public _0223E51C
	.public _0223E532
	.public _0223E544
	.public _0223E54A
	.public _0223E56C
	.public _0223E58E
	.public _0223E59E
	.public _0223E5AC
	.public _0223E6FA
	.public _0223E740
	.public _0223E78A
	.public _0223E79E
	.public _0223E804
	.public _0223E844
	.public _0223E85A
	.public _0223E860
	.public _0223E864
	.public _0223E868
	.public _0223E86C
	.public _0223E870
	.public _0223E874
	.public _0223E878
	.public _0223E88E
	.public _0223E8AE
	.public _0223EA20
	.public _0223EA38
	.public _0223EA70
	.public _0223EA88
	.public _0223EA8C
	.public _0223EA90
	.public _0223EA94
	.public _0223EBD8
	.public _0223EBDC
	.public _0223EBE0
	.public _0223EBF6
	.public _0223EC36
	.public _0223EC40
	.public _0223EC5C
	.public _0223EC80
	.public _0223EC84
	.public _0223ECDA
	.public _0223ECE0
	.public _0223ECFC
	.public _0223ED0E
	.public _0223ED1C
	.public _0223ED40
	.public _0223ED52
	.public _0223ED5A
	.public _0223ED5C
	.public _0223ED92
	.public _0223EDAA
	.public _0223EDC2
	.public _0223EDDA
	.public _0223EE12
	.public _0223EE30
	.public _0223EE38
	.public _0223EE58
	.public _0223EE5E
	.public _0223EE64
	.public _0223EE8C
	.public _0223EEB6
	.public _0223EEC2
	.public _0223EED0
	.public _0223EEF6
	.public _0223EF18
	.public _0223EF1E
	.public _0223EF32
	.public _0223EF38
	.public _0223EF42
	.public _0223EF48
	.public _0223EF4C
	.public _0223EF50
	.public _0223EF54
	.public _0223EF58
	.public _0223F034
	.public _0223F0AA
	.public _0223F0B8
	.public _0223F130
	.public _0223F156
	.public _0223F168
	.public _0223F1A0
	.public _0223F1C2
	.public _0223F1D2
	.public _0223F1F6
	.public _0223F202
	.public _0223F208
	.public _0223F214
	.public _0223F244
	.public _0223F254
	.public _0223F256
	.public _0223F26E
	.public _0223F2BE
	.public _0223F2C2
	.public _0223F2D0
	.public _0223F2FA
	.public _0223F30C
	.public _0223F310
	.public _0223F388
	.public _0223F3A4
	.public _0223F3B8
	.public _0223F3CC
	.public _0223F3F0
	.public _0223F3FE
	.public _0223F408
	.public _0223F40A
	.public _0223F44C
	.public _0223F464
	.public _0223F47C
	.public _0223F494
	.public _0223F4DC
	.public _0223F51C
	.public _0223F540
	.public _0223F548
	.public _0223F56E
	.public _0223F592
	.public _0223F598
	.public _0223F5C0
	.public _0223F5EA
	.public _0223F5F6
	.public _0223F604
	.public _0223F616
	.public _0223F63C
	.public _0223F652
	.public _0223F666
	.public _0223F66C
	.public _0223F670
	.public _0223F674
	.public _0223F678
	.public _0223F67C
	.public _0223F680
	.public _0223F6A4
	.public _0223F6BC
	.public _0223F6DE
	.public _0223F6F0
	.public _0223F714
	.public _0223F71C
	.public _0223F746
	.public _0223F74A
	.public _0223F750
	.public _0223F786
	.public _0223F798
	.public _0223F7BC
	.public _0223F7D2
	.public _0223F7E2
	.public _0223F7F2
	.public _0223F7FC
	.public _0223F7FE
	.public _0223F84A
	.public _0223F8B8
	.public _0223F926
	.public _0223F93E
	.public _0223F956
	.public _0223F9C4
	.public _0223FA02
	.public _0223FA28
	.public _0223FA4A
	.public _0223FA5A
	.public _0223FA5C
	.public _0223FA86
	.public _0223FA8E
	.public _0223FABC
	.public _0223FAC0
	.public _0223FAC6
	.public _0223FAD4
	.public _0223FAE4
	.public _0223FB10
	.public _0223FB14
	.public _0223FB18
	.public _0223FB1C
	.public _0223FB20
	.public _0223FB24
	.public _0223FB38
	.public _0223FB60
	.public _0223FB84
	.public _0223FBC0
	.public _0223FBE2
	.public _0223FBF4
	.public _0223FC20
	.public _0223FC28
	.public _0223FC52
	.public _0223FC56
	.public _0223FC5C
	.public _0223FC90
	.public _0223FC9E
	.public _0223FD3C
	.public _0223FD48
	.public _0223FD4A
	.public _0223FD58
	.public _0223FD6C
	.public _0223FDC2
	.public _0223FE14
	.public _0223FE3C
	.public _0223FE5A
	.public _0223FE70
	.public _0223FE74
	.public _0223FE88
	.public _0223FE98
	.public _0223FEAA
	.public _0223FEB4
	.public _0223FEB6
	.public _0223FED2
	.public _0223FEE4
	.public _0223FF0C
	.public _0223FF26
	.public _0223FF4A
	.public _0223FF60
	.public _0223FF6E
	.public _0223FF82
	.public _0223FF8E
	.public _0223FF96
	.public _0223FFAA
	.public _0223FFE4
	.public _0223FFEC
	.public _0223FFF0
	.public _0223FFF4
	.public _0223FFF8
	.public _0223FFFC
	.public _02240000
	.public _02240004
	.public _02240018
	.public _02240030
	.public _02240040
	.public _02240044
	.public _02240058
	.public _02240072
	.public _02240084
	.public _0224009A
	.public _022400BA
	.public _022400C8
	.public _022400E2
	.public _02240114
	.public _022401AC
	.public _022401C0
	.public _022401EA
	.public _02240204
	.public _02240208
	.public _0224020C
	.public _0224021A
	.public _0224022C
	.public _0224039C
	.public _022403A0
	.public _022403A4
	.public _022403A8
	.public _022403AC
	.public _022403B0
	.public _022403B4
	.public _022403B8
	.public _022403BC
	.public _02240426
	.public _022404DE
	.public _0224052E
	.public _02240540
	.public _0224054A
	.public _0224055C
	.public _0224058C
	.public _022405BA
	.public _022405CC
	.public _022405D6
	.public _022405E8
	.public _02240608
	.public _0224061E
	.public _0224066C
	.public _02240678
	.public _0224067C
	.public _02240680
	.public _02240684
	.public _02240688
	.public _0224068A
	.public _022408C0
	.public _02240908
	.public _0224090C
	.public _02240938
	.public _0224097C
	.public _02240980
	.public _022409AC
	.public _02240A96
	.public _02240AC8
	.public _02240AD4
	.public _02240B58
	.public _02240B5C
	.public _02240B68
	.public _02240B6C
	.public _02240BA0
	.public _02240BAC
	.public _02240BC6
	.public _02240BD6
	.public _02240BE0
	.public _02240C62
	.public _02240C6C
	.public _02240C9A
	.public _02240D1E
	.public _02240D24
	.public _02240D28
	.public _02240D5C
	.public _02240D60
	.public _02240DBE
	.public _02240E26
	.public _02240E40
	.public _02240E4C
	.public _02240E74
	.public _02240F04
	.public _02240F34
	.public _02240FA0
	.public _02240FBA
	.public _02240FC8
	.public _02240FD4
	.public _02240FE2
	.public _02240FEE
	.public _02241004
	.public _0224103C
	.public _02241062
	.public _0224108C
	.public _0224109C
	.public _022410C6
	.public _022410F6
	.public _02241106
	.public _02241116
	.public _02241126
	.public _0224112C
	.public _02241130
	.public _02241134
	.public _02241138
	.public _02241180
	.public _02241196
	.public _022411D6
	.public _022411E8
	.public _02241200
	.public _0224120C
	.public _02241210
	.public _02241214
	.public _02241274
	.public _02241294
	.public _022412BA
	.public _022412BC
	.public _022412C0
	.public _022412E0
	.public _022412F6
	.public _02241308
	.public _02241312
	.public _02241320
	.public _02241324
	.public _02241328
	.public _0224132C
	.public _02241330
	.public _02241334
	.public _02241338
	.public _0224133C
	.public _0224137E
	.public _02241394
	.public _022413D2
	.public _022413DC
	.public _02241418
	.public _0224144C
	.public _02241498
	.public _022414A2
	.public _022414D8
	.public _022414DC
	.public _02241520
	.public _0224164C
	.public _0224169E
	.public _022416C8
	.public _0224171C
	.public _02241748
	.public _022417B0
	.public _02241800
	.public _02241838
	.public _0224183C
	.public _0224197C
	.public _022419DC
	.public _02241A34
	.public _02241A74
	.public _02241A78
	.public _02241BB4
	.public _02241C2A
	.public _02241C3E
	.public _02241C5A
	.public _02241C76
	.public _02241C7C
	.public _02241C80
	.public _02241C90
	.public _02241C96
	.public _02241CC0
	.public _02241CD4
	.public _02241CE2
	.public _02241CE4
	.public _02241CE8
	.public _02241D18
	.public _02241D24
	.public _02241D34
	.public _02241D60
	.public _02241D88
	.public _02241D8C
	.public _02241D90
	.public _02241DB8
	.public _02241DD4
	.public _02241DD8
	.public _02241DF6
	.public _02241DFE
	.public _02241E0A
	.public _02241E5E
	.public _02241E64
	.public _02241EB0
	.public _02241ED8
	.public _02241F24
	.public _02241F4C
	.public _02241F68
	.public _02241F70
	.public _02241F7A
	.public _02241FB8
	.public _02241FBC
	.public _02241FD2
	.public _02241FE6
	.public _02241FE8
	.public _02242000
	.public _0224201C
	.public _0224203A
	.public _02242046
	.public _02242052
	.public _02242054
	.public _0224206A
	.public _02242084
	.public _02242090
	.public _022420A8
	.public _022420AC
	.public _022420B0
	.public _022420CA
	.public _022420D0
	.public _022420D4
	.public _02242124
	.public _0224212A
	.public _02242166
	.public _0224216C
	.public _0224217A
	.public _02242198
	.public _022421F8
	.public _02242208
	.public _022422FA
	.public _0224231A
	.public _0224232C
	.public _02242364
	.public _0224239C
	.public _022423A8
	.public _022423C8
	.public _022423CC
	.public _022423E6
	.public _02242416
	.public _0224241C
	.public _02242438
	.public _0224246E
	.public _0224249A
	.public _022424A4
	.public _022424A8
	.public _022424CC
	.public _0224255A
	.public _02242576
	.public _02242580
	.public _02242584
	.public _02242588
	.public _022425BC
	.public _022425C0
	.public _02242624
	.public _02242644
	.public _02242656
	.public _02242680
	.public _02242684
	.public _0224268C
	.public _02242690
	.public _022426BA
	.public _022426C6
	.public _022426D2
	.public _022426E4
	.public _022426F0
	.public _022426FA
	.public _022426FC
	.public _02242700
	.public _02242758
	.public _022427B0
	.public _022429C8
	.public _02242A60
	.public _02242A88
	.public _02242B00
	.public _02242B04
	.public _02242B1A
	.public _02242B42
	.public _02242B66
	.public _02242BC0
	.public _02242BC4
	.public _02242C30
	.public _02242C34
	.public _02242C38
	.public _02242C3C
	.public _02242C40
	.public _02242C44
	.public _02242C78
	.public _02242C7C
	.public _02242E42
	.public _02242E6A
	.public _02242FE4
	.public _02243008
	.public _02243064
	.public _02243086
	.public _02243096
	.public _0224313C
	.public _0224316A
	.public _02243172
	.public _02243184
	.public _02243196
	.public _022431D2
	.public _022431DC
	.public _022431F0
	.public _022431F4
	.public _02243264
	.public _02243268
	.public _0224326C
	.public _0224327E
	.public _022432D0
	.public _022432D4
	.public _022432D8
	.public _02243308
	.public _0224330C
	.public _02243310
	.public _0224332C
	.public _02243348
	.public _0224335A
	.public _0224338E
	.public _022433CA
	.public _022433E8
	.public _022433EC
	.public _022433F0
	.public _022433F4
	.public _022433F8
	.public _0224341C
	.public _02243430
	.public _02243442
	.public gBattleFactoryAppSummaryPages
	.public BattleFactoryApp_Init
	.public BattleFactoryApp_Main
	.public BattleFactoryApp_Exit
	.public BattleFactoryApp_SlideIn
	.public BattleFactoryApp_ShowScreen
	.public BattleFactoryApp_SetupRentalScreen
	.public BattleFactoryApp_CreateRentalBalls
	.public BattleFactoryApp_SetupSwapOutScreen
	.public BattleFactoryApp_SetupSwapInScreen
	.public BattleFactoryApp_CreateSwapBalls
	.public BattleFactoryApp_CreateSwapPokepics
	.public BattleFactoryApp_WaitSummary
	.public BattleFactoryApp_SelectRentals
	.public BattleFactoryApp_UndoLastRental
	.public BattleFactoryApp_AddRental
	.public BattleFactoryApp_RemoveRental
	.public BattleFactoryApp_ConfirmRentals
	.public BattleFactoryApp_DeselectCursorRental
	.public BattleFactoryApp_SelectSwapOut
	.public BattleFactoryApp_PickSwapOut
	.public BattleFactoryApp_ConfirmCancelSwap
	.public BattleFactoryApp_ResumeSwapOut
	.public BattleFactoryApp_SelectSwapIn
	.public BattleFactoryApp_UnpickSwapOut
	.public BattleFactoryApp_PickSwapIn
	.public BattleFactoryApp_ShowSwapInPrompt
	.public BattleFactoryApp_ConfirmCancelSwapIn
	.public BattleFactoryApp_SwitchPage
	.public BattleFactoryApp_LinkSendSwap
	.public BattleFactoryApp_LinkSync
	.public BattleFactoryApp_FadeOut
	.public BattleFactoryApp_ShowLinkTradeResult
	.public BattleFactoryApp_VBlankCallback
	.public BattleFactoryApp_SetGraphicsBanks
	.public BattleFactoryApp_InitBgLayers
	.public BattleFactoryApp_InitBgGraphics
	.public BattleFactoryApp_FreeBgLayers
	.public BattleFactoryApp_ScrollBallsIn
	.public BattleFactoryApp_ScrollBallsOut
	.public BattleFactoryApp_AnimateBackground
	.public BattleFactoryApp_SetBgPalette
	.public BattleFactoryApp_SetCenterAnim
	.public BattleFactoryApp_LoadBgGfx81
	.public BattleFactoryApp_LoadBgGfx92
	.public BattleFactoryApp_LoadBgGfx4
	.public BattleFactoryApp_LoadBgPalette
	.public BattleFactoryApp_LoadSubScreenBg
	.public BattleFactoryApp_PrintMessage
	.public BattleFactoryApp_ShowMessage
	.public BattleFactoryApp_BufferNumber
	.public BattleFactoryApp_BufferSpeciesName
	.public BattleFactoryApp_PrintPlayerName
	.public BattleFactoryApp_PrintPartnerName
	.public BattleFactoryApp_PrintMonName
	.public BattleFactoryApp_PrintPartnerMonName
	.public BattleFactoryApp_FreeGraphics
	.public BattleFactoryApp_ResumeAfterSummary
	.public BattleFactoryApp_DisableDisplay
	.public BattleFactoryApp_InitGraphics
	.public BattleFactoryApp_CreateSummaryArgs
	.public BattleFactoryApp_IsCancelRequested
	.public BattleFactoryApp_CreatePokepic
	.public BattleFactoryApp_SendLinkCommand
	.public BattleFactoryApp_PrepareLinkPing
	.public BattleFactory_ReceivePing
	.public BattleFactoryApp_PrepareLinkRentals
	.public BattleFactory_ReceiveRentals
	.public BattleFactoryApp_PrintPartnerRentals
	.public BattleFactory_ReceiveSwap
	.public BattleFactoryApp_CreateBall
	.public BattleFactoryApp_CreateCenterSprite
	.public BattleFactoryApp_DeleteCenterSprites
	.public BattleFactoryApp_InitWindows
	.public BattleFactoryApp_MoveRentalCursor
	.public BattleFactoryApp_MoveButtonCursor
	.public BattleFactoryApp_OpenRentalMenu
	.public BattleFactoryApp_CloseRentalMenu
	.public BattleFactoryApp_PrintRentalMenu
	.public BattleFactoryApp_MoveSwapOutCursor
	.public BattleFactoryApp_MoveSwapInCursor
	.public BattleFactoryApp_OpenSwapOutMenu
	.public BattleFactoryApp_CloseSwapOutMenu
	.public BattleFactoryApp_RedrawSwapOutButtons
	.public BattleFactoryApp_PrintSwapOutMenu
	.public BattleFactoryApp_OpenSwapInMenu
	.public BattleFactoryApp_CloseSwapInMenu
	.public BattleFactoryApp_RedrawSwapInButtons
	.public BattleFactoryApp_PrintSwapInMenu
	.public BattleFactoryApp_InitYesNo
	.public BattleFactoryApp_UpdatePreviewPokepic
	.public BattleFactory_GetPokepicPos
	.public BattleFactoryApp_GetCursorPokepicPos
	.public BattleFactoryApp_MovePicCursor
	.public BattleFactoryApp_GetCursorSlot
	.public BattleFactoryApp_UpdateSwapOutPicCursor
	.public BattleFactoryApp_UpdateSwapInPicCursor
	.public BattleFactoryApp_CreatePartyPokepics
	.public BattleFactoryApp_ReplacePokepic
	.public BattleFactoryApp_ReplacePokepicFromOther
	.public BattleFactoryApp_CreateSlotMarkers
	.public BattleFactoryApp_DeleteSlotMarkers
	.public BattleFactoryApp_UpdateSlotMarkers
	.public BattleFactoryApp_SetSlotMarkers
	.public BattleFactoryApp_CreateOrderSprites
	.public BattleFactoryApp_DeleteOrderSprites
	.public BattleFactoryApp_UpdateOrderSprites
	.public BattleFactoryApp_ShowMonIcon
	.public BattleFactoryApp_PrintRentalNames
	.public BattleFactoryApp_PrintPartyNames
	.public BattleFactoryApp_PrintSwapNames
	.public BattleFactoryApp_PrintSwapInName
	.public BattleFactoryApp_LoadSubPalette
	.public BattleFactoryApp_UpdatePaletteBlink
	.public BattleFactoryApp_StartButtonFlash
	.public BattleFactoryApp_FlashWideButton
	.public BattleFactoryApp_FlashNarrowButton
	.public BattleFactoryApp_UpdateButtonFlash
	.public BattleFactoryApp_SetBallsTranslucent
	.public BattleFactoryApp_InitBgCellManager
	.public BattleFactorySpriteGfx_Init
	.public BattleFactorySpriteGfx_CreateSprite
	.public BattleFactorySpriteGfx_Free
	.public BattleFactoryApp_InitObjTransfers
	.public BattleFactoryApp_Setup3D
	.public BattleFactoryApp_Draw3D
	.public BattleFactory_CreatePokepic
	.public BattleFactorySprite_Create
	.public BattleFactorySprite_CreateSub
	.public BattleFactorySprite_LoadCharData
	.public BattleFactoryBall_Create
	.public BattleFactoryBall_Move
	.public BattleFactoryBall_MoveOffscreen
	.public BattleFactoryApp_AddWindows
	.public BattleFactoryApp_DrawMessageFrame
	.public BattleFactoryApp_PrintStringAligned
	.public BattleFactoryApp_PrintMsgAligned
	.public BattleFactoryApp_LoadButtonGraphics
	.public BattleFactoryApp_DrawButtons
	.public BattleFactoryApp_ClearButtons
	.public BattleFactoryApp_CreateRentalGrid
	.public BattleFactory_SetRentalGridMenu
	.public BattleFactoryApp_CreateSwapOutGrid
	.public BattleFactoryApp_CreateLinkSwapOutGrid
	.public BattleFactory_SetSwapOutGridMenu
	.public BattleFactoryApp_RecreateSwapOutGrid
	.public BattleFactoryApp_CreateSwapInGrid
	.public BattleFactory_SetSwapInGridMenu
	.public gBattleFactoryBallPositions_Multi2
	.public ov81_0224345E
	.public gBattleFactoryBallPositions_Single
	.public ov81_02243466
	.public gBattleFactoryBallPositions_Multi
	.public ov81_02243472
	.public gBattleFactoryAppGraphicsModes
	.public gBattleFactoryBallPositions_Rental
	.public ov81_02243492
	.public gBattleFactoryAppBgTemplate_Main1
	.public gBattleFactoryAppBgTemplate_Main2
	.public gBattleFactoryAppBgTemplate_Sub1
	.public gBattleFactoryAppBgTemplate_Main3
	.public gBattleFactoryAppBgTemplate_Sub0
	.public gBattleFactoryAppBgTemplate_Sub2
	.public gBattleFactoryAppBgTemplate_Sub3
	.public gBattleFactoryAppGraphicsBanks
	.public gBattleFactorySpriteResManSizes
	.public gBattleFactoryObjCharTransferTemplate
	.public gBattleFactoryAppWindowTemplates
	.public gBattleFactorySwapInGridCallbacks
	.public gBattleFactorySwapOutGridCallbacks
	.public gBattleFactoryRentalGridCallbacks
	.public gBattleFactorySwapOutGridHitboxes
	.public gBattleFactoryLinkSwapOutGridHitboxes
	.public gBattleFactorySwapInGridHitboxesB
	.public gBattleFactorySwapInGridHitboxesA
	.public gBattleFactoryRentalGridHitboxes
	.public gBattleFactoryLinkSwapOutGridBoxes
	.public gBattleFactorySwapOutGridBoxes
	.public gBattleFactorySwapInGridBoxesA
	.public gBattleFactorySwapInGridBoxesB
	.public gBattleFactoryRentalGridBoxes
	.public gBattleFactoryAppSummaryPages
	.public BattleFactoryApp_Init
	.public BattleFactoryApp_Main
	.public BattleFactoryApp_Exit
	.public BattleFactoryApp_SlideIn
	.public BattleFactoryApp_ShowScreen
	.public BattleFactoryApp_SetupRentalScreen
	.public BattleFactoryApp_CreateRentalBalls
	.public BattleFactoryApp_CreateRentalPokepics
	.public BattleFactoryApp_SetupSwapOutScreen
	.public BattleFactoryApp_SetupSwapInScreen
	.public BattleFactoryApp_CreateSwapBalls
	.public BattleFactoryApp_CreateSwapPokepics
	.public BattleFactoryApp_WaitSummary
	.public BattleFactoryApp_SelectRentals
	.public BattleFactoryApp_UndoLastRental
	.public BattleFactoryApp_AddRental
	.public BattleFactoryApp_RemoveRental
	.public BattleFactoryApp_ConfirmRentals
	.public BattleFactoryApp_CancelLastRental
	.public BattleFactoryApp_DeselectCursorRental
	.public BattleFactoryApp_SelectSwapOut
	.public BattleFactoryApp_PickSwapOut
	.public BattleFactoryApp_ConfirmCancelSwap
	.public BattleFactoryApp_ResumeSwapOut
	.public BattleFactoryApp_SelectSwapIn
	.public BattleFactoryApp_UnpickSwapOut
	.public BattleFactoryApp_PickSwapIn
	.public BattleFactoryApp_ShowSwapInPrompt
	.public BattleFactoryApp_ConfirmCancelSwapIn
	.public BattleFactoryApp_ResumeSwapIn
	.public BattleFactoryApp_SwitchPage
	.public BattleFactoryApp_LinkSendSwap
	.public BattleFactoryApp_LinkSync
	.public BattleFactoryApp_FadeOut
	.public BattleFactoryApp_ShowLinkTradeResult
	.public BattleFactoryApp_VBlankCallback
	.public BattleFactoryApp_SetGraphicsBanks
	.public BattleFactoryApp_InitBgLayers
	.public BattleFactoryApp_InitBgGraphics
	.public BattleFactoryApp_InitSprites
	.public BattleFactoryApp_FreeBgLayers
	.public BattleFactoryApp_SetMainState
	.public BattleFactoryApp_ScrollBallsIn
	.public BattleFactoryApp_ScrollBallsOut
	.public BattleFactoryApp_AnimateBackground
	.public BattleFactoryApp_SetBgPalette
	.public BattleFactoryApp_SetCenterAnim
	.public BattleFactoryApp_LoadBgGfx81
	.public BattleFactoryApp_LoadBgGfx92
	.public BattleFactoryApp_LoadBgGfx4
	.public BattleFactoryApp_LoadBgPalette
	.public BattleFactoryApp_LoadSubScreenBg
	.public BattleFactoryApp_PrintMessage
	.public BattleFactoryApp_ShowMessage
	.public BattleFactoryApp_BufferNumber
	.public BattleFactoryApp_BufferSpeciesName
	.public BattleFactoryApp_PrintPlayerName
	.public BattleFactoryApp_PrintPartnerName
	.public BattleFactoryApp_PrintMonName
	.public BattleFactoryApp_PrintPartnerMonName
	.public BattleFactoryApp_FreeGraphics
	.public BattleFactoryApp_ResumeAfterSummary
	.public BattleFactoryApp_DisableDisplay
	.public BattleFactoryApp_InitGraphics
	.public BattleFactoryApp_CreateSummaryArgs
	.public BattleFactoryApp_IsScreen
	.public BattleFactory_GetRentalCount
	.public BattleFactoryApp_IsCancelRequested
	.public BattleFactoryApp_SetCancelRequested
	.public BattleFactoryApp_CreatePokepic
	.public BattleFactoryApp_SendLinkCommand
	.public BattleFactoryApp_PrepareLinkPing
	.public BattleFactory_ReceivePing
	.public BattleFactoryApp_PrepareLinkRentals
	.public BattleFactory_ReceiveRentals
	.public BattleFactory_ReceiveUnused
	.public BattleFactoryApp_PrintPartnerRentals
	.public BattleFactoryApp_PrepareLinkSwap
	.public BattleFactory_ReceiveSwap
	.public BattleFactoryApp_CreateBall
	.public BattleFactoryApp_CreateCenterSprite
	.public BattleFactoryApp_DeleteCenterSprites
	.public BattleFactoryApp_InitWindows
	.public BattleFactoryApp_CloseWindow
	.public BattleFactoryApp_MoveRentalCursor
	.public BattleFactoryApp_MoveButtonCursor
	.public BattleFactoryApp_OpenRentalMenu
	.public BattleFactoryApp_CloseRentalMenu
	.public BattleFactoryApp_PrintRentalMenu
	.public BattleFactoryApp_MoveSwapOutCursor
	.public BattleFactoryApp_MoveSwapInCursor
	.public BattleFactoryApp_OpenSwapOutMenu
	.public BattleFactoryApp_CloseSwapOutMenu
	.public BattleFactoryApp_RedrawSwapOutButtons
	.public BattleFactoryApp_ClearSwapOutMenu
	.public BattleFactoryApp_PrintSwapOutMenu
	.public BattleFactoryApp_OpenSwapInMenu
	.public BattleFactoryApp_CloseSwapInMenu
	.public BattleFactoryApp_RedrawSwapInButtons
	.public BattleFactoryApp_ClearSwapInMenu
	.public BattleFactoryApp_PrintSwapInMenu
	.public BattleFactoryApp_CreateYesNo
	.public BattleFactoryApp_DestroyYesNo
	.public BattleFactoryApp_InitYesNo
	.public BattleFactoryApp_UpdatePreviewPokepic
	.public BattleFactory_GetPokepicPos
	.public BattleFactoryApp_GetCursorPokepicPos
	.public BattleFactoryApp_MovePicCursor
	.public BattleFactoryApp_GetCursorSlot
	.public BattleFactoryApp_UpdateSwapOutPicCursor
	.public BattleFactoryApp_UpdateSwapInPicCursor
	.public BattleFactoryApp_CreatePartyPokepics
	.public BattleFactoryApp_ReplacePokepic
	.public BattleFactoryApp_ReplacePokepicFromOther
	.public BattleFactoryApp_CreateSlotMarkers
	.public BattleFactoryApp_DeleteSlotMarkers
	.public BattleFactoryApp_UpdateSlotMarkers
	.public BattleFactoryApp_SetSlotMarkers
	.public BattleFactoryApp_CreateOrderSprites
	.public BattleFactoryApp_DeleteOrderSprites
	.public BattleFactoryApp_UpdateOrderSprites
	.public BattleFactoryApp_ShowMonIcon
	.public BattleFactoryApp_PrintRentalNames
	.public BattleFactoryApp_PrintPartyNames
	.public BattleFactoryApp_PrintSwapNames
	.public BattleFactoryApp_PrintSwapInName
	.public BattleFactoryApp_LoadSubPalette
	.public BattleFactoryApp_UpdatePaletteBlink
	.public BattleFactoryApp_StartButtonFlash
	.public BattleFactoryApp_FlashWideButton
	.public BattleFactoryApp_FlashNarrowButton
	.public BattleFactoryApp_UpdateButtonFlash
	.public BattleFactoryApp_SetBallsTranslucent
	.public BattleFactory_IsLinkMode
	.public BattleFactoryApp_IsLinkMode
	.public BattleFactoryApp_InitBgCellManager
	.public BattleFactoryApp_FreeBgCellManager
	.public BattleFactorySpriteGfx_Init
	.public BattleFactorySpriteGfx_CreateSprite
	.public BattleFactorySpriteGfx_Free
	.public BattleFactoryApp_InitObjTransfers
	.public BattleFactoryApp_Setup3D
	.public BattleFactoryApp_Draw3D
	.public BattleFactory_CreatePokepic
	.public BattleFactory_SetPokepicHFlip
	.public BattleFactorySprite_Create
	.public BattleFactorySprite_CreateSub
	.public BattleFactorySprite_Delete
	.public BattleFactorySprite_SetVisible
	.public BattleFactorySprite_SetPosition
	.public BattleFactorySprite_SetPositionSub
	.public BattleFactorySprite_SetMatrix
	.public BattleFactorySprite_IsAnimated
	.public BattleFactorySprite_SetAnim
	.public BattleFactorySprite_SetPaletteOverride
	.public BattleFactorySprite_SetPalette
	.public BattleFactorySprite_LoadCharData
	.public BattleFactoryBall_Create
	.public BattleFactoryBall_Delete
	.public BattleFactoryBall_SetVisible
	.public BattleFactoryBall_Move
	.public BattleFactoryBall_SetPosition
	.public BattleFactoryBall_GetPosition
	.public BattleFactoryBall_SetSelected
	.public BattleFactoryBall_IsSelected
	.public BattleFactoryBall_Select
	.public BattleFactoryBall_Deselect
	.public BattleFactoryBall_MoveOffscreen
	.public BattleFactoryBall_GetX
	.public BattleFactoryBall_GetY
	.public BattleFactoryBall_SetAnim
	.public BattleFactoryBall_SetPaletteOverride
	.public BattleFactoryBall_SetOamMode
	.public BattleFactoryBall_Free
	.public BattleFactoryApp_AddWindows
	.public BattleFactoryApp_RemoveWindows
	.public BattleFactoryApp_DrawMessageFrame
	.public BattleFactoryApp_PrintStringAligned
	.public BattleFactoryApp_PrintMsgAligned
	.public BattleFactoryApp_SetLinkNameWindows
	.public BattleFactoryApp_LoadButtonGraphics
	.public BattleFactoryApp_DrawButtons
	.public BattleFactoryApp_ClearButtons
	.public BattleFactory_FreeGrid
	.public BattleFactory_GetGridCursorPos
	.public BattleFactory_GridNop
	.public BattleFactoryApp_CreateRentalGrid
	.public BattleFactory_SetRentalGridMenu
	.public BattleFactoryApp_OnRentalCursorMove
	.public BattleFactoryApp_CreateSwapOutGrid
	.public BattleFactoryApp_CreateLinkSwapOutGrid
	.public BattleFactory_SetSwapOutGridMenu
	.public BattleFactoryApp_OnSwapOutCursorMove
	.public BattleFactoryApp_RecreateSwapOutGrid
	.public BattleFactoryApp_CreateSwapInGrid
	.public BattleFactory_SetSwapInGridMenu
	.public BattleFactoryApp_OnSwapInCursorMove
	.include "overlay_81.inc"
	.include "global.inc"

	.text
	.public BattleFactoryApp_CreateRentalPokepics
	.public BattleFactoryApp_CancelLastRental
	.public BattleFactoryApp_ResumeSwapIn
	.public BattleFactoryApp_InitSprites
	.public BattleFactoryApp_SetMainState
	.public BattleFactoryApp_IsScreen
	.public BattleFactory_GetRentalCount
	.public BattleFactoryApp_SetCancelRequested
	.public BattleFactory_ReceiveUnused
	.public BattleFactoryApp_PrepareLinkSwap
	.public BattleFactoryApp_CloseWindow
	.public BattleFactoryApp_ClearSwapOutMenu
	.public BattleFactoryApp_ClearSwapInMenu
	.public BattleFactoryApp_CreateYesNo
	.public BattleFactoryApp_DestroyYesNo
	.public BattleFactory_IsLinkMode
	.public BattleFactoryApp_IsLinkMode
	.public BattleFactoryApp_FreeBgCellManager
	.public BattleFactory_SetPokepicHFlip
	.public BattleFactorySprite_Delete
	.public BattleFactorySprite_SetVisible
	.public BattleFactorySprite_SetPosition
	.public BattleFactorySprite_SetPositionSub
	.public BattleFactorySprite_SetMatrix
	.public BattleFactorySprite_IsAnimated
	.public BattleFactorySprite_SetAnim
	.public BattleFactorySprite_SetPaletteOverride
	.public BattleFactorySprite_SetPalette
	.public BattleFactoryBall_Delete
	.public BattleFactoryBall_SetVisible
	.public BattleFactoryBall_SetPosition
	.public BattleFactoryBall_GetPosition
	.public BattleFactoryBall_SetSelected
	.public BattleFactoryBall_IsSelected
	.public BattleFactoryBall_Select
	.public BattleFactoryBall_Deselect
	.public BattleFactoryBall_GetX
	.public BattleFactoryBall_GetY
	.public BattleFactoryBall_SetAnim
	.public BattleFactoryBall_SetPaletteOverride
	.public BattleFactoryBall_SetOamMode
	.public BattleFactoryBall_Free
	.public BattleFactoryApp_RemoveWindows
	.public BattleFactoryApp_SetLinkNameWindows
	.public BattleFactory_FreeGrid
	.public BattleFactory_GetGridCursorPos
	.public BattleFactory_GridNop
	.public BattleFactoryApp_OnRentalCursorMove
	.public BattleFactoryApp_OnSwapOutCursorMove
	.public BattleFactoryApp_OnSwapInCursorMove
	.rodata

gBattleFactoryAppSummaryPages:
	.byte 0x00, 0x01, 0x03, 0x04

gBattleFactoryBallPositions_Multi2: ; 0x0224345C
	.byte 0x60, 0x00

ov81_0224345E: ; 0x0224345E
	.byte 0x40, 0x00
	.byte 0x98, 0x00, 0x40, 0x00

gBattleFactoryBallPositions_Single: ; 0x02243464
	.byte 0x40, 0x00

ov81_02243466: ; 0x02243466
	.byte 0x40, 0x00, 0x78, 0x00, 0x40, 0x00, 0xB0, 0x00, 0x40, 0x00

gBattleFactoryBallPositions_Multi: ; 0x02243470
	.byte 0x28, 0x00

ov81_02243472: ; 0x02243472
	.byte 0x40, 0x00, 0x60, 0x00, 0x40, 0x00, 0x98, 0x00, 0x40, 0x00, 0xD0, 0x00, 0x40, 0x00

gBattleFactoryAppGraphicsModes: ; 0x02243480
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00

gBattleFactoryBallPositions_Rental: ; 0x02243490
	.byte 0x18, 0x00

ov81_02243492: ; 0x02243492
	.byte 0x40, 0x00, 0x40, 0x00, 0x40, 0x00, 0x68, 0x00, 0x40, 0x00, 0x90, 0x00, 0x40, 0x00
	.byte 0xB8, 0x00, 0x40, 0x00, 0xE0, 0x00, 0x40, 0x00

gBattleFactoryAppBgTemplate_Main1: ; 0x022434A8
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x04, 0x00, 0x01, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gBattleFactoryAppBgTemplate_Main2: ; 0x022434C4
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x06, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleFactoryAppBgTemplate_Sub1: ; 0x022434E0
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleFactoryAppBgTemplate_Main3: ; 0x022434FC
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1D, 0x00
	.byte 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleFactoryAppBgTemplate_Sub0: ; 0x02243518
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1C, 0x04, 0x00, 0x01, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gBattleFactoryAppBgTemplate_Sub2: ; 0x02243534
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x04, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleFactoryAppBgTemplate_Sub3: ; 0x02243550
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1D, 0x06, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleFactoryAppGraphicsBanks: ; 0x0224356C
	.byte 0x02, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x60, 0x00, 0x00, 0x00

gBattleFactorySpriteResManSizes: ; 0x02243594
	.byte 0x06, 0x06, 0x06, 0x06

gBattleFactoryObjCharTransferTemplate: ; 0x02243598
	.byte 0x20, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x64, 0x00, 0x00, 0x00

gBattleFactoryAppWindowTemplates: ; 0x022435A8
	.byte 0x01, 0x01, 0x08, 0x08, 0x02, 0x0D, 0x01, 0x00
	.byte 0x01, 0x01, 0x01, 0x08, 0x02, 0x0D, 0x11, 0x00, 0x01, 0x01, 0x0B, 0x0A, 0x02, 0x0D, 0x21, 0x00
	.byte 0x01, 0x0B, 0x0B, 0x0A, 0x02, 0x0D, 0x35, 0x00, 0x01, 0x15, 0x0B, 0x0A, 0x02, 0x0D, 0x49, 0x00
	.byte 0x01, 0x04, 0x04, 0x0A, 0x02, 0x0D, 0x6D, 0x00, 0x01, 0x12, 0x04, 0x0A, 0x02, 0x0D, 0x81, 0x00
	.byte 0x05, 0x02, 0x13, 0x1B, 0x04, 0x0C, 0x01, 0x00, 0x05, 0x0C, 0x01, 0x0A, 0x02, 0x0D, 0x6D, 0x00
	.byte 0x05, 0x02, 0x0F, 0x07, 0x02, 0x09, 0x81, 0x00, 0x05, 0x17, 0x0F, 0x07, 0x02, 0x09, 0x8F, 0x00
	.byte 0x05, 0x02, 0x0C, 0x0C, 0x02, 0x09, 0x9D, 0x00, 0x05, 0x12, 0x0C, 0x0C, 0x02, 0x09, 0xB5, 0x00
	.byte 0x05, 0x12, 0x0C, 0x0C, 0x02, 0x09, 0xCD, 0x00, 0x05, 0x0A, 0x0F, 0x0C, 0x02, 0x09, 0xE5, 0x00
	.byte 0x05, 0x12, 0x0C, 0x0C, 0x02, 0x09, 0xB5, 0x00, 0x05, 0x02, 0x0F, 0x0C, 0x02, 0x09, 0xCD, 0x00
	.byte 0x05, 0x12, 0x0F, 0x0C, 0x02, 0x09, 0xE5, 0x00

gBattleFactorySwapInGridCallbacks: ; 0x02243638
	.word BattleFactory_GridNop
	.word BattleFactory_GridNop
	.word BattleFactoryApp_OnSwapInCursorMove
	.word BattleFactoryApp_OnSwapInCursorMove

gBattleFactorySwapOutGridCallbacks: ; 0x02243648
	.word BattleFactory_GridNop
	.word BattleFactory_GridNop
	.word BattleFactoryApp_OnSwapOutCursorMove
	.word BattleFactoryApp_OnSwapOutCursorMove

gBattleFactoryRentalGridCallbacks: ; 0x02243658
	.word BattleFactory_GridNop
	.word BattleFactory_GridNop
	.word BattleFactoryApp_OnRentalCursorMove
	.word BattleFactoryApp_OnRentalCursorMove

gBattleFactorySwapOutGridHitboxes: ; 0x02243668
	.byte 0x2C, 0x53, 0x2C, 0x53, 0x2C, 0x53, 0x64, 0x8B
	.byte 0x2C, 0x53, 0x9C, 0xC3, 0x74, 0x8B, 0xB4, 0xF3, 0x5C, 0x73, 0x0C, 0x73, 0x5C, 0x73, 0x8C, 0xF3
	.byte 0x74, 0x8B, 0x4C, 0xB3, 0xFF, 0x00, 0x00, 0x00

gBattleFactoryLinkSwapOutGridHitboxes: ; 0x02243688
	.byte 0x2C, 0x53, 0x4C, 0x73, 0x2C, 0x53, 0x84, 0xAB
	.byte 0x00, 0x00, 0x00, 0x00, 0x74, 0x8B, 0xB4, 0xF3, 0x5C, 0x73, 0x0C, 0x73, 0x5C, 0x73, 0x8C, 0xF3
	.byte 0x74, 0x8B, 0x4C, 0xB3, 0xFF, 0x00, 0x00, 0x00

gBattleFactorySwapInGridHitboxesB: ; 0x022436A8
	.byte 0x2C, 0x53, 0x2C, 0x53, 0x2C, 0x53, 0x64, 0x8B
	.byte 0x2C, 0x53, 0x9C, 0xC3, 0x00, 0x00, 0x00, 0x00, 0x74, 0x8B, 0x0C, 0x4B, 0x74, 0x8B, 0xB4, 0xF3
	.byte 0x74, 0x8B, 0x0C, 0x73, 0x74, 0x8C, 0x8C, 0xF3, 0xFF, 0x00, 0x00, 0x00

gBattleFactorySwapInGridHitboxesA: ; 0x022436CC
	.byte 0x2C, 0x53, 0x14, 0x3B
	.byte 0x2C, 0x53, 0x4C, 0x73, 0x2C, 0x53, 0x84, 0xAB, 0x2C, 0x53, 0xBC, 0xE3, 0x74, 0x8B, 0x0C, 0x4B
	.byte 0x74, 0x8B, 0xB4, 0xF3, 0x74, 0x8B, 0x0C, 0x73, 0x74, 0x8C, 0x8C, 0xF3, 0xFF, 0x00, 0x00, 0x00

gBattleFactoryRentalGridHitboxes: ; 0x022436F0
	.byte 0x2C, 0x53, 0x04, 0x2B, 0x2C, 0x53, 0x2C, 0x53, 0x2C, 0x53, 0x54, 0x7B, 0x2C, 0x53, 0x7C, 0xA3
	.byte 0x2C, 0x53, 0xA4, 0xCB, 0x2C, 0x53, 0xCC, 0xF3, 0x5C, 0x73, 0x0C, 0x73, 0x5C, 0x73, 0x8C, 0xF3
	.byte 0x74, 0x8B, 0x4C, 0xB3, 0xFF, 0x00, 0x00, 0x00

gBattleFactoryLinkSwapOutGridBoxes: ; 0x02243718
	.byte 0x60, 0x40, 0x00, 0x00, 0x03, 0x03, 0x03, 0x01
	.byte 0x98, 0x40, 0x00, 0x00, 0x03, 0x03, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x02, 0x02, 0x02, 0x02
	.byte 0xD4, 0x80, 0x00, 0x00, 0x80, 0x80, 0x01, 0x00, 0x40, 0x68, 0x00, 0x00, 0x04, 0x06, 0x04, 0x05
	.byte 0xC0, 0x68, 0x00, 0x00, 0x05, 0x06, 0x04, 0x05, 0x80, 0x80, 0x00, 0x00, 0x84, 0x06, 0x06, 0x06

gBattleFactorySwapOutGridBoxes: ; 0x02243750
	.byte 0x40, 0x40, 0x00, 0x00, 0x03, 0x03, 0x03, 0x01, 0x78, 0x40, 0x00, 0x00, 0x03, 0x03, 0x00, 0x02
	.byte 0xB0, 0x40, 0x00, 0x00, 0x03, 0x03, 0x01, 0x03, 0xD4, 0x80, 0x00, 0x00, 0x80, 0x80, 0x02, 0x00
	.byte 0x40, 0x68, 0x00, 0x00, 0x04, 0x06, 0x04, 0x05, 0xC0, 0x68, 0x00, 0x00, 0x05, 0x06, 0x04, 0x05
	.byte 0x80, 0x80, 0x00, 0x00, 0x84, 0x06, 0x06, 0x06

gBattleFactorySwapInGridBoxesA: ; 0x02243788
	.byte 0x28, 0x40, 0x00, 0x00, 0x04, 0x04, 0x05, 0x01
	.byte 0x60, 0x40, 0x00, 0x00, 0x04, 0x04, 0x00, 0x02, 0x98, 0x40, 0x00, 0x00, 0x04, 0x04, 0x01, 0x03
	.byte 0xD0, 0x40, 0x00, 0x00, 0x04, 0x04, 0x02, 0x04, 0x2C, 0x80, 0x00, 0x00, 0x00, 0x00, 0x03, 0x05
	.byte 0xD4, 0x80, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x40, 0x80, 0x00, 0x00, 0x06, 0x06, 0x06, 0x07
	.byte 0xC0, 0x80, 0x00, 0x00, 0x07, 0x07, 0x06, 0x07

gBattleFactorySwapInGridBoxesB: ; 0x022437C8
	.byte 0x40, 0x40, 0x00, 0x00, 0x04, 0x04, 0x05, 0x01
	.byte 0x78, 0x40, 0x00, 0x00, 0x04, 0x04, 0x00, 0x02, 0xB0, 0x40, 0x00, 0x00, 0x04, 0x04, 0x01, 0x04
	.byte 0x00, 0x00, 0x00, 0x00, 0x03, 0x03, 0x03, 0x03, 0x2C, 0x80, 0x00, 0x00, 0x00, 0x00, 0x02, 0x05
	.byte 0xD4, 0x80, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x40, 0x80, 0x00, 0x00, 0x06, 0x06, 0x06, 0x07
	.byte 0xC0, 0x80, 0x00, 0x00, 0x07, 0x07, 0x06, 0x07

gBattleFactoryRentalGridBoxes: ; 0x02243808
	.byte 0x18, 0x40, 0x00, 0x00, 0x00, 0x00, 0x05, 0x01
	.byte 0x40, 0x40, 0x00, 0x00, 0x01, 0x01, 0x00, 0x02, 0x68, 0x40, 0x00, 0x00, 0x02, 0x02, 0x01, 0x03
	.byte 0x90, 0x40, 0x00, 0x00, 0x03, 0x03, 0x02, 0x04, 0xB8, 0x40, 0x00, 0x00, 0x04, 0x04, 0x03, 0x05
	.byte 0xE0, 0x40, 0x00, 0x00, 0x05, 0x05, 0x04, 0x00, 0x40, 0x68, 0x00, 0x00, 0x06, 0x08, 0x06, 0x07
	.byte 0xC0, 0x68, 0x00, 0x00, 0x07, 0x08, 0x06, 0x07, 0x80, 0x80, 0x00, 0x00, 0x86, 0x08, 0x08, 0x08
	; 0x02243850
