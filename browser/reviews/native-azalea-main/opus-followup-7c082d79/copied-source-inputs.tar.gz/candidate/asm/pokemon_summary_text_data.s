#include "constants/items.h"
#include "constants/moves.h"
#include "constants/pokemon.h"
#include "constants/ribbon.h"
#include "constants/field_move_response.h"
#include "msgdata/msg/msg_0300.h"
	.include "asm/macros.inc"
	.include "pokemon_summary_text_data.inc"
	.include "global.inc"

	.public gOverlayTemplate_Battle
	.public gNatureStatMods

	.public _0208C3EC
	.public _0208C428
	.public _0208C444
	.public _0208C44C
	.public _0208C458
	.public _0208C464
	.public _0208C470
	.public _0208C480
	.public _0208C48A
	.public _0208C48C
	.public _0208C4AE
	.public _0208C4CE
	.public _0208C4D0
	.public _0208C4D4
	.public _0208C4D8
	.public _0208C4DC
	.public _0208C4F8
	.public _0208C500
	.public _0208C512
	.public _0208C52A
	.public _0208C536
	.public _0208C548
	.public _0208C55A
	.public _0208C55C
	.public _0208C56C
	.public _0208C5E0
	.public _0208C600
	.public _0208C60C
	.public _0208C610
	.public _0208C69C
	.public _0208C6A8
	.public _0208C6AC
	.public _0208C6B0
	.public _0208C6FA
	.public _0208C70A
	.public _0208C730
	.public _0208C734
	.public _0208C738
	.public _0208C774
	.public _0208C790
	.public _0208C794
	.public _0208C7B6
	.public _0208C7DA
	.public _0208C7F4
	.public _0208C816
	.public _0208C81A
	.public _0208C83C
	.public _0208C840
	.public _0208C844
	.public _0208C848
	.public _0208C84C
	.public _0208C8C4
	.public _0208C99C
	.public _0208C9A0
	.public _0208CA14
	.public _0208CA1E
	.public _0208CBC8
	.public _0208CBCC
	.public _0208CBD0
	.public _0208CC40
	.public _0208CC48
	.public _0208CC58
	.public _0208CC68
	.public _0208CC78
	.public _0208CC7E
	.public _0208CC84
	.public _0208CD34
	.public _0208CDF0
	.public _0208CE00
	.public _0208CE1C
	.public _0208CE2A
	.public _0208CE96
	.public _0208CEC4
	.public _0208CF3C
	.public _0208CF4A
	.public _0208CFA8
	.public _0208CFAC
	.public _0208CFB0
	.public _0208CFE8
	.public _0208D00A
	.public _0208D02C
	.public _0208D04E
	.public _0208D074
	.public _0208D0A0
	.public _0208D102
	.public _0208D110
	.public _0208D170
	.public _0208D174
	.public _0208D458
	.public _0208D45C
	.public _0208D460
	.public _0208D464
	.public _0208D468
	.public _0208D46C
	.public _0208D470
	.public _0208D48C
	.public _0208D53A
	.public _0208D6AA
	.public _0208D6B0
	.public _0208D6B4
	.public _0208D720
	.public _0208D724
	.public _0208D73E
	.public _0208D7B0
	.public _0208D7B4
	.public _0208D7B8
	.public _0208D7BC
	.public _0208D7C0
	.public _0208D854
	.public _0208D870
	.public _0208D874
	.public _0208D878
	.public _0208D87C
	.public _0208D880
	.public _0208D8B8
	.public _0208D8CA
	.public _0208D952
	.public _0208D994
	.public _0208D998
	.public _0208D99C
	.public _0208DA10
	.public _0208DA1E
	.public _0208DA4E
	.public _0208DA5C
	.public _0208DAC8
	.public _0208DACC
	.public _0208DAD0
	.public _0208DB4E
	.public _0208DB60
	.public _0208DBEC
	.public _0208DC2A
	.public _0208DC32
	.public _0208DC60
	.public _0208DC64
	.public _0208DCD6
	.public _0208DD12
	.public _0208DD18
	.public _0208DD1C
	.public _0208DD82
	.public _0208DD98
	.public _0208DD9C
	.public _0208DDBA
	.public _0208DDC4
	.public _0208DDCA
	.public _0208DDCE
	.public _0208DDD2
	.public _0208DDD6
	.public _0208DDDA
	.public _0208DDDE
	.public _0208DDE2
	.public _0208DDE4
	.public _0208DE34
	.public _0208DE38
	.public _0208DE3C
	.public gPokemonSummaryRibbonWindowTemplates
	.public gPokemonSummaryInfoWindowTemplates
	.public gPokemonSummaryStatsWindowTemplates
	.public gPokemonSummaryWindowTemplates
	.public PokemonSummary_AddWindows
	.public PokemonSummary_AddPageWindows
	.public PokemonSummary_RemovePageWindows
	.public PokemonSummary_RemoveWindows
	.public PokemonSummary_PrintNickname
	.public PokemonSummary_PrintLevel
	.public PokemonSummary_PrintHeldItem
	.public PokemonSummary_IsPlayersMon
	.public PokemonSummary_PrintBuffer
	.public PokemonSummary_PrintStatLabel
	.public PokemonSummary_PrintMessage
	.public PokemonSummary_FormatNumber
	.public PokemonSummary_PrintValuePair
	.public PokemonSummary_PrintLabels
	.public PokemonSummary_PrintPage
	.public PokemonSummary_PrintInfo
	.public PokemonSummary_PrintTrainerMemo
	.public PokemonSummary_CountShinyLeaves
	.public PokemonSummary_PrintMemo
	.public PokemonSummary_PrintStats
	.public PokemonSummary_PrintMoves
	.public PokemonSummary_PrintPokeathlonStatLabels
	.public PokemonSummary_PrintRibbonCount
	.public PokemonSummary_PrintFlavorPreference
	.public PokemonSummary_PrintRibbonInfo
	.public PokemonSummary_PrintMoveSlot
	.public PokemonSummary_PrintMoveInfo
	.public PokemonSummary_ClearMoveInfo
	.public PokemonSummary_PrintMoveToLearn
	.public PokemonSummary_ScheduleMainBg1Transfer
	.public PokemonSummary_PrintSwappedMoves
	.public PokemonSummary_PrintCantForgetHMMessage
	.public PokemonSummary_ShowForgetLabel
	.public PokemonSummary_ShowSwitchLabel
	.public PokemonSummary_PrintConditionChangeMessage
	.text
	.public PokemonSummary_RemovePageWindows
	.public PokemonSummary_RemoveWindows
	.public PokemonSummary_IsPlayersMon
	.public PokemonSummary_PrintBuffer
	.public PokemonSummary_PrintStatLabel
	.public PokemonSummary_PrintMessage
	.public PokemonSummary_FormatNumber
	.public PokemonSummary_CountShinyLeaves
	.public PokemonSummary_PrintMemo
	.public PokemonSummary_PrintMoves
	.public PokemonSummary_PrintRibbonCount
	.public PokemonSummary_PrintFlavorPreference
	.public PokemonSummary_PrintRibbonInfo
	.public PokemonSummary_ClearMoveInfo
	.public PokemonSummary_PrintMoveToLearn
	.public PokemonSummary_ScheduleMainBg1Transfer
	.public PokemonSummary_PrintSwappedMoves
	.public PokemonSummary_PrintCantForgetHMMessage
	.public PokemonSummary_ShowForgetLabel
	.public PokemonSummary_ShowSwitchLabel
	.public PokemonSummary_PrintConditionChangeMessage
	.rodata

	.balign 4, 0
gPokemonSummaryRibbonWindowTemplates:
	.byte 0x04, 0x0D, 0x11, 0x05, 0x02, 0x0D
	.short 0x021F
	.byte 0x04, 0x01, 0x10, 0x15, 0x02, 0x0D
	.short 0x0229
	.byte 0x04, 0x01, 0x12, 0x1E, 0x04, 0x0D
	.short 0x0253
	.byte 0x01, 0x01, 0x03, 0x0A, 0x02, 0x0D
	.short 0x021F
	.byte 0x01, 0x01, 0x07, 0x0A, 0x02, 0x0D
	.short 0x0233
	.byte 0x01, 0x01, 0x0B, 0x0A, 0x02, 0x0D
	.short 0x0247
	.byte 0x01, 0x01, 0x0F, 0x0A, 0x02, 0x0D
	.short 0x025B
	.byte 0x01, 0x01, 0x13, 0x0A, 0x02, 0x0D
	.short 0x026F
gPokemonSummaryInfoWindowTemplates:
	.byte 0x04, 0x0C, 0x01, 0x03, 0x02, 0x0D
	.short 0x021F
	.byte 0x04, 0x09, 0x03, 0x09, 0x02, 0x0D
	.short 0x0227
	.byte 0x04, 0x09, 0x07, 0x09, 0x02, 0x0D
	.short 0x0239
	.byte 0x04, 0x0B, 0x09, 0x05, 0x02, 0x0D
	.short 0x024B
	.byte 0x04, 0x0A, 0x0D, 0x07, 0x02, 0x0D
	.short 0x0255
	.byte 0x04, 0x0B, 0x11, 0x06, 0x02, 0x0D
	.short 0x0263
	.byte 0x01, 0x00, 0x03, 0x12, 0x12, 0x0D
	.short 0x021F
	.byte 0x01, 0x01, 0x16, 0x0B, 0x02, 0x0D
	.short 0x0363
gPokemonSummaryStatsWindowTemplates:
	.byte 0x01, 0x0B, 0x03, 0x07, 0x02, 0x0D
	.short 0x021F
	.byte 0x01, 0x0D, 0x06, 0x03, 0x02, 0x0D
	.short 0x022D
	.byte 0x01, 0x0D, 0x08, 0x03, 0x02, 0x0D
	.short 0x0233
	.byte 0x01, 0x0D, 0x0A, 0x03, 0x02, 0x0D
	.short 0x0239
	.byte 0x01, 0x0D, 0x0C, 0x03, 0x02, 0x0D
	.short 0x023F
	.byte 0x01, 0x0D, 0x0E, 0x03, 0x02, 0x0D
	.short 0x0245
	.byte 0x01, 0x09, 0x11, 0x09, 0x02, 0x0D
	.short 0x024B
	.byte 0x01, 0x00, 0x13, 0x13, 0x04, 0x0D
	.short 0x025D
	.byte 0x04, 0x05, 0x01, 0x0B, 0x04, 0x0D
	.short 0x021F
	.byte 0x04, 0x05, 0x05, 0x0B, 0x04, 0x0D
	.short 0x024B
	.byte 0x04, 0x05, 0x09, 0x0B, 0x04, 0x0D
	.short 0x0277
	.byte 0x04, 0x05, 0x0D, 0x0B, 0x04, 0x0D
	.short 0x02A3
	.byte 0x04, 0x05, 0x13, 0x0B, 0x04, 0x0D
	.short 0x02CF
	.byte 0x04, 0x1B, 0x06, 0x03, 0x02, 0x0D
	.short 0x02FB
	.byte 0x04, 0x1B, 0x08, 0x03, 0x02, 0x0D
	.short 0x0301
	.byte 0x04, 0x11, 0x0A, 0x0F, 0x0A, 0x0D
	.short 0x0307
	.byte 0x04, 0x01, 0x14, 0x0F, 0x02, 0x0D
	.short 0x039D
	.byte 0x04, 0x01, 0x11, 0x0A, 0x02, 0x0D
	.short 0x039D
gPokemonSummaryWindowTemplates:
	.byte 0x04, 0x14, 0x01, 0x0B, 0x02, 0x0D
	.short 0x0001
	.byte 0x01, 0x14, 0x01, 0x0B, 0x02, 0x0D
	.short 0x0017
	.byte 0x01, 0x14, 0x01, 0x0B, 0x02, 0x0D
	.short 0x002D
	.byte 0x01, 0x01, 0x00, 0x0B, 0x02, 0x0D
	.short 0x0043
	.byte 0x04, 0x14, 0x01, 0x0B, 0x02, 0x0D
	.short 0x0059
	.byte 0x01, 0x14, 0x01, 0x0B, 0x02, 0x0D
	.short 0x006F
	.byte 0x01, 0x14, 0x14, 0x06, 0x02, 0x0D
	.short 0x0085
	.byte 0x04, 0x01, 0x01, 0x09, 0x02, 0x0D
	.short 0x0091
	.byte 0x04, 0x01, 0x03, 0x05, 0x02, 0x0D
	.short 0x00A3
	.byte 0x04, 0x01, 0x05, 0x05, 0x02, 0x0D
	.short 0x00AD
	.byte 0x04, 0x01, 0x07, 0x05, 0x02, 0x0D
	.short 0x00B7
	.byte 0x04, 0x01, 0x09, 0x05, 0x02, 0x0D
	.short 0x00C1
	.byte 0x04, 0x01, 0x0B, 0x0F, 0x02, 0x0D
	.short 0x00CB
	.byte 0x04, 0x01, 0x0F, 0x0C, 0x02, 0x0D
	.short 0x00E9
	.byte 0x04, 0x06, 0x11, 0x03, 0x02, 0x0D
	.short 0x0101
	.byte 0x01, 0x05, 0x03, 0x02, 0x02, 0x0D
	.short 0x0107
	.byte 0x01, 0x03, 0x06, 0x06, 0x02, 0x0D
	.short 0x010B
	.byte 0x01, 0x03, 0x08, 0x06, 0x02, 0x0D
	.short 0x0117
	.byte 0x01, 0x03, 0x0A, 0x06, 0x02, 0x0D
	.short 0x0123
	.byte 0x01, 0x03, 0x0C, 0x06, 0x02, 0x0D
	.short 0x012F
	.byte 0x01, 0x03, 0x0E, 0x06, 0x02, 0x0D
	.short 0x013B
	.byte 0x01, 0x00, 0x11, 0x07, 0x02, 0x0D
	.short 0x0147
	.byte 0x01, 0x01, 0x16, 0x06, 0x02, 0x0D
	.short 0x0147
	.byte 0x04, 0x19, 0x15, 0x05, 0x02, 0x0D
	.short 0x0153
	.byte 0x04, 0x12, 0x04, 0x06, 0x02, 0x0D
	.short 0x015D
	.byte 0x04, 0x12, 0x06, 0x06, 0x02, 0x0D
	.short 0x0169
	.byte 0x04, 0x12, 0x08, 0x08, 0x02, 0x0D
	.short 0x0175
	.byte 0x01, 0x12, 0x0B, 0x09, 0x02, 0x0D
	.short 0x0185
	.byte 0x01, 0x02, 0x0D, 0x0C, 0x02, 0x0D
	.short 0x0197
	.byte 0x04, 0x01, 0x11, 0x0C, 0x02, 0x0D
	.short 0x01AF
	.byte 0x04, 0x14, 0x01, 0x0B, 0x02, 0x0D
	.short 0x01C7
	.byte 0x01, 0x14, 0x16, 0x0C, 0x02, 0x0D
	.short 0x01DD
	.byte 0x01, 0x14, 0x06, 0x06, 0x02, 0x0D
	.short 0x01F5
	.byte 0x01, 0x16, 0x04, 0x09, 0x02, 0x0D
	.short 0x0201
