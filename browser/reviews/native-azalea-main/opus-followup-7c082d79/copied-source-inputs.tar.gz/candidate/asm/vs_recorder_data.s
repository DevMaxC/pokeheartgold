	.include "asm/macros.inc"
	.public _0222B826
	.public _0222B920
	.public _0222B924
	.public _0222B928
	.public _0222B92C
	.public _0222B930
	.public _0222B9FE
	.public _0222BA34
	.public _0222BA3E
	.public _0222BA4A
	.public _0222BA84
	.public _0222BA88
	.public _0222BA8C
	.public _0222BAB4
	.public _0222BC14
	.public _0222BC18
	.public _0222BC1C
	.public _0222BC20
	.public _0222BC24
	.public _0222BC28
	.public _0222BC2C
	.public _0222BC30
	.public _0222BC34
	.public _0222BC38
	.public _0222BC3C
	.public _0222BC40
	.public _0222BC4C
	.public _0222BC50
	.public _0222BC64
	.public _0222BCD2
	.public _0222BCE4
	.public _0222BCF8
	.public _0222BCFC
	.public _0222BD00
	.public _0222BD28
	.public _0222BD2C
	.public _0222BD3E
	.public _0222BD4A
	.public _0222BD70
	.public _0222BD8E
	.public _0222BD9E
	.public _0222BDA8
	.public _0222BDC0
	.public _0222BDD8
	.public _0222BDF0
	.public _0222BE08
	.public _0222BE20
	.public _0222BE38
	.public _0222BE50
	.public _0222BE68
	.public _0222BE80
	.public _0222BE98
	.public _0222BEB0
	.public _0222BEC8
	.public _0222BEE0
	.public _0222BEEC
	.public _0222BF04
	.public _0222BF0A
	.public _0222BF0E
	.public _0222BF2C
	.public _0222BF30
	.public _0222BF34
	.public _0222BF38
	.public _0222BF3C
	.public _0222BF40
	.public _0222BF44
	.public _0222BF48
	.public _0222BF4C
	.public _0222BF50
	.public _0222BF54
	.public _0222BF58
	.public _0222BF5C
	.public _0222BF60
	.public _0222BF7C
	.public _0222BFAC
	.public _0222C006
	.public _0222C010
	.public _0222C014
	.public _0222C034
	.public _0222C038
	.public _0222C060
	.public _0222C088
	.public _0222C09E
	.public _0222C0AA
	.public _0222C0B6
	.public _0222C0C2
	.public _0222C0CE
	.public _0222C0DA
	.public _0222C0E6
	.public _0222C0F2
	.public _0222C0FE
	.public _0222C10A
	.public _0222C116
	.public _0222C122
	.public _0222C12E
	.public _0222C13A
	.public _0222C146
	.public _0222C150
	.public _0222C154
	.public _0222C158
	.public _0222C184
	.public _0222C192
	.public _0222C1AE
	.public _0222C1D2
	.public _0222C1EA
	.public _0222C200
	.public _0222C20C
	.public _0222C212
	.public _0222C218
	.public _0222C21C
	.public _0222C220
	.public _0222C224
	.public _0222C228
	.public _0222C22C
	.public _0222C230
	.public _0222C234
	.public _0222C238
	.public _0222C2EE
	.public _0222C300
	.public _0222C316
	.public _0222C328
	.public _0222C33C
	.public _0222C340
	.public _0222C344
	.public _0222C348
	.public _0222C34C
	.public _0222C350
	.public _0222C354
	.public _0222C358
	.public _0222C35C
	.public _0222C370
	.public _0222C394
	.public _0222C398
	.public _0222C3B4
	.public _0222C3DA
	.public _0222C416
	.public _0222C424
	.public _0222C428
	.public _0222C42C
	.public _0222C430
	.public _0222C43E
	.public _0222C46C
	.public _0222C470
	.public _0222C47C
	.public _0222C492
	.public _0222C49C
	.public _0222C4B0
	.public _0222C4B4
	.public _0222C4CA
	.public _0222C4D8
	.public _0222C4E4
	.public _0222C4F4
	.public _0222C5D6
	.public _0222C680
	.public _0222C6DA
	.public _0222C7B4
	.public _0222C7F6
	.public _0222C87C
	.public _0222C880
	.public _0222C916
	.public _0222C928
	.public _0222C93C
	.public _0222C94A
	.public _0222C9CE
	.public _0222C9E2
	.public _0222CA20
	.public _0222CA2C
	.public _0222CA38
	.public _0222CA4C
	.public _0222CA5A
	.public _0222CA60
	.public _0222CA64
	.public _0222CA68
	.public _0222CA6C
	.public _0222CA70
	.public _0222CA74
	.public _0222CA78
	.public _0222CA7C
	.public _0222CA80
	.public _0222CA84
	.public _0222CA88
	.public _0222CA96
	.public _0222CA9A
	.public _0222CAB8
	.public _0222CAC6
	.public _0222CAF8
	.public _0222CB06
	.public _0222CB0E
	.public _0222CB16
	.public _0222CB1E
	.public _0222CB26
	.public _0222CB2E
	.public _0222CB34
	.public _0222CBB8
	.public _0222CBBC
	.public _0222CBD8
	.public _0222CBDC
	.public _0222CBEC
	.public _0222CC24
	.public _0222CC54
	.public _0222CC82
	.public _0222CC9E
	.public _0222CCA0
	.public _0222CCA4
	.public _0222CCA8
	.public _0222CCE8
	.public _0222CD20
	.public _0222CDD2
	.public _0222CE02
	.public _0222CE30
	.public _0222CE4C
	.public _0222CE64
	.public _0222CE68
	.public _0222CE6C
	.public _0222CE70
	.public _0222CE74
	.public _0222CE78
	.public _0222CE8A
	.public _0222CEBE
	.public _0222CED0
	.public _0222CED4
	.public _0222CEE4
	.public _0222CF08
	.public _0222CF0C
	.public _0222CF2C
	.public _0222CF80
	.public _0222CF84
	.public _0222CF88
	.public _0222CF8C
	.public _0222CF90
	.public _0222CF9C
	.public _0222CFB8
	.public _0222CFC8
	.public _0222CFE4
	.public _0222CFF6
	.public _0222D016
	.public _0222D02C
	.public _0222D038
	.public _0222D03C
	.public _0222D040
	.public _0222D044
	.public _0222D064
	.public _0222D06C
	.public _0222D078
	.public _0222D080
	.public _0222D090
	.public _0222D096
	.public _0222D0A6
	.public _0222D10C
	.public _0222D15A
	.public _0222D180
	.public _0222D194
	.public _0222D1B6
	.public _0222D1CE
	.public _0222D222
	.public _0222D224
	.public _0222D246
	.public _0222D278
	.public _0222D27C
	.public _0222D280
	.public _0222D284
	.public _0222D2C8
	.public _0222D2E6
	.public _0222D3D6
	.public _0222D3DC
	.public _0222D3E0
	.public _0222D3E4
	.public _0222D410
	.public _0222D478
	.public _0222D494
	.public _0222D4FC
	.public _0222D504
	.public _0222D554
	.public _0222D558
	.public _0222D56C
	.public _0222D574
	.public _0222D5A8
	.public _0222D5BE
	.public _0222D668
	.public _0222D6CC
	.public _0222D738
	.public _0222D788
	.public _0222D7D8
	.public _0222D7FC
	.public _0222D83C
	.public _0222D840
	.public _0222D868
	.public _0222D86C
	.public _0222D870
	.public _0222D90C
	.public _0222D948
	.public _0222D95E
	.public _0222D974
	.public _0222D978
	.public _0222D97C
	.public _0222D9B0
	.public _0222D9C6
	.public _0222D9DC
	.public _0222D9E0
	.public _0222D9E4
	.public _0222DA14
	.public _0222DA22
	.public _0222DA2C
	.public _0222DA38
	.public _0222DA54
	.public _0222DA64
	.public _0222DA76
	.public _0222DA7C
	.public _0222DA80
	.public _0222DA98
	.public _0222DAA2
	.public _0222DABC
	.public _0222DAEC
	.public _0222DB1A
	.public _0222DB28
	.public _0222DB2C
	.public _0222DBA4
	.public _0222DBAC
	.public _0222DBB6
	.public _0222DBC0
	.public _0222DBC8
	.public _0222DBD0
	.public _0222DBDC
	.public _0222DBE0
	.public _0222DBE4
	.public _0222DBE8
	.public _0222DD00
	.public _0222DD04
	.public _0222DD64
	.public _0222DE30
	.public _0222DE34
	.public _0222DE38
	.public _0222DE3C
	.public _0222DE9C
	.public _0222DEA0
	.public _0222DEA4
	.public _0222DEA8
	.public _0222DECC
	.public _0222DF54
	.public _0222DF58
	.public _0222DF5C
	.public _0222DFA4
	.public _0222DFA8
	.public _0222DFAC
	.public _0222DFE2
	.public _0222DFE4
	.public _0222E08A
	.public _0222E090
	.public _0222E094
	.public _0222E098
	.public _0222E0AA
	.public _0222E0BC
	.public _0222E0D6
	.public _0222E33C
	.public _0222E3F6
	.public _0222E428
	.public _0222E42C
	.public _0222E430
	.public _0222E434
	.public _0222E46A
	.public _0222E4A0
	.public _0222E4AC
	.public _0222E4D0
	.public _0222E508
	.public _0222E50C
	.public _0222E610
	.public _0222E614
	.public _0222E620
	.public _0222E654
	.public _0222E664
	.public _0222E66A
	.public _0222E676
	.public _0222E67E
	.public _0222E68C
	.public _0222E6C4
	.public _0222E6D4
	.public _0222E6E8
	.public _0222E794
	.public _0222E798
	.public _0222E824
	.public _0222E85C
	.public _0222E884
	.public _0222E890
	.public _0222E8BC
	.public _0222E8C0
	.public _0222E90A
	.public _0222E95C
	.public _0222E99E
	.public _0222E9A8
	.public _0222E9B4
	.public _0222E9E0
	.public _0222E9E6
	.public _0222EA1A
	.public _0222EA72
	.public _0222EAAE
	.public _0222EAB0
	.public _0222EAC0
	.public _0222EB8A
	.public _0222EB94
	.public _0222EB98
	.public _0222EBBA
	.public _0222EBE4
	.public _0222EBEA
	.public _0222EC0A
	.public _0222ECA0
	.public _0222ECBE
	.public _0222ECC8
	.public _0222ECD4
	.public _0222ECE0
	.public _0222ECEE
	.public _0222ED28
	.public _0222ED4E
	.public _0222ED6E
	.public _0222EDA8
	.public _0222EE7A
	.public _0222EEB4
	.public _0222EEC8
	.public _0222EECC
	.public _0222EF2A
	.public _0222EF7C
	.public _0222EFCA
	.public _0222EFD4
	.public _0222EFEE
	.public _0222EFFC
	.public _0222F024
	.public _0222F030
	.public _0222F07C
	.public _0222F086
	.public _0222F098
	.public _0222F0BE
	.public _0222F0CE
	.public _0222F100
	.public _0222F11A
	.public _0222F14C
	.public _0222F16A
	.public _0222F174
	.public _0222F180
	.public _0222F18A
	.public _0222F19E
	.public _0222F1D8
	.public _0222F1FE
	.public _0222F21E
	.public _0222F258
	.public _0222F32A
	.public _0222F36A
	.public _0222F384
	.public _0222F388
	.public _0222F3AA
	.public _0222F3D0
	.public _0222F3DA
	.public _0222F3EA
	.public _0222F3F8
	.public _0222F420
	.public _0222F42C
	.public _0222F472
	.public _0222F484
	.public _0222F49E
	.public _0222F4AE
	.public _0222F4E8
	.public _0222F500
	.public _0222F5D2
	.public _0222F5E4
	.public _0222F5E8
	.public _0222F60C
	.public _0222F624
	.public _0222F62E
	.public _0222F63C
	.public _0222F658
	.public _0222F66A
	.public _0222F678
	.public _0222F68E
	.public _0222F696
	.public _0222F69C
	.public _0222F6C0
	.public _0222F6CC
	.public _0222F6E6
	.public _0222F6F2
	.public _0222F704
	.public _0222F712
	.public _0222F71C
	.public _0222F73C
	.public _0222F7C6
	.public _0222F7CA
	.public _0222F830
	.public _0222F842
	.public _0222F84C
	.public _0222F850
	.public _0222F854
	.public _0222F89C
	.public _0222F8B2
	.public _0222F8E4
	.public _0222F8FA
	.public _0222F912
	.public _0222F94C
	.public _0222F98A
	.public _0222F98E
	.public _0222F9B4
	.public _0222F9B8
	.public _0222F9BC
	.public _0222F9DC
	.public _0222FA20
	.public _0222FA28
	.public _0222FA48
	.public _0222FA4A
	.public _0222FA52
	.public _0222FA6E
	.public _0222FA74
	.public _0222FA82
	.public _0222FAAC
	.public _0222FAC6
	.public _0222FADA
	.public _0222FADC
	.public _0222FAFA
	.public _0222FB0C
	.public _0222FB1A
	.public _0222FB20
	.public _0222FB24
	.public _0222FB70
	.public _0222FBA8
	.public _0222FBAC
	.public _0222FBB0
	.public _0222FBF2
	.public _0222FBF4
	.public _0222FC0C
	.public _0222FC10
	.public _0222FC36
	.public _0222FC3C
	.public _0222FC48
	.public _0222FC80
	.public _0222FC8C
	.public _0222FCB6
	.public _0222FCB8
	.public _0222FCBC
	.public _0222FCC0
	.public _0222FCC4
	.public _0222FCC8
	.public _0222FCD8
	.public _0222FCFC
	.public _0222FD04
	.public _0222FD28
	.public _0222FD4E
	.public _0222FD74
	.public _0222FD9A
	.public _0222FDA4
	.public _0222FDB0
	.public _0222FDBC
	.public _0222FDC0
	.public _0222FDCE
	.public _0222FDDE
	.public _0222FDEE
	.public _0222FDF8
	.public _0222FDFC
	.public _0222FE64
	.public _0222FE88
	.public _0222FE94
	.public _0222FE9C
	.public _0222FEB6
	.public _0222FF44
	.public _0222FF5E
	.public _0222FF60
	.public _0222FF70
	.public _0222FF82
	.public _0222FFAE
	.public _02230062
	.public _022301F4
	.public _02230206
	.public _022302A0
	.public _022302A4
	.public _022302A8
	.public _022302AC
	.public _022302B0
	.public _022302BA
	.public _02230394
	.public _022303A0
	.public _022303DC
	.public _022303F0
	.public _022303F8
	.public _022303FC
	.public _02230400
	.public _0223040C
	.public _0223041E
	.public _02230436
	.public _022304C8
	.public _022304DC
	.public _02230506
	.public _0223050E
	.public _02230522
	.public _02230530
	.public _02230558
	.public _02230616
	.public _02230630
	.public _02230634
	.public _02230670
	.public _02230688
	.public _0223069C
	.public _022306A8
	.public _022306B4
	.public _022306EC
	.public _02230734
	.public _02230792
	.public _022307C2
	.public _022307D6
	.public _02230846
	.public _0223085C
	.public _02230860
	.public _0223087E
	.public _02230884
	.public _02230890
	.public _02230894
	.public _02230912
	.public _0223092C
	.public _02230930
	.public _02230934
	.public _02230938
	.public _0223093C
	.public _02230940
	.public _02230954
	.public _02230960
	.public _0223096C
	.public _02230A12
	.public _02230A22
	.public _02230A40
	.public _02230A44
	.public _02230A48
	.public _02230A4C
	.public _02230A50
	.public _02230A54
	.public _02230A58
	.public _02230A5C
	.public _02230A60
	.public _02230A64
	.public _02230A68
	.public _02230A6C
	.public _02230A70
	.public _02230A74
	.public _02230A78
	.public _02230A7C
	.public _02230A82
	.public _02230A92
	.public _02230AA6
	.public _02230AAA
	.public _02230AAE
	.public _02230AB2
	.public _02230AB6
	.public _02230ABA
	.public _02230ABE
	.public _02230AC2
	.public _02230AC6
	.public _02230ACA
	.public _02230ACE
	.public _02230AD4
	.public _02230ADA
	.public _02230AE6
	.public _02230AF8
	.public _02230B08
	.public _02230B14
	.public _02230B16
	.public _02230B1A
	.public _02230B1E
	.public _02230B22
	.public _02230B26
	.public _02230B2A
	.public _02230B30
	.public _02230B40
	.public _02230B48
	.public _02230B4C
	.public _02230B50
	.public _02230B54
	.public _02230B58
	.public _02230B5E
	.public _02230B6E
	.public _02230B7C
	.public _02230B80
	.public _02230B84
	.public _02230B88
	.public _02230B8C
	.public _02230B90
	.public _02230B94
	.public _02230B98
	.public _02230B9E
	.public _02230BAE
	.public _02230BB6
	.public _02230BBA
	.public _02230BBE
	.public _02230BC2
	.public _02230BC6
	.public _02230BCC
	.public _02230BDA
	.public _02230BDE
	.public _02230BE2
	.public _02230BE6
	.public _02230BEC
	.public _02230BFC
	.public _02230C08
	.public _02230C0C
	.public _02230C10
	.public _02230C14
	.public _02230C18
	.public _02230C1C
	.public _02230C20
	.public _02230C26
	.public _02230C36
	.public _02230C46
	.public _02230C4A
	.public _02230C4E
	.public _02230C52
	.public _02230C56
	.public _02230C5A
	.public _02230C5E
	.public _02230C62
	.public _02230C66
	.public _02230C6C
	.public _02230C7C
	.public _02230C84
	.public _02230C88
	.public _02230C8C
	.public _02230C90
	.public _02230C94
	.public _02230C9C
	.public _02230CA0
	.public _02230CB0
	.public _02230CB8
	.public _02230CBC
	.public _02230CC0
	.public _02230CC4
	.public _02230CC8
	.public _02230CCE
	.public _02230CD2
	.public _02230D1C
	.public _02230D32
	.public _02230D46
	.public _02230D58
	.public _02230D70
	.public _02230D84
	.public _02230D8C
	.public _02230D90
	.public _02230D9E
	.public _02230DBA
	.public _02230DC8
	.public _02230DFE
	.public _02230EAC
	.public _02230EB0
	.public _02230ED4
	.public _02230EE6
	.public _02230EF2
	.public _02230F00
	.public _02230F12
	.public _02230FA2
	.public _02230FAC
	.public _02230FE6
	.public _02231032
	.public _02231056
	.public _02231078
	.public _0223107E
	.public _022310A0
	.public _022310A6
	.public _022310DA
	.public _022310E2
	.public _022310E8
	.public _022310EC
	.public _022310F0
	.public _022310F4
	.public _022310F8
	.public _022310FC
	.public _02231116
	.public _02231118
	.public _0223117A
	.public _02231192
	.public _022311D6
	.public _022311E8
	.public _022311FA
	.public _02231202
	.public _0223127E
	.public _022312AE
	.public _022312CE
	.public _022312E6
	.public _022312EE
	.public _022312FC
	.public _02231304
	.public _02231308
	.public _0223130C
	.public _02231310
	.public _02231314
	.public _02231318
	.public _02231330
	.public _02231398
	.public _022313B8
	.public _022313E4
	.public _022313EA
	.public _02231428
	.public _0223143E
	.public _0223148C
	.public _02231522
	.public _0223152A
	.public _02231560
	.public _02231574
	.public _02231580
	.public _022315A2
	.public _022315B0
	.public _022315B2
	.public _022315F6
	.public _0223160C
	.public _0223161A
	.public _0223168A
	.public _02231690
	.public _02231694
	.public _02231698
	.public _022316B6
	.public _022316CA
	.public _022316DC
	.public _022316EE
	.public _022316F8
	.public _022316FC
	.public _02231710
	.public _0223171E
	.public _02231724
	.public _02231728
	.public _0223175E
	.public _02231788
	.public _02231802
	.public _0223180E
	.public _0223181A
	.public _0223183A
	.public _02231850
	.public _02231858
	.public _0223185C
	.public _02231860
	.public _02231864
	.public _02231890
	.public _02231898
	.public _022318BC
	.public _022318C2
	.public _022318DA
	.public _02231904
	.public _02231932
	.public _0223194A
	.public _02231970
	.public _02231994
	.public _022319BA
	.public _022319BC
	.public _022319F4
	.public _02231A4A
	.public _02231A6E
	.public _02231A72
	.public _02231A8C
	.public _02231A9A
	.public _02231AC8
	.public _02231AD2
	.public _02231AF0
	.public _02231B98
	.public _02231BB6
	.public _02231BD2
	.public _02231BDC
	.public _02231BEA
	.public _02231BF8
	.public _02231C02
	.public _02231C0E
	.public _02231C1C
	.public _02231C24
	.public _02231C3E
	.public _02231C44
	.public _02231C54
	.public _02231C5C
	.public _02231C60
	.public _02231C64
	.public _02231C68
	.public _02231C6C
	.public _02231C70
	.public _02231C74
	.public _02231C8E
	.public _02231C90
	.public _02231CB8
	.public _02231D0E
	.public _02231D2A
	.public _02231D52
	.public _02231D7C
	.public _02231DD4
	.public _02231DF2
	.public _02231E10
	.public _02231E20
	.public _02231E2A
	.public _02231E36
	.public _02231E38
	.public _02231E60
	.public _02231E6C
	.public _02231E72
	.public _02231E88
	.public _02231E90
	.public _02231E94
	.public _02231E98
	.public _02231E9C
	.public _02231EA0
	.public _02231EB2
	.public _02231EBE
	.public _02231EC8
	.public _02231EE0
	.public _02231EE2
	.public _02231EF8
	.public _02231F0C
	.public _02231F6E
	.public _02231FF2
	.public _0223200A
	.public _0223201E
	.public _02232080
	.public _02232088
	.public _02232090
	.public _022320A2
	.public _022320AE
	.public _022320B8
	.public _022320EC
	.public _02232100
	.public _02232162
	.public _022321E6
	.public _022321FE
	.public _02232212
	.public _02232274
	.public _0223227E
	.public _02232284
	.public _022322F8
	.public _0223230C
	.public _02232356
	.public _022323E2
	.public _02232400
	.public _02232420
	.public _0223242A
	.public _02232446
	.public _02232458
	.public _02232460
	.public _02232468
	.public _0223246C
	.public _02232482
	.public _0223248E
	.public _02232496
	.public _022324AC
	.public _022324CE
	.public _0223252A
	.public _0223256A
	.public _02232584
	.public _0223258C
	.public _02232590
	.public _02232594
	.public _022325CC
	.public _022325D4
	.public _022325E6
	.public _022325F0
	.public _02232600
	.public _02232618
	.public _02232644
	.public _0223266A
	.public _0223267A
	.public _0223269C
	.public _022326A6
	.public _022326BE
	.public _022326D6
	.public _022327B8
	.public _02232804
	.public _02232810
	.public _02232820
	.public _02232854
	.public _0223285E
	.public _0223287C
	.public _022328B2
	.public _022328CC
	.public _0223290A
	.public _0223293A
	.public _02232954
	.public _02232984
	.public _0223298C
	.public _02232994
	.public _022329B2
	.public _022329C2
	.public _022329D4
	.public _022329F4
	.public _02232A0E
	.public _02232A22
	.public _02232A30
	.public _02232A38
	.public _02232A3C
	.public _02232A40
	.public _02232A44
	.public _02232A5E
	.public _02232A82
	.public _02232A92
	.public _02232ACE
	.public _02232AD6
	.public _02232AE8
	.public _02232AF0
	.public _02232AF4
	.public _02232B14
	.public _02232B34
	.public _02232B44
	.public _02232B66
	.public _02232B70
	.public _02232B8E
	.public _02232BC2
	.public _02232BCE
	.public _02232BD4
	.public _02232BF2
	.public _02232C1E
	.public _02232C28
	.public _02232C36
	.public _02232C5C
	.public _02232C76
	.public _02232CBA
	.public _02232D0E
	.public _02232D3E
	.public _02232D58
	.public _02232D64
	.public _02232D70
	.public _02232D90
	.public _02232DB2
	.public _02232E0E
	.public _02232E56
	.public _02232E5A
	.public _02232E64
	.public _02232E7E
	.public _02232E9C
	.public _02232EAC
	.public _02232EC2
	.public _02232EC8
	.public _02232ECC
	.public _02232ED0
	.public _02232EF0
	.public _02232F00
	.public _02232F26
	.public _02232F30
	.public _02232F3A
	.public _02232F48
	.public _02232F4C
	.public _02233040
	.public _022330FC
	.public _0223310A
	.public _02233168
	.public _02233370
	.public _022333B2
	.public _022333F4
	.public _02233474
	.public _022334D8
	.public _022334DC
	.public _022334E0
	.public _022334E4
	.public _022334E8
	.public _022334EC
	.public _022334F0
	.public _022334F4
	.public _02233502
	.public _0223350A
	.public _02233512
	.public _0223354A
	.public _022335A4
	.public _022335D8
	.public _022335F0
	.public _0223363A
	.public _02233668
	.public _0223367C
	.public _02233682
	.public _0223369C
	.public _022336A2
	.public _02233728
	.public _0223375E
	.public _02233780
	.public _022337D2
	.public _02233804
	.public _02233808
	.public _02233824
	.public _02233846
	.public _02233894
	.public _022338B8
	.public _022338BC
	.public _022338C0
	.public _022338C4
	.public _022338C8
	.public _022338CC
	.public _022338DE
	.public _02233924
	.public _02233956
	.public _02233986
	.public _022339B8
	.public _022339BC
	.public _022339C0
	.public _022339C4
	.public _022339C8
	.public _022339E0
	.public _02233A0C
	.public _02233A1E
	.public _02233A3A
	.public _02233AE2
	.public _02233AE8
	.public _02233B00
	.public _02233B26
	.public _02233B46
	.public _02233B5C
	.public _02233B70
	.public _02233B88
	.public _02233C30
	.public _02233C38
	.public _02233C4A
	.public _02233CA8
	.public _02233CDC
	.public _02233CE6
	.public _02233CE8
	.public _02233D4E
	.public _02233D54
	.public _02233D5C
	.public _02233D68
	.public _02233D72
	.public _02233D9C
	.public _02233DE6
	.public _02233E42
	.public _02233E86
	.public _02233EB6
	.public _02233ED0
	.public _02233ED8
	.public _02233EE0
	.public _02233EE4
	.public _02233F1C
	.public _02233F24
	.public _02233F3A
	.public _02233F46
	.public _02233F50
	.public _02233F5C
	.public _02233F66
	.public _02233FA2
	.public _02233FAE
	.public _02233FB2
	.public _02233FFA
	.public _0223403E
	.public _0223404A
	.public _0223409E
	.public _02234106
	.public _02234136
	.public _0223413C
	.public _02234140
	.public _02234144
	.public _02234148
	.public _022341DC
	.public _022341FC
	.public _02234210
	.public _0223425A
	.public _022342AE
	.public _022342C4
	.public _02234328
	.public _0223434A
	.public _022343B2
	.public _022343DA
	.public _022343F0
	.public _02234426
	.public _02234440
	.public _02234446
	.public _02234466
	.public _0223446C
	.public _02234492
	.public _022344AA
	.public _022344CA
	.public _022344D0
	.public _022344D4
	.public _022344F2
	.public _022344FA
	.public _02234506
	.public _02234514
	.public _02234586
	.public _022345E0
	.public _022345FA
	.public _02234652
	.public _0223466C
	.public _0223467E
	.public _022346B2
	.public _022346CE
	.public _022346F0
	.public _0223473E
	.public _02234776
	.public _022347C2
	.public _022347F2
	.public _022347F8
	.public _022347FC
	.public _02234800
	.public _02234804
	.public _02234808
	.public _02234826
	.public _02234898
	.public _022348DE
	.public _022348F8
	.public _02234946
	.public _02234984
	.public _022349D8
	.public _02234A08
	.public _02234A0C
	.public _02234A10
	.public _02234A2C
	.public _02234A32
	.public _02234A4A
	.public _02234A56
	.public _02234A60
	.public _02234AA6
	.public _02234AD4
	.public _02234AEE
	.public _02234B0C
	.public _02234B1A
	.public _02234B34
	.public _02234B56
	.public _02234B76
	.public _02234B90
	.public _02234BA4
	.public _02234BAC
	.public _02234BB0
	.public _02234BB4
	.public _02234BB8
	.public _02234BD0
	.public _02234BDC
	.public _02234BE6
	.public _02234BFE
	.public _02234C10
	.public _02234C34
	.public _02234CA0
	.public _02234CD4
	.public _02234CEC
	.public _02234D20
	.public _02234D40
	.public _02234D5A
	.public _02234D74
	.public _02234D7C
	.public _02234D84
	.public _02234D88
	.public _02234D8C
	.public _02234D90
	.public _02234DAE
	.public _02234E1A
	.public _02234E60
	.public _02234E7A
	.public _02234EC8
	.public _02234F06
	.public _02234F5A
	.public _02234F8A
	.public _02234F90
	.public _02234F94
	.public _02234FAE
	.public _02234FB6
	.public _02234FC2
	.public _02234FCC
	.public _0223500C
	.public _02235028
	.public _02235072
	.public _02235086
	.public _022350C0
	.public _022350E0
	.public _022350F4
	.public _02235106
	.public _02235118
	.public _0223511C
	.public _02235120
	.public _02235124
	.public _02235128
	.public _02235146
	.public _022351D0
	.public _022351E6
	.public _02235234
	.public _0223524E
	.public _02235254
	.public _02235274
	.public _02235278
	.public _0223529E
	.public _022352B6
	.public _022352CC
	.public _022352D2
	.public _022352E4
	.public _02235316
	.public _02235336
	.public _0223533C
	.public _02235340
	.public _02235344
	.public _02235348
	.public _02235362
	.public _02235380
	.public _0223539A
	.public _022353A8
	.public _022353EA
	.public _02235410
	.public _0223542A
	.public _02235430
	.public _02235446
	.public _02235452
	.public _0223545C
	.public _02235470
	.public _0223548A
	.public _02235492
	.public _022354A4
	.public _022354D2
	.public _022354EA
	.public _022354F2
	.public _02235542
	.public _022355A6
	.public _022355AE
	.public _022355C2
	.public _022355CA
	.public _022355F6
	.public _0223561E
	.public _02235626
	.public _0223563E
	.public _02235656
	.public _02235662
	.public _0223566C
	.public _02235680
	.public _0223569A
	.public _022356A2
	.public _022356B4
	.public _022356E2
	.public _022356FA
	.public _02235702
	.public _02235774
	.public _022357B6
	.public _022357C6
	.public _022357DA
	.public _022357E2
	.public _02235822
	.public _02235836
	.public _0223583E
	.public _02235846
	.public _022358BC
	.public _02235918
	.public _02235938
	.public _0223593C
	.public _02235988
	.public _0223598C
	.public _02235990
	.public _022359AC
	.public _022359B0
	.public _022359E8
	.public _02235A0E
	.public _02235B66
	.public _02235C18
	.public _02235C54
	.public _02235C72
	.public _02235C78
	.public _02235C96
	.public _02235D48
	.public _02235D84
	.public _02235DA2
	.public _02235DA8
	.public _02235DE6
	.public _02235DF6
	.public _02235DFE
	.public _02235E0A
	.public _02235E16
	.public _02235E1E
	.public _02235E2C
	.public _02235E30
	.public _02235E92
	.public _02235EA4
	.public _02235EB2
	.public _02235EBA
	.public _02235ECC
	.public _02235EDE
	.public _02235EEA
	.public _02235F00
	.public _02235F12
	.public _02235F52
	.public _02235F7C
	.public _02235F98
	.public _02235F9C
	.public _02235FEE
	.public _02235FF6
	.public _02235FF8
	.public _02236014
	.public _022360BE
	.public _022360DA
	.public _02236100
	.public _02236104
	.public _02236108
	.public _02236118
	.public _02236154
	.public _02236180
	.public _022361AC
	.public _022361C0
	.public _022361C4
	.public _022361CA
	.public _022361D4
	.public _022361F2
	.public _02236202
	.public _0223620A
	.public _02236212
	.public _02236222
	.public _0223622A
	.public _0223624A
	.public _02236252
	.public _0223626A
	.public _0223626C
	.public _02236278
	.public _022362A4
	.public _022362B8
	.public _022362D6
	.public _022362DE
	.public _022362E0
	.public _0223630E
	.public _0223631C
	.public _0223634A
	.public _02236358
	.public _02236376
	.public _0223638E
	.public _02236398
	.public _022363A8
	.public _022363B6
	.public _022363B8
	.public _022363D4
	.public _0223649C
	.public _022364C4
	.public _022364C8
	.public _022364CC
	.public _02236560
	.public _0223656E
	.public _022366A4
	.public _022366A8
	.public _022366AC
	.public _022366B0
	.public _022366B4
	.public _022366B8
	.public _022366BC
	.public _022366C0
	.public _022366C4
	.public _022366C8
	.public _022366E6
	.public _022366FC
	.public _02236752
	.public _02236782
	.public _022367AC
	.public _022367B2
	.public _022367CC
	.public _022367D8
	.public _022367E0
	.public _02236822
	.public _0223685A
	.public _02236886
	.public _022368DC
	.public _022368E4
	.public _022368E8
	.public _02236920
	.public _02236946
	.public _02236980
	.public _022369D8
	.public _022369F6
	.public _02236A32
	.public _02236A4E
	.public _02236A54
	.public _02236A8A
	.public _02236A92
	.public _02236A9E
	.public _02236AAE
	.public _02236ACC
	.public _02236B18
	.public _02236B40
	.public _02236B5E
	.public _02236B62
	.public _02236BA4
	.public _02236BCE
	.public _02236C02
	.public _02236C26
	.public _02236C48
	.public _02236C50
	.public _02236C58
	.public _02236C5C
	.public _02236C60
	.public _02236C80
	.public _02236C9E
	.public _02236CE6
	.public _02236D04
	.public _02236D36
	.public _02236D52
	.public _02236D58
	.public _02236D5C
	.public _02236D7C
	.public _02236DC6
	.public _02236DEE
	.public _02236E0C
	.public _02236E12
	.public _02236E34
	.public _02236E60
	.public _02236E88
	.public _02236EA6
	.public _02236EAC
	.public _02236ED2
	.public _02236F2C
	.public _02236F30
	.public _02236F34
	.public _02236F50
	.public _02236FD8
	.public _02236FDC
	.public _02236FF0
	.public _02237018
	.public _02237078
	.public _0223713C
	.public _02237140
	.public _0223719C
	.public _022371B2
	.public _022371D0
	.public _022371DE
	.public _02237214
	.public _02237238
	.public _02237280
	.public _022372F6
	.public _022373D2
	.public _022373E0
	.public _022373F2
	.public _02237404
	.public _02237436
	.public _02237462
	.public _02237470
	.public _022374B2
	.public _022374CC
	.public _022374CE
	.public _022374D0
	.public _02237540
	.public _02237544
	.public _02237562
	.public _0223757A
	.public _022375A0
	.public _022375AC
	.public _0223763C
	.public _02237640
	.public _02237668
	.public _02237684
	.public _022376F8
	.public _02237718
	.public _02237792
	.public _022377D6
	.public _022377F8
	.public _02237814
	.public _0223781C
	.public _0223784E
	.public _02237888
	.public _02237894
	.public _022378DE
	.public _02237938
	.public _02237970
	.public _02237974
	.public _02237994
	.public _02237A1E
	.public _02237A5A
	.public _02237A7C
	.public _02237A98
	.public _02237AA0
	.public _02237AA4
	.public _02237AE6
	.public _02237B70
	.public _02237B74
	.public _02237B78
	.public _02237BD0
	.public _02237C50
	.public _02237C84
	.public _02237CBA
	.public _02237D16
	.public _02237D3C
	.public _02237D60
	.public _02237D64
	.public _02237D68
	.public _02237D7C
	.public _02237DAE
	.public _02237DB6
	.public _02237DC2
	.public _02237DD4
	.public _02237E1A
	.public _02237E8A
	.public _02237EA8
	.public _02237EE8
	.public _02237EFE
	.public _02237F06
	.public _02237F9A
	.public _02237FAE
	.public _02237FE6
	.public _02237FEC
	.public _02237FFE
	.public _0223806C
	.public _02238082
	.public _02238084
	.public _022380B4
	.public _02238104
	.public _02238124
	.public _02238128
	.public _0223812C
	.public _02238130
	.public _02238134
	.public _02238138
	.public _0223813C
	.public _02238140
	.public _0223817E
	.public _0223823A
	.public _02238272
	.public _02238278
	.public _0223827C
	.public _02238280
	.public _02238284
	.public _02238288
	.public _0223828C
	.public _022382AA
	.public _022382FA
	.public _022382FC
	.public _02238300
	.public _0223831C
	.public _0223832C
	.public _0223833E
	.public _0223834C
	.public _02238350
	.public _02238354
	.public _022383A6
	.public _022383B4
	.public _022383B8
	.public _022383BC
	.public _022383C0
	.public _022383C4
	.public _022383E4
	.public _022383E6
	.public _0223842A
	.public _0223844A
	.public _022384B4
	.public _022384EA
	.public _0223852E
	.public _02238534
	.public _02238538
	.public _0223853C
	.public _02238540
	.public _02238544
	.public _02238548
	.public _02238560
	.public _0223856C
	.public _02238574
	.public _022385B2
	.public _022385D2
	.public _02238610
	.public _0223862E
	.public _02238648
	.public _022386C6
	.public _022386DC
	.public _022386DE
	.public _0223871A
	.public _022387D0
	.public _022387D8
	.public _022387F4
	.public _022387FC
	.public _02238800
	.public _02238804
	.public _02238808
	.public _0223880C
	.public _02238810
	.public _02238814
	.public _02238818
	.public _0223881C
	.public _02238854
	.public _0223889A
	.public _022388A6
	.public _022388BE
	.public _0223891E
	.public _02238A10
	.public _02238A30
	.public _02238A38
	.public _02238A3C
	.public _02238A40
	.public _02238A44
	.public _02238A48
	.public _02238A4C
	.public _02238A6C
	.public _02238A86
	.public _02238AD6
	.public _02238B52
	.public _02238B96
	.public _02238B9C
	.public _02238BA0
	.public _02238BA4
	.public _02238BA8
	.public _02238BAC
	.public _02238BCC
	.public _02238BDA
	.public _02238BFE
	.public _02238C16
	.public _02238C5E
	.public _02238D14
	.public _02238D38
	.public _02238D40
	.public _02238D44
	.public _02238D48
	.public _02238D4C
	.public _02238D50
	.public _02238D54
	.public _02238D58
	.public _02238D72
	.public _02238DC8
	.public _02238DD4
	.public _02238E1E
	.public _02238E78
	.public _02238EB0
	.public _02238EB4
	.public _02238ED4
	.public _02238EFC
	.public _02238F1A
	.public _02238F2E
	.public _02238F34
	.public _02238F5A
	.public _02238FD4
	.public _02238FD8
	.public _02238FDC
	.public _02238FE0
	.public _02238FE4
	.public _02238FE8
	.public _02238FEC
	.public _02238FF0
	.public _0223901C
	.public _02239022
	.public _02239026
	.public _0223902C
	.public _02239084
	.public _0223910E
	.public _02239120
	.public _02239126
	.public _02239176
	.public _022391FE
	.public _0223920C
	.public _02239214
	.public _02239264
	.public _022392FE
	.public _02239314
	.public _02239318
	.public _0223931C
	.public _02239320
	.public _02239324
	.public _02239328
	.public _0223932C
	.public _02239330
	.public _02239334
	.public _02239338
	.public _0223933C
	.public _02239358
	.public _022393EC
	.public _022393F0
	.public _02239400
	.public _02239434
	.public _0223947C
	.public _022394B4
	.public _02239508
	.public _0223950C
	.public _02239510
	.public _02239520
	.public _02239548
	.public _02239558
	.public _0223956C
	.public _02239570
	.public _022395BA
	.public _022395CE
	.public _02239614
	.public _0223961A
	.public _02239668
	.public _022396A6
	.public _022396D0
	.public _022396F8
	.public _0223971C
	.public _02239726
	.public _0223973A
	.public _022397A4
	.public _022397A8
	.public _022397AC
	.public _022397B0
	.public _022397B4
	.public _022397B8
	.public _022397F0
	.public _02239816
	.public _02239950
	.public _0223996C
	.public _0223998A
	.public _022399A8
	.public _022399B6
	.public _022399EE
	.public _02239A48
	.public _02239A4C
	.public _02239A50
	.public _02239A54
	.public _02239A6E
	.public _02239A82
	.public _02239ACC
	.public _02239B42
	.public _02239B52
	.public _02239B72
	.public _02239B7A
	.public _02239B86
	.public _02239B94
	.public _02239BD4
	.public _02239BE4
	.public _02239BEC
	.public _02239C2A
	.public _02239CD6
	.public _02239CEE
	.public _02239CF6
	.public _02239D34
	.public _02239D58
	.public _02239D5C
	.public _02239D78
	.public _02239D7A
	.public _02239DA6
	.public _02239DBA
	.public _02239E18
	.public _02239E6E
	.public _02239EA0
	.public _02239EC8
	.public _02239ED0
	.public _02239ED4
	.public _02239ED8
	.public _02239EDC
	.public _02239EE0
	.public _02239EE4
	.public _02239EE8
	.public _02239EEC
	.public _02239EF0
	.public _02239EF4
	.public _02239EF8
	.public _02239F14
	.public _02239FC0
	.public _02239FF0
	.public _0223A022
	.public _0223A028
	.public _0223A030
	.public _0223A074
	.public _0223A078
	.public _0223A07C
	.public _0223A096
	.public _0223A0B8
	.public _0223A0EC
	.public _0223A10C
	.public _0223A13E
	.public _0223A144
	.public _0223A148
	.public _0223A14C
	.public _0223A150
	.public _0223A154
	.public _0223A16E
	.public _0223A19E
	.public _0223A1EA
	.public _0223A23E
	.public _0223A26E
	.public _0223A29A
	.public _0223A2BE
	.public _0223A2D0
	.public _0223A2E8
	.public _0223A312
	.public _0223A318
	.public _0223A31C
	.public _0223A320
	.public _0223A33E
	.public _0223A35C
	.public _0223A382
	.public _0223A3B0
	.public _0223A3B4
	.public _0223A3B8
	.public _0223A3C6
	.public _0223A3E4
	.public _0223A3F0
	.public _0223A402
	.public _0223A428
	.public _0223A42C
	.public _0223A58A
	.public _0223A5FA
	.public _0223A602
	.public _0223A638
	.public _0223A63C
	.public _0223A65A
	.public _0223A662
	.public _0223A66E
	.public _0223A678
	.public _0223A69C
	.public _0223A6A8
	.public _0223A6AE
	.public _0223A6CE
	.public _0223A6E8
	.public _0223A72E
	.public _0223A75A
	.public _0223A794
	.public _0223A7CC
	.public _0223A7E8
	.public _0223A80A
	.public _0223A812
	.public _0223A818
	.public _0223A81C
	.public _0223A820
	.public _0223A824
	.public _0223A828
	.public _0223A82C
	.public _0223A830
	.public _0223A834
	.public _0223A838
	.public _0223A88E
	.public _0223A89E
	.public _0223A8CC
	.public _0223A8FE
	.public _0223A918
	.public _0223A91E
	.public _0223A938
	.public _0223A944
	.public _0223A954
	.public _0223A964
	.public _0223A99C
	.public _0223A9B6
	.public _0223A9D4
	.public _0223AA0A
	.public _0223AA18
	.public _0223AA4E
	.public _0223AA5C
	.public _0223AA76
	.public _0223AA82
	.public _0223AA94
	.public _0223AA9C
	.public _0223AA9E
	.public _0223AAF0
	.public _0223AB4A
	.public _0223ABCC
	.public _0223ABFC
	.public _0223AC04
	.public _0223AC08
	.public _0223AC0C
	.public _0223AC10
	.public _0223AC14
	.public _0223AC18
	.public _0223AC1C
	.public _0223AC20
	.public _0223AC3C
	.public _0223AC80
	.public _0223AC9A
	.public _0223ACC0
	.public _0223ACC6
	.public _0223ACCC
	.public _0223ACE4
	.public _0223ACF0
	.public _0223ACF8
	.public _0223AD20
	.public _0223AD40
	.public _0223AD5A
	.public _0223AD9A
	.public _0223AE1E
	.public _0223AE5A
	.public _0223AE82
	.public _0223AEB0
	.public _0223AEBC
	.public _0223AED2
	.public _0223AEEC
	.public _0223AF02
	.public _0223AF10
	.public _0223AF18
	.public _0223AF20
	.public _0223AF50
	.public _0223AF5C
	.public _0223AF64
	.public _0223AF8C
	.public _0223AFC2
	.public _0223AFDC
	.public _0223B020
	.public _0223B092
	.public _0223B0C2
	.public _0223B0EA
	.public _0223B118
	.public _0223B124
	.public _0223B13A
	.public _0223B154
	.public _0223B16A
	.public _0223B178
	.public _0223B180
	.public _0223B188
	.public _0223B18C
	.public _0223B1A6
	.public _0223B1F6
	.public _0223B202
	.public _0223B218
	.public _0223B278
	.public _0223B292
	.public _0223B298
	.public _0223B2BC
	.public _0223B31A
	.public _0223B36C
	.public _0223B370
	.public _0223B3BA
	.public _0223B3EC
	.public _0223B444
	.public _0223B448
	.public _0223B460
	.public _0223B4F0
	.public _0223B516
	.public _0223B550
	.public _0223B566
	.public _0223B570
	.public _0223B58C
	.public _0223B5A2
	.public _0223B5AC
	.public _0223B5DE
	.public _0223B5EA
	.public _0223B5F2
	.public _0223B628
	.public _0223B646
	.public _0223B65A
	.public _0223B6A4
	.public _0223B700
	.public sMainMenuUtilGiftPalettes
	.public _0223B74E
	.public _0223B756
	.public _0223B776
	.public _0223B77E
	.public _0223B78A
	.public _0223B798
	.public _0223B7DA
	.public _0223B7E2
	.public _0223B7F0
	.public _0223B816
	.public _0223B836
	.public _0223B85E
	.public _0223B86C
	.public _0223B86E
	.public _0223B876
	.public _0223B87C
	.public _0223B8B0
	.public _0223B8DA
	.public _0223B8DE
	.public _0223B8F8
	.public _0223B8FE
	.public _0223B920
	.public _0223B940
	.public _0223B95A
	.public _0223B98E
	.public _0223BA04
	.public _0223BA36
	.public _0223BA58
	.public _0223BA60
	.public _0223BA64
	.public _0223BA68
	.public _0223BA6C
	.public _0223BB68
	.public _0223BB6C
	.public _0223BB70
	.public _0223BB8C
	.public _0223BB8E
	.public _0223BB9A
	.public _0223BBA2
	.public _0223BCCE
	.public _0223BD3C
	.public _0223BD6E
	.public _0223BD74
	.public _0223BD7C
	.public _0223BD80
	.public _0223BD84
	.public _0223BD88
	.public _0223BD8C
	.public _0223BD90
	.public _0223BD94
	.public _0223BDB2
	.public _0223BDB4
	.public _0223BE22
	.public _0223BE2E
	.public _0223BE42
	.public _0223BEB6
	.public _0223BEBC
	.public _0223BF1E
	.public _0223BF24
	.public _0223BF56
	.public _0223BF5E
	.public _0223BF64
	.public _0223BF68
	.public _0223BF6C
	.public _0223BF70
	.public _0223BF74
	.public _0223BF78
	.public _0223BF7C
	.public _0223BF80
	.public _0223BF84
	.public _0223BFA2
	.public _0223BFBA
	.public _0223BFF0
	.public _0223C00A
	.public _0223C030
	.public _0223C0A4
	.public _0223C0D4
	.public _0223C0EA
	.public _0223C0F6
	.public _0223C0FE
	.public _0223C10E
	.public _0223C15C
	.public _0223C1BE
	.public _0223C200
	.public _0223C21A
	.public _0223C222
	.public _0223C228
	.public _0223C22C
	.public _0223C230
	.public _0223C234
	.public _0223C238
	.public _0223C23C
	.public _0223C26A
	.public _0223C276
	.public _0223C27E
	.public _0223C298
	.public _0223C2A4
	.public _0223C2BC
	.public _0223C2D4
	.public _0223C304
	.public _0223C330
	.public _0223C340
	.public _0223C364
	.public _0223C370
	.public _0223C388
	.public _0223C3A0
	.public _0223C3C0
	.public _0223C3E0
	.public _0223C3F0
	.public _0223C40A
	.public _0223C416
	.public _0223C482
	.public _0223C48E
	.public _0223C494
	.public _0223C4AC
	.public _0223C4B8
	.public _0223C4C4
	.public _0223C4EA
	.public _0223C4F8
	.public _0223C592
	.public _0223C5E0
	.public _0223C642
	.public _0223C684
	.public _0223C69E
	.public _0223C6BC
	.public _0223C6CC
	.public _0223C6E2
	.public _0223C6E8
	.public _0223C6EC
	.public _0223C6F0
	.public _0223C6F4
	.public _0223C6F8
	.public _0223C6FC
	.public _0223C700
	.public _0223C704
	.public _0223C708
	.public _0223C70C
	.public _0223C7C4
	.public _0223C7CE
	.public _0223C804
	.public _0223C808
	.public _0223C838
	.public _0223C83E
	.public _0223C84A
	.public _0223C858
	.public _0223C874
	.public _0223C880
	.public _0223C8BC
	.public _0223C902
	.public _0223C91C
	.public _0223C92C
	.public _0223C936
	.public _0223C964
	.public _0223C99A
	.public _0223C9B4
	.public _0223CA0A
	.public _0223CA7C
	.public _0223CAAC
	.public _0223CAD4
	.public _0223CB02
	.public _0223CB0E
	.public _0223CB24
	.public _0223CB3E
	.public _0223CB54
	.public _0223CB62
	.public _0223CB6C
	.public _0223CB7A
	.public _0223CB96
	.public _0223CBA2
	.public _0223CBDE
	.public _0223CC24
	.public _0223CC40
	.public _0223CC44
	.public _0223CC48
	.public _0223CC4C
	.public _0223CC76
	.public _0223CC90
	.public _0223CC98
	.public _0223CD10
	.public _0223CE34
	.public _0223CE82
	.public _0223CE8A
	.public _0223CE9A
	.public _0223CEB2
	.public _0223CEC2
	.public _0223CEDA
	.public _0223CEEA
	.public _0223CEF8
	.public _0223CEFC
	.public _0223CF1E
	.public _0223CF26
	.public _0223CF44
	.public _0223CF4C
	.public _0223CF54
	.public _0223CF68
	.public _0223CF6C
	.public _0223CF82
	.public _0223CF98
	.public _0223CFA6
	.public _0223D000
	.public _0223D004
	.public _0223D022
	.public _0223D056
	.public _0223D062
	.public _0223D070
	.public _0223D072
	.public _0223D07C
	.public _0223D094
	.public _0223D0BA
	.public _0223D0D4
	.public _0223D0E8
	.public _0223D10E
	.public _0223D11E
	.public _0223D158
	.public _0223D170
	.public _0223D188
	.public _0223D194
	.public _0223D198
	.public _0223D19C
	.public _0223D1A0
	.public _0223D1A4
	.public _0223D1A8
	.public _0223D1C0
	.public _0223D1C4
	.public _0223D1D0
	.public _0223D1EC
	.public _0223D204
	.public _0223D208
	.public _0223D21E
	.public _0223D23C
	.public _0223D240
	.public _0223D278
	.public _0223D292
	.public _0223D2A2
	.public _0223D2BE
	.public _0223D2E2
	.public _0223D2E6
	.public _0223D308
	.public _0223D31C
	.public _0223D320
	.public _0223D340
	.public _0223D350
	.public _0223D392
	.public _0223D39C
	.public _0223D3BA
	.public _0223D3E0
	.public _0223D3FC
	.public _0223D412
	.public _0223D438
	.public _0223D450
	.public _0223D48A
	.public _0223D4BA
	.public _0223D4CA
	.public _0223D4DA
	.public _0223D4E0
	.public _0223D4E4
	.public _0223D4E8
	.public _0223D4EC
	.public _0223D4F0
	.public _0223D4F4
	.public _0223D4F8
	.public _0223D4FC
	.public _0223D500
	.public _0223D5A4
	.public _0223D5A8
	.public _0223D5AC
	.public _0223D5B0
	.public _0223D5B4
	.public _0223D5B8
	.public _0223D5BC
	.public _0223D5C0
	.public _0223D5C4
	.public _0223D5C8
	.public _0223D5DC
	.public _0223D5FC
	.public _0223D614
	.public _0223D622
	.public _0223D640
	.public _0223D64C
	.public _0223D65E
	.public _0223D684
	.public _0223D688
	.public _0223D6A0
	.public _0223D6DA
	.public _0223D6E6
	.public _0223D6F4
	.public _0223D6F6
	.public _0223D700
	.public _0223D718
	.public _0223D73E
	.public _0223D758
	.public _0223D76C
	.public _0223D792
	.public _0223D7A2
	.public _0223D7DA
	.public _0223D7F2
	.public _0223D80A
	.public _0223D814
	.public _0223D818
	.public _0223D81C
	.public _0223D820
	.public _0223D824
	.public _0223D828
	.public _0223D82C
	.public _0223D844
	.public _0223D848
	.public _0223D854
	.public _0223D870
	.public _0223D88E
	.public _0223D892
	.public _0223D8A8
	.public _0223D8CC
	.public _0223D8D0
	.public _0223D90A
	.public _0223D926
	.public _0223D936
	.public _0223D952
	.public _0223D976
	.public _0223D97A
	.public _0223D99C
	.public _0223D9B0
	.public _0223D9B4
	.public _0223D9D4
	.public _0223D9E4
	.public _0223DA26
	.public _0223DA30
	.public _0223DA4E
	.public _0223DA74
	.public _0223DA90
	.public _0223DAA6
	.public _0223DACC
	.public _0223DAE4
	.public _0223DB1C
	.public _0223DB4C
	.public _0223DB5C
	.public _0223DB6C
	.public _0223DB70
	.public _0223DB74
	.public _0223DB78
	.public _0223DB7C
	.public _0223DB80
	.public _0223DB84
	.public _0223DB88
	.public _0223DB8C
	.public _0223DB90
	.public _0223DBAA
	.public _0223DBB6
	.public _0223DBC6
	.public _0223DBCA
	.public _0223DBD0
	.public _0223DBEA
	.public _0223DC0C
	.public _0223DC18
	.public _0223DC30
	.public _0223DC94
	.public _0223DCD8
	.public _0223DCDC
	.public _0223DCE0
	.public _0223DCE4
	.public _0223DCE8
	.public _0223DCEC
	.public _0223DD18
	.public _0223DD2E
	.public _0223DD38
	.public _0223DD60
	.public _0223DD64
	.public _0223DD94
	.public _0223DDB0
	.public _0223DDDC
	.public _0223DDE0
	.public _0223DDE4
	.public _0223DE18
	.public _0223DE50
	.public _0223DE78
	.public _0223DE84
	.public _0223DEB0
	.public _0223DEB4
	.public _0223DED0
	.public _0223DED2
	.public _0223DF0C
	.public _0223DF10
	.public _0223DF14
	.public _0223DF18
	.public _0223DF32
	.public _0223DF4E
	.public _0223DF66
	.public _0223DFC6
	.public _0223E010
	.public _0223E014
	.public _0223E018
	.public _0223E01C
	.public _0223E020
	.public _0223E03C
	.public _0223E052
	.public _0223E05C
	.public _0223E060
	.public _0223E07E
	.public _0223E094
	.public _0223E09C
	.public _0223E0A0
	.public _0223E184
	.public _0223E188
	.public _0223E18C
	.public _0223E1A8
	.public _0223E252
	.public _0223E2D4
	.public _0223E2EE
	.public _0223E2F4
	.public _0223E2FC
	.public _0223E300
	.public _0223E304
	.public _0223E308
	.public _0223E30C
	.public _0223E310
	.public _0223E314
	.public _0223E318
	.public _0223E31C
	.public _0223E320
	.public _0223E338
	.public _0223E356
	.public _0223E37E
	.public _0223E39E
	.public _0223E3B8
	.public _0223E3E2
	.public _0223E456
	.public _0223E486
	.public _0223E48C
	.public _0223E490
	.public _0223E4AA
	.public _0223E4B4
	.public _0223E4D4
	.public _0223E4EE
	.public _0223E500
	.public _0223E508
	.public _0223E510
	.public _0223E516
	.public _0223E51C
	.public _0223E532
	.public _0223E53E
	.public _0223E548
	.public _0223E576
	.public _0223E5C2
	.public _0223E5CC
	.public _0223E5F2
	.public _0223E60C
	.public _0223E63E
	.public _0223E656
	.public _0223E686
	.public _0223E6AE
	.public _0223E6C8
	.public _0223E6D0
	.public _0223E6D4
	.public _0223E6D8
	.public _0223E6DC
	.public _0223E6E0
	.public _0223E6E4
	.public _0223E6E8
	.public _0223E720
	.public _0223E72C
	.public _0223E74A
	.public _0223E7F4
	.public _0223E810
	.public _0223E838
	.public _0223E83C
	.public _0223E840
	.public _0223E844
	.public _0223E856
	.public _0223E86C
	.public _0223E88C
	.public _0223E896
	.public _0223E8A6
	.public _0223E8CC
	.public _0223E8E6
	.public _0223E900
	.public _0223E90E
	.public _0223E918
	.public _0223E938
	.public _0223E960
	.public _0223E97A
	.public _0223E98C
	.public _0223E994
	.public _0223E998
	.public _0223E99C
	.public _0223E9A0
	.public _0223E9B8
	.public _0223E9C4
	.public _0223E9CE
	.public _0223E9EE
	.public _0223EA00
	.public _0223EA1C
	.public _0223EA88
	.public _0223EABC
	.public _0223EADC
	.public _0223EB0C
	.public _0223EB40
	.public _0223EB5A
	.public _0223EB72
	.public _0223EB8E
	.public _0223EB96
	.public _0223EB9C
	.public _0223EBA0
	.public _0223EBA4
	.public _0223EBA8
	.public _0223EBAC
	.public _0223EBB0
	.public _0223EBB4
	.public _0223EBF2
	.public _0223EC02
	.public _0223EC0A
	.public _0223EC16
	.public _0223EC22
	.public _0223EC2A
	.public _0223EC38
	.public _0223EC3C
	.public _0223EC9A
	.public _0223ECAC
	.public _0223ECB6
	.public _0223ECBE
	.public _0223ECD0
	.public _0223ECE2
	.public _0223ECEE
	.public _0223ED02
	.public _0223ED14
	.public _0223ED4C
	.public _0223ED74
	.public _0223ED90
	.public _0223ED94
	.public _0223ED98
	.public _0223ED9C
	.public _0223EDA0
	.public _0223EDA4
	.public _0223EDD4
	.public _0223EDD8
	.public _0223EDDC
	.public _0223EDF2
	.public _0223EDFE
	.public _0223EE08
	.public _0223EE3E
	.public _0223EE9C
	.public _0223EEB6
	.public _0223EF02
	.public _0223EF1A
	.public _0223EF3A
	.public _0223EF62
	.public _0223EF7C
	.public _0223EF84
	.public _0223EF88
	.public _0223EF8C
	.public _0223EF90
	.public _0223EF94
	.public _0223EF98
	.public _0223EF9C
	.public _0223EFA0
	.public _0223EFBA
	.public _0223EFD4
	.public _0223F004
	.public _0223F01E
	.public _0223F024
	.public _0223F042
	.public _0223F054
	.public _0223F05C
	.public _0223F072
	.public _0223F088
	.public _0223F08A
	.public _0223F0B2
	.public _0223F0E6
	.public _0223F0FC
	.public _0223F118
	.public _0223F11E
	.public _0223F126
	.public _0223F140
	.public _0223F148
	.public _0223F150
	.public _0223F154
	.public _0223F158
	.public _0223F15C
	.public _0223F160
	.public _0223F164
	.public _0223F168
	.public _0223F182
	.public _0223F1AA
	.public _0223F1D2
	.public _0223F1EC
	.public _0223F1F2
	.public _0223F1F8
	.public _0223F1FC
	.public _0223F218
	.public _0223F21A
	.public _0223F226
	.public _0223F230
	.public _0223F31C
	.public _0223F38A
	.public _0223F3BC
	.public _0223F3C2
	.public _0223F3C8
	.public _0223F3CC
	.public _0223F3D0
	.public _0223F3D4
	.public _0223F3D8
	.public _0223F3DC
	.public _0223F3E0
	.public _0223F3FE
	.public _0223F456
	.public _0223F462
	.public _0223F474
	.public _0223F4E6
	.public _0223F4EC
	.public _0223F540
	.public _0223F546
	.public _0223F578
	.public _0223F57E
	.public _0223F584
	.public _0223F588
	.public _0223F58C
	.public _0223F590
	.public _0223F594
	.public _0223F598
	.public _0223F5B2
	.public _0223F614
	.public _0223F678
	.public _0223F692
	.public _0223F698
	.public _0223F69C
	.public _0223F6A0
	.public _0223F6A4
	.public _0223F6A8
	.public _0223F6AC
	.public _0223F6B0
	.public _0223F6B4
	.public _0223F6B8
	.public _0223F6CE
	.public _0223F6DA
	.public _0223F6E2
	.public _0223F6F2
	.public _0223F73C
	.public _0223F7A6
	.public _0223F7E8
	.public _0223F802
	.public _0223F80A
	.public _0223F810
	.public _0223F814
	.public _0223F818
	.public _0223F81C
	.public _0223F820
	.public _0223F824
	.public _0223F828
	.public _0223F82C
	.public _0223F844
	.public _0223F85C
	.public _0223F87A
	.public _0223F896
	.public _0223F8E4
	.public _0223F8EE
	.public _0223F904
	.public _0223F958
	.public _0223F972
	.public _0223F978
	.public _0223F97C
	.public _0223F980
	.public _0223F9AE
	.public _0223F9B6
	.public _0223F9C2
	.public _0223F9CE
	.public _0223F9EC
	.public _0223F9F6
	.public _0223FA1C
	.public _0223FA68
	.public _0223FA82
	.public _0223FA92
	.public _0223FA9C
	.public _0223FAD0
	.public _0223FB12
	.public _0223FB8E
	.public _0223FBBA
	.public _0223FBE2
	.public _0223FC12
	.public _0223FC1C
	.public _0223FC32
	.public _0223FC4C
	.public _0223FC62
	.public _0223FC70
	.public _0223FC7A
	.public _0223FC8C
	.public _0223FC94
	.public _0223FC98
	.public _0223FC9C
	.public _0223FCB4
	.public _0223FCDA
	.public _0223FCE8
	.public _0223FCF0
	.public _0223FCF4
	.public _0223FD1A
	.public _0223FD28
	.public _0223FD30
	.public _0223FD34
	.public _0223FD4C
	.public _0223FD7C
	.public _0223FDA6
	.public _0223FDAE
	.public _0223FDBA
	.public _0223FDC4
	.public _0223FDEA
	.public _0223FDF4
	.public _0223FDFA
	.public _0223FE1A
	.public _0223FE34
	.public _0223FE7A
	.public _0223FEA6
	.public _0223FEE0
	.public _0223FF18
	.public _0223FF34
	.public _0223FF5A
	.public _0223FF68
	.public _0223FF70
	.public _0223FF74
	.public _0223FF78
	.public _0223FF7C
	.public _0223FF80
	.public _0223FF84
	.public _0223FF88
	.public _0223FFA0
	.public _0223FFAC
	.public _0223FFB8
	.public _0223FFDE
	.public _0223FFEC
	.public _022400AE
	.public _022400F8
	.public _0224015A
	.public _0224019C
	.public _022401B6
	.public _022401D4
	.public _022401E4
	.public _022401FA
	.public _02240200
	.public _02240204
	.public _02240208
	.public _0224020C
	.public _02240210
	.public _02240214
	.public _02240218
	.public _0224021C
	.public _02240220
	.public _02240224
	.public _02240228
	.public _0224022C
	.public _02240230
	.public _02240234
	.public _022402A6
	.public _022402BA
	.public _02240304
	.public _02240360
	.public _02240372
	.public _02240398
	.public _022403A2
	.public _022403C8
	.public _022403D2
	.public _022403E4
	.public _022403EC
	.public _022403FA
	.public _02240414
	.public _0224043A
	.public _022404AA
	.public _022404CE
	.public _022404F6
	.public _02240510
	.public _02240516
	.public _0224051C
	.public _02240540
	.public _02240562
	.public _02240588
	.public _022405B6
	.public _022405D0
	.public _022405E0
	.public _022405E6
	.public _022405EC
	.public _02240626
	.public _02240692
	.public _022406C2
	.public _022406E2
	.public _022406EE
	.public _022406F8
	.public _02240736
	.public _02240744
	.public _02240764
	.public _02240772
	.public _022407BA
	.public _022407EE
	.public _02240806
	.public _02240814
	.public _0224081A
	.public _0224082C
	.public _02240834
	.public _0224083C
	.public _02240840
	.public _02240844
	.public _02240848
	.public _0224084C
	.public _02240850
	.public _02240854
	.public _02240858
	.public _022408A8
	.public _02240908
	.public _0224090C
	.public _02240940
	.public _0224094C
	.public _02240954
	.public _02240962
	.public _0224096C
	.public _02240A4C
	.public _02240AB4
	.public _02240AF6
	.public _02240B10
	.public _02240B18
	.public _02240B20
	.public _02240B24
	.public _02240B28
	.public _02240B2C
	.public _02240B30
	.public _02240B34
	.public _02240B38
	.public _02240B3C
	.public _02240B54
	.public _02240B6C
	.public _02240B8A
	.public _02240BA2
	.public _02240BAE
	.public _02240BB6
	.public _02240C04
	.public _02240C0E
	.public _02240C24
	.public _02240C4A
	.public _02240C64
	.public _02240C92
	.public _02240D12
	.public _02240D42
	.public _02240D48
	.public _02240D4C
	.public _02240D70
	.public _02240DCE
	.public _02240E20
	.public _02240E24
	.public _02240EDA
	.public _02240EE4
	.public _02240F1C
	.public _02240F20
	.public _02240F9C
	.public _0224100C
	.public _02241014
	.public _0224104C
	.public _02241050
	.public _02241098
	.public _022410C6
	.public _0224110C
	.public _02241110
	.public _02241124
	.public _0224116C
	.public _02241174
	.public _02241180
	.public _0224118C
	.public _022411AA
	.public _022411B4
	.public _022411DA
	.public _02241226
	.public _02241240
	.public _02241250
	.public _0224125A
	.public _02241288
	.public _022412AE
	.public _022412C8
	.public _02241316
	.public _02241398
	.public _022413CA
	.public _022413DC
	.public _022413E0
	.public _022413E4
	.public _022413E8
	.public _02241400
	.public _02241418
	.public _02241430
	.public _02241448
	.public _02241478
	.public _0224149C
	.public _022414A8
	.public _022414B4
	.public _02241548
	.public _02241560
	.public _02241562
	.public _022415E8
	.public _02241660
	.public _0224168C
	.public _022416B4
	.public _022416DC
	.public _022416E6
	.public _0224170C
	.public _02241726
	.public _02241744
	.public _02241754
	.public _0224176A
	.public _02241770
	.public _02241774
	.public _02241778
	.public _0224177C
	.public _02241780
	.public _02241784
	.public _02241788
	.public _0224178C
	.public _02241790
	.public _02241794
	.public _02241798
	.public _0224179C
	.public _022417A0
	.public _022417F0
	.public _022417FC
	.public _02241804
	.public _02241818
	.public _02241826
	.public _02241876
	.public _02241884
	.public _022418D4
	.public _022418FA
	.public _02241910
	.public _0224193A
	.public _02241940
	.public _02241944
	.public _0224198C
	.public _02241A00
	.public _02241A30
	.public _02241A50
	.public _02241AA8
	.public _02241AAC
	.public _02241AF8
	.public _02241BD4
	.public _02241BD8
	.public _02241C08
	.public _02241C0C
	.public _02241C28
	.public _02241C30
	.public _02241C40
	.public _02241C50
	.public _02241C60
	.public _02241C6E
	.public _02241C8E
	.public _02241C96
	.public _02241CB6
	.public _02241CBE
	.public _02241CC6
	.public _02241CD4
	.public _02241CEA
	.public _02241D00
	.public _02241D0E
	.public _02241D30
	.public _02241D3A
	.public _02241D4E
	.public _02241D62
	.public _02241D86
	.public _02241DA8
	.public _02241DB0
	.public _02241DC6
	.public _02241DD6
	.public _02241DF6
	.public _02241DFE
	.public _02241E00
	.public _02241E04
	.public _02241E08
	.public _02241E0C
	.public _02241E10
	.public _02241E32
	.public _02241E3A
	.public _02241E3C
	.public _02241E5E
	.public _02241E66
	.public _02241E76
	.public _02241E8E
	.public _02241E9C
	.public _02241EB4
	.public _02241EC2
	.public _02241ED0
	.public _02241EF2
	.public _02241EFA
	.public _02241F1A
	.public _02241F22
	.public _02241F2A
	.public _02241F38
	.public _02241F4E
	.public _02241F64
	.public _02241F72
	.public _02241F9C
	.public _02241FB4
	.public _022420DC
	.public _022420F4
	.public _02242186
	.public _022421B2
	.public _022421F8
	.public _0224223E
	.public _0224224A
	.public _02242252
	.public _0224226E
	.public _02242278
	.public _02242290
	.public _022422A8
	.public _022422D8
	.public _02242302
	.public _02242312
	.public _02242338
	.public _02242342
	.public _0224235A
	.public _02242374
	.public _02242392
	.public _022423AE
	.public _022423B8
	.public _022423DE
	.public _0224242A
	.public _02242444
	.public _0224246E
	.public _02242488
	.public _0224248C
	.public _022424A8
	.public _022424EE
	.public _02242508
	.public _0224252E
	.public _02242534
	.public _02242556
	.public _02242566
	.public _02242594
	.public _022425C6
	.public _022425E0
	.public _022425E4
	.public _022425FC
	.public _02242608
	.public _02242618
	.public _02242628
	.public _02242660
	.public _0224267A
	.public _0224269A
	.public _022426D0
	.public _022426DE
	.public _02242714
	.public _02242722
	.public _0224273C
	.public _02242748
	.public _0224275A
	.public _02242762
	.public _02242764
	.public _022427A6
	.public _022427FC
	.public _0224287E
	.public _022428AE
	.public _022428B4
	.public _022428B8
	.public _022428BC
	.public _022428C0
	.public _022428C4
	.public _022428C8
	.public _022428CC
	.public _022428D0
	.public _022428E8
	.public _022428F4
	.public _022428FC
	.public _02242924
	.public _02242944
	.public _0224295E
	.public _02242992
	.public _02242A18
	.public _02242A4E
	.public _02242A76
	.public _02242AA6
	.public _02242AB0
	.public _02242AC6
	.public _02242AE0
	.public _02242AE6
	.public _02242B00
	.public _02242B0C
	.public _02242B14
	.public _02242B40
	.public _02242B66
	.public _02242B80
	.public _02242BB8
	.public _02242C2C
	.public _02242C58
	.public _02242C80
	.public _02242CB0
	.public _02242CBA
	.public _02242CD0
	.public _02242CEA
	.public _02242CF0
	.public _02242CF8
	.public _02242D18
	.public _02242D38
	.public _02242D48
	.public _02242D64
	.public _02242D6E
	.public _02242DD6
	.public _02242DDC
	.public _02242DE4
	.public _02242DE8
	.public _02242DEC
	.public _02242E10
	.public _02242E3C
	.public _02242E40
	.public _02242E44
	.public _02242F9C
	.public _02242FA0
	.public _02242FA4
	.public _02242FA8
	.public _02242FDA
	.public _02243006
	.public _0224300E
	.public _0224306E
	.public _0224309C
	.public _0224312A
	.public _0224315E
	.public _02243170
	.public _022431A0
	.public _022431C0
	.public _022431DC
	.public _022431EC
	.public _02243208
	.public _02243298
	.public _022432A6
	.public _022432C0
	.public _022432C2
	.public _022432DA
	.public _02243324
	.public _02243356
	.public _02243364
	.public _0224336C
	.public _02243394
	.public _022433BA
	.public _022433DA
	.public _022433F2
	.public _02243412
	.public _0224341C
	.public _02243428
	.public _0224343E
	.public _0224344E
	.public _02243460
	.public _0224346E
	.public _02243484
	.public _02243494
	.public _022434A6
	.public _022434B4
	.public _022434D0
	.public _022434F2
	.public _02243504
	.public _02243518
	.public _02243526
	.public _0224352C
	.public _02243530
	.public _02243534
	.public _02243554
	.public _02243558
	.public _02243590
	.public _022435A8
	.public _022435C2
	.public _022435FC
	.public _02243610
	.public _02243650
	.public _022436B0
	.public _022436C0
	.public _022436E4
	.public _022436F6
	.public _02243716
	.public _02243764
	.public _022437AC
	.public _022437B0
	.public _022437B4
	.public _022437B8
	.public _022437BC
	.public _022437D2
	.public _022437E2
	.public _022437E8
	.public _02243806
	.public _02243814
	.public _0224381C
	.public _02243830
	.public _02243844
	.public _02243862
	.public _02243904
	.public _02243926
	.public _02243934
	.public _02243946
	.public _02243950
	.public _02243954
	.public _02243958
	.public _0224397A
	.public _0224397E
	.public _022439A6
	.public _022439B4
	.public _022439DA
	.public _022439E6
	.public _022439EE
	.public _02243A06
	.public _02243A10
	.public _02243A1A
	.public _02243A22
	.public _02243B44
	.public _02243B5E
	.public _02243B6A
	.public _02243B74
	.public _02243B7C
	.public _02243B88
	.public _02243BAA
	.public _02243BBA
	.public _02243BC2
	.public _02243BD8
	.public _02243C50
	.public _02243CB8
	.public _02243D12
	.public _02243D4E
	.public _02243D60
	.public _02243E7C
	.public _02243E9A
	.public _02243FB4
	.public _02243FF2
	.public _02243FFC
	.public _02244008
	.public _0224401C
	.public _02244040
	.public _0224404A
	.public _0224405C
	.public _0224407A
	.public _0224408A
	.public _0224408C
	.public _0224409A
	.public _022440CA
	.public _022440CE
	.public _022440F2
	.public _022440FA
	.public _02244106
	.public _0224410C
	.public _0224412E
	.public _0224414A
	.public _02244186
	.public _02244196
	.public _0224419C
	.public _022441B6
	.public _022441D8
	.public _022441E0
	.public _022441F2
	.public _0224420C
	.public _02244228
	.public _0224422E
	.public _0224427A
	.public _02244288
	.public _022442C8
	.public _022442EC
	.public _0224436A
	.public _02244372
	.public _022443A8
	.public _022443AC
	.public _022443B0
	.public _02244490
	.public _0224452C
	.public _02244540
	.public _0224458A
	.public _02244618
	.public _02244626
	.public _02244640
	.public _0224464C
	.public _0224465A
	.public _022446A6
	.public _022446E2
	.public _022446FC
	.public _0224471E
	.public _0224473E
	.public _02244760
	.public _02244782
	.public _0224478E
	.public _022447B8
	.public _022447BE
	.public _022447D8
	.public _022447FE
	.public _02244808
	.public _0224481E
	.public _02244824
	.public _02244828
	.public _0224482C
	.public _02244830
	.public _02244834
	.public _02244838
	.public _02244856
	.public _0224485A
	.public _02244860
	.public _02244896
	.public _022448EA
	.public _0224491A
	.public _02244AC6
	.public _02244AD2
	.public _02244AFA
	.public _02244B1A
	.public _02244B28
	.public _02244B2C
	.public _02244B30
	.public _02244B34
	.public _02244B38
	.public _02244B4A
	.public _02244B64
	.public _02244B68
	.public _02244B6C
	.public _02244B84
	.public _02244B90
	.public _02244BA6
	.public _02244BB4
	.public _02244BB8
	.public _02244BCE
	.public _02244C2A
	.public _02244C34
	.public _02244C38
	.public _02244C3C
	.public _02244C40
	.public sVsRecorderGraphicsModes
	.public sVsRecorderFrontierPrintPositions
	.public VsRecorder_InitResources
	.public VsRecorder_FreeResources
	.public VsRecorder_InitBgLayers
	.public VsRecorder_SetScreensFlipped
	.public VsRecorder_ResetBg2
	.public VsRecorder_InitSpriteSystem
	.public VsRecorder_VBlankCB
	.public VsRecorder_Main
	.public VsRecorder_SetScreenIfDone
	.public VsRecorder_SetSubState
	.public VsRecorder_SetStep
	.public VsRecorder_RefreshMenu
	.public VsRecorder_MenuEnterChild
	.public VsRecorder_MenuRestore
	.public VsRecorder_MenuRunAction
	.public VsRecorder_MenuCanSelect
	.public VsRecorder_OnMenuTouch
	.public VsRecorder_InitMenuHitboxes
	.public VsRecorder_UpdateMenuHitboxes
	.public VsRecorder_ClearMenuHitboxes
	.public VsRecorder_UpdateMenuTouch
	.public VsRecorder_MenuPop
	.public VsRecorder_ClearResumeState
	.public VsRecorder_HasResumeScreen
	.public VsRecorder_SetResumeScreen
	.public VsRecorder_LoadFrameBg
	.public VsRecorder_LoadMessageBg
	.public VsRecorder_LoadBoxDataMessageBg
	.public VsRecorder_LoadDecorGfx
	.public VsRecorder_CreateDecorSprites
	.public VsRecorder_DeleteDecorSprites
	.public VsRecorder_DestroyDecorTasks
	.public VsRecorder_LoadMenuRowGfx
	.public VsRecorder_UnloadMenuRowChars
	.public VsRecorder_LayoutMenuRows
	.public VsRecorder_CreateMenuRowSprites
	.public VsRecorder_RefreshChoiceRows
	.public VsRecorder_AttachMenuRowText
	.public VsRecorder_RefreshPathRows
	.public VsRecorder_DeleteMenuRowSprites
	.public VsRecorder_SetMenuRowsDrawFlag
	.public VsRecorder_DecorTask
	.public VsRecorder_SetSpritePos
	.public VsRecorder_GetSpritePos
	.public VsRecorder_CreateMenuRowText
	.public VsRecorder_SetMenuRowText
	.public VsRecorder_FreeMenuRowText
	.public VsRecorder_CreateTextSprite
	.public VsRecorder_SetTextSpriteMsg
	.public VsRecorder_FreeTextSprite
	.public VsRecorder_LoadButtonGfx31
	.public VsRecorder_LoadButtonGfx
	.public VsRecorder_LoadSlotButtonGfx
	.public VsRecorder_FreeButtonGfx
	.public VsRecorder_NewButtonSprite
	.public VsRecorder_FreeMenuRows
	.public VsRecorder_RebuildMenuRowsParent
	.public VsRecorder_RebuildMenuRows
	.public VsRecorder_InitBlend
	.public VsRecorder_ApplyBlend
	.public VsRecorder_InitBgBlend
	.public VsRecorder_StepBlend
	.public VsRecorder_StepFade
	.public VsRecorder_ResetFade
	.public VsRecorder_NewMessageFormat
	.public VsRecorder_GetBlendColor
	.public VsRecorder_GetMenuBlendColor
	.public VsRecorder_GetSchemeFileId
	.public VsRecorder_ReloadSchemePalettes
	.public VsRecorder_ClearPaletteBlend
	.public VsRecorder_LoadSpeciesList
	.public VsRecorder_SetBoxUploaded
	.public VsRecorder_IsBoxUploaded
	.public VsRecorder_ShowNotice
	.public VsRecorder_HideNotice
	.public VsRecorder_RemoveTopMessage
	.public VsRecorder_ShowTopMessage
	.public VsRecorder_SetMessageText
	.public VsRecorder_HideTopMessage
	.public VsRecorder_ShowMenuNotice
	.public VsRecorder_PrintProfile
	.public VsRecorder_RemoveProfileWindows
	.public VsRecorder_SetProfileMonIconDrawFlag
	.public VsRecorder_FreeProfileMonIcon
	.public VsRecorder_CreateProfileMonIcon
	.public VsRecorder_SetProfileAvatarDrawFlag
	.public VsRecorder_FreeProfileAvatar
	.public VsRecorder_GetAvatarFileId
	.public VsRecorder_CreateProfileAvatar
	.public VsRecorder_CreateProfile
	.public VsRecorder_FreeProfile
	.public VsRecorder_SetProfileDrawFlag
	.public VsRecorder_PrintListLocation
	.public VsRecorder_InitMessageList
	.public VsRecorder_InitList
	.public VsRecorder_InitRankingList
	.public VsRecorder_InitPairList
	.public VsRecorder_RedrawPairList
	.public VsRecorder_RedrawRankingList
	.public VsRecorder_UpdateMessageList
	.public VsRecorder_RedrawNameList
	.public VsRecorder_ListMoveCursor
	.public VsRecorder_ListScroll
	.public VsRecorder_RemoveListWindow
	.public VsRecorder_ClearListWindow
	.public VsRecorder_CreateListArrows
	.public VsRecorder_SetListArrowsY
	.public VsRecorder_UpdateListArrows
	.public VsRecorder_UpdateListArrowsCursor
	.public VsRecorder_FreeListArrows
	.public VsRecorder_NewScrollSprite
	.public VsRecorder_DeleteTouchScrollSprites
	.public VsRecorder_CreateTouchScrollSprites
	.public VsRecorder_CreateTouchScrollSpritesWithAnim
	.public VsRecorder_InitTouchScroll
	.public VsRecorder_FreeTouchScroll
	.public VsRecorder_TouchScrollTrack
	.public VsRecorder_TouchScrollSetEnabled
	.public VsRecorder_UpdateTouchScroll
	.public VsRecorder_AddGameStatsScore
	.public VsRecorder_ImportBattleRecord
	.public VsRecorder_FlipScreensTask
	.public VsRecorder_StartFlipScreens
	.public VsRecorder_IsFlipScreensDone
	.public VsRecorder_VBlankTask
	.public VsRecorder_StartVBlankTask
	.public VsRecorder_StepRecordSave
	.public VsRecorder_SetBattleResult
	.public VsRecorder_OnVideoListReceived
	.public VsRecorder_LoadSavedVideos
	.public VsRecorder_FreeSavedVideos
	.public VsRecorder_LoadMonIconGfx
	.public VsRecorder_UnloadMonIconGfx
	.public VsRecorder_OpenMonIconNarc
	.public VsRecorder_CloseMonIconNarc
	.public VsRecorder_NewMonIcon
	.public VsRecorder_DeleteMonIcon
	.public VsRecorder_DeleteSprite
	.public VsRecorder_PrintVideoInfo
	.public VsRecorder_RemoveVideoInfoWindows
	.public VsRecorder_HeaderUsesThreeMonLayout
	.public VsRecorderVideoInfo_UsesThreeMonLayout
	.public VsRecorderVideoInfo_GetScreenId
	.public VsRecorder_CreateVideoPartyIcons
	.public VsRecorder_CreateVideoInfo
	.public VsRecorder_FreeVideoInfo
	.public VsRecorder_SetVideoPartyIconsDrawFlag
	.public VsRecorder_GetCenteredTextX
	.public VsRecorder_ResetRecordSave
	.public VsRecorder_ClearSavedVideoKeys
	.public VsRecorder_ResetBgPriorities
	.public VsRecorder_PlaceOrbitCursor
	.public VsRecorder_CountDigits
	.public VsRecorder_LoadScreen
	.public VsRecorder_TouchIndicatorTask
	.public VsRecorder_ShowTouchIndicator
	.public VsRecorder_OnTouchConfirm
	.public VsRecorder_IsVBlankPaused
	.public VsRecorder_SetVBlankPaused
	.public VsRecorder_CreateLabeledSprite
	.public VsRecorder_FreeLabeledSprite
	.public VsRecorder_SetupMessageScreenMsg
	.public VsRecorder_ShowMessageScreen
	.public VsRecorder_MessageScreen
	.public VsRecorder_IsVideoSaved
	.public VsRecorder_SanitizeName
	.public VsRecorder_SetPlaceholderName
	.public VsRecorder_ShowTouchHere
	.public VsRecorder_HideTouchHere
	.public VsRecorder_TitleIntro
	.public VsRecorder_TitleShowMenu
	.public VsRecorder_TitleFlash
	.public VsRecorder_TitleSlideInChoices
	.public VsRecorder_SlideInChoiceRows
	.public VsRecorder_MenuMain
	.public VsRecorder_CheckSchemeArrowTouch
	.public VsRecorder_MenuInvalid
	.public VsRecorder_MenuExit
	.public VsRecorder_MenuSlideIn
	.public VsRecorder_MenuShow
	.public VsRecorder_RowMoveTask
	.public VsRecorder_MenuSelect
	.public VsRecorder_MenuBack
	.public VsRecorder_MenuPrevScheme
	.public VsRecorder_MenuNextScheme
	.public VsRecorder_SavedVideoInit
	.public VsRecorder_SavedVideoEnter
	.public VsRecorder_SavedVideoShow
	.public VsRecorder_SavedVideoMain
	.public VsRecorder_SavedVideoToggleProfile
	.public VsRecorder_ShowYesNoWindows
	.public VsRecorder_HideYesNoWindows
	.public VsRecorder_SavedVideoSavePrompt
	.public VsRecorder_SavedVideoSave
	.public VsRecorder_SavedVideoPlay
	.public VsRecorder_SavedVideoExit
	.public VsRecorder_SavedVideoResume
	.public VsRecorder_OnSavedVideoTouch
	.public VsRecorder_SetSavedVideoSlot
	.public VsRecorder_ShowProfileButton
	.public VsRecorder_RemoveProfileButton
	.public VsRecorder_PrintProfileButton
	.public VsRecorder_CreateExitButton
	.public VsRecorder_FreeExitButton
	.public VsRecorder_PlaceFrontierExitButton
	.public VsRecorder_LoadFrontierButtonGfx
	.public VsRecorder_CreateFrontierButtons
	.public VsRecorder_FreeFrontierButtons
	.public VsRecorder_LoadFrontierGfx
	.public VsRecorder_GrayscalePalette
	.public VsRecorder_GrayFrontierPrints
	.public VsRecorder_CreateFrontierSprites
	.public VsRecorder_FreeFrontierSprites
	.public VsRecorder_SpinInFrontierSprites
	.public VsRecorder_SpinOutFrontierSprites
	.public VsRecorder_PlaceFrontierSprites
	.public VsRecorder_FrontierEnter
	.public VsRecorder_FrontierMain
	.public VsRecorder_FrontierExit
	.public VsRecorder_DressUpInit
	.public VsRecorder_DressUpEnter
	.public VsRecorder_DressUpSendShow
	.public VsRecorder_DressUpSendMain
	.public VsRecorder_DressUpSendUpload
	.public VsRecorder_DressUpSendExit
	.public VsRecorder_DressUpViewInit
	.public VsRecorder_DressUpViewSelectCategory
	.public VsRecorder_DressUpViewSelectSpecies
	.public VsRecorder_DressUpViewExit
	.public VsRecorder_DressUpViewDownload
	.public VsRecorder_DressUpViewShowPhoto
	.public VsRecorder_DressUpViewMain
	.public VsRecorder_DressUpViewClosePhoto
	.public VsRecorder_DressUpViewToggleProfile
	.public VsRecorder_DressUpViewChangePhoto
	.public VsRecorder_RemoveDressUpToggleWindow
	.public VsRecorder_PrintDressUpToggleLabel
	.public VsRecorder_CreateDressUpToggleWindow
	.public VsRecorder_DressUpVBlankCB
	.public VsRecorder_SetPhotoWindow
	.public VsRecorder_DisablePhotoWindow
	.public VsRecorder_SetDressUpSendButtonHidden
	.public VsRecorder_CreateDressUpButtons
	.public VsRecorder_FreeDressUpButtons
	.public VsRecorder_PrintOwnPhotoCaption
	.public VsRecorder_PrintPhotoCaption
	.public VsRecorder_DressUpCategoryHasSeen
	.public VsRecorder_BuildDressUpSpeciesList
	.public VsRecorder_FreeDressUpSpeciesList
	.public VsRecorder_OnDressUpCategoryTouch
	.public VsRecorder_CreateDressUpCategoryWindows
	.public VsRecorder_RemoveDressUpCategoryWindows
	.public VsRecorder_RemovePhotoCaption
	.public VsRecorder_OnDressUpUploaded
	.public VsRecorder_OnDressUpListReceived
	.public VsRecorder_LoadBoxDataOwner
	.public VsRecorder_FreeBoxDataOwner
	.public VsRecorder_BoxFormHasMon
	.public VsRecorder_SkipToOccupiedSlot
	.public VsRecorder_OnBoxDataSendTouch
	.public VsRecorder_OnBoxDataSendCategoryTouch
	.public VsRecorder_OnBoxDataViewCategoryTouch
	.public VsRecorder_OnBoxListTouch
	.public VsRecorder_OnBoxDataBoxTouch
	.public VsRecorder_CreateBoxDataButtons
	.public VsRecorder_FreeBoxDataButtons
	.public VsRecorder_SelectFirstBoxMon
	.public VsRecorder_PackBoxForm
	.public VsRecorder_BoxDataInit
	.public VsRecorder_BoxDataEnter
	.public VsRecorder_BoxDataSendChangeBox
	.public VsRecorder_SetBoxDataSendButtonHidden
	.public VsRecorder_BoxDataSendShowCategories
	.public VsRecorder_BoxDataSendSelectCategory
	.public VsRecorder_BoxDataSendUpload
	.public VsRecorder_BoxDataSendCancelCategory
	.public VsRecorder_BoxDataSendQuit
	.public VsRecorder_BoxDataViewQuit
	.public VsRecorder_CreateBoxDataWindows
	.public VsRecorder_CreateBoxDataCategoryButtons
	.public VsRecorder_RemoveBoxDataCategoryButtons
	.public VsRecorder_RemoveBoxDataWindows
	.public VsRecorder_PrintBoxDataMessage
	.public VsRecorder_PrintBoxDataOwnerMessage
	.public VsRecorder_PrintBoxName
	.public VsRecorder_ClearBoxDataInfoWindows
	.public VsRecorder_HasAllBits
	.public VsRecorder_PrintBoxMonName
	.public VsRecorder_CreateBoxMonIcons
	.public VsRecorder_SetBoxMonIconsDrawFlag
	.public VsRecorder_FreeBoxMonIcons
	.public VsRecorder_CreateBoxMonPic
	.public VsRecorder_SetBoxMonPicVanished
	.public VsRecorder_FreeBoxMonPic
	.public VsRecorder_ShowBox
	.public VsRecorder_RefreshOwnBox
	.public VsRecorder_BoxDataSendShow
	.public VsRecorder_BoxDataSendMain
	.public VsRecorder_BoxDataSendExit
	.public VsRecorder_BoxDataViewShow
	.public VsRecorder_BoxDataViewSelectCategory
	.public VsRecorder_CreateBoxListButtons
	.public VsRecorder_PrintBoxListProfileButton
	.public VsRecorder_CreateNextMonButton
	.public VsRecorder_RemoveNextMonButton
	.public VsRecorder_RemoveBoxListButtons
	.public VsRecorder_CreateBoxListTitle
	.public VsRecorder_RemoveBoxListTitle
	.public VsRecorder_BoxDataViewDownload
	.public VsRecorder_CreateBoxListItems
	.public VsRecorder_FreeBoxListItems
	.public VsRecorder_BoxListMain
	.public VsRecorder_BoxListBack
	.public VsRecorder_BoxDataViewOpenBox
	.public VsRecorder_BoxDataViewBoxMain
	.public VsRecorder_BoxDataViewCloseBox
	.public VsRecorder_BoxListShowProfile
	.public VsRecorder_BoxListHideProfile
	.public VsRecorder_BoxDataViewExit
	.public VsRecorder_OnBoxUploaded
	.public VsRecorder_OnBoxListReceived
	.public VsRecorder_InitRankingsList
	.public VsRecorder_FillRankingEntries
	.public VsRecorder_CreateRankingsButtonLabels
	.public VsRecorder_RemoveRankingsButtonLabels
	.public VsRecorder_CreateRankingsWindows
	.public VsRecorder_RemoveRankingsWindows
	.public VsRecorder_GetRankedRecordValue
	.public VsRecorder_PrintRankingsInfo
	.public VsRecorder_SetRankingsSendButtonHidden
	.public VsRecorder_CreateRankingsButtons
	.public VsRecorder_FreeRankingsButtons
	.public VsRecorder_UpdateRankingTeamCount
	.public VsRecorder_OnRankingsTouch
	.public VsRecorder_RankingsInit
	.public VsRecorder_RankingsEnter
	.public VsRecorder_RankingsDownload
	.public VsRecorder_RankingsShow
	.public VsRecorder_RankingsMain
	.public VsRecorder_RankingsCloseList
	.public VsRecorder_RankingsExit
	.public VsRecorder_RankingsInvalid
	.public VsRecorder_RankingsSwitch
	.public VsRecorder_OnRankingsHeaderReceived
	.public VsRecorder_OnRankingsReceived
	.public VsRecorder_PlaceVideoListIcons
	.public VsRecorder_CreateVideoListButtons
	.public VsRecorder_PrintVideoListMessage
	.public VsRecorder_VideoListDownloadVideo
	.public VsRecorder_FreeVideoDetails
	.public VsRecorder_VideoListOverwriteMain
	.public VsRecorder_VideoListOverwriteNo
	.public VsRecorder_VideoListSave
	.public VsRecorder_VideoListConfirmOverwrite
	.public VsRecorder_VideoListReturnToDetails
	.public VsRecorder_VideoListSlotsMain
	.public VsRecorder_VideoListSlotsCancel
	.public VsRecorder_VideoListBackToList
	.public VsRecorder_SetSlotButtonName
	.public VsRecorder_CreateSlotButtons
	.public VsRecorder_FreeSlotButtons
	.public VsRecorder_FreeVideoListButtons
	.public VsRecorder_SetVideoListButtonsMode
	.public VsRecorder_RemoveVideoListWindows
	.public VsRecorder_RemoveVideoListButtonWindows
	.public VsRecorder_VideoListInit
	.public VsRecorder_VideoListEnter
	.public VsRecorder_VideoListDownloadList
	.public VsRecorder_CreateVideoListWindows
	.public VsRecorder_VideoListShowList
	.public VsRecorder_VideoListSelect
	.public VsRecorder_VideoListExit
	.public VsRecorder_VideoListShowDetails
	.public VsRecorder_VideoListDetailsMain
	.public VsRecorder_VideoListToggleProfile
	.public VsRecorder_VideoListPlay
	.public VsRecorder_VideoListResume
	.public VsRecorder_ShowVideoListMessage
	.public VsRecorder_VideoListShowSlots
	.public VsRecorder_RemoveDetailsButtonWindow
	.public VsRecorder_PrintDetailsButtonLabel
	.public VsRecorder_CreateDetailsButtonWindow
	.public VsRecorder_CreateOverwriteWindows
	.public VsRecorder_RemoveOverwriteWindows
	.public VsRecorder_OnVideoDetailsTouch
	.public VsRecorder_OnSaveSlotTouch
	.public VsRecorder_OnOverwriteTouch
	.public VsRecorder_LoadVideoDetails
	.public VsRecorder_CreateVideoListIcons
	.public VsRecorder_SetVideoListIconsDrawFlag
	.public VsRecorder_FreeVideoListIcons
	.public VsRecorder_ScrollVideoListIcons
	.public VsRecorder_FreeDetailsButtons
	.public VsRecorder_GetNet
	.public VsRecorder_InitNet
	.public VsRecorder_IsNetIdle
	.public VsRecorder_UpdateNet
	.public VsRecorder_FreeNet
	.public VsRecorder_PlaceSearchResultIcons
	.public VsRecorder_CreateSearchResultIcons
	.public VsRecorder_SetSearchResultIconsDrawFlag
	.public VsRecorder_FreeSearchResultIcons
	.public VsRecorder_ScrollSearchResultIcons
	.public VsRecorder_HasSearchConditions
	.public VsRecorder_CreateSearchConditionWindows
	.public VsRecorder_PrintSearchFacility
	.public VsRecorder_PrintSearchSpecies
	.public VsRecorder_PrintSearchLocation
	.public VsRecorder_PrintLocationButtonLabel
	.public VsRecorder_CreateSearchButtonWindows
	.public VsRecorder_RemoveSearchWindows
	.public VsRecorder_RemoveSearchButtonWindows
	.public VsRecorder_CreateSearchResultWindows
	.public VsRecorder_VideoSearchShowConditions
	.public VsRecorder_VideoSearchConditionsMain
	.public VsRecorder_VideoSearchExit
	.public VsRecorder_VideoSearchOpenCondition
	.public VsRecorder_VideoSearchSelectFacility
	.public VsRecorder_VideoSearchClearSpecies
	.public VsRecorder_CreateSearchCategoryWindows
	.public VsRecorder_RemoveSearchCategoryWindows
	.public VsRecorder_VideoSearchSelectCategory
	.public VsRecorder_VideoSearchSelectSpecies
	.public VsRecorder_SearchCategoryHasSeen
	.public VsRecorder_BuildSearchSpeciesList
	.public VsRecorder_FreeSearchSpeciesList
	.public VsRecorder_VideoSearchSelectLocation
	.public VsRecorder_VideoSearchReturnToConditions
	.public VsRecorder_VideoSearchRequest
	.public VsRecorder_VideoSearchLeaveConditions
	.public VsRecorder_VideoSearchShowResults
	.public VsRecorder_VideoSearchResultsMain
	.public VsRecorder_VideoSearchResultsBack
	.public VsRecorder_VideoSearchShowDetails
	.public VsRecorder_VideoSearchDetailsMain
	.public VsRecorder_VideoSearchToggleProfile
	.public VsRecorder_VideoSearchPlay
	.public VsRecorder_VideoSearchBackToResults
	.public VsRecorder_VideoSearchShowSlots
	.public VsRecorder_VideoSearchSlotsMain
	.public VsRecorder_VideoSearchSlotsCancel
	.public VsRecorder_VideoSearchReturnToDetails
	.public VsRecorder_VideoSearchConfirmOverwrite
	.public VsRecorder_VideoSearchOverwriteMain
	.public VsRecorder_VideoSearchOverwriteNo
	.public VsRecorder_VideoSearchSave
	.public VsRecorder_VideoSearchDownloadVideo
	.public VsRecorder_VideoSearchResume
	.public VsRecorder_VideoSearchInit
	.public VsRecorder_VideoSearchEnter
	.public VsRecorder_NumberSearchShowPad
	.public VsRecorder_NumberSearchPadMain
	.public VsRecorder_NumberSearchClosePad
	.public VsRecorder_NumberSearchExit
	.public VsRecorder_NumberSearchDownloadVideo
	.public VsRecorder_LoadFoundVideoDetails
	.public VsRecorder_LoadSearchResultDetails
	.public VsRecorder_FreeFoundVideoDetails
	.public VsRecorder_NumberSearchShowDetails
	.public VsRecorder_NumberSearchDetailsMain
	.public VsRecorder_NumberSearchToggleProfile
	.public VsRecorder_NumberSearchPlay
	.public VsRecorder_NumberSearchExitDetails
	.public VsRecorder_SetSearchSlotButtonName
	.public VsRecorder_ShowSearchMessage
	.public VsRecorder_PrintSearchMessage
	.public VsRecorder_CreateSearchSlotButtons
	.public VsRecorder_FreeSearchSlotButtons
	.public VsRecorder_NumberSearchShowSlots
	.public VsRecorder_NumberSearchSlotsMain
	.public VsRecorder_NumberSearchSlotsCancel
	.public VsRecorder_NumberSearchReturnToDetails
	.public VsRecorder_NumberSearchConfirmOverwrite
	.public VsRecorder_NumberSearchOverwriteMain
	.public VsRecorder_NumberSearchOverwriteNo
	.public VsRecorder_NumberSearchSave
	.public VsRecorder_NumberSearchResume
	.public VsRecorder_SendVideoShowCursor
	.public VsRecorder_SendVideoUpload
	.public VsRecorder_SendVideoExit
	.public VsRecorder_RemoveSearchDetailsButtonWindow
	.public VsRecorder_PrintSearchDetailsButtonLabel
	.public VsRecorder_CreateSearchDetailsButtonWindow
	.public VsRecorder_CreateSearchOverwriteWindows
	.public VsRecorder_RemoveSearchOverwriteWindows
	.public VsRecorder_OnNumberSearchDetailsTouch
	.public VsRecorder_OnNumberSearchSlotTouch
	.public VsRecorder_OnNumberSearchOverwriteTouch
	.public VsRecorder_OnSearchConditionTouch
	.public VsRecorder_OnSpeciesGroupTouch
	.public VsRecorder_OnSearchDetailsTouch
	.public VsRecorder_OnSearchSlotTouch
	.public VsRecorder_OnSearchOverwriteTouch
	.public VsRecorder_SetNumberPadButtonsMode
	.public VsRecorder_CreateNumberPadButtons
	.public VsRecorder_FreeNumberPadButtons
	.public VsRecorder_SetSearchButtonsMode
	.public VsRecorder_CreateSearchButtons
	.public VsRecorder_FreeSearchButtons
	.public VsRecorder_FoundVideoToggleProfile
	.public VsRecorder_FoundVideoShowSlots
	.public VsRecorder_FoundVideoConfirmOverwrite
	.public VsRecorder_FoundVideoOverwriteNo
	.public VsRecorder_FoundVideoSave
	.public VsRecorder_FoundVideoReturnToDetails
	.public VsRecorder_FoundVideoSlotsCancel
	.public VsRecorder_FoundVideoPlay
	.public VsRecorder_OnVideoUploaded
	.public VsRecorder_OnVideoDownloaded
	.public VsRecorder_OnVideoSaveReported
	.public VsRecorder_PrintVideoNumber
	.public VsRecorder_NewNumberPadConfig
	.public VsRecorder_FreeNumberPadConfig
	.public VsRecorder_NumberPadSetGroup
	.public VsRecorder_NumberPadInitLayout
	.public VsRecorder_NumberPadSetState
	.public VsRecorder_NumberPadInit
	.public VsRecorder_NumberPadFree
	.public VsRecorder_NumberPadInput
	.public VsRecorder_NumberPadSwitchGroup
	.public VsRecorder_NumberPadMain
	.public VsRecorder_NumberPadConfirm
	.public VsRecorder_NumberPadBack
	.public VsRecorder_NumberPadInitHitboxes
	.public VsRecorder_OnNumberPadTouch
	.public VsRecorder_NumberPadRunAction
	.public VsRecorder_NumberPadClearAction
	.public VsRecorder_NumberPadFindGroupFirst
	.public VsRecorder_NumberPadFindGroupLast
	.public VsRecorder_NumberPadLoadGfx
	.public VsRecorder_NumberPadShowSprites
	.public VsRecorder_NumberPadFreeSprites
	.public VsRecorder_NumberPadCreateDigitSprites
	.public VsRecorder_NumberPadCreateCursors
	.public VsRecorder_NumberPadSetCursorDrawFlag
	.public VsRecorder_NumberPadMoveCursor
	.public VsRecorder_NumberPadPlaceKeyCursor
	.public VsRecorder_NumberPadPlaceCursorOnKey
	.public VsRecorder_NumberPadUpdateCursors
	.public VsRecorder_GetDigitAnim
	.public VsRecorder_NumberPadUpdateEnabled
	.public VsRecorder_NumberPadLayoutDigits
	.public VsRecorder_NumberPadUpdateHitboxes
	.public VsRecorder_ShowDeleteWindow
	.public VsRecorder_HideDeleteWindow
	.public VsRecorder_PrintDeleteMessage
	.public VsRecorder_ShowDeleteYesNo
	.public VsRecorder_HideDeleteYesNo
	.public VsRecorder_DeleteInit
	.public VsRecorder_DeleteEnter
	.public VsRecorder_DeleteMain
	.public VsRecorder_DeleteExit
	.public VsRecorder_LoadPlaceholderTrainerName
	.public VsRecorder_WriteRecordAsync
	.public VsRecorder_EncryptRecord
	.public VsRecorder_SaveRecordNumber
	.public VsRecorder_WriteRecord
	.public sVsRecorderOamCharTransferParam
	.public sVsRecorderSpriteResourceCounts
	.public sVsRecorderOamManagerParam
	.public sVsRecorderGraphicsBanks
	.public sVsRecorderBgTemplate_Main0
	.public sVsRecorderBgTemplate_Main1
	.public sVsRecorderBgTemplate_Main2
	.public sVsRecorderBgTemplate_Main3
	.public sVsRecorderBgTemplate_Sub0
	.public sVsRecorderBgTemplate_Sub1
	.public sVsRecorderBgTemplate_Sub2
	.public sVsRecorderBgTemplate_Sub3
	.public gVsRecorderDecorSpriteXOffsets
	.public sVsRecorderMenuRowDrawPriorities
	.public sVsRecorderDecorAngles
	.public sVsRecorderDecorScales
	.public sVsRecorderTouchScrollLeftHitbox
	.public sVsRecorderTouchScrollRightHitbox
	.public sVsRecorderRankLimits
	.public sVsRecorderRankLimitsRedraw
	.public sVsRecorderVideoInfoLabelMsgIds
	.public sVsRecorderSchemeFileIds1
	.public sVsRecorderSchemeBlendColors
	.public sVsRecorderSchemeBgPaletteFiles
	.public sVsRecorderSchemeMenuBlendColors
	.public sVsRecorderSchemeBgFramePaletteFiles
	.public sVsRecorderSchemeObjPaletteFiles
	.public sVsRecorderVideoInfoLabelWindows
	.public sVsRecorderProfileLabelMsgIds
	.public sVsRecorderProfileLabelWindows
	.public sVsRecorderVideoPartyIconLayout
	.public sVsRecorderAvatarFileIds
	.public sVsRecorderTitleSubStates
	.public sVsRecorderPrevSchemeHitbox
	.public sVsRecorderNextSchemeHitbox
	.public sVsRecorderMenuSubStates
	.public sVsRecorderSaveYesHitbox
	.public sVsRecorderSaveNoHitbox
	.public sVsRecorderSavedVideoHitboxes
	.public sVsRecorderSavedVideoSubStates
	.public sVsRecorderFrontierSubStates
	.public sVsRecorderFrontierPrintPaletteSlots
	.public sVsRecorderFrontierIconCharFiles
	.public sVsRecorderFrontierIconPaletteFiles
	.public sVsRecorderFrontierPrintAnims
	.public sVsRecorderDressUpCenterButtonHitbox
	.public sVsRecorderDressUpLeftButtonHitbox
	.public sVsRecorderDressUpRightButtonHitbox
	.public sVsRecorderDressUpTopBarHitbox
	.public sVsRecorderDressUpPrevPhotoHitbox
	.public sVsRecorderDressUpNextPhotoHitbox
	.public sVsRecorderDressUpSpeciesListHitboxes
	.public sVsRecorderDressUpSpeciesListConfig
	.public sVsRecorderDressUpSendSubStates
	.public sVsRecorderDressUpViewSubStates
	.public ov40_02245268
	.public sVsRecorderBoxDataHitboxes
	.public sVsRecorderBoxListButtonWindows
	.public sVsRecorderBoxListHitboxes
	.public sVsRecorderBoxDataWindowFillColors
	.public sVsRecorderBoxDataWindows
	.public sVsRecorderBoxDataSendHitboxes
	.public sVsRecorderBoxDataCategoryButtonWindows
	.public sVsRecorderBoxDataCategoryHitboxes
	.public sVsRecorderBoxListConfig
	.public sVsRecorderBoxDataSendSubStates
	.public sVsRecorderBoxDataViewSubStates
	.public sVsRecorderRankingTeamCounts
	.public sVsRecorderRankingsHitboxes
	.public sVsRecorderRankingsButtonLabelWindows
	.public sVsRecorderRankingsThisWeekWindows
	.public sVsRecorderRankingsLastWeekWindows
	.public sVsRecorderRankingsThisWeekListConfig
	.public sVsRecorderRankingsLastWeekListConfig
	.public sVsRecorderRankingsSubStates
	.public sVsRecorderVideoListOpenHitbox
	.public sVsRecorderVideoListExitHitbox
	.public sVsRecorderOverwriteHitboxes
	.public sVsRecorderVideoListTitleMsgIds
	.public sVsRecorderSaveSlotHitboxes
	.public sVsRecorderSaveSlotMsgIds
	.public sVsRecorderSaveSlotAnims
	.public sVsRecorderVideoDetailHitboxes
	.public sVsRecorderVideoListConfig
	.public sVsRecorderScrollIconOrder
	.public sVsRecorderListIconOrder
	.public sVsRecorderVideoListIconPositions
	.public sVsRecorderVideoListSubStates
	.public sVsRecorderSearchLocationListHitboxes
	.public sVsRecorderSearchResultOpenHitbox
	.public sVsRecorderSearchBackHitbox
	.public sVsRecorderSearchOverwriteHitboxes
	.public sVsRecorderSearchButtonMsgIds
	.public sVsRecorderSearchFacilityListHitboxes
	.public sVsRecorderSearchSaveSlotHitboxes
	.public sVsRecorderSearchSlotMsgIds
	.public sVsRecorderSearchSlotAnims
	.public sVsRecorderSearchLocationListEntries
	.public sVsRecorderSearchDetailHitboxes
	.public sVsRecorderSearchConditionHitboxes
	.public sVsRecorderSearchSpeciesListHitboxes
	.public sVsRecorderSearchConditionMsgIds
	.public sVsRecorderSpeciesGroupHitboxes
	.public sVsRecorderSearchLocationListConfig
	.public sVsRecorderSearchFacilityListConfig
	.public sVsRecorderSearchFacilityListConfigLong
	.public sVsRecorderSearchResultListConfig
	.public sVsRecorderSearchSpeciesListConfig
	.public sVsRecorderSearchListIconOrder
	.public sVsRecorderSearchScrollIconOrder
	.public sVsRecorderSearchButtonWindows
	.public sVsRecorderSearchFacilityListEntries
	.public sVsRecorderSearchConditionWindows
	.public sVsRecorderSearchResultIconPositions
	.public sVsRecorderSearchFacilityListEntriesLong
	.public sVsRecorderSendVideoSubStates
	.public sVsRecorderNumberSearchSubStates
	.public sVsRecorderVideoSearchSubStates
	.public sVsRecorderNumberPadStates
	.public sVsRecorderNumberPadStartX
	.public sVsRecorderNumberPadKeys
	.public sVsRecorderDeleteYesHitbox
	.public sVsRecorderDeleteNoHitbox
	.public sVsRecorderDeleteSubStates
	.public sVsRecorderDressUpSpeciesGroupStarts
	.public sVsRecorderRankedRecordGameStats
	.public sVsRecorderSearchSpeciesGroupStarts
	.public sVsRecorderDigitScalesOldGroup
	.public sVsRecorderDigitScalesNewGroup
	.include "overlay_40.inc"
	.include "global.inc"

	.text
	.public VsRecorder_SetScreenIfDone
	.public VsRecorder_SetSubState
	.public VsRecorder_SetStep
	.public VsRecorder_RefreshMenu
	.public VsRecorder_UpdateMenuTouch
	.public VsRecorder_HasResumeScreen
	.public VsRecorder_SetResumeScreen
	.public VsRecorder_SetSpritePos
	.public VsRecorder_GetSpritePos
	.public VsRecorder_FreeMenuRows
	.public VsRecorder_ResetFade
	.public VsRecorder_NewMessageFormat
	.public VsRecorder_SetBoxUploaded
	.public VsRecorder_IsBoxUploaded
	.public VsRecorder_SetProfileMonIconDrawFlag
	.public VsRecorder_SetProfileAvatarDrawFlag
	.public VsRecorder_CreateProfile
	.public VsRecorder_SetProfileDrawFlag
	.public VsRecorder_RemoveListWindow
	.public VsRecorder_ClearListWindow
	.public VsRecorder_SetListArrowsY
	.public VsRecorder_DeleteTouchScrollSprites
	.public VsRecorder_CreateTouchScrollSprites
	.public VsRecorder_InitTouchScroll
	.public VsRecorder_FreeTouchScroll
	.public VsRecorder_AddGameStatsScore
	.public VsRecorder_IsFlipScreensDone
	.public VsRecorder_SetBattleResult
	.public VsRecorder_OpenMonIconNarc
	.public VsRecorder_CloseMonIconNarc
	.public VsRecorder_DeleteSprite
	.public VsRecorderVideoInfo_UsesThreeMonLayout
	.public VsRecorderVideoInfo_GetScreenId
	.public VsRecorder_CreateVideoInfo
	.public VsRecorder_SetVideoPartyIconsDrawFlag
	.public VsRecorder_ResetRecordSave
	.public VsRecorder_OnTouchConfirm
	.public VsRecorder_IsVBlankPaused
	.public VsRecorder_SetVBlankPaused
	.public VsRecorder_FreeLabeledSprite
	.public VsRecorder_OnDressUpUploaded
	.public VsRecorder_BoxFormHasMon
	.public VsRecorder_HasAllBits
	.public VsRecorder_FreeBoxMonPic
	.public VsRecorder_OnBoxUploaded
	.public VsRecorder_RankingsInvalid
	.public VsRecorder_GetNet
	.public VsRecorder_IsNetIdle
	.public VsRecorder_UpdateNet
	.public VsRecorder_FreeNet
	.public VsRecorder_VideoSearchSave
	.public VsRecorder_NumberSearchSave
	.public VsRecorder_OnVideoSaveReported
	.public VsRecorder_NumberPadSetState
	.public VsRecorder_NumberPadFree
	.public VsRecorder_NumberPadClearAction
	.public VsRecorder_DeleteEnter
	.public VsRecorder_DeleteExit







	.rodata

sVsRecorderMenuRowDrawPriorities: ; 0x02244DC0
	.byte 0x05, 0x0A, 0x0F, 0x14, 0x19, 0x19, 0x14, 0x0F, 0x0A, 0x05, 0x52, 0x00, 0xB2, 0x00, 0x76, 0x00
	.byte 0x2A, 0x00, 0x96, 0x00, 0xD2, 0x00, 0x00, 0x00

sVsRecorderDecorAngles: ; 0x02244DD8
	.byte 0x5A, 0x00, 0x00, 0x00, 0x87, 0x00, 0x00, 0x00
	.byte 0x0E, 0x01, 0x00, 0x00, 0x2D, 0x00, 0x00, 0x00, 0xE1, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sVsRecorderDecorScales: ; 0x02244DF0
	.byte 0x33, 0x33, 0xB3, 0x3F, 0x66, 0x66, 0xE6, 0x3F, 0x00, 0x00, 0x00, 0x40, 0xCD, 0xCC, 0xCC, 0x3F
	.byte 0x33, 0x33, 0xB3, 0x3F, 0xCD, 0xCC, 0xCC, 0x3F

sVsRecorderTouchScrollLeftHitbox: ; 0x02244E08
	.byte 0x08, 0x80, 0x08, 0x20

sVsRecorderTouchScrollRightHitbox: ; 0x02244E0C
	.byte 0x08, 0x80, 0xE0, 0xF8

sVsRecorderRankLimits: ; 0x02244E10
	.byte 0x10, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00

sVsRecorderRankLimitsRedraw: ; 0x02244E1C
	.byte 0x10, 0x00, 0x00, 0x00
	.byte 0x0C, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00

sVsRecorderVideoInfoLabelMsgIds: ; 0x02244E28
	.byte 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00
	.byte 0x14, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00

sVsRecorderSchemeFileIds1: ; 0x02244E40
	.byte 0x6B, 0x00, 0x00, 0x00, 0x6C, 0x00, 0x00, 0x00, 0x6D, 0x00, 0x00, 0x00, 0x6E, 0x00, 0x00, 0x00
	.byte 0x6F, 0x00, 0x00, 0x00, 0x82, 0x00, 0x00, 0x00, 0x87, 0x00, 0x00, 0x00

sVsRecorderSchemeBlendColors: ; 0x02244E5C
	.byte 0xFA, 0x73, 0x00, 0x00
	.byte 0x1F, 0x77, 0x00, 0x00, 0x7B, 0x6F, 0x00, 0x00, 0xFF, 0x6F, 0x00, 0x00, 0xBF, 0x4E, 0x00, 0x00
	.byte 0x5E, 0x57, 0x00, 0x00, 0x9F, 0x5B, 0x00, 0x00

sVsRecorderSchemeBgPaletteFiles: ; 0x02244E78
	.byte 0x70, 0x00, 0x00, 0x00, 0x71, 0x00, 0x00, 0x00
	.byte 0x72, 0x00, 0x00, 0x00, 0x73, 0x00, 0x00, 0x00, 0x74, 0x00, 0x00, 0x00, 0x83, 0x00, 0x00, 0x00
	.byte 0x88, 0x00, 0x00, 0x00

sVsRecorderSchemeMenuBlendColors: ; 0x02244E94
	.byte 0x42, 0x16, 0x00, 0x00, 0x7F, 0x35, 0x00, 0x00, 0xEF, 0x3D, 0x00, 0x00
	.byte 0x1F, 0x03, 0x00, 0x00, 0xBC, 0x00, 0x00, 0x00, 0x31, 0x01, 0x00, 0x00, 0x3F, 0x02, 0x00, 0x00

sVsRecorderSchemeBgFramePaletteFiles: ; 0x02244EB0
	.byte 0x66, 0x00, 0x00, 0x00, 0x67, 0x00, 0x00, 0x00, 0x68, 0x00, 0x00, 0x00, 0x69, 0x00, 0x00, 0x00
	.byte 0x6A, 0x00, 0x00, 0x00, 0x81, 0x00, 0x00, 0x00, 0x86, 0x00, 0x00, 0x00

sVsRecorderSchemeObjPaletteFiles: ; 0x02244ECC
	.byte 0x75, 0x00, 0x00, 0x00
	.byte 0x76, 0x00, 0x00, 0x00, 0x77, 0x00, 0x00, 0x00, 0x78, 0x00, 0x00, 0x00, 0x79, 0x00, 0x00, 0x00
	.byte 0x84, 0x00, 0x00, 0x00, 0x89, 0x00, 0x00, 0x00

sVsRecorderVideoInfoLabelWindows: ; 0x02244EE8
	.byte 0x04, 0x00, 0x04, 0x00, 0x18, 0x00, 0x02, 0x00
	.byte 0x04, 0x00, 0x06, 0x00, 0x18, 0x00, 0x04, 0x00, 0x04, 0x00, 0x0B, 0x00, 0x05, 0x00, 0x02, 0x00
	.byte 0x04, 0x00, 0x0D, 0x00, 0x05, 0x00, 0x02, 0x00, 0x04, 0x00, 0x15, 0x00, 0x18, 0x00, 0x02, 0x00

sVsRecorderProfileLabelMsgIds: ; 0x02244F10
	.byte 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00
	.byte 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00
	.byte 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00

sVsRecorderProfileLabelWindows: ; 0x02244F40
	.byte 0x04, 0x00, 0x04, 0x00, 0x18, 0x00, 0x02, 0x00, 0x0F, 0x00, 0x08, 0x00, 0x03, 0x00, 0x02, 0x00
	.byte 0x10, 0x00, 0x08, 0x00, 0x0D, 0x00, 0x02, 0x00, 0x04, 0x00, 0x0B, 0x00, 0x0B, 0x00, 0x02, 0x00
	.byte 0x04, 0x00, 0x0D, 0x00, 0x18, 0x00, 0x02, 0x00, 0x04, 0x00, 0x0F, 0x00, 0x1A, 0x00, 0x02, 0x00
	.byte 0x04, 0x00, 0x11, 0x00, 0x0B, 0x00, 0x02, 0x00, 0x04, 0x00, 0x13, 0x00, 0x18, 0x00, 0x04, 0x00
	.byte 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x15, 0x00, 0x18, 0x00, 0x02, 0x00

sVsRecorderVideoPartyIconLayout: ; 0x02244F90
	.byte 0x58, 0x00, 0x68, 0x00, 0x70, 0x00, 0x68, 0x00, 0x88, 0x00, 0x68, 0x00, 0xA0, 0x00, 0x68, 0x00
	.byte 0xB8, 0x00, 0x68, 0x00, 0xD0, 0x00, 0x68, 0x00, 0x18, 0x00, 0x98, 0x00, 0x30, 0x00, 0x98, 0x00
	.byte 0x48, 0x00, 0x98, 0x00, 0x60, 0x00, 0x98, 0x00, 0x78, 0x00, 0x98, 0x00, 0x90, 0x00, 0x98, 0x00
	.byte 0x18, 0x00, 0x88, 0x00, 0x30, 0x00, 0x88, 0x00, 0x48, 0x00, 0x88, 0x00, 0x28, 0x00, 0xA0, 0x00
	.byte 0x40, 0x00, 0xA0, 0x00, 0x58, 0x00, 0xA0, 0x00, 0x90, 0x00, 0x88, 0x00, 0xA8, 0x00, 0x88, 0x00
	.byte 0xC0, 0x00, 0x88, 0x00, 0xA0, 0x00, 0xA0, 0x00, 0xB8, 0x00, 0xA0, 0x00, 0xD0, 0x00, 0xA0, 0x00

sVsRecorderAvatarFileIds: ; 0x02244FF0
	.byte 0x03, 0x00, 0x00, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x11, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00
	.byte 0x05, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x13, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00
	.byte 0x0B, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x15, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00
	.byte 0x1F, 0x00, 0x00, 0x00, 0x39, 0x00, 0x00, 0x00, 0x17, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00
	.byte 0x32, 0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x19, 0x00, 0x00, 0x00, 0x1A, 0x00, 0x00, 0x00
	.byte 0x33, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00, 0x1B, 0x00, 0x00, 0x00, 0x1C, 0x00, 0x00, 0x00
	.byte 0x3E, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x1D, 0x00, 0x00, 0x00, 0x1E, 0x00, 0x00, 0x00
	.byte 0x46, 0x00, 0x00, 0x00, 0x31, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00
	.byte 0x06, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x21, 0x00, 0x00, 0x00, 0x22, 0x00, 0x00, 0x00
	.byte 0x07, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x23, 0x00, 0x00, 0x00, 0x24, 0x00, 0x00, 0x00
	.byte 0x0D, 0x00, 0x00, 0x00, 0x24, 0x00, 0x00, 0x00, 0x25, 0x00, 0x00, 0x00, 0x26, 0x00, 0x00, 0x00
	.byte 0x0E, 0x00, 0x00, 0x00, 0x19, 0x00, 0x00, 0x00, 0x27, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00
	.byte 0x23, 0x00, 0x00, 0x00, 0x55, 0x00, 0x00, 0x00, 0x29, 0x00, 0x00, 0x00, 0x2A, 0x00, 0x00, 0x00
	.byte 0x25, 0x00, 0x00, 0x00, 0x23, 0x00, 0x00, 0x00, 0x2B, 0x00, 0x00, 0x00, 0x2C, 0x00, 0x00, 0x00
	.byte 0x2A, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00, 0x2D, 0x00, 0x00, 0x00, 0x2E, 0x00, 0x00, 0x00
	.byte 0x3F, 0x00, 0x00, 0x00, 0x21, 0x00, 0x00, 0x00, 0x2F, 0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00

sVsRecorderTitleSubStates: ; 0x022450F0
	.word VsRecorder_TitleIntro
	.word VsRecorder_TitleShowMenu
	.word VsRecorder_TitleFlash
	.word VsRecorder_TitleSlideInChoices

sVsRecorderPrevSchemeHitbox: ; 0x02245100
	.byte 0x00, 0xC0, 0x00, 0x08

sVsRecorderNextSchemeHitbox: ; 0x02245104
	.byte 0x00, 0xC0, 0xF8, 0x00

sVsRecorderMenuSubStates: ; 0x02245108
	.word VsRecorder_MenuMain
	.word VsRecorder_MenuInvalid
	.word VsRecorder_MenuExit
	.word VsRecorder_MenuSelect
	.word VsRecorder_MenuBack
	.word VsRecorder_MenuSlideIn
	.word VsRecorder_MenuShow
	.word VsRecorder_MenuPrevScheme
	.word VsRecorder_MenuNextScheme

sVsRecorderSaveYesHitbox: ; 0x0224512C
	.byte 0x28, 0x48, 0x20, 0x78

sVsRecorderSaveNoHitbox: ; 0x02245130
	.byte 0x28, 0x48, 0x90, 0xE8

sVsRecorderSavedVideoHitboxes: ; 0x02245134
	.byte 0x10, 0x30, 0x40, 0xC8, 0x40, 0x70, 0x58, 0xA8, 0x98, 0xB8, 0x50, 0xB0

sVsRecorderSavedVideoSubStates: ; 0x02245140
	.word VsRecorder_SavedVideoInit
	.word VsRecorder_SavedVideoEnter
	.word VsRecorder_SavedVideoShow
	.word VsRecorder_SavedVideoMain
	.word VsRecorder_SavedVideoToggleProfile
	.word VsRecorder_SavedVideoSavePrompt
	.word VsRecorder_SavedVideoSave
	.word VsRecorder_SavedVideoPlay
	.word VsRecorder_SavedVideoExit
	.word VsRecorder_SavedVideoResume

sVsRecorderFrontierSubStates: ; 0x02245168
	.word VsRecorder_FrontierEnter
	.word VsRecorder_FrontierMain
	.word VsRecorder_FrontierExit

sVsRecorderFrontierPrintPaletteSlots: ; 0x02245174
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00

sVsRecorderFrontierIconCharFiles: ; 0x02245188
	.byte 0x7E, 0x00, 0x00, 0x00, 0x24, 0x01, 0x00, 0x00
	.byte 0x2A, 0x01, 0x00, 0x00, 0x28, 0x01, 0x00, 0x00, 0x26, 0x01, 0x00, 0x00

sVsRecorderFrontierIconPaletteFiles: ; 0x0224519C
	.byte 0x7D, 0x00, 0x00, 0x00
	.byte 0x23, 0x01, 0x00, 0x00, 0x29, 0x01, 0x00, 0x00, 0x27, 0x01, 0x00, 0x00, 0x25, 0x01, 0x00, 0x00

sVsRecorderFrontierPrintAnims: ; 0x022451B0
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00

sVsRecorderDressUpCenterButtonHitbox: ; 0x022451C4
	.byte 0x98, 0xB8, 0x50, 0xB0

sVsRecorderDressUpLeftButtonHitbox: ; 0x022451C8
	.byte 0x98, 0xB8, 0x20, 0x80

sVsRecorderDressUpRightButtonHitbox: ; 0x022451CC
	.byte 0x98, 0xB8, 0x80, 0xE0

sVsRecorderDressUpTopBarHitbox: ; 0x022451D0
	.byte 0x10, 0x30, 0x38, 0xC8

sVsRecorderDressUpPrevPhotoHitbox: ; 0x022451D4
	.byte 0x48, 0x68, 0x18, 0x48

sVsRecorderDressUpNextPhotoHitbox: ; 0x022451D8
	.byte 0x48, 0x68, 0xB8, 0xE8

sVsRecorderDressUpSpeciesListHitboxes:
	.byte 0x18, 0x28, 0x38, 0xC0
	.byte 0x28, 0x38, 0x38, 0xC0, 0x38, 0x48, 0x38, 0xC0, 0x48, 0x58, 0x38, 0xC0, 0x58, 0x68, 0x38, 0xC0
	.byte 0x68, 0x78, 0x38, 0xC0

sVsRecorderDressUpSpeciesListConfig: ; 0x022451F4
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x09, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00
	.byte 0x20, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.word sVsRecorderDressUpSpeciesListHitboxes

sVsRecorderDressUpSendSubStates: ; 0x02245220
	.word VsRecorder_DressUpInit
	.word VsRecorder_DressUpEnter
	.word VsRecorder_DressUpSendShow
	.word VsRecorder_DressUpSendMain
	.word VsRecorder_DressUpSendUpload
	.word VsRecorder_DressUpSendExit

sVsRecorderDressUpViewSubStates: ; 0x02245238
	.word VsRecorder_DressUpInit
	.word VsRecorder_DressUpEnter
	.word VsRecorder_DressUpViewInit
	.word VsRecorder_DressUpViewSelectCategory
	.word VsRecorder_DressUpViewSelectSpecies
	.word VsRecorder_DressUpViewExit
	.word VsRecorder_DressUpViewDownload
	.word VsRecorder_DressUpViewShowPhoto
	.word VsRecorder_DressUpViewMain
	.word VsRecorder_DressUpViewClosePhoto
	.word VsRecorder_DressUpViewToggleProfile
	.word VsRecorder_DressUpViewChangePhoto

ov40_02245268: ; 0x02245268
	.byte 0x04, 0x03, 0x18, 0x02

sVsRecorderBoxDataHitboxes: ; 0x0224526C
	.byte 0x20, 0x60, 0x48, 0xB8
	.byte 0x98, 0xB8, 0x50, 0xB0

sVsRecorderBoxListButtonWindows: ; 0x02245274
	.byte 0x08, 0x03, 0x10, 0x02, 0x09, 0x0A, 0x0E, 0x02, 0x79, 0x00, 0x00, 0x00
	.byte 0x3B, 0x00, 0x00, 0x00

sVsRecorderBoxListHitboxes: ; 0x02245284
	.byte 0x10, 0x30, 0x38, 0xC8, 0x40, 0x70, 0x38, 0xC8, 0x98, 0xB8, 0x50, 0xB0

sVsRecorderBoxDataWindowFillColors: ; 0x02245290
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xCC, 0x00, 0x00, 0x00, 0x1B, 0x00, 0x00, 0x00
	.byte 0x13, 0x00, 0x00, 0x00, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x0D, 0x0F, 0x00, 0x00, 0x01, 0x0F, 0x00
	.byte 0x00, 0x0D, 0x0F, 0x00

sVsRecorderBoxDataWindows: ; 0x022452B4
	.byte 0x01, 0x02, 0x09, 0x03, 0x0F, 0x01, 0x0D, 0x03, 0x01, 0x15, 0x1E, 0x02
	.byte 0x06, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sVsRecorderBoxDataSendHitboxes: ; 0x022452CC
	.byte 0x20, 0x40, 0x18, 0x48
	.byte 0x20, 0x40, 0xB8, 0xE0, 0x98, 0xB8, 0x20, 0x80, 0x98, 0xB8, 0x80, 0xE0

sVsRecorderBoxDataCategoryButtonWindows: ; 0x022452DC
	.byte 0x03, 0x03, 0x0B, 0x02
	.byte 0x12, 0x03, 0x0B, 0x02, 0x03, 0x08, 0x0B, 0x02, 0x12, 0x08, 0x0B, 0x02, 0x03, 0x0D, 0x0B, 0x02
	.byte 0x12, 0x0D, 0x0B, 0x02

sVsRecorderBoxDataCategoryHitboxes: ; 0x022452F4
	.byte 0x18, 0x28, 0x18, 0x78, 0x18, 0x28, 0x90, 0xF0, 0x40, 0x50, 0x18, 0x78
	.byte 0x40, 0x50, 0x90, 0xF0, 0x68, 0x78, 0x18, 0x78, 0x68, 0x78, 0x90, 0xF0, 0x98, 0xB8, 0x50, 0xB0

sVsRecorderBoxListConfig: ; 0x02245310
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x07, 0x00, 0x00, 0x00, 0x1A, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sVsRecorderBoxDataSendSubStates: ; 0x0224533C
	.word VsRecorder_BoxDataInit
	.word VsRecorder_BoxDataEnter
	.word VsRecorder_BoxDataSendShow
	.word VsRecorder_BoxDataSendMain
	.word VsRecorder_BoxDataSendChangeBox
	.word VsRecorder_BoxDataSendShowCategories
	.word VsRecorder_BoxDataSendSelectCategory
	.word VsRecorder_BoxDataSendCancelCategory
	.word VsRecorder_BoxDataSendUpload
	.word VsRecorder_BoxDataSendQuit
	.word VsRecorder_BoxDataSendExit

sVsRecorderBoxDataViewSubStates: ; 0x02245368
	.word VsRecorder_BoxDataInit
	.word VsRecorder_BoxDataEnter
	.word VsRecorder_BoxDataViewShow
	.word VsRecorder_BoxDataViewSelectCategory
	.word VsRecorder_BoxDataViewDownload
	.word VsRecorder_BoxListMain
	.word VsRecorder_BoxListBack
	.word VsRecorder_BoxListShowProfile
	.word VsRecorder_BoxListHideProfile
	.word VsRecorder_BoxDataViewOpenBox
	.word VsRecorder_BoxDataViewBoxMain
	.word VsRecorder_BoxDataViewCloseBox
	.word VsRecorder_BoxDataViewQuit
	.word VsRecorder_BoxDataViewExit

sVsRecorderRankingTeamCounts: ; 0x022453A0
	.byte 0x10, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00

sVsRecorderRankingsHitboxes: ; 0x022453AC
	.byte 0x18, 0x38, 0x30, 0xD0
	.byte 0x50, 0x70, 0x30, 0xD0, 0x98, 0xB8, 0x50, 0xB0

sVsRecorderRankingsButtonLabelWindows: ; 0x022453B8
	.byte 0x07, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x12, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00
	.byte 0x12, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00

sVsRecorderRankingsThisWeekWindows: ; 0x022453D8
	.byte 0x04, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x18, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00
	.byte 0x18, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00

sVsRecorderRankingsLastWeekWindows: ; 0x022453F8
	.byte 0x04, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x18, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00
	.byte 0x18, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00

sVsRecorderRankingsThisWeekListConfig: ; 0x02245418
	.byte 0x00, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sVsRecorderRankingsLastWeekListConfig: ; 0x02245444
	.byte 0x00, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x04, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00
	.byte 0x00, 0x01, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sVsRecorderRankingsSubStates: ; 0x02245470
	.word VsRecorder_RankingsInit
	.word VsRecorder_RankingsEnter
	.word VsRecorder_RankingsDownload
	.word VsRecorder_RankingsInvalid
	.word VsRecorder_RankingsSwitch
	.word VsRecorder_RankingsShow
	.word VsRecorder_RankingsMain
	.word VsRecorder_RankingsCloseList
	.word VsRecorder_RankingsExit

sVsRecorderVideoListOpenHitbox: ; 0x02245494
	.byte 0x20, 0x60, 0x50, 0xB0

sVsRecorderVideoListExitHitbox: ; 0x02245498
	.byte 0x98, 0xB8, 0x50, 0xB0

sVsRecorderOverwriteHitboxes: ; 0x0224549C
	.byte 0x28, 0x48, 0x20, 0x78
	.byte 0x28, 0x48, 0x90, 0xE8

sVsRecorderVideoListTitleMsgIds: ; 0x022454A4
	.byte 0x61, 0x00, 0x00, 0x00, 0x62, 0x00, 0x00, 0x00, 0x7B, 0x00, 0x00, 0x00

sVsRecorderSaveSlotHitboxes: ; 0x022454B0
	.byte 0x19, 0x39, 0x32, 0xD2, 0x3D, 0x5D, 0x32, 0xD2, 0x61, 0x81, 0x32, 0xD2, 0x85, 0xA5, 0x32, 0xD2

sVsRecorderSaveSlotMsgIds: ; 0x022454C0
	.byte 0x08, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00

sVsRecorderSaveSlotAnims: ; 0x022454D0
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00

sVsRecorderVideoDetailHitboxes: ; 0x022454E0
	.byte 0x10, 0x30, 0x40, 0xC8, 0x40, 0x70, 0x58, 0xA8, 0x98, 0xB8, 0x80, 0xE0, 0x98, 0xB8, 0x20, 0x80

sVsRecorderVideoListConfig: ; 0x022454F0
	.byte 0x00, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sVsRecorderScrollIconOrder: ; 0x0224551C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00

sVsRecorderListIconOrder: ; 0x0224554C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00

sVsRecorderVideoListIconPositions: ; 0x0224557C
	.byte 0x68, 0x00, 0x48, 0x00
	.byte 0x80, 0x00, 0x48, 0x00, 0x98, 0x00, 0x48, 0x00, 0xB0, 0x00, 0x48, 0x00, 0xC8, 0x00, 0x48, 0x00
	.byte 0xE0, 0x00, 0x48, 0x00, 0x68, 0x00, 0x60, 0x00, 0x80, 0x00, 0x60, 0x00, 0x98, 0x00, 0x60, 0x00
	.byte 0xB0, 0x00, 0x60, 0x00, 0xC8, 0x00, 0x60, 0x00, 0xE0, 0x00, 0x60, 0x00, 0x68, 0x00, 0x78, 0x00
	.byte 0x80, 0x00, 0x78, 0x00, 0x98, 0x00, 0x78, 0x00, 0xB0, 0x00, 0x78, 0x00, 0xC8, 0x00, 0x78, 0x00
	.byte 0xE0, 0x00, 0x78, 0x00, 0x68, 0x00, 0x90, 0x00, 0x80, 0x00, 0x90, 0x00, 0x98, 0x00, 0x90, 0x00
	.byte 0xB0, 0x00, 0x90, 0x00, 0xC8, 0x00, 0x90, 0x00, 0xE0, 0x00, 0x90, 0x00, 0x68, 0x00, 0xA8, 0x00
	.byte 0x80, 0x00, 0xA8, 0x00, 0x98, 0x00, 0xA8, 0x00, 0xB0, 0x00, 0xA8, 0x00, 0xC8, 0x00, 0xA8, 0x00
	.byte 0xE0, 0x00, 0xA8, 0x00

sVsRecorderVideoListSubStates: ; 0x022455F4
	.word VsRecorder_VideoListInit
	.word VsRecorder_VideoListEnter
	.word VsRecorder_VideoListDownloadList
	.word VsRecorder_VideoListShowList
	.word VsRecorder_VideoListSelect
	.word VsRecorder_VideoListExit
	.word VsRecorder_VideoListShowDetails
	.word VsRecorder_VideoListDetailsMain
	.word VsRecorder_VideoListToggleProfile
	.word VsRecorder_VideoListPlay
	.word VsRecorder_VideoListBackToList
	.word VsRecorder_VideoListShowSlots
	.word VsRecorder_VideoListSlotsMain
	.word VsRecorder_VideoListSlotsCancel
	.word VsRecorder_VideoListConfirmOverwrite
	.word VsRecorder_VideoListOverwriteMain
	.word VsRecorder_VideoListOverwriteNo
	.word VsRecorder_VideoListSave
	.word VsRecorder_VideoListDownloadVideo
	.word VsRecorder_VideoListResume
	.word VsRecorder_VideoListReturnToDetails

sVsRecorderSearchLocationListHitboxes:
	.byte 0x18, 0x38, 0x38, 0xC8

sVsRecorderSearchResultOpenHitbox: ; 0x0224564C
	.byte 0x20, 0x60, 0x50, 0xB0

sVsRecorderSearchBackHitbox: ; 0x02245650
	.byte 0x98, 0xB8, 0x50, 0xB0

sVsRecorderSearchOverwriteHitboxes: ; 0x02245654
	.byte 0x28, 0x48, 0x20, 0x78, 0x28, 0x48, 0x90, 0xE8

sVsRecorderSearchButtonMsgIds: ; 0x0224565C
	.byte 0x30, 0x00, 0x00, 0x00
	.byte 0x31, 0x00, 0x00, 0x00, 0x32, 0x00, 0x00, 0x00

sVsRecorderSearchFacilityListHitboxes:
	.byte 0x18, 0x38, 0x30, 0xD0, 0x38, 0x58, 0x30, 0xD0
	.byte 0x58, 0x78, 0x30, 0xD0

sVsRecorderSearchSaveSlotHitboxes: ; 0x02245674
	.byte 0x19, 0x39, 0x32, 0xD2, 0x3D, 0x5D, 0x32, 0xD2, 0x61, 0x81, 0x32, 0xD2
	.byte 0x85, 0xA5, 0x32, 0xD2

sVsRecorderSearchSlotMsgIds: ; 0x02245684
	.byte 0x08, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00

sVsRecorderSearchSlotAnims: ; 0x02245694
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00

sVsRecorderSearchLocationListEntries:
	.byte 0x10, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sVsRecorderSearchDetailHitboxes: ; 0x022456B4
	.byte 0x10, 0x30, 0x40, 0xC8, 0x40, 0x70, 0x58, 0xA8, 0x98, 0xB8, 0x80, 0xE0
	.byte 0x98, 0xB8, 0x20, 0x80

sVsRecorderSearchConditionHitboxes: ; 0x022456C4
	.byte 0x10, 0x30, 0x28, 0xD8, 0x38, 0x58, 0x28, 0xD8, 0x60, 0x80, 0x28, 0xD8
	.byte 0x98, 0xB8, 0x20, 0x80, 0x98, 0xB8, 0x80, 0xE0

sVsRecorderSearchSpeciesListHitboxes:
	.byte 0x18, 0x28, 0x38, 0xC0, 0x28, 0x38, 0x38, 0xC0
	.byte 0x38, 0x48, 0x38, 0xC0, 0x48, 0x58, 0x38, 0xC0, 0x58, 0x68, 0x38, 0xC0, 0x68, 0x78, 0x38, 0xC0

sVsRecorderSearchConditionMsgIds: ; 0x022456F0
	.byte 0x30, 0x00, 0x00, 0x00, 0x31, 0x00, 0x00, 0x00, 0x32, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00
	.byte 0x7D, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00

sVsRecorderSpeciesGroupHitboxes: ; 0x02245708
	.byte 0x18, 0x30, 0x28, 0x48, 0x18, 0x30, 0x70, 0x90
	.byte 0x18, 0x30, 0xB8, 0xD8, 0x38, 0x50, 0x28, 0x48, 0x38, 0x50, 0x70, 0x90, 0x38, 0x50, 0xB8, 0xD8
	.byte 0x58, 0x70, 0x28, 0x48, 0x58, 0x70, 0x70, 0x90, 0x58, 0x70, 0xB8, 0xD8

sVsRecorderSearchLocationListConfig: ; 0x0224572C
	.word sVsRecorderSearchLocationListEntries
	.byte 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x10, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00
	.word sVsRecorderSearchLocationListHitboxes

sVsRecorderSearchFacilityListConfig: ; 0x02245758
	.word sVsRecorderSearchFacilityListEntries
	.byte 0x05, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00
	.byte 0x0C, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.word sVsRecorderSearchFacilityListHitboxes

sVsRecorderSearchFacilityListConfigLong: ; 0x02245784
	.word sVsRecorderSearchFacilityListEntriesLong
	.byte 0x17, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x07, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00
	.byte 0x20, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.word sVsRecorderSearchFacilityListHitboxes

sVsRecorderSearchResultListConfig: ; 0x022457B0
	.word sVsRecorderSearchFacilityListEntriesLong
	.byte 0x06, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00
	.word 0

sVsRecorderSearchSpeciesListConfig: ; 0x022457DC
	.word 0
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x0E, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.byte 0x06, 0x00, 0x00, 0x00
	.word sVsRecorderSearchSpeciesListHitboxes

sVsRecorderSearchListIconOrder: ; 0x02245808
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00

sVsRecorderSearchScrollIconOrder: ; 0x02245838
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00

sVsRecorderSearchButtonWindows: ; 0x02245868
	.byte 0x07, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x14, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00
	.byte 0x14, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00
	.byte 0x14, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00

sVsRecorderSearchFacilityListEntries:
	.byte 0xA9, 0x00, 0x00, 0x00, 0xFA, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xAA, 0x00, 0x00, 0x00, 0xFB, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xAB, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xAC, 0x00, 0x00, 0x00, 0xFD, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xAD, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sVsRecorderSearchConditionWindows: ; 0x022458E8
	.byte 0x04, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x0F, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00
	.byte 0x0F, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00
	.byte 0x0F, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00
	.byte 0x14, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00
	.byte 0x0F, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00
	.byte 0x19, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00

sVsRecorderSearchResultIconPositions: ; 0x02245948
	.byte 0x68, 0x00, 0x48, 0x00, 0x80, 0x00, 0x48, 0x00
	.byte 0x98, 0x00, 0x48, 0x00, 0xB0, 0x00, 0x48, 0x00, 0xC8, 0x00, 0x48, 0x00, 0xE0, 0x00, 0x48, 0x00
	.byte 0x68, 0x00, 0x60, 0x00, 0x80, 0x00, 0x60, 0x00, 0x98, 0x00, 0x60, 0x00, 0xB0, 0x00, 0x60, 0x00
	.byte 0xC8, 0x00, 0x60, 0x00, 0xE0, 0x00, 0x60, 0x00, 0x68, 0x00, 0x78, 0x00, 0x80, 0x00, 0x78, 0x00
	.byte 0x98, 0x00, 0x78, 0x00, 0xB0, 0x00, 0x78, 0x00, 0xC8, 0x00, 0x78, 0x00, 0xE0, 0x00, 0x78, 0x00
	.byte 0x68, 0x00, 0x90, 0x00, 0x80, 0x00, 0x90, 0x00, 0x98, 0x00, 0x90, 0x00, 0xB0, 0x00, 0x90, 0x00
	.byte 0xC8, 0x00, 0x90, 0x00, 0xE0, 0x00, 0x90, 0x00, 0x68, 0x00, 0xA8, 0x00, 0x80, 0x00, 0xA8, 0x00
	.byte 0x98, 0x00, 0xA8, 0x00, 0xB0, 0x00, 0xA8, 0x00, 0xC8, 0x00, 0xA8, 0x00, 0xE0, 0x00, 0xA8, 0x00

sVsRecorderSearchFacilityListEntriesLong:
	.byte 0xA9, 0x00, 0x00, 0x00, 0xFA, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xAA, 0x00, 0x00, 0x00, 0xFB, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xAB, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xAC, 0x00, 0x00, 0x00, 0xFD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xAD, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xAE, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xAF, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB0, 0x00, 0x00, 0x00, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB1, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB2, 0x00, 0x00, 0x00, 0x13, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB3, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB4, 0x00, 0x00, 0x00, 0x15, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB5, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB6, 0x00, 0x00, 0x00, 0x17, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB7, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB8, 0x00, 0x00, 0x00, 0x19, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xB9, 0x00, 0x00, 0x00, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xBA, 0x00, 0x00, 0x00, 0x1B, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xBB, 0x00, 0x00, 0x00, 0x1C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xBC, 0x00, 0x00, 0x00, 0x1D, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xBD, 0x00, 0x00, 0x00, 0x1E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xBE, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0xBF, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sVsRecorderSendVideoSubStates: ; 0x02245B30
	.word VsRecorder_VideoSearchInit
	.word VsRecorder_VideoSearchEnter
	.word VsRecorder_SendVideoShowCursor
	.word VsRecorder_SendVideoUpload
	.word VsRecorder_SendVideoExit

sVsRecorderNumberSearchSubStates: ; 0x02245B44
	.word VsRecorder_VideoSearchInit
	.word VsRecorder_VideoSearchEnter
	.word VsRecorder_NumberSearchShowPad
	.word VsRecorder_NumberSearchPadMain
	.word VsRecorder_NumberSearchClosePad
	.word VsRecorder_NumberSearchExit
	.word VsRecorder_NumberSearchDownloadVideo
	.word VsRecorder_NumberSearchShowDetails
	.word VsRecorder_NumberSearchDetailsMain
	.word VsRecorder_NumberSearchToggleProfile
	.word VsRecorder_NumberSearchPlay
	.word VsRecorder_NumberSearchExitDetails
	.word VsRecorder_NumberSearchShowSlots
	.word VsRecorder_NumberSearchSlotsMain
	.word VsRecorder_NumberSearchSlotsCancel
	.word VsRecorder_NumberSearchConfirmOverwrite
	.word VsRecorder_NumberSearchOverwriteMain
	.word VsRecorder_NumberSearchOverwriteNo
	.word VsRecorder_NumberSearchSave
	.word VsRecorder_NumberSearchResume
	.word VsRecorder_NumberSearchReturnToDetails

sVsRecorderVideoSearchSubStates: ; 0x02245B98
	.word VsRecorder_VideoSearchInit
	.word VsRecorder_VideoSearchEnter
	.word VsRecorder_VideoSearchShowConditions
	.word VsRecorder_VideoSearchConditionsMain
	.word VsRecorder_VideoSearchExit
	.word VsRecorder_VideoSearchOpenCondition
	.word VsRecorder_VideoSearchSelectFacility
	.word VsRecorder_VideoSearchClearSpecies
	.word VsRecorder_VideoSearchSelectCategory
	.word VsRecorder_VideoSearchSelectSpecies
	.word VsRecorder_VideoSearchSelectLocation
	.word VsRecorder_VideoSearchReturnToConditions
	.word VsRecorder_VideoSearchRequest
	.word VsRecorder_VideoSearchLeaveConditions
	.word VsRecorder_VideoSearchShowResults
	.word VsRecorder_VideoSearchResultsMain
	.word VsRecorder_VideoSearchResultsBack
	.word VsRecorder_VideoSearchShowDetails
	.word VsRecorder_VideoSearchDetailsMain
	.word VsRecorder_VideoSearchToggleProfile
	.word VsRecorder_VideoSearchPlay
	.word VsRecorder_VideoSearchBackToResults
	.word VsRecorder_VideoSearchShowSlots
	.word VsRecorder_VideoSearchSlotsMain
	.word VsRecorder_VideoSearchSlotsCancel
	.word VsRecorder_VideoSearchConfirmOverwrite
	.word VsRecorder_VideoSearchOverwriteMain
	.word VsRecorder_VideoSearchOverwriteNo
	.word VsRecorder_VideoSearchSave
	.word VsRecorder_VideoSearchDownloadVideo
	.word VsRecorder_VideoSearchResume
	.word VsRecorder_VideoSearchReturnToDetails

sVsRecorderNumberPadStates: ; 0x02245C18
	.word VsRecorder_NumberPadInit
	.word VsRecorder_NumberPadInput
	.word VsRecorder_NumberPadSwitchGroup
	.word VsRecorder_NumberPadFree

sVsRecorderNumberPadStartX: ; 0x02245C28
	.byte 0x38, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x38, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sVsRecorderNumberPadKeys: ; 0x02245C40
	.byte 0x20, 0x00, 0x50, 0x00, 0x14, 0x00, 0x14, 0x00, 0x50, 0x00, 0x50, 0x00, 0x14, 0x00, 0x14, 0x00
	.byte 0x80, 0x00, 0x50, 0x00, 0x14, 0x00, 0x14, 0x00, 0xB0, 0x00, 0x50, 0x00, 0x14, 0x00, 0x14, 0x00
	.byte 0xE0, 0x00, 0x50, 0x00, 0x14, 0x00, 0x14, 0x00, 0x20, 0x00, 0x80, 0x00, 0x14, 0x00, 0x14, 0x00
	.byte 0x50, 0x00, 0x80, 0x00, 0x14, 0x00, 0x14, 0x00, 0x80, 0x00, 0x80, 0x00, 0x14, 0x00, 0x14, 0x00
	.byte 0xB0, 0x00, 0x80, 0x00, 0x14, 0x00, 0x14, 0x00, 0xE0, 0x00, 0x80, 0x00, 0x14, 0x00, 0x14, 0x00
	.byte 0x4C, 0x00, 0xB0, 0x00, 0x3C, 0x00, 0x0C, 0x00, 0xC0, 0x00, 0xB0, 0x00, 0x3C, 0x00, 0x0C, 0x00

sVsRecorderDeleteYesHitbox: ; 0x02245CA0
	.byte 0x28, 0x48, 0x20, 0x78

sVsRecorderDeleteNoHitbox: ; 0x02245CA4
	.byte 0x28, 0x48, 0x90, 0xE8

sVsRecorderDeleteSubStates: ; 0x02245CA8
	.word VsRecorder_DeleteInit
	.word VsRecorder_DeleteEnter
	.word VsRecorder_DeleteMain
	.word VsRecorder_DeleteExit

	.data

sVsRecorderFrontierPrintPositions:
	.byte 0x80, 0x00, 0x2A, 0x00, 0xBD, 0x00, 0x57, 0x00, 0xAC, 0x00, 0x86, 0x00, 0x53, 0x00, 0x86, 0x00
	.byte 0x42, 0x00, 0x57, 0x00

sVsRecorderDressUpSpeciesGroupStarts: ; 0x02245CD4
	.byte 0x00, 0x00, 0x57, 0x00, 0x88, 0x00, 0xBF, 0x00, 0xEB, 0x00, 0x2F, 0x01
	.byte 0x68, 0x01, 0xC9, 0x01, 0xE7, 0x01, 0xED, 0x01

sVsRecorderRankedRecordGameStats: ; 0x02245CE8
	.byte 0x4A, 0x00, 0x00, 0x00, 0x4D, 0x00, 0x00, 0x00
	.byte 0x4F, 0x00, 0x00, 0x00, 0x50, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00
	.byte 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00
	.byte 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00
	.byte 0x5B, 0x00, 0x00, 0x00, 0x5C, 0x00, 0x00, 0x00, 0x5D, 0x00, 0x00, 0x00, 0x5E, 0x00, 0x00, 0x00
	.byte 0x5F, 0x00, 0x00, 0x00, 0x60, 0x00, 0x00, 0x00, 0x61, 0x00, 0x00, 0x00, 0x62, 0x00, 0x00, 0x00
	.byte 0x63, 0x00, 0x00, 0x00, 0x64, 0x00, 0x00, 0x00, 0x65, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00
	.byte 0x0B, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00
	.byte 0x10, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x17, 0x00, 0x00, 0x00
	.byte 0x18, 0x00, 0x00, 0x00, 0x19, 0x00, 0x00, 0x00, 0x1B, 0x00, 0x00, 0x00, 0x1C, 0x00, 0x00, 0x00
	.byte 0x1D, 0x00, 0x00, 0x00, 0x1E, 0x00, 0x00, 0x00, 0x24, 0x00, 0x00, 0x00, 0x29, 0x00, 0x00, 0x00
	.byte 0x2A, 0x00, 0x00, 0x00, 0x2D, 0x00, 0x00, 0x00, 0x72, 0x00, 0x00, 0x00, 0x73, 0x00, 0x00, 0x00
	.byte 0x74, 0x00, 0x00, 0x00, 0x75, 0x00, 0x00, 0x00, 0x2E, 0x00, 0x00, 0x00, 0x76, 0x00, 0x00, 0x00
	.byte 0x2F, 0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x31, 0x00, 0x00, 0x00, 0x32, 0x00, 0x00, 0x00
	.byte 0x33, 0x00, 0x00, 0x00, 0x34, 0x00, 0x00, 0x00, 0x35, 0x00, 0x00, 0x00, 0x36, 0x00, 0x00, 0x00
	.byte 0x37, 0x00, 0x00, 0x00, 0x38, 0x00, 0x00, 0x00, 0x39, 0x00, 0x00, 0x00, 0x3A, 0x00, 0x00, 0x00
	.byte 0x3B, 0x00, 0x00, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x3D, 0x00, 0x00, 0x00, 0x3E, 0x00, 0x00, 0x00
	.byte 0x3F, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x41, 0x00, 0x00, 0x00, 0x42, 0x00, 0x00, 0x00
	.byte 0x43, 0x00, 0x00, 0x00, 0x44, 0x00, 0x00, 0x00, 0x45, 0x00, 0x00, 0x00, 0x46, 0x00, 0x00, 0x00
	.byte 0x77, 0x00, 0x00, 0x00, 0x78, 0x00, 0x00, 0x00, 0x47, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00
	.byte 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00
	.byte 0xFF, 0xFF, 0x00, 0x00

sVsRecorderSearchSpeciesGroupStarts: ; 0x02245E44
	.byte 0x00, 0x00, 0x57, 0x00, 0x88, 0x00, 0xBF, 0x00, 0xEB, 0x00, 0x2F, 0x01
	.byte 0x68, 0x01, 0xC9, 0x01, 0xE7, 0x01, 0xED, 0x01

sVsRecorderDigitScalesOldGroup: ; 0x02245E58
	.byte 0xCD, 0xCC, 0x4C, 0x3F, 0x9A, 0x99, 0x19, 0x3F
	.byte 0xCD, 0xCC, 0xCC, 0x3E, 0xCD, 0xCC, 0x4C, 0x3E, 0xCD, 0xCC, 0x4C, 0x3F, 0x00, 0x00, 0x80, 0x3F
	.byte 0x00, 0x00, 0x80, 0x3F

sVsRecorderDigitScalesNewGroup: ; 0x02245E74
	.byte 0x00, 0x00, 0x00, 0x3F, 0xCD, 0xCC, 0x4C, 0x3E, 0x00, 0x00, 0x00, 0x3F
	.byte 0x00, 0x00, 0x80, 0x3F, 0x9A, 0x99, 0x99, 0x3F, 0x00, 0x00, 0x80, 0x3F, 0x00, 0x00, 0x80, 0x3F
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
