	.include "asm/macros.inc"
	.public _0223DDF8
	.public _0223DE10
	.public _0223DE12
	.public _0223DE3C
	.public _0223DE40
	.public _0223DE44
	.public _0223DE48
	.public _0223DE4C
	.public _0223DE50
	.public _0223DE54
	.public _0223DE58
	.public _0223DE5C
	.public _0223DE94
	.public _0223DEC6
	.public _0223DED6
	.public _0223DEEC
	.public _0223DEFE
	.public _0223DF08
	.public _0223DF1E
	.public _0223DF3E
	.public _0223DF54
	.public _0223DF60
	.public _0223DF76
	.public _0223DF8C
	.public _0223DF9A
	.public _0223DFAC
	.public _0223DFB0
	.public _0223DFB4
	.public _0223DFB8
	.public _0223E000
	.public _0223E004
	.public _0223E020
	.public _0223E02A
	.public _0223E03E
	.public _0223E046
	.public _0223E066
	.public _0223E06E
	.public _0223E08E
	.public _0223E0B4
	.public _0223E0EE
	.public _0223E0F6
	.public _0223E104
	.public _0223E15C
	.public _0223E168
	.public _0223E196
	.public _0223E1C2
	.public _0223E1E8
	.public _0223E200
	.public _0223E20A
	.public _0223E216
	.public _0223E22A
	.public _0223E236
	.public _0223E254
	.public _0223E27A
	.public _0223E284
	.public _0223E296
	.public _0223E2AA
	.public _0223E2BE
	.public _0223E2D2
	.public _0223E2F6
	.public _0223E2FA
	.public _0223E2FE
	.public _0223E30A
	.public _0223E322
	.public _0223E32C
	.public _0223E378
	.public _0223E3A4
	.public _0223E3C8
	.public _0223E418
	.public _0223E42C
	.public _0223E43E
	.public _0223E442
	.public _0223E4C0
	.public _0223E4F0
	.public _0223E4F4
	.public _0223E4F8
	.public _0223E4FC
	.public _0223E500
	.public _0223E504
	.public _0223E508
	.public _0223E50C
	.public _0223E510
	.public _0223E514
	.public _0223E518
	.public _0223E51C
	.public _0223E520
	.public _0223E552
	.public _0223E574
	.public _0223E5AC
	.public _0223E5E4
	.public _0223E5F2
	.public _0223E608
	.public _0223E61C
	.public _0223E67E
	.public _0223E698
	.public _0223E6A6
	.public _0223E6BA
	.public _0223E6CC
	.public _0223E6F2
	.public _0223E714
	.public _0223E754
	.public _0223E756
	.public _0223E75C
	.public _0223E76E
	.public _0223E784
	.public _0223E7B2
	.public _0223E7C0
	.public _0223E7E2
	.public _0223E814
	.public _0223E838
	.public _0223E84A
	.public _0223E852
	.public _0223E854
	.public _0223E882
	.public _0223E898
	.public _0223E8AE
	.public _0223E8B6
	.public _0223E8CA
	.public _0223E8D8
	.public _0223E8DC
	.public _0223E8E0
	.public _0223E8E4
	.public _0223E8E8
	.public _0223E8EC
	.public _0223E8F0
	.public _0223E8F4
	.public _0223E8F8
	.public _0223E8FC
	.public _0223E900
	.public _0223E904
	.public _0223E908
	.public _0223E90C
	.public _0223E910
	.public _0223E916
	.public _0223E918
	.public _0223E924
	.public _0223E936
	.public _0223E982
	.public _0223E9A2
	.public _0223E9CA
	.public _0223E9EC
	.public _0223EA14
	.public _0223EA26
	.public _0223EA38
	.public _0223EA3A
	.public _0223EA96
	.public _0223EB0A
	.public _0223EB36
	.public _0223EB7E
	.public _0223EB92
	.public _0223EBA4
	.public _0223EC04
	.public _0223EC1E
	.public _0223EC2C
	.public _0223EC40
	.public _0223EC52
	.public _0223EC78
	.public _0223EC84
	.public _0223EC88
	.public _0223EC8C
	.public _0223EC90
	.public _0223EC94
	.public _0223EC98
	.public _0223EC9C
	.public _0223ECA0
	.public _0223ECA4
	.public _0223ECA8
	.public _0223ECC0
	.public _0223ECDA
	.public _0223ED00
	.public _0223ED10
	.public _0223ED12
	.public _0223ED82
	.public _0223EDAE
	.public _0223EDC2
	.public _0223EDE2
	.public _0223EE04
	.public _0223EE18
	.public _0223EE26
	.public _0223EE46
	.public _0223EE5A
	.public _0223EE68
	.public _0223EE86
	.public _0223EE8C
	.public _0223EE90
	.public _0223EE94
	.public _0223EE98
	.public _0223EE9C
	.public _0223EEB6
	.public _0223EEC0
	.public _0223EEF2
	.public _0223EF06
	.public _0223EF10
	.public _0223EF16
	.public _0223EF1E
	.public _0223EF40
	.public _0223EF5E
	.public _0223EF8C
	.public _0223EF96
	.public _0223EF9C
	.public _0223EFA0
	.public _0223EFB8
	.public _0223EFD0
	.public _0223EFDA
	.public _0223EFF2
	.public _0223F00C
	.public _0223F022
	.public _0223F042
	.public _0223F050
	.public _0223F0CA
	.public _0223F0EA
	.public _0223F0F0
	.public _0223F164
	.public _0223F18C
	.public _0223F190
	.public _0223F194
	.public _0223F198
	.public _0223F19C
	.public _0223F1A0
	.public _0223F1A4
	.public _0223F1A8
	.public _0223F1AC
	.public _0223F1B0
	.public _0223F1B4
	.public _0223F1B8
	.public _0223F1BC
	.public _0223F1C0
	.public _0223F1C4
	.public _0223F1F8
	.public _0223F1FC
	.public _0223F268
	.public _0223F32C
	.public _0223F332
	.public _0223F344
	.public _0223F346
	.public _0223F394
	.public _0223F45C
	.public _0223F48C
	.public _0223F548
	.public _0223F594
	.public _0223F598
	.public _0223F59C
	.public _0223F5A0
	.public _0223F5A4
	.public _0223F5A8
	.public _0223F5AC
	.public _0223F5B0
	.public _0223F5B4
	.public _0223F5B8
	.public _0223F5BC
	.public _0223F5C0
	.public _0223F5C4
	.public _0223F5C8
	.public _0223F660
	.public _0223F67C
	.public _0223F680
	.public _0223F684
	.public _0223F688
	.public _0223F68C
	.public _0223F700
	.public _0223F704
	.public _0223F708
	.public _0223F72C
	.public _0223F730
	.public _0223F79C
	.public _0223F7B2
	.public _0223F7D8
	.public _0223F7DC
	.public _0223F7E0
	.public _0223F7EE
	.public _0223F800
	.public _0223F9D8
	.public _0223F9DC
	.public _0223F9E0
	.public _0223F9E4
	.public _0223F9E8
	.public _0223F9EC
	.public _0223F9F0
	.public _0223F9F4
	.public _0223F9F8
	.public _0223F9FC
	.public _0223FA4E
	.public _0223FA70
	.public _0223FAEC
	.public _0223FB68
	.public _0223FBE8
	.public _0223FC44
	.public _0224009E
	.public _022400B2
	.public _022400E2
	.public _022400E4
	.public _0224010A
	.public _02240116
	.public _02240168
	.public _0224016C
	.public _02240186
	.public _0224019A
	.public _022401C0
	.public _022401C4
	.public _022401E0
	.public _022401E6
	.public _02240230
	.public _02240234
	.public _02240252
	.public _02240254
	.public _0224028C
	.public _022402F0
	.public _022402FC
	.public _0224032C
	.public _02240330
	.public _02240374
	.public _02240378
	.public _02240380
	.public _022403B0
	.public _022403B4
	.public _022403BC
	.public _02240428
	.public _02240440
	.public _022404D2
	.public _022404F8
	.public _022404FC
	.public _02240500
	.public _02240504
	.public _02240508
	.public _0224050C
	.public _02240510
	.public _02240520
	.public _02240524
	.public _02240574
	.public _0224058C
	.public _022405BC
	.public _022405C0
	.public _02240658
	.public _0224065C
	.public _02240660
	.public _02240682
	.public _02240722
	.public _02240738
	.public _0224073C
	.public _02240740
	.public _02240744
	.public _02240764
	.public _022407C8
	.public _022407D2
	.public _022407E8
	.public _022407EC
	.public _022407F0
	.public _022407F4
	.public _022407F8
	.public _02240880
	.public _02240884
	.public _02240888
	.public _022408DC
	.public _02240960
	.public _02240970
	.public _02240974
	.public _02240978
	.public _0224097C
	.public _02240980
	.public _02240994
	.public _02240AA2
	.public _02240AC2
	.public _02240B22
	.public _02240B34
	.public _02240B38
	.public _02240B3C
	.public _02240B40
	.public _02240B44
	.public _02240B48
	.public _02240B4C
	.public _02240B50
	.public _02240B8A
	.public _02240B98
	.public _02240BB0
	.public _02240BCE
	.public _02240C28
	.public _02240C2C
	.public _02240C30
	.public _02240C34
	.public _02240C38
	.public _02240C3C
	.public _02240C40
	.public _02240C44
	.public _02240C68
	.public _02240C88
	.public _02240CC6
	.public _02240CCA
	.public _02240CF4
	.public _02240CF8
	.public _02240D22
	.public _02240D26
	.public _02240D60
	.public _02240D7E
	.public _02240D8A
	.public _02240DA4
	.public _02240DCE
	.public _02240DDC
	.public _02240DF8
	.public _02240E00
	.public _02240E26
	.public _02240E60
	.public _02240E68
	.public _02240E6C
	.public _02240E8C
	.public _02240E96
	.public _02240EA0
	.public _02240EA6
	.public _02240EB0
	.public _02240EBA
	.public _02240EBE
	.public _02240EE4
	.public _02240EEC
	.public _02240EF0
	.public _02240EF4
	.public _02240EFE
	.public _02240F0C
	.public _02240F18
	.public _02240F26
	.public _02240F38
	.public _02240F3C
	.public _02240F40
	.public _02240F44
	.public _02240F68
	.public _02240F70
	.public _02240F74
	.public _02240F78
	.public _02240F9E
	.public _02241018
	.public _02241024
	.public _0224103A
	.public _02241048
	.public _02241064
	.public _02241066
	.public _0224108E
	.public _022410AC
	.public _022410E0
	.public _0224110C
	.public _02241128
	.public _0224112A
	.public _02241152
	.public _0224117A
	.public _02241188
	.public _02241196
	.public _0224119C
	.public _022411A0
	.public _022411A4
	.public _022411A8
	.public _022411AC
	.public _022411C0
	.public _022411CA
	.public _022411CE
	.public _022411D2
	.public _022411D6
	.public _022411D8
	.public _022411EC
	.public _022411F6
	.public _022411FA
	.public _022411FE
	.public _02241202
	.public _02241204
	.public _02241222
	.public _02241228
	.public _02241250
	.public _0224126E
	.public _02241274
	.public _0224129C
	.public _022412D4
	.public _022412D8
	.public _022412FC
	.public _02241318
	.public _02241334
	.public _02241350
	.public _02241380
	.public _02241388
	.public _02241390
	.public _02241398
	.public _022413A0
	.public _022413A6
	.public _022413BA
	.public _022413C0
	.public _022413E4
	.public _02241400
	.public _02241404
	.public _02241408
	.public _02241428
	.public _02241436
	.public _02241438
	.public _0224145A
	.public _02241470
	.public _022414A6
	.public _022414B8
	.public _022414C4
	.public _022414C8
	.public _022414D8
	.public _022414FC
	.public _02241500
	.public _0224150C
	.public _02241526
	.public _02241528
	.public _02241580
	.public _022415BA
	.public _022415E8
	.public _0224165A
	.public _02241664
	.public _0224166E
	.public _02241680
	.public _02241684
	.public _0224168C
	.public _02241690
	.public _02241694
	.public _02241698
	.public _0224169C
	.public _022416D6
	.public _02241724
	.public _02241728
	.public _0224172C
	.public _0224174E
	.public _02241758
	.public _02241806
	.public _0224185A
	.public _0224187C
	.public _022418D4
	.public _022418E0
	.public _022418E4
	.public _02241914
	.public _0224192A
	.public _02241934
	.public _0224193E
	.public _02241940
	.public _02241962
	.public _02241974
	.public _0224198C
	.public _0224199E
	.public _022419DE
	.public _022419F4
	.public _02241A14
	.public _02241A34
	.public _02241A40
	.public _02241A48
	.public _02241A4C
	.public _02241A50
	.public _02241A54
	.public _02241A58
	.public _02241A5C
	.public _02241AB4
	.public _02241AB8
	.public _02241B10
	.public _02241B14
	.public _02241B28
	.public _02241B2C
	.public _02241B48
	.public _02241B98
	.public _02241BA4
	.public _02241BAE
	.public _02241BB8
	.public _02241BBC
	.public _02241BC0
	.public _02241BE0
	.public _02241BE2
	.public _02241C72
	.public _02241C86
	.public _02241C92
	.public _02241CC4
	.public _02241CFA
	.public _02241D82
	.public _02241D8C
	.public _02241DC4
	.public _02241DC8
	.public _02241DCC
	.public _02241DD0
	.public _02241DD4
	.public _02241F24
	.public _02241F2C
	.public _02241F44
	.public _02241FA8
	.public _02241FAC
	.public _02241FB0
	.public _02241FB4
	.public _02241FB8
	.public _02241FBC
	.public _02241FC0
	.public _02241FC4
	.public _02241FC8
	.public _02241FCC
	.public _02241FD0
	.public _02241FD4
	.public _02241FD8
	.public _02241FDC
	.public _02241FE0
	.public _02241FE4
	.public _02241FE8
	.public _02241FEC
	.public _022421DC
	.public _02242334
	.public _02242354
	.public _02242586
	.public _022425F2
	.public _0224262C
	.public _02242630
	.public _02242634
	.public _02242638
	.public _0224263C
	.public _02242640
	.public _02242644
	.public _02242648
	.public _0224264C
	.public _02242650
	.public _02242654
	.public _02242658
	.public _0224265C
	.public _02242660
	.public _02242664
	.public _02242712
	.public _02242720
	.public _0224272E
	.public _02242740
	.public _0224280C
	.public _02242810
	.public _02242854
	.public _02242870
	.public _02242878
	.public _022428BA
	.public _022428D8
	.public _022428E2
	.public _022429CC
	.public _022429D0
	.public _022429D4
	.public _022429D8
	.public _022429DC
	.public _022429E0
	.public _02242A46
	.public _02242A76
	.public _02242AA0
	.public _02242AA4
	.public _02242AA8
	.public _02242AAC
	.public _02242AB0
	.public _02242ABC
	.public _02242ADC
	.public _02242AE8
	.public _02242B9C
	.public _02242BA0
	.public _02242BA4
	.public _02242BA8
	.public _02242BC2
	.public _02242BE8
	.public _02242BEC
	.public _02242C12
	.public _02242C2E
	.public _02242C38
	.public _02242C52
	.public _02242C6A
	.public _02242C7C
	.public _02242C9C
	.public _02242CA0
	.public _02242CA4
	.public _02242CA8
	.public _02242CCE
	.public _02242CE8
	.public _02242D02
	.public _02242D1A
	.public _02242D2C
	.public _02242D4C
	.public _02242D50
	.public _02242D54
	.public _02242D58
	.public _02242DA0
	.public _02242DA4
	.public _02242DA8
	.public _02242DF4
	.public _02242DF8
	.public _02242E2E
	.public _02242E42
	.public _02242E4A
	.public _02242E4E
	.public _02242E52
	.public _02242E54
	.public _02242E80
	.public _02242E84
	.public _02242EBA
	.public _02242EBE
	.public _02242EC2
	.public _02242ED6
	.public _02242EDE
	.public _02242EE2
	.public _02242EE4
	.public _02242F10
	.public _02242F14
	.public _02242F28
	.public _02242F4E
	.public _02242F78
	.public _02242FBA
	.public _02242FD0
	.public _02242FD8
	.public _02242FDC
	.public _02242FE0
	.public _02242FE4
	.public _022430AA
	.public _022430C2
	.public _022430C4
	.public _022430EC
	.public _022430F0
	.public _022430F4
	.public _022430F8
	.public _022430FC
	.public _02243100
	.public _02243104
	.public _02243142
	.public _02243176
	.public _02243186
	.public _022431A2
	.public _022431B4
	.public _022431BE
	.public _022431D4
	.public _022431F0
	.public _02243206
	.public _02243212
	.public _02243228
	.public _0224323E
	.public _0224324C
	.public _02243260
	.public _02243264
	.public _022432A8
	.public _022432AC
	.public _022432B0
	.public _022432CC
	.public _022432D6
	.public _022432EA
	.public _022432F2
	.public _02243312
	.public _0224331A
	.public _0224333A
	.public _02243360
	.public _0224339A
	.public _022433A2
	.public _022433B0
	.public _0224340E
	.public _02243434
	.public _02243456
	.public _0224347C
	.public _02243484
	.public _0224348E
	.public _022434A8
	.public _022434B2
	.public _022434BA
	.public _022434BC
	.public _022434CE
	.public _022434D8
	.public _022434F6
	.public _0224351A
	.public _0224351C
	.public _02243528
	.public _02243536
	.public _0224353E
	.public _02243584
	.public _022435C6
	.public _022435FA
	.public _0224360C
	.public _0224361E
	.public _02243630
	.public _02243678
	.public _022436B2
	.public _022436B8
	.public _022436D4
	.public _022436FE
	.public _02243700
	.public _02243706
	.public _02243720
	.public _0224376E
	.public _0224377C
	.public _022437CA
	.public _022437D8
	.public _022437EA
	.public _022437F0
	.public _022437F4
	.public _022437F8
	.public _022437FC
	.public _02243800
	.public _02243804
	.public _0224384C
	.public _0224388C
	.public _02243892
	.public _022438AE
	.public _022438E0
	.public _022438E2
	.public _022438E8
	.public _02243902
	.public _02243948
	.public _0224394E
	.public _0224397C
	.public _022439BA
	.public _022439C0
	.public _022439EC
	.public _02243A36
	.public _02243A48
	.public _02243A62
	.public _02243A76
	.public _02243A86
	.public _02243A88
	.public _02243AA2
	.public _02243AB6
	.public _02243AC6
	.public _02243AC8
	.public _02243B26
	.public _02243B40
	.public _02243B46
	.public _02243B5A
	.public _02243B64
	.public _02243B86
	.public _02243B92
	.public _02243BA8
	.public _02243BAC
	.public _02243BB0
	.public _02243BB4
	.public _02243BB8
	.public _02243BBC
	.public _02243BCE
	.public _02243BDA
	.public _02243BE0
	.public _02243BFA
	.public _02243C1C
	.public _02243C4C
	.public _02243C7A
	.public _02243C80
	.public _02243C84
	.public _02243C9E
	.public _02243CAA
	.public _02243CCE
	.public _02243CE8
	.public _02243CEC
	.public _02243CF4
	.public _02243D16
	.public _02243D34
	.public _02243D46
	.public _02243D74
	.public _02243D78
	.public _02243D90
	.public _02243DA8
	.public _02243DB2
	.public _02243DCA
	.public _02243DE4
	.public _02243DFA
	.public _02243E1A
	.public _02243E28
	.public _02243E88
	.public _02243E8C
	.public _02243EBE
	.public _02243EDC
	.public _02243F50
	.public _02243F80
	.public _02243F84
	.public _02243F88
	.public _02243F8C
	.public _02243F90
	.public _02243F94
	.public _02243F98
	.public _02243FCC
	.public _02243FD0
	.public _02244030
	.public _0224409E
	.public _022440A4
	.public _022440B6
	.public _0224417C
	.public _0224419A
	.public _022441AC
	.public _02244226
	.public _0224422E
	.public _02244234
	.public _02244354
	.public _02244370
	.public _02244374
	.public _02244378
	.public _0224437C
	.public _02244380
	.public _02244384
	.public _02244388
	.public _0224438C
	.public _02244390
	.public _02244400
	.public _02244404
	.public _02244428
	.public _02244484
	.public _0224449A
	.public _022444B8
	.public _022444BC
	.public _022444CA
	.public _022444DC
	.public _0224463C
	.public _02244640
	.public _02244644
	.public _02244648
	.public _0224464C
	.public _02244650
	.public _02244654
	.public _02244658
	.public _022446AE
	.public _02244902
	.public _02244904
	.public _02244924
	.public _02244946
	.public _022449AA
	.public _022449C0
	.public _022449CC
	.public _022449D0
	.public _022449F4
	.public _022449F8
	.public _02244A08
	.public _02244A66
	.public _02244A70
	.public _02244A80
	.public _02244A84
	.public _02244A8C
	.public _02244A94
	.public _02244AB8
	.public _02244B14
	.public _02244B18
	.public _02244B3C
	.public _02244B66
	.public _02244B6A
	.public _02244BA4
	.public _02244BC2
	.public _02244BCE
	.public _02244BE8
	.public _02244C54
	.public _02244CD0
	.public _02244CFA
	.public _02244D08
	.public _02244D22
	.public _02244D2A
	.public _02244D50
	.public _02244D8A
	.public _02244D92
	.public _02244D98
	.public _02244D9C
	.public _02244DBC
	.public _02244DC6
	.public _02244DD0
	.public _02244DD6
	.public _02244DE0
	.public _02244DEA
	.public _02244DEE
	.public _02244E16
	.public _02244E44
	.public _02244E50
	.public _02244E5C
	.public _02244E6A
	.public _02244E86
	.public _02244E88
	.public _02244E96
	.public _02244E98
	.public _02244EC0
	.public _02244EE8
	.public _02244F08
	.public _02244F16
	.public _02244F36
	.public _02244F44
	.public _02244F52
	.public _02244F58
	.public _02244F5C
	.public _02244F88
	.public _02244F94
	.public _02244FA0
	.public _02244FB0
	.public _02244FBC
	.public _02244FE0
	.public _02244FF0
	.public _0224500E
	.public _02245032
	.public _02245042
	.public _02245060
	.public _02245064
	.public _02245070
	.public _022450C0
	.public _022450C8
	.public _022450D0
	.public _022450D8
	.public _022450E0
	.public _022450E6
	.public _022450FA
	.public _02245100
	.public _02245126
	.public _02245144
	.public _02245148
	.public _02245168
	.public _02245176
	.public _02245178
	.public _0224519A
	.public _022451B0
	.public _022451B4
	.public _022451EA
	.public _022451FC
	.public _02245208
	.public _0224520C
	.public _0224521C
	.public _02245240
	.public _02245244
	.public _02245250
	.public _0224526A
	.public _0224526C
	.public _02245284
	.public _022452F0
	.public _022452F8
	.public _022452FC
	.public _02245314
	.public _02245380
	.public _02245388
	.public _0224538C
	.public _022453AC
	.public _022453B8
	.public _022453BC
	.public _02245472
	.public _022454C6
	.public _022454E8
	.public _02245540
	.public _0224554C
	.public _02245550
	.public _022455C8
	.public _02245602
	.public _02245630
	.public _02245668
	.public _02245672
	.public _02245676
	.public _02245680
	.public _02245684
	.public _02245686
	.public _022456A8
	.public _022456BA
	.public _022456D2
	.public _022456E4
	.public _02245704
	.public _0224570E
	.public _0224571A
	.public _02245728
	.public _02245734
	.public _0224573C
	.public _02245740
	.public _02245744
	.public _022457F0
	.public _02245810
	.public _02245814
	.public _02245818
	.public _0224581C
	.public _02245820
	.public _0224588E
	.public _022458A0
	.public _022458C6
	.public _022458D6
	.public _0224590E
	.public _02245946
	.public _02245968
	.public _02245990
	.public _02245994
	.public _02245998
	.public _0224599C
	.public _022459A8
	.public _022459C4
	.public _02245A14
	.public _02245A20
	.public _02245A2A
	.public _02245A34
	.public _02245A38
	.public _02245A3C
	.public _02245A82
	.public _02245AB6
	.public _02245ABE
	.public _02245AC6
	.public _02245AE6
	.public _02245AEA
	.public _02245B7A
	.public _02245B9A
	.public _02245BBE
	.public _02245C36
	.public _02245C78
	.public _02245C7C
	.public _02245C94
	.public _02245CA4
	.public _02245CC6
	.public _02245CDE
	.public _02245CE0
	.public _02245CE4
	.public _02245CFC
	.public _02245CFE
	.public _02245E54
	.public _02245E5C
	.public _02245E74
	.public _02245EDC
	.public _02245EE0
	.public _02245EE4
	.public _02245EE8
	.public _02245EEC
	.public _02245EF0
	.public _02245EF4
	.public _02245EF8
	.public _02245EFC
	.public _02245F00
	.public _02245F04
	.public _02245F08
	.public _02245F0C
	.public _02245F10
	.public _02245F14
	.public _02245F18
	.public _02245F1C
	.public _02245F20
	.public _02246110
	.public _022461FE
	.public _0224621E
	.public _022462D8
	.public _0224631C
	.public _02246328
	.public _022464D2
	.public _02246538
	.public _0224653C
	.public _02246540
	.public _02246544
	.public _02246548
	.public _0224654C
	.public _02246550
	.public _02246554
	.public _02246558
	.public _0224655C
	.public _02246560
	.public _02246564
	.public _02246568
	.public _0224656C
	.public _02246570
	.public _0224662C
	.public _0224664C
	.public _0224665A
	.public _02246722
	.public _02246724
	.public _02246784
	.public _02246858
	.public _02246864
	.public _0224686E
	.public _02246884
	.public _0224690C
	.public _02246910
	.public _02246914
	.public _02246918
	.public _02246948
	.public _02246962
	.public _0224696A
	.public _02246984
	.public _022469B6
	.public _022469D4
	.public _022469E0
	.public _02246A90
	.public _02246A94
	.public _02246A98
	.public _02246A9C
	.public _02246AA0
	.public _02246AEE
	.public _02246B1A
	.public _02246B2E
	.public _02246B5C
	.public _02246B60
	.public _02246B64
	.public _02246B68
	.public _02246BB6
	.public _02246BD8
	.public _02246BF0
	.public _02246C1C
	.public _02246C20
	.public _02246C24
	.public _02246C28
	.public _02246C42
	.public _02246C6C
	.public _02246CB0
	.public _02246CB4
	.public _02246CB8
	.public _02246CBC
	.public _02246CF4
	.public _02246CFE
	.public _02246D02
	.public _02246D06
	.public _02246D0A
	.public _02246D0C
	.public _02246D36
	.public _02246D3C
	.public _02246D6E
	.public _02246D70
	.public _02246D96
	.public _02246DA0
	.public _02246DA8
	.public _02246DB0
	.public _02246DB8
	.public _02246DBE
	.public _02246DEA
	.public _02246DF0
	.public _02246DF4
	.public _02246DF8
	.public _02246DFC
	.public _02246E00
	.public _02246E04
	.public _02246E4C
	.public _02246EFC
	.public _022470AE
	.public _022470C2
	.public _022470CC
	.public _022470D4
	.public _02247110
	.public _02247124
	.public _02247148
	.public _022471BA
	.public _022471BE
	.public _022471D4
	.public _02247206
	.public _02247220
	.public _0224723A
	.public _0224730C
	.public _02247310
	.public _0224754A
	.public _02247564
	.public _02247608
	.public _0224762C
	.public _02247660
	.public _02247664
	.public _022476C0
	.public _022476EA
	.public _02247738
	.public _0224774A
	.public _0224774C
	.public _02247752
	.public _02247764
	.public _02247776
	.public _022477C0
	.public _02247814
	.public _02247832
	.public _02247860
	.public _022478D0
	.public _022478EE
	.public _02247910
	.public _02247914
	.public _02247918
	.public _0224792C
	.public _0224793E
	.public _02247940
	.public _02247984
	.public _02247994
	.public _022479B6
	.public _022479C6
	.public _02247A1C
	.public _02247A4A
	.public _02247A68
	.public _02247A6C
	.public _02247A70
	.public _02247A74
	.public _02247A78
	.public _02247AA2
	.public _02247AC0
	.public _02247AC4
	.public _02247AC8
	.public _02247ACC
	.public _02247AD0
	.public _02247AEC
	.public _02247AF4
	.public _02247AF6
	.public _02247B00
	.public _02247B2C
	.public _02247B30
	.public _02247B44
	.public _02247B48
	.public _02247B5C
	.public _02247B60
	.public _02247B74
	.public _02247B78
	.public _02247BB8
	.public _02247BBC
	.public _02247BC0
	.public _02247BDE
	.public _02247BE6
	.public _02247BE8
	.public _02247C04
	.public _02247C08
	.public _02247C24
	.public _02247C28
	.public _02247C30
	.public _02247C3E
	.public _02247C46
	.public _02247C4C
	.public _02247C50
	.public _02247C54
	.public _02247C7C
	.public _02247C80
	.public _02247C84
	.public _02247CAC
	.public _02247CB0
	.public _02247CB4
	.public _02247CC0
	.public _02247CC8
	.public _02247CEC
	.public _02247D00
	.public _02247D08
	.public gBattleCastlePartyAppHealMessages
	.public BattleCastlePartyApp_Init
	.public BattleCastlePartyApp_Main
	.public BattleCastlePartyApp_Exit
	.public BattleCastlePartyApp_FadeIn
	.public BattleCastlePartyApp_DrawScreen
	.public BattleCastlePartyApp_HandleMenu
	.public BattleCastlePartyApp_LinkAction
	.public BattleCastlePartyApp_LinkExit
	.public BattleCastlePartyApp_FadeOut
	.public BattleCastlePartyApp_FreeResources
	.public BattleCastlePartyApp_DisableDisplay
	.public BattleCastlePartyApp_InitGraphics
	.public BattleCastlePartyApp_InitBgGraphics
	.public BattleCastlePartyApp_InitSpriteGfx
	.public BattleCastlePartyApp_FreeBgLayers
	.public BattleCastlePartyApp_VBlankCallback
	.public BattleCastlePartyApp_SetGraphicsBanks
	.public BattleCastlePartyApp_InitBgLayers
	.public BattleCastlePartyApp_LoadPartyBg
	.public BattleCastlePartyApp_LoadBgPalette
	.public BattleCastlePartyApp_LoadStatsSummaryBg
	.public BattleCastlePartyApp_ReloadBgPalette
	.public BattleCastlePartyApp_LoadMovesSummaryBg
	.public BattleCastlePartyApp_LoadItemGridBg
	.public BattleCastlePartyApp_LoadSubScreenBg
	.public BattleCastlePartyApp_PrintMessage
	.public BattleCastlePartyApp_AddMessage
	.public BattleCastlePartyApp_ShowMessage
	.public BattleCastlePartyApp_PrintStatsSummary
	.public BattleCastlePartyApp_PrintSummaryText
	.public BattleCastlePartyApp_PrintMovesSummary
	.public BattleCastlePartyApp_PrintMove
	.public BattleCastlePartyApp_PrintPartyHp
	.public BattleCastlePartyApp_PrintMonHp
	.public BattleCastlePartyApp_PrintPartyLevels
	.public BattleCastlePartyApp_PrintMonLevelAndGender
	.public BattleCastlePartyApp_RedrawMonHp
	.public BattleCastlePartyApp_PrintChoosePrompt
	.public BattleCastlePartyApp_HideChoosePrompt
	.public BattleCastlePartyApp_OpenMainMenu
	.public BattleCastlePartyApp_CloseMainMenu
	.public BattleCastlePartyApp_OpenHealMenu
	.public BattleCastlePartyApp_CloseHealMenu
	.public BattleCastlePartyApp_OpenRentalMenu
	.public BattleCastlePartyApp_CloseRentalMenu
	.public BattleCastlePartyApp_OpenItemGrid
	.public BattleCastlePartyApp_CloseItemGrid
	.public BattleCastlePartyApp_ShowYesNoPrompt
	.public BattleCastlePartyApp_PrintItemGridHeader
	.public BattleCastlePartyApp_PrintItemNames
	.public BattleCastlePartyApp_DrawItemIcons
	.public BattleCastlePartyApp_PrintItemPageNumber
	.public BattleCastlePartyApp_PrintReturnButton
	.public BattleCastlePartyApp_PrintItemDescription
	.public BattleCastlePartyApp_PrintSelectedMonInfo
	.public BattleCastlePartyApp_SetupItemGrid
	.public BattleCastlePartyApp_BufferNumber
	.public BattleCastlePartyApp_BufferMonNickname
	.public BattleCastlePartyApp_BufferPlayerName
	.public BattleCastlePartyApp_PrintPlayerName
	.public BattleCastlePartyApp_PrintPartnerName
	.public BattleCastlePartyApp_PrintGenderSymbol
	.public BattleCastlePartyApp_SetMainState
	.public BattleCastlePartyApp_MoveCursor
	.public BattleCastlePartyApp_DrawCursor
	.public BattleCastlePartyApp_GetCursorPos
	.public BattleCastlePartyApp_GetRentalCost
	.public BattleCastlePartyApp_GetRentalCostByItemId
	.public BattleCastlePartyApp_GetRentalItemId
	.public BattleCastlePartyApp_GetTrainerNamePositions
	.public BattleCastlePartyApp_PlayActionEffect
	.public BattleCastlePartyApp_GetMonIconHpPalette
	.public BattleCastlePartyApp_GetHpBarAnimSeq
	.public BattleCastlePartyApp_ScrollStatsSummary
	.public BattleCastlePartyApp_ScrollMovesSummary
	.public BattleCastlePartyApp_CloseAll
	.public BattleCastlePartyApp_IsAnyPpUsed
	.public BattleCastlePartyApp_CloseWindow
	.public BattleCastlePartyApp_SendLinkCommand
	.public BattleCastlePartyApp_PrepareLinkRanks
	.public BattleCastlePartyApp_ReceiveRanks
	.public BattleCastlePartyApp_PrepareLinkAction
	.public BattleCastlePartyApp_ReceiveAction
	.public BattleCastlePartyApp_PrepareLinkCursor
	.public BattleCastlePartyApp_ReceiveCursor
	.public BattleCastlePartyApp_PrepareLinkExit
	.public BattleCastlePartyApp_ReceiveExit
	.public BattleCastlePartyApp_UseItemOnMon
	.public BattleCastlePartyApp_PrintTrainerNames
	.public BattleCastlePartyApp_HealMon
	.public BattleCastlePartyApp_GiveRentalItem
	.public BattleCastlePartyApp_CloseMenus
	.public BattleCastlePartyApp_ReturnToItemList
	.public BattleCastlePartyApp_PrintCastlePoints
	.public BattleCastlePartyApp_ApplyAction
	.public BattleCastlePartyApp_ShowMonStats
	.public BattleCastlePartyApp_ShowMonMoves
	.public BattleCastlePartyApp_HideSummaryPanel
	.public BattleCastlePartyApp_UpdateMonIcons
	.public BattleCastlePartyApp_RankUp
	.public BattleCastlePartyApp_PrintExpandedMessage
	.public BattleCastlePartyApp_LoadMonSummary
	.public BattleCastlePartyApp_PrintSummaryLabels
	.public BattleCastlePartyApp_PrintMonSummary
	.public BattleCastlePartyApp_RefreshMonSummary
	.public BattleCastlePartyApp_ShowMonSummary
	.public BattleCastlePartyApp_GetItemButtonPos
	.public BattleCastlePartyApp_ShowSelectedItem
	.public BattleCastlePartyApp_ShowItemGrid
	.public BattleCastlePartyApp_SetCursorPos
	.public BattleCastlePartyApp_SetItemCursor
	.public BattleCastlePartyApp_ShowItemDescription
	.public BattleCastlePartyApp_CreateListMenu
	.public BattleCastlePartyApp_CreateMainMenuList
	.public BattleCastlePartyApp_CreateHealMenuList
	.public BattleCastlePartyApp_CreateRentalMenuList
	.public BattleCastlePartyApp_DestroyListMenu
	.public BattleCastlePartyApp_PrintMainMenuHelp
	.public BattleCastlePartyApp_PrintHealMenuHelp
	.public BattleCastlePartyApp_PrintRentalMenuHelp
	.public BattleCastlePartyApp_StartButtonAnim
	.public BattleCastlePartyApp_AnimatePressedButton
	.public BattleCastleOpponentApp_Init
	.public BattleCastleOpponentApp_Main
	.public BattleCastleOpponentApp_Exit
	.public BattleCastleOpponentApp_FadeIn
	.public BattleCastleOpponentApp_DrawScreen
	.public BattleCastleOpponentApp_HandleMenu
	.public BattleCastleOpponentApp_LinkAction
	.public BattleCastleOpponentApp_LinkExit
	.public BattleCastleOpponentApp_FadeOut
	.public BattleCastleOpponentApp_FreeResources
	.public BattleCastleOpponentApp_DisableDisplay
	.public BattleCastleOpponentApp_InitGraphics
	.public BattleCastleOpponentApp_InitBgGraphics
	.public BattleCastleOpponentApp_InitSpriteGfx
	.public BattleCastleOpponentApp_FreeBgLayers
	.public BattleCastleOpponentApp_VBlankCallback
	.public BattleCastleOpponentApp_SetGraphicsBanks
	.public BattleCastleOpponentApp_InitBgLayers
	.public BattleCastleOpponentApp_LoadPartyBg
	.public BattleCastleOpponentApp_LoadBgPalette
	.public BattleCastleOpponentApp_LoadSummaryBg
	.public BattleCastleOpponentApp_LoadSummaryBgPalette
	.public BattleCastleOpponentApp_LoadSubScreenBg
	.public BattleCastleOpponentApp_PrintMessage
	.public BattleCastleOpponentApp_AddMessage
	.public BattleCastleOpponentApp_ShowMessage
	.public BattleCastleOpponentApp_PrintPartyHp
	.public BattleCastleOpponentApp_PrintPartyLevels
	.public BattleCastleOpponentApp_ShowYesNoPrompt
	.public BattleCastleOpponentApp_OpenLevelMenu
	.public BattleCastleOpponentApp_CloseLevelMenu
	.public BattleCastleOpponentApp_BufferNumber
	.public BattleCastleOpponentApp_BufferSpeciesName
	.public BattleCastleOpponentApp_BufferPlayerName
	.public BattleCastleOpponentApp_PrintPlayerName
	.public BattleCastleOpponentApp_PrintPartnerName
	.public BattleCastleOpponentApp_PrintGenderSymbol
	.public BattleCastleOpponentApp_PrintChoosePrompt
	.public BattleCastleOpponentApp_HideChoosePrompt
	.public BattleCastleOpponentApp_OpenMainMenu
	.public BattleCastleOpponentApp_CloseMainMenu
	.public BattleCastleOpponentApp_OpenSummaryMenu
	.public BattleCastleOpponentApp_CloseSummaryMenu
	.public BattleCastleOpponentApp_SetMainState
	.public BattleCastleOpponentApp_MoveCursor
	.public BattleCastleOpponentApp_DrawCursor
	.public BattleCastleOpponentApp_GetCursorPos
	.public BattleCastleOpponentApp_GetTrainerNamePositions
	.public BattleCastleOpponentApp_PlayActionEffect
	.public BattleCastleOpponentApp_FinishLinkAction
	.public BattleCastleOpponentApp_GetLevelChangeCost
	.public BattleCastleOpponentApp_CloseAll
	.public BattleCastleOpponentApp_CloseWindow
	.public BattleCastleOpponentApp_SendLinkCommand
	.public BattleCastleOpponentApp_PrepareLinkRanks
	.public BattleCastleOpponentApp_ReceiveRanks
	.public BattleCastleOpponentApp_PrepareLinkAction
	.public BattleCastleOpponentApp_ReceiveAction
	.public BattleCastleOpponentApp_PrepareLinkCursor
	.public BattleCastleOpponentApp_ReceiveCursor
	.public BattleCastleOpponentApp_PrepareLinkExit
	.public BattleCastleOpponentApp_ReceiveExit
	.public BattleCastleOpponentApp_SetStatsBought
	.public BattleCastleOpponentApp_BuyStats
	.public BattleCastleOpponentApp_SetMovesBought
	.public BattleCastleOpponentApp_BuyMoves
	.public BattleCastleOpponentApp_CloseMenus
	.public BattleCastleOpponentApp_OpenMessageBox
	.public BattleCastleOpponentApp_PrintCastlePoints
	.public BattleCastleOpponentApp_ConfirmLevelChange
	.public BattleCastleOpponentApp_PrintTrainerNames
	.public BattleCastleOpponentApp_ApplyAction
	.public BattleCastleOpponentApp_CheckMon
	.public BattleCastleOpponentApp_CheckMonAndRedrawHp
	.public BattleCastleOpponentApp_ChangeLevel
	.public BattleCastleOpponentApp_HideSummaryBg
	.public BattleCastleOpponentApp_UpdateMonIcons
	.public BattleCastleOpponentApp_TryBuy
	.public BattleCastleOpponentApp_RankUp
	.public BattleCastleOpponentApp_ShowBoughtMarks
	.public BattleCastleOpponentApp_ShowMonBoughtMarks
	.public BattleCastleOpponentApp_GetBoughtMarkPos
	.public BattleCastleOpponentApp_PrintExpandedMessage
	.public BattleCastleOpponentApp_LoadMonSummary
	.public BattleCastleOpponentApp_PrintSummaryLabels
	.public BattleCastleOpponentApp_PrintMonSummary
	.public BattleCastleOpponentApp_ShowMonSummary
	.public BattleCastleOpponentApp_ShowSummaryPanel
	.public BattleCastleOpponentApp_LoadMonPic
	.public BattleCastleOpponentApp_SetCursorPos
	.public BattleCastleOpponentApp_CreateListMenu
	.public BattleCastleOpponentApp_CreateMainMenuList
	.public BattleCastleOpponentApp_CreateSummaryMenuList
	.public BattleCastleOpponentApp_CreateLevelMenuList
	.public BattleCastleOpponentApp_DestroyListMenu
	.public BattleCastleOpponentApp_PrintMainMenuHelp
	.public BattleCastleOpponentApp_PrintSummaryMenuHelp
	.public BattleCastle_InitSpriteGfx
	.public BattleCastle_CreateSprite
	.public BattleCastle_FreeSpriteGfx
	.public BattleCastle_LoadItemIconChar
	.public BattleCastle_LoadItemIconPalette
	.public BattleCastle_InitSpriteTransfer
	.public BattleCastle_LoadPartyListGfx
	.public BattleCastle_LoadMonPicGfx
	.public BattleCastleSprite_New
	.public BattleCastleSprite_NewSubScreen
	.public BattleCastleSprite_Delete
	.public BattleCastleSprite_SetDrawFlag
	.public BattleCastleSprite_SetPosition
	.public BattleCastleSprite_SetPositionSubScreen
	.public BattleCastleSprite_SetAnim
	.public BattleCastleSprite_SetMonIconPalette
	.public BattleCastleSprite_ChangeAnim
	.public BattleCastleSprite_SetBounce
	.public BattleCastleSprite_IsAnimated
	.public BattleCastleSprite_ShowAnim11WithSE
	.public BattleCastleSprite_LoadMonPic
	.public BattleCastle_SetSpritesTranslucent
	.public BattleCastle_GetMonIndex
	.public BattleCastle_GetSideSlot
	.public BattleCastle_GetRank
	.public BattleCastle_PlaySEOnInput
	.public BattleCastle_BufferPartnerName
	.public BattleCastle_ClearBgToggleRequests
	.public BattleCastle_RequestBgToggle
	.public BattleCastle_ApplyBgToggleRequests
	.public BattleCastlePrompt_Init
	.public BattleCastlePrompt_Free
	.public BattleCastlePrompt_Show
	.public BattleCastlePrompt_Hide
	.public BattleCastle_AddWindows
	.public BattleCastle_RemoveWindows
	.public BattleCastle_DrawWindowFrame
	.public BattleCastle_GetMenuTiles
	.public BattleCastle_PrintString
	.public BattleCastle_PrintMsg
	.public BattleCastle_FreeGrid
	.public BattleCastle_GridCallbackNoOp
	.public BattleCastlePartyApp_CreatePartyGrid
	.public BattleCastleOpponentApp_CreatePartyGrid
	.public BattleCastle_HandlePartyGridInput
	.public BattleCastle_SetGridInputsToNext
	.public BattleCastlePartyApp_OnPartyGridKeyMove
	.public BattleCastlePartyApp_OnPartyGridTouch
	.public BattleCastleOpponentApp_OnPartyGridKeyMove
	.public BattleCastleOpponentApp_OnPartyGridTouch
	.public BattleCastlePartyApp_CreateItemGrid
	.public BattleCastle_HandleItemGridInput
	.public BattleCastlePartyApp_OnItemGridKeyMove
	.public BattleCastlePartyApp_OnItemGridTouch
	.public BattleCastle_CreateListMenuSpawner
	.public BattleCastle_DestroyListMenuSpawner
	.public BattleCastle_CreateListMenu
	.public BattleCastle_DestroyListMenu
	.public BattleCastle_IsAdvancePressed
	.public gBattleCastlePartyAppBerryCounts
	.public gBattleCastlePartyAppHealCosts
	.public gBattleCastlePartyAppMainMenuHelpMessages
	.public gBattleCastlePartyAppItemCounts
	.public gBattleCastlePartyAppGraphicsModes
	.public gBattleCastlePartyAppRankUpCosts
	.public ov83_02247D4E
	.public gBattleCastlePartyAppRankUpMessages
	.public gBattleCastlePartyAppMainMenuItems
	.public gBattleCastlePartyAppBgTemplate_Sub2
	.public gBattleCastlePartyAppBgTemplate_Main1
	.public gBattleCastlePartyAppBgTemplate_Main0
	.public gBattleCastlePartyAppBgTemplate_Sub3
	.public gBattleCastlePartyAppBgTemplate_Main2
	.public gBattleCastlePartyAppBgTemplate_Main3
	.public gBattleCastlePartyAppBgTemplate_Sub0
	.public gBattleCastlePartyAppBgTemplate_Sub1
	.public gBattleCastlePartyAppButtonRects
	.public gBattleCastlePartyAppGraphicsBanks
	.public gBattleCastlePartyAppRentalMenuOptions
	.public gBattleCastleRentalItems
	.public gBattleCastleRentalItemCosts
	.public gBattleCastlePartyAppHealMenuOptions
	.public gBattleCastleRentalBerries
	.public gBattleCastleRentalBerryCosts
	.public gBattleCastlePartyAppListMenuY
	.public gBattleCastleOpponentAppListMenuY
	.public gBattleCastleOpponentAppListMenuTemplate
	.public gBattleCastleOpponentAppStatsHelpMessages
	.public gBattleCastleOpponentAppMovesHelpMessages
	.public gBattleCastleOpponentAppRankUpHelpMessages
	.public gBattleCastleOpponentAppCancelHelpMessages
	.public gBattleCastleOpponentAppGraphicsModes
	.public gBattleCastleOpponentAppRankUpMessages
	.public gBattleCastleOpponentAppBgTemplate_Main1
	.public gBattleCastleOpponentAppBgTemplate_Main0
	.public gBattleCastleOpponentAppBgTemplate_Main2
	.public gBattleCastleOpponentAppBgTemplate_Main3
	.public gBattleCastleOpponentAppBgTemplate_Sub0
	.public gBattleCastleOpponentAppBgTemplate_Sub1
	.public gBattleCastleOpponentAppGraphicsBanks
	.public gBattleCastleSpriteResManSizes
	.public gBattleCastleObjCharTransferTemplate
	.public gBattleCastleMonPicRect
	.public gBattleCastleWindowSets
	.public gBattleCastleOpponentAppWindowTemplates
	.public gBattleCastlePartyAppWindowTemplates
	.public gBattleCastleItemGridArrowHitboxes
	.public gBattleCastlePartyAppPartyGridCallbacks
	.public gBattleCastleOpponentAppPartyGridCallbacks
	.public gBattleCastleItemGridCallbacks
	.public gBattleCastlePartyGrid3Hitboxes
	.public gBattleCastlePartyGridSlots
	.public gBattleCastlePartyGrid4Hitboxes
	.public gBattleCastleItemGridCursorAnims
	.public gBattleCastleItemGridButtons
	.public gBattleCastlePartyGrid3Boxes
	.public gBattleCastleItemGridHitboxes
	.public gBattleCastlePartyGrid4Boxes
	.public gBattleCastleItemGridBoxes
	.public ov83_02248611
	.include "overlay_83.inc"
	.include "global.inc"

	.text
	.public BattleCastlePartyApp_DrawScreen
	.public BattleCastlePartyApp_FadeOut
	.public BattleCastlePartyApp_DisableDisplay
	.public BattleCastlePartyApp_PrintPartyHp
	.public BattleCastlePartyApp_PrintPartyLevels
	.public BattleCastlePartyApp_HideChoosePrompt
	.public BattleCastlePartyApp_CloseMainMenu
	.public BattleCastlePartyApp_CloseHealMenu
	.public BattleCastlePartyApp_CloseRentalMenu
	.public BattleCastlePartyApp_ShowYesNoPrompt
	.public BattleCastlePartyApp_BufferNumber
	.public BattleCastlePartyApp_BufferMonNickname
	.public BattleCastlePartyApp_BufferPlayerName
	.public BattleCastlePartyApp_SetMainState
	.public BattleCastlePartyApp_GetTrainerNamePositions
	.public BattleCastlePartyApp_CloseAll
	.public BattleCastlePartyApp_CloseWindow
	.public BattleCastlePartyApp_PrepareLinkCursor
	.public BattleCastlePartyApp_PrepareLinkExit
	.public BattleCastlePartyApp_ReceiveExit
	.public BattleCastlePartyApp_UseItemOnMon
	.public BattleCastlePartyApp_ReturnToItemList
	.public BattleCastlePartyApp_HideSummaryPanel
	.public BattleCastlePartyApp_GetItemButtonPos
	.public BattleCastlePartyApp_SetCursorPos
	.public BattleCastlePartyApp_ShowItemDescription
	.public BattleCastlePartyApp_StartButtonAnim
	.public BattleCastleOpponentApp_DrawScreen
	.public BattleCastleOpponentApp_FadeOut
	.public BattleCastleOpponentApp_DisableDisplay
	.public BattleCastleOpponentApp_ShowYesNoPrompt
	.public BattleCastleOpponentApp_OpenLevelMenu
	.public BattleCastleOpponentApp_CloseLevelMenu
	.public BattleCastleOpponentApp_BufferNumber
	.public BattleCastleOpponentApp_BufferSpeciesName
	.public BattleCastleOpponentApp_BufferPlayerName
	.public BattleCastleOpponentApp_HideChoosePrompt
	.public BattleCastleOpponentApp_OpenMainMenu
	.public BattleCastleOpponentApp_CloseMainMenu
	.public BattleCastleOpponentApp_OpenSummaryMenu
	.public BattleCastleOpponentApp_CloseSummaryMenu
	.public BattleCastleOpponentApp_SetMainState
	.public BattleCastleOpponentApp_GetTrainerNamePositions
	.public BattleCastleOpponentApp_GetLevelChangeCost
	.public BattleCastleOpponentApp_CloseAll
	.public BattleCastleOpponentApp_CloseWindow
	.public BattleCastleOpponentApp_PrepareLinkCursor
	.public BattleCastleOpponentApp_PrepareLinkExit
	.public BattleCastleOpponentApp_ReceiveExit
	.public BattleCastleOpponentApp_SetStatsBought
	.public BattleCastleOpponentApp_SetMovesBought
	.public BattleCastleOpponentApp_OpenMessageBox
	.public BattleCastleOpponentApp_CheckMonAndRedrawHp
	.public BattleCastleOpponentApp_HideSummaryBg
	.public BattleCastleOpponentApp_ShowMonBoughtMarks
	.public BattleCastleOpponentApp_GetBoughtMarkPos
	.public BattleCastleOpponentApp_ShowMonSummary
	.public BattleCastleOpponentApp_SetCursorPos
	.public BattleCastleSprite_Delete
	.public BattleCastleSprite_SetDrawFlag
	.public BattleCastleSprite_SetAnim
	.public BattleCastleSprite_SetMonIconPalette
	.public BattleCastleSprite_ChangeAnim
	.public BattleCastleSprite_SetBounce
	.public BattleCastleSprite_IsAnimated
	.public BattleCastle_SetSpritesTranslucent
	.public BattleCastle_GetMonIndex
	.public BattleCastle_GetSideSlot
	.public BattleCastle_PlaySEOnInput
	.public BattleCastle_BufferPartnerName
	.public BattleCastle_ClearBgToggleRequests
	.public BattleCastlePrompt_Init
	.public BattleCastlePrompt_Free
	.public BattleCastlePrompt_Hide
	.public BattleCastle_GetMenuTiles
	.public BattleCastle_FreeGrid
	.public BattleCastle_GridCallbackNoOp
	.public BattleCastle_SetGridInputsToNext
	.public BattleCastlePartyApp_OnPartyGridKeyMove
	.public BattleCastlePartyApp_OnPartyGridTouch
	.public BattleCastleOpponentApp_OnPartyGridKeyMove
	.public BattleCastleOpponentApp_OnPartyGridTouch
	.public BattleCastle_CreateListMenuSpawner
	.public BattleCastle_DestroyListMenuSpawner
	.public BattleCastle_DestroyListMenu
	.public BattleCastle_IsAdvancePressed
	.rodata

gBattleCastlePartyAppHealMessages:
	.byte 0x22, 0x00, 0x23, 0x00
	.byte 0x24, 0x00

gBattleCastlePartyAppBerryCounts: ; 0x02247D12
	.byte 0x08, 0x00, 0x08, 0x00, 0x20, 0x00

gBattleCastlePartyAppHealCosts: ; 0x02247D18
	.byte 0x0A, 0x00, 0x08, 0x00, 0x0C, 0x00

gBattleCastlePartyAppMainMenuHelpMessages: ; 0x02247D1E
	.byte 0x0E, 0x00
	.byte 0x0F, 0x00, 0x12, 0x00

gBattleCastlePartyAppItemCounts: ; 0x02247D24
	.byte 0x0C, 0x00, 0x0C, 0x00, 0x1B, 0x00, 0x03, 0x00, 0x00, 0x0B, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppGraphicsModes: ; 0x02247D38
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppRankUpCosts: ; 0x02247D48
	.byte 0x00, 0x00, 0x64, 0x00, 0x64, 0x00

ov83_02247D4E: ; 0x02247D4E
	.byte 0x00, 0x00
	.byte 0x64, 0x00, 0x96, 0x00, 0x00, 0x00, 0x32, 0x00, 0x32, 0x00

gBattleCastlePartyAppRankUpMessages: ; 0x02247D5A
	.byte 0x00, 0x00, 0x2A, 0x00, 0x2B, 0x00
	.byte 0x00, 0x00, 0x44, 0x00, 0x45, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppMainMenuItems: ; 0x02247D6C
	.byte 0x09, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00
	.byte 0xFE, 0xFF, 0xFF, 0xFF

gBattleCastlePartyAppBgTemplate_Sub2: ; 0x02247D84
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1D, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppBgTemplate_Main1: ; 0x02247DA0
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1F, 0x04, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppBgTemplate_Main0: ; 0x02247DBC
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x06
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppBgTemplate_Sub3: ; 0x02247DD8
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1C, 0x06, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppBgTemplate_Main2: ; 0x02247DF4
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1D, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppBgTemplate_Main3: ; 0x02247E10
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1C, 0x02, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppBgTemplate_Sub0: ; 0x02247E2C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x00
	.byte 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppBgTemplate_Sub1: ; 0x02247E48
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x04, 0x00, 0x02, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gBattleCastlePartyAppButtonRects: ; 0x02247E64
	.byte 0x00, 0x04, 0x10, 0x05, 0x10, 0x04, 0x10, 0x05, 0x00, 0x09, 0x10, 0x05
	.byte 0x10, 0x09, 0x10, 0x05, 0x00, 0x0E, 0x10, 0x05, 0x10, 0x0E, 0x10, 0x05, 0x00, 0x14, 0x04, 0x04
	.byte 0x06, 0x14, 0x04, 0x04, 0x19, 0x14, 0x07, 0x04

gBattleCastlePartyAppGraphicsBanks: ; 0x02247E88
	.byte 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x60, 0x00, 0x00, 0x00

gBattleCastlePartyAppRentalMenuOptions: ; 0x02247EB0
	.byte 0x01, 0x00, 0x00, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x2D, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x2E, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x2F, 0x00, 0x00, 0x00, 0xFE, 0xFF, 0xFF, 0xFF

gBattleCastleRentalItems: ; 0x02247EE0
	.byte 0xDD, 0x00, 0xD9, 0x00, 0x0F, 0x01, 0xFD, 0x00, 0x15, 0x01, 0x0D, 0x01, 0x1E, 0x01, 0x28, 0x01
	.byte 0x10, 0x01, 0x11, 0x01, 0xEC, 0x00, 0x02, 0x01, 0xD6, 0x00, 0xE6, 0x00, 0x13, 0x01, 0xEA, 0x00
	.byte 0xD5, 0x00, 0xE8, 0x00, 0x09, 0x01, 0x14, 0x01, 0xDC, 0x00, 0x29, 0x01, 0x1F, 0x01, 0x0A, 0x01
	.byte 0x0B, 0x01, 0x0C, 0x01, 0x0E, 0x01

gBattleCastleRentalItemCosts: ; 0x02247F16
	.byte 0x0A, 0x00, 0x0F, 0x00, 0x05, 0x00, 0x0F, 0x00, 0x0A, 0x00
	.byte 0x0A, 0x00, 0x0A, 0x00, 0x0A, 0x00, 0x0A, 0x00, 0x0A, 0x00, 0x0F, 0x00, 0x0F, 0x00, 0x05, 0x00
	.byte 0x0F, 0x00, 0x0A, 0x00, 0x14, 0x00, 0x14, 0x00, 0x14, 0x00, 0x14, 0x00, 0x14, 0x00, 0x14, 0x00
	.byte 0x14, 0x00, 0x14, 0x00, 0x14, 0x00, 0x14, 0x00, 0x14, 0x00, 0x14, 0x00

gBattleCastlePartyAppHealMenuOptions: ; 0x02247F4C
	.byte 0x01, 0x00, 0x00, 0x00
	.byte 0x13, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x15, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x17, 0x00, 0x00, 0x00, 0xFE, 0xFF, 0xFF, 0xFF

gBattleCastleRentalBerries: ; 0x02247F88
	.byte 0x95, 0x00, 0x96, 0x00, 0x97, 0x00, 0x98, 0x00
	.byte 0x99, 0x00, 0x9C, 0x00, 0x9D, 0x00, 0x9E, 0x00, 0xC9, 0x00, 0xCA, 0x00, 0xCB, 0x00, 0xCC, 0x00
	.byte 0xCD, 0x00, 0xCE, 0x00, 0xCF, 0x00, 0xB8, 0x00, 0xB9, 0x00, 0xBA, 0x00, 0xBB, 0x00, 0xBC, 0x00
	.byte 0xBD, 0x00, 0xBE, 0x00, 0xBF, 0x00, 0xC0, 0x00, 0xC1, 0x00, 0xC2, 0x00, 0xC3, 0x00, 0xC4, 0x00
	.byte 0xC5, 0x00, 0xC6, 0x00, 0xC7, 0x00, 0xC8, 0x00

gBattleCastleRentalBerryCosts: ; 0x02247FC8
	.byte 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00
	.byte 0x02, 0x00, 0x02, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00
	.byte 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00
	.byte 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00
	.byte 0x05, 0x00, 0x05, 0x00, 0x05, 0x00, 0x05, 0x00

gBattleCastlePartyAppListMenuY: ; 0x02248008
	.byte 0x12, 0x0E, 0x0B, 0x08, 0x05, 0x02, 0x00, 0x00

gBattleCastleOpponentAppListMenuY: ; 0x02248010
	.byte 0x12, 0x0E, 0x0B, 0x08, 0x05, 0x02, 0x00, 0x00

gBattleCastleOpponentAppListMenuTemplate: ; 0x02248018
	.byte 0x03, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gBattleCastleOpponentAppStatsHelpMessages: ; 0x02248024
	.byte 0x25, 0x00, 0x25, 0x00

gBattleCastleOpponentAppMovesHelpMessages: ; 0x02248028
	.byte 0x26, 0x00, 0x26, 0x00

gBattleCastleOpponentAppRankUpHelpMessages: ; 0x0224802C
	.byte 0x27, 0x00, 0x28, 0x00

gBattleCastleOpponentAppCancelHelpMessages: ; 0x02248030
	.byte 0x29, 0x00, 0x29, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00
	.byte 0x0F, 0x00, 0x00, 0x00

gBattleCastleOpponentAppGraphicsModes: ; 0x02248044
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gBattleCastleOpponentAppRankUpMessages: ; 0x02248054
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x5F, 0x00, 0x5F, 0x00, 0x00, 0x00

gBattleCastleOpponentAppBgTemplate_Main1: ; 0x02248068
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x02, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gBattleCastleOpponentAppBgTemplate_Main0: ; 0x02248084
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastleOpponentAppBgTemplate_Main2: ; 0x022480A0
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x02, 0x05, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastleOpponentAppBgTemplate_Main3: ; 0x022480BC
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x04, 0x02
	.byte 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

gBattleCastleOpponentAppBgTemplate_Sub0: ; 0x022480D8
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x00, 0x00, 0x03, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gBattleCastleOpponentAppBgTemplate_Sub1: ; 0x022480F4
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x04, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x0A, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00, 0xFE, 0xFF, 0xFF, 0xFF
	.byte 0x21, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x22, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x23, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x24, 0x00, 0x00, 0x00, 0xFE, 0xFF, 0xFF, 0xFF

gBattleCastleOpponentAppGraphicsBanks: ; 0x02248150
	.byte 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x60, 0x00, 0x00, 0x00

gBattleCastleSpriteResManSizes: ; 0x02248178
	.byte 0x0E, 0x0E, 0x0E, 0x0E

gBattleCastleObjCharTransferTemplate: ; 0x0224817C
	.byte 0x20, 0x00, 0x00, 0x00
	.byte 0x00, 0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x6B, 0x00, 0x00, 0x00

gBattleCastleMonPicRect: ; 0x0224818C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00

gBattleCastleWindowSets: ; 0x0224819C
	.word gBattleCastlePartyAppWindowTemplates
	.byte 0x46, 0x00, 0x00, 0x00
	.word gBattleCastleOpponentAppWindowTemplates
	.byte 0x23, 0x00, 0x00, 0x00

gBattleCastleOpponentAppWindowTemplates:
	.byte 0x01, 0x01, 0x01, 0x1E
	.byte 0x02, 0x0E, 0x01, 0x00, 0x01, 0x1A, 0x13, 0x04, 0x03, 0x0E, 0x3D, 0x00, 0x01, 0x00, 0x04, 0x20
	.byte 0x02, 0x0E, 0x49, 0x00, 0x01, 0x00, 0x09, 0x20, 0x02, 0x0E, 0x89, 0x00, 0x00, 0x04, 0x0A, 0x1A
	.byte 0x0E, 0x0E, 0x01, 0x00, 0x00, 0x17, 0x0F, 0x08, 0x08, 0x0E, 0x01, 0x00, 0x00, 0x16, 0x09, 0x09
	.byte 0x08, 0x0E, 0x6D, 0x01, 0x00, 0x02, 0x13, 0x1B, 0x04, 0x0D, 0xB5, 0x01, 0x00, 0x02, 0x13, 0x14
	.byte 0x04, 0x0D, 0x21, 0x02, 0x00, 0x02, 0x13, 0x11, 0x04, 0x0D, 0x71, 0x02, 0x00, 0x18, 0x0D, 0x07
	.byte 0x04, 0x0E, 0xB5, 0x02, 0x00, 0x18, 0x0B, 0x07, 0x06, 0x0E, 0xD1, 0x02, 0x05, 0x0D, 0x01, 0x08
	.byte 0x02, 0x0F, 0xF0, 0x03, 0x05, 0x15, 0x01, 0x01, 0x02, 0x0F, 0xEE, 0x03, 0x05, 0x17, 0x01, 0x03
	.byte 0x02, 0x0F, 0xE8, 0x03, 0x05, 0x1A, 0x01, 0x03, 0x02, 0x0F, 0xE2, 0x03, 0x05, 0x0D, 0x04, 0x07
	.byte 0x02, 0x0F, 0xD4, 0x03, 0x05, 0x14, 0x04, 0x0B, 0x02, 0x0F, 0xBE, 0x03, 0x05, 0x0D, 0x07, 0x06
	.byte 0x02, 0x0F, 0xB2, 0x03, 0x05, 0x14, 0x07, 0x08, 0x02, 0x0F, 0xA2, 0x03, 0x05, 0x0D, 0x0A, 0x06
	.byte 0x02, 0x0F, 0x96, 0x03, 0x05, 0x13, 0x0A, 0x0C, 0x02, 0x0F, 0x7E, 0x03, 0x05, 0x01, 0x0B, 0x02
	.byte 0x02, 0x0F, 0x7A, 0x03, 0x05, 0x04, 0x0B, 0x07, 0x02, 0x0F, 0x6C, 0x03, 0x05, 0x01, 0x0D, 0x06
	.byte 0x02, 0x0F, 0x58, 0x03, 0x05, 0x08, 0x0D, 0x03, 0x02, 0x0F, 0x52, 0x03, 0x05, 0x01, 0x11, 0x07
	.byte 0x02, 0x0F, 0x44, 0x03, 0x05, 0x08, 0x11, 0x03, 0x02, 0x0F, 0x3E, 0x03, 0x05, 0x01, 0x0F, 0x06
	.byte 0x02, 0x0F, 0x32, 0x03, 0x05, 0x08, 0x0F, 0x03, 0x02, 0x0F, 0x2C, 0x03, 0x05, 0x01, 0x13, 0x07
	.byte 0x02, 0x0F, 0x1E, 0x03, 0x05, 0x08, 0x13, 0x03, 0x02, 0x0F, 0x18, 0x03, 0x05, 0x01, 0x15, 0x06
	.byte 0x02, 0x0F, 0x0C, 0x03, 0x05, 0x08, 0x15, 0x03, 0x02, 0x0F, 0x06, 0x03, 0x05, 0x0D, 0x0E, 0x12
	.byte 0x08, 0x0F, 0x76, 0x02

gBattleCastlePartyAppWindowTemplates:
	.byte 0x01, 0x01, 0x01, 0x1E, 0x02, 0x0E, 0x01, 0x00, 0x01, 0x1A, 0x13, 0x04
	.byte 0x03, 0x0E, 0x3D, 0x00, 0x01, 0x00, 0x04, 0x20, 0x02, 0x0E, 0x49, 0x00, 0x01, 0x00, 0x09, 0x20
	.byte 0x02, 0x0E, 0x89, 0x00, 0x00, 0x05, 0x0A, 0x18, 0x0E, 0x0E, 0x01, 0x00, 0x00, 0x0C, 0x02, 0x13
	.byte 0x0C, 0x0E, 0x01, 0x00, 0x00, 0x02, 0x13, 0x1B, 0x04, 0x0D, 0xEF, 0x01, 0x00, 0x02, 0x13, 0x14
	.byte 0x04, 0x0D, 0x5B, 0x02, 0x00, 0x02, 0x13, 0x11, 0x04, 0x0D, 0xAB, 0x02, 0x00, 0x17, 0x11, 0x08
	.byte 0x06, 0x0E, 0xEF, 0x02, 0x00, 0x14, 0x07, 0x0B, 0x0A, 0x0E, 0x1F, 0x03, 0x00, 0x16, 0x09, 0x09
	.byte 0x08, 0x0E, 0x1F, 0x03, 0x00, 0x07, 0x11, 0x17, 0x06, 0x0D, 0x5B, 0x02, 0x00, 0x18, 0x0D, 0x07
	.byte 0x04, 0x0E, 0xE5, 0x02, 0x00, 0x18, 0x0B, 0x07, 0x06, 0x0E, 0x01, 0x03, 0x00, 0x01, 0x01, 0x08
	.byte 0x04, 0x0E, 0x2B, 0x03, 0x00, 0x01, 0x07, 0x0A, 0x02, 0x0E, 0x4B, 0x03, 0x00, 0x01, 0x0D, 0x0B
	.byte 0x02, 0x0E, 0x5F, 0x03, 0x05, 0x0D, 0x01, 0x08, 0x02, 0x0F, 0xF0, 0x03, 0x05, 0x15, 0x01, 0x01
	.byte 0x02, 0x0F, 0xEE, 0x03, 0x05, 0x17, 0x01, 0x03, 0x02, 0x0F, 0xE8, 0x03, 0x05, 0x1A, 0x01, 0x03
	.byte 0x02, 0x0F, 0xE2, 0x03, 0x05, 0x0D, 0x04, 0x07, 0x02, 0x0F, 0xD4, 0x03, 0x05, 0x14, 0x04, 0x0B
	.byte 0x02, 0x0F, 0xBE, 0x03, 0x05, 0x0D, 0x07, 0x06, 0x02, 0x0F, 0xB2, 0x03, 0x05, 0x14, 0x07, 0x08
	.byte 0x02, 0x0F, 0xA2, 0x03, 0x05, 0x0D, 0x0A, 0x06, 0x02, 0x0F, 0x96, 0x03, 0x05, 0x13, 0x0A, 0x0C
	.byte 0x02, 0x0F, 0x7E, 0x03, 0x05, 0x01, 0x0B, 0x02, 0x02, 0x0F, 0x7A, 0x03, 0x05, 0x04, 0x0B, 0x07
	.byte 0x02, 0x0F, 0x6C, 0x03, 0x05, 0x01, 0x0D, 0x06, 0x02, 0x0F, 0x58, 0x03, 0x05, 0x08, 0x0D, 0x03
	.byte 0x02, 0x0F, 0x52, 0x03, 0x05, 0x01, 0x11, 0x07, 0x02, 0x0F, 0x44, 0x03, 0x05, 0x08, 0x11, 0x03
	.byte 0x02, 0x0F, 0x3E, 0x03, 0x05, 0x01, 0x0F, 0x06, 0x02, 0x0F, 0x32, 0x03, 0x05, 0x08, 0x0F, 0x03
	.byte 0x02, 0x0F, 0x2C, 0x03, 0x05, 0x01, 0x13, 0x07, 0x02, 0x0F, 0x1E, 0x03, 0x05, 0x08, 0x13, 0x03
	.byte 0x02, 0x0F, 0x18, 0x03, 0x05, 0x01, 0x15, 0x07, 0x02, 0x0F, 0x0A, 0x03, 0x05, 0x08, 0x15, 0x03
	.byte 0x02, 0x0F, 0x04, 0x03, 0x05, 0x0D, 0x0E, 0x0B, 0x02, 0x0F, 0xEE, 0x02, 0x05, 0x0D, 0x10, 0x0B
	.byte 0x02, 0x0F, 0xD8, 0x02, 0x05, 0x0D, 0x12, 0x0B, 0x02, 0x0F, 0xC2, 0x02, 0x05, 0x0D, 0x14, 0x0B
	.byte 0x02, 0x0F, 0xAC, 0x02, 0x05, 0x1A, 0x0E, 0x05, 0x02, 0x0F, 0xA2, 0x02, 0x05, 0x1A, 0x10, 0x05
	.byte 0x02, 0x0F, 0x98, 0x02, 0x05, 0x1A, 0x12, 0x05, 0x02, 0x0F, 0x8E, 0x02, 0x05, 0x1A, 0x14, 0x05
	.byte 0x02, 0x0F, 0x84, 0x02, 0x00, 0x03, 0x04, 0x0D, 0x05, 0x0E, 0x01, 0x00, 0x00, 0x13, 0x04, 0x0D
	.byte 0x05, 0x0E, 0x42, 0x00, 0x00, 0x03, 0x09, 0x0D, 0x05, 0x0E, 0x83, 0x00, 0x00, 0x13, 0x09, 0x0D
	.byte 0x05, 0x0E, 0xC4, 0x00, 0x00, 0x03, 0x0E, 0x0D, 0x05, 0x0E, 0x05, 0x01, 0x00, 0x13, 0x0E, 0x0D
	.byte 0x05, 0x0E, 0x46, 0x01, 0x00, 0x0A, 0x08, 0x0C, 0x02, 0x0E, 0x87, 0x01, 0x00, 0x16, 0x08, 0x05
	.byte 0x02, 0x0E, 0x9F, 0x01, 0x00, 0x0E, 0x15, 0x04, 0x02, 0x0E, 0xA9, 0x01, 0x00, 0x1A, 0x15, 0x05
	.byte 0x02, 0x0E, 0xB1, 0x01, 0x00, 0x02, 0x01, 0x0C, 0x02, 0x0E, 0xBB, 0x01, 0x00, 0x10, 0x01, 0x08
	.byte 0x02, 0x0E, 0xD3, 0x01, 0x00, 0x18, 0x01, 0x06, 0x02, 0x0E, 0xE3, 0x01, 0x07, 0x04, 0x11, 0x1B
	.byte 0x06, 0x0F, 0x5E, 0x03, 0x07, 0x0D, 0x05, 0x08, 0x02, 0x0F, 0x4E, 0x03, 0x07, 0x15, 0x05, 0x01
	.byte 0x02, 0x0F, 0x4C, 0x03, 0x07, 0x17, 0x05, 0x03, 0x02, 0x0F, 0x46, 0x03, 0x07, 0x1A, 0x05, 0x03
	.byte 0x02, 0x0F, 0x40, 0x03, 0x07, 0x0D, 0x08, 0x02, 0x02, 0x0F, 0x3C, 0x03, 0x07, 0x10, 0x08, 0x08
	.byte 0x02, 0x0F, 0x2C, 0x03, 0x07, 0x0D, 0x0B, 0x06, 0x02, 0x0F, 0x20, 0x03, 0x07, 0x13, 0x0B, 0x0C
	.byte 0x02, 0x0F, 0x08, 0x03

gBattleCastleItemGridArrowHitboxes: ; 0x022484F4
	.byte 0xA0, 0xBF, 0x00, 0x27, 0xA0, 0xBF, 0x28, 0x4F, 0xFF, 0x00, 0x00, 0x00

gBattleCastlePartyAppPartyGridCallbacks: ; 0x02248500
	.word BattleCastle_GridCallbackNoOp
	.word BattleCastle_GridCallbackNoOp
	.word BattleCastlePartyApp_OnPartyGridKeyMove
	.word BattleCastlePartyApp_OnPartyGridTouch

gBattleCastleOpponentAppPartyGridCallbacks: ; 0x02248510
	.word BattleCastle_GridCallbackNoOp
	.word BattleCastle_GridCallbackNoOp
	.word BattleCastleOpponentApp_OnPartyGridKeyMove
	.word BattleCastleOpponentApp_OnPartyGridTouch

gBattleCastleItemGridCallbacks: ; 0x02248520
	.word BattleCastle_GridCallbackNoOp
	.word BattleCastle_GridCallbackNoOp
	.word BattleCastlePartyApp_OnItemGridKeyMove
	.word BattleCastlePartyApp_OnItemGridTouch

gBattleCastlePartyGrid3Hitboxes: ; 0x02248530
	.byte 0x98, 0xAF, 0xC8, 0xF7, 0x20, 0x4F, 0x20, 0x5F, 0x20, 0x4F, 0x60, 0x9F, 0x20, 0x4F, 0xA0, 0xDF
	.byte 0xFF, 0x00, 0x00, 0x00

gBattleCastlePartyGridSlots: ; 0x02248544
	.byte 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00

gBattleCastlePartyGrid4Hitboxes: ; 0x02248558
	.byte 0x98, 0xAF, 0xC8, 0xF7, 0x20, 0x4F, 0x00, 0x3F
	.byte 0x20, 0x4F, 0x40, 0x7F, 0x20, 0x4F, 0x80, 0xBF, 0x20, 0x4F, 0xC0, 0xFF, 0xFF, 0x00, 0x00, 0x00

gBattleCastleItemGridCursorAnims: ; 0x02248570
	.byte 0x03, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x13, 0x00, 0x00, 0x00

gBattleCastleItemGridButtons: ; 0x0224858C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x05, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00

gBattleCastlePartyGrid3Boxes: ; 0x022485A8
	.byte 0x00, 0x00, 0x00, 0x00, 0x81, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x03, 0x02, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x01, 0x03
	.byte 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x02, 0x01

gBattleCastleItemGridHitboxes: ; 0x022485C8
	.byte 0x20, 0x47, 0x00, 0x7F, 0x20, 0x47, 0x80, 0xFF
	.byte 0x48, 0x6F, 0x00, 0x7F, 0x48, 0x6F, 0x80, 0xFF, 0x70, 0x97, 0x00, 0x7F, 0x70, 0x97, 0x80, 0xFF
	.byte 0xA0, 0xBF, 0xC8, 0xFF, 0xFF, 0x00, 0x00, 0x00

gBattleCastlePartyGrid4Boxes: ; 0x022485E8
	.byte 0x00, 0x00, 0x00, 0x00, 0x81, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x04, 0x02, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x01, 0x03
	.byte 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x02, 0x04, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x03, 0x01

gBattleCastleItemGridBoxes: ; 0x02248610
	.byte 0x40

ov83_02248611: ; 0x02248611
	.byte 0x34, 0x00, 0x00, 0x00, 0x02, 0x00, 0x01, 0xC0, 0x34, 0x00, 0x00, 0x01, 0x03, 0x00, 0x01
	.byte 0x40, 0x5C, 0x00, 0x00, 0x00, 0x04, 0x02, 0x03, 0xC0, 0x5C, 0x00, 0x00, 0x01, 0x05, 0x02, 0x03
	.byte 0x40, 0x84, 0x00, 0x00, 0x02, 0x06, 0x04, 0x05, 0xC0, 0x84, 0x00, 0x00, 0x03, 0x06, 0x04, 0x05
	.byte 0xE4, 0xB0, 0x00, 0x00, 0x85, 0x06, 0x06, 0x06
	; 0x02248648
