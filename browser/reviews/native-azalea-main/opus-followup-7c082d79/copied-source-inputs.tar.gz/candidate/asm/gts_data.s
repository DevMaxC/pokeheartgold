#include "config.h"
#include "constants/pokemon.h"
	.include "asm/macros.inc"
	.public _022378D8
	.public _022378E8
	.public _022378F4
	.public _02237926
	.public _02237934
	.public _0223794C
	.public _02237966
	.public _02237984
	.public _0223798A
	.public _02237990
	.public _02237996
	.public _0223799C
	.public _022379A2
	.public _022379A8
	.public _022379AE
	.public _022379B4
	.public _022379BA
	.public _022379C0
	.public _022379C6
	.public _022379CE
	.public _022379D4
	.public _022379E2
	.public _022379FA
	.public _02237A18
	.public _02237A24
	.public _02237A2A
	.public _02237A30
	.public _02237A36
	.public _02237A3C
	.public _02237A42
	.public _02237A4C
	.public _02237A54
	.public _02237A5A
	.public _02237A68
	.public _02237A80
	.public _02237A9A
	.public _02237AAE
	.public _02237AB8
	.public _02237AC2
	.public _02237ACC
	.public _02237AD4
	.public _02237ADA
	.public _02237AE8
	.public _02237B00
	.public _02237B1A
	.public _02237B34
	.public _02237B3A
	.public _02237B44
	.public _02237B4E
	.public _02237B56
	.public _02237B60
	.public _02237B68
	.public _02237B6E
	.public _02237B7C
	.public _02237B94
	.public _02237BB2
	.public _02237BB8
	.public _02237BC0
	.public _02237BC4
	.public _02237BC8
	.public _02237BCC
	.public _02237BD2
	.public _02237BD8
	.public _02237BDE
	.public _02237BE6
	.public _02237BEC
	.public _02237BFA
	.public _02237C12
	.public _02237C30
	.public _02237C3C
	.public _02237C42
	.public _02237C48
	.public _02237C4E
	.public _02237C54
	.public _02237C5A
	.public _02237C64
	.public _02237C6C
	.public _02237C72
	.public _02237C80
	.public _02237C98
	.public _02237CBC
	.public _02237CC8
	.public _02237CDC
	.public _02237CE4
	.public _02237CEA
	.public _02237CF8
	.public _02237D10
	.public _02237D2A
	.public _02237D40
	.public _02237D5E
	.public _02237D68
	.public _02237D72
	.public _02237D7C
	.public _02237D86
	.public _02237D90
	.public _02237D9A
	.public _02237DA4
	.public _02237DAE
	.public _02237DB6
	.public _02237DBC
	.public _02237DCA
	.public _02237DE2
	.public _02237DFA
	.public _02237E00
	.public _02237E06
	.public _02237E0A
	.public _02237E10
	.public _02237E1E
	.public _02237E36
	.public _02237E54
	.public _02237E5A
	.public _02237E60
	.public _02237E66
	.public _02237E6C
	.public _02237E72
	.public _02237E7A
	.public _02237E80
	.public _02237E8E
	.public _02237EA6
	.public _02237EBC
	.public _02237EC0
	.public _02237EC4
	.public _02237EC8
	.public _02237ECC
	.public _02237EE2
	.public _02237EE8
	.public _02237EF0
	.public _02237EF8
	.public _02237F00
	.public _02237F0A
	.public _02237F12
	.public _02237F18
	.public _02237F24
	.public _02237F28
	.public _02237F34
	.public _02237F46
	.public _02237F4A
	.public _02237F50
	.public _02237F54
	.public _02237F60
	.public _02237F94
	.public _02237FA4
	.public _02237FA8
	.public _02237FAC
	.public _02237FB0
	.public _02237FE2
	.public _02237FF4
	.public _02237FF8
	.public _02237FFC
	.public _02238000
	.public _02238004
	.public _02238036
	.public _02238048
	.public _0223804C
	.public _02238050
	.public _02238054
	.public _02238086
	.public _02238098
	.public _0223809C
	.public _022380A0
	.public _022380A4
	.public _022380CA
	.public _022380DC
	.public _022380E0
	.public _022380E4
	.public _022380E8
	.public _0223810E
	.public _02238120
	.public _02238124
	.public _02238128
	.public _0223812C
	.public _02238180
	.public _02238194
	.public _02238198
	.public _0223819C
	.public _022381A0
	.public _022381B8
	.public _022381E8
	.public _022381F8
	.public _022381FC
	.public _02238200
	.public _02238204
	.public _0223824A
	.public _0223825C
	.public _02238260
	.public _02238264
	.public _02238268
	.public _0223829A
	.public _022382AC
	.public _022382B0
	.public _022382B4
	.public _022382B8
	.public _022382BC
	.public _022382E2
	.public _022382F4
	.public _022382F8
	.public _022382FC
	.public _02238300
	.public _02238340
	.public _02238350
	.public _02238354
	.public _02238358
	.public _0223835C
	.public _02238386
	.public _0223838C
	.public _02238394
	.public _022383AA
	.public _022383EC
	.public _022383F2
	.public _022383F8
	.public _022383FE
	.public _02238404
	.public _0223840A
	.public _02238410
	.public _02238414
	.public _02238428
	.public _0223842C
	.public _02238444
	.public _02238446
	.public _0223856E
	.public _02238582
	.public _02238588
	.public _0223858C
	.public _02238590
	.public _02238594
	.public _02238598
	.public _0223859C
	.public _022385A0
	.public _022385A4
	.public _022385A8
	.public _022385AC
	.public _022385B0
	.public _022385B4
	.public _022385B8
	.public _022385BC
	.public _022385E4
	.public _022385F0
	.public _0223860C
	.public _02238634
	.public _02238642
	.public _02238656
	.public _022386A0
	.public _022386B6
	.public _022386BA
	.public _022386D2
	.public _022386D8
	.public _022386DC
	.public _022386E0
	.public _022386E4
	.public _022386E8
	.public _022386EC
	.public _022386F0
	.public _02238794
	.public _02238798
	.public _0223879C
	.public _022387A0
	.public _022387A4
	.public _022387A8
	.public _022387C0
	.public _022387CC
	.public _022387E8
	.public _022387EC
	.public _022387F0
	.public _022387F4
	.public _02238802
	.public _02238814
	.public _02238874
	.public _02238878
	.public _022388C0
	.public _022388C4
	.public _022388C8
	.public _022388CC
	.public _022388FC
	.public _02238970
	.public _02238ACC
	.public _02238B2C
	.public _02238B30
	.public _02238B34
	.public _02238B38
	.public _02238B3C
	.public _02238B40
	.public _02238B44
	.public _02238B48
	.public _02238B4C
	.public _02238B50
	.public _02238B7C
	.public _02238C52
	.public _02238C56
	.public _02238CA2
	.public _02238CA8
	.public _02238D28
	.public _02238D2C
	.public _02238D30
	.public _02238D34
	.public _02238D4A
	.public _02238D52
	.public _02238D58
	.public _02238D5C
	.public _02238D7C
	.public _02238D80
	.public _02238DAA
	.public _02238DB8
	.public _02238DD4
	.public _02238DE2
	.public _02238E1C
	.public _02238E3C
	.public _02238E40
	.public _02238E6C
	.public _02238E94
	.public _02238ECC
	.public _02238EF8
	.public _02238EFC
	.public _02238F00
	.public _02238F0E
	.public _02238F20
	.public _02238F58
	.public _02238F5C
	.public _02238F60
	.public _02238F78
	.public _02238F7C
	.public _02238F96
	.public _02238F98
	.public _02238FC8
	.public _02238FD8
	.public _02238FDC
	.public _02238FEC
	.public _02238FF0
	.public _02239072
	.public _022390A2
	.public _022390B8
	.public _022390BC
	.public _022390C8
	.public _022390CC
	.public _022390D0
	.public _022390D4
	.public _022390D8
	.public _022390F8
	.public _022391E0
	.public _022391E4
	.public _022391E8
	.public _022391EC
	.public _02239252
	.public _022392AC
	.public _022392B0
	.public _022392B4
	.public _022392B8
	.public _0223932C
	.public _02239402
	.public _0223940A
	.public _0223949C
	.public _022394A0
	.public _022394A4
	.public _022394B0
	.public _022394B4
	.public _02239510
	.public _022395B0
	.public _022395B4
	.public _022395B8
	.public _022395BC
	.public _022395C0
	.public _022395E6
	.public _02239600
	.public _02239604
	.public _02239608
	.public _0223960C
	.public _02239610
	.public _02239638
	.public _02239654
	.public _0223968E
	.public _02239694
	.public _022396DC
	.public _022396F0
	.public _02239728
	.public _0223972C
	.public _02239738
	.public _0223973C
	.public _02239756
	.public _02239772
	.public _02239796
	.public _022397CC
	.public _022397E8
	.public _0223981C
	.public _02239820
	.public _02239824
	.public _02239828
	.public _0223982C
	.public _02239830
	.public _02239876
	.public _022398AC
	.public _022398C0
	.public _022398FE
	.public _02239938
	.public _0223993C
	.public _02239940
	.public _02239944
	.public _02239948
	.public _0223994C
	.public _02239950
	.public _02239978
	.public _02239988
	.public _0223998C
	.public _022399B6
	.public _022399CE
	.public _02239A08
	.public _02239A0C
	.public _02239A62
	.public _02239A98
	.public _02239A9C
	.public _02239AA0
	.public _02239AA4
	.public _02239AA8
	.public _02239AC6
	.public _02239AFA
	.public _02239B16
	.public _02239B7C
	.public _02239B80
	.public _02239BD4
	.public _02239BD8
	.public _02239C2C
	.public _02239C30
	.public _02239C68
	.public _02239D88
	.public _02239E58
	.public _02239E5C
	.public _02239E60
	.public _02239E64
	.public _02239E78
	.public _02239F68
	.public _02239F6C
	.public _02239F70
	.public _02239F74
	.public _0223A0D0
	.public _0223A132
	.public _0223A190
	.public _0223A194
	.public _0223A198
	.public _0223A19C
	.public _0223A1C2
	.public _0223A1D4
	.public _0223A1D8
	.public _0223A1DC
	.public _0223A1E0
	.public _0223A20A
	.public _0223A220
	.public _0223A22E
	.public _0223A250
	.public _0223A254
	.public _0223A27A
	.public _0223A2A4
	.public _0223A2B8
	.public _0223A2C0
	.public _0223A2C4
	.public _0223A2C8
	.public _0223A2CC
	.public _0223A31C
	.public _0223A320
	.public _0223A354
	.public _0223A372
	.public _0223A378
	.public _0223A37C
	.public _0223A380
	.public _0223A3D4
	.public _0223A3D8
	.public _0223A43A
	.public _0223A45E
	.public _0223A46A
	.public _0223A48C
	.public _0223A494
	.public _0223A498
	.public _0223A49C
	.public _0223A4BA
	.public _0223A4EE
	.public _0223A56C
	.public _0223A570
	.public _0223A574
	.public _0223A630
	.public _0223A66E
	.public _0223A71C
	.public _0223A720
	.public _0223A724
	.public _0223A728
	.public _0223A7DC
	.public _0223A7E0
	.public _0223A8B4
	.public _0223A8B8
	.public _0223AA0A
	.public _0223AA3E
	.public _0223AA54
	.public _0223AA60
	.public _0223AA64
	.public _0223AA68
	.public _0223AA6C
	.public _0223AA70
	.public _0223AA74
	.public _0223AA78
	.public _0223AA7C
	.public _0223AA80
	.public _0223AA84
	.public _0223AA88
	.public _0223AA8C
	.public _0223AAA6
	.public _0223AAEC
	.public _0223AAF0
	.public _0223AAF4
	.public _0223AAF8
	.public _0223AAFC
	.public _0223AB38
	.public _0223ABAE
	.public _0223ABB8
	.public _0223ABCC
	.public _0223ABD0
	.public _0223ABD4
	.public _0223ACF0
	.public _0223AD8A
	.public _0223ADD6
	.public _0223AE10
	.public _0223AE2C
	.public _0223AE30
	.public _0223AE34
	.public _0223AE38
	.public _0223AE3C
	.public _0223AE72
	.public _0223AE88
	.public _0223AE8C
	.public _0223AE90
	.public _0223AE94
	.public _0223AED4
	.public _0223AEEA
	.public _0223AF18
	.public _0223AF1C
	.public _0223AF20
	.public _0223AF24
	.public _0223AF28
	.public _0223AF2C
	.public _0223AF50
	.public _0223AF54
	.public _0223AF58
	.public _0223AF90
	.public _0223AF9C
	.public _0223AFA4
	.public _0223AFF2
	.public _0223AFF4
	.public _0223AFF8
	.public _0223B02C
	.public _0223B054
	.public _0223B07A
	.public _0223B0A0
	.public _0223B0BA
	.public _0223B0E6
	.public _0223B10C
	.public _0223B114
	.public _0223B118
	.public _0223B11C
	.public _0223B120
	.public _0223B124
	.public _0223B128
	.public _0223B160
	.public _0223B178
	.public _0223B184
	.public _0223B1B0
	.public _0223B1B4
	.public _0223B202
	.public _0223B23C
	.public _0223B240
	.public _0223B244
	.public _0223B248
	.public _0223B24C
	.public _0223B250
	.public _0223B254
	.public _0223B2B4
	.public _0223B2B8
	.public _0223B2BC
	.public _0223B2F6
	.public _0223B2FC
	.public _0223B332
	.public _0223B338
	.public _0223B33C
	.public gConnectToRangerGraphicsBanks
	.public _0223B35E
	.public _0223B3B4
	.public _0223B3B8
	.public _0223B3E8
	.public _0223B418
	.public _0223B480
	.public _0223B4B4
	.public _0223B4CC
	.public _0223B4D0
	.public _0223B558
	.public _0223B6A2
	.public _0223B6AC
	.public _0223B6B0
	.public _0223B6B4
	.public _0223B6B8
	.public _0223B6BC
	.public _0223B6C0
	.public _0223B6C4
	.public _0223B6C8
	.public _0223B6CC
	.public _0223B6D0
	.public _0223B6D4
	.public _0223B6D8
	.public _0223B6DC
	.public _0223B6E0
	.public _0223B6E4
	.public _0223B6E8
	.public _0223B704
	.public _0223B768
	.public _0223B76C
	.public _0223B770
	.public _0223B774
	.public _0223B778
	.public _0223B77C
	.public _0223B780
	.public _0223B784
	.public _0223B7C8
	.public _0223B8A4
	.public _0223B8A8
	.public _0223B8AC
	.public _0223B8B0
	.public _0223BA9C
	.public _0223BAA0
	.public _0223BAA4
	.public _0223BAA8
	.public _0223BAD4
	.public _0223BAD8
	.public _0223BADC
	.public _0223BB22
	.public _0223BB6E
	.public _0223BBBC
	.public _0223BC10
	.public _0223BC14
	.public _0223BC18
	.public _0223BC1C
	.public _0223BC20
	.public _0223BC24
	.public _0223BC28
	.public _0223BC46
	.public _0223BC5A
	.public _0223BC6C
	.public _0223BC70
	.public _0223BC74
	.public _0223BC78
	.public _0223BCC8
	.public _0223BCCC
	.public _0223BCFC
	.public _0223BD00
	.public _0223BD48
	.public _0223BD4E
	.public _0223BD64
	.public _0223BD78
	.public _0223BD7C
	.public _0223BD88
	.public _0223BD8C
	.public _0223BDA6
	.public _0223BDB4
	.public _0223BDC2
	.public _0223BDF0
	.public _0223BDFE
	.public _0223BE0C
	.public _0223BE1A
	.public _0223BE4A
	.public _0223BE52
	.public _0223BE70
	.public _0223BE74
	.public _0223BE78
	.public _0223BE7C
	.public _0223BE80
	.public _0223BEA8
	.public _0223BECA
	.public _0223BEEE
	.public _0223BEF4
	.public _0223BEF8
	.public _0223BEFC
	.public _0223BF2E
	.public _0223BF66
	.public _0223BF8C
	.public _0223BF94
	.public _0223BF98
	.public _0223BF9C
	.public _0223BFA0
	.public _0223BFA4
	.public _0223BFBA
	.public _0223BFC0
	.public _0223C002
	.public _0223C01C
	.public _0223C02A
	.public _0223C044
	.public _0223C082
	.public _0223C0BC
	.public _0223C0C0
	.public _0223C0C4
	.public _0223C0F4
	.public _0223C122
	.public _0223C150
	.public _0223C15E
	.public _0223C164
	.public _0223C16A
	.public _0223C170
	.public _0223C176
	.public _0223C18C
	.public _0223C190
	.public _0223C194
	.public _0223C198
	.public _0223C1CC
	.public _0223C1EA
	.public _0223C1F0
	.public _0223C1F4
	.public _0223C22C
	.public _0223C234
	.public _0223C238
	.public _0223C26C
	.public _0223C270
	.public _0223C2A8
	.public _0223C2AC
	.public _0223C2E4
	.public _0223C2E8
	.public _0223C2FA
	.public _0223C300
	.public _0223C32E
	.public _0223C346
	.public _0223C368
	.public _0223C380
	.public _0223C396
	.public _0223C3A0
	.public _0223C3B6
	.public _0223C3BE
	.public _0223C404
	.public _0223C408
	.public _0223C40C
	.public _0223C410
	.public _0223C414
	.public _0223C418
	.public _0223C41C
	.public _0223C440
	.public _0223C44E
	.public _0223C494
	.public _0223C498
	.public _0223C49C
	.public _0223C4A0
	.public _0223C4A4
	.public _0223C4A8
	.public _0223C4AC
	.public _0223C4D6
	.public _0223C4E0
	.public _0223C508
	.public _0223C528
	.public _0223C54C
	.public _0223C56E
	.public _0223C5F6
	.public _0223C5FC
	.public _0223C600
	.public _0223C604
	.public _0223C608
	.public _0223C60C
	.public _0223C610
	.public _0223C614
	.public _0223C63C
	.public _0223C65C
	.public _0223C682
	.public _0223C6A0
	.public _0223C6D6
	.public _0223C6DC
	.public _0223C6E0
	.public _0223C6E4
	.public _0223C6E8
	.public _0223C6EC
	.public _0223C714
	.public _0223C73C
	.public _0223C740
	.public _0223C768
	.public _0223C774
	.public _0223C7AE
	.public _0223C7B4
	.public _0223C7B8
	.public _0223C7BC
	.public _0223C7C0
	.public _0223C7E8
	.public _0223C810
	.public _0223C814
	.public _0223C840
	.public _0223C856
	.public _0223C890
	.public _0223C898
	.public _0223C89C
	.public _0223C8A0
	.public _0223C8A4
	.public _0223C8A8
	.public _0223C8AC
	.public _0223C8D8
	.public _0223C90E
	.public _0223C91E
	.public _0223C924
	.public _0223C954
	.public _0223C972
	.public _0223C9A6
	.public _0223C9FA
	.public _0223CA06
	.public _0223CA0C
	.public _0223CA10
	.public _0223CA14
	.public _0223CA36
	.public _0223CA3C
	.public _0223CA68
	.public _0223CAAC
	.public _0223CAB4
	.public _0223CAB8
	.public _0223CABC
	.public _0223CAC0
	.public _0223CB14
	.public _0223CB18
	.public _0223CC00
	.public _0223CC1A
	.public _0223CC1C
	.public _0223CC60
	.public _0223CC64
	.public _0223CC9C
	.public _0223CD24
	.public _0223CD38
	.public _0223CD40
	.public _0223CD98
	.public _0223CDAE
	.public _0223CDCC
	.public _0223CDD0
	.public _0223CDD4
	.public _0223CDF4
	.public _0223CE10
	.public _0223CE40
	.public _0223CF34
	.public _0223CF38
	.public _0223CF3C
	.public _0223CF40
	.public _0223CF44
	.public _0223D0B0
	.public _0223D0BC
	.public _0223D0C6
	.public _0223D0CC
	.public _0223D10A
	.public _0223D14E
	.public _0223D190
	.public _0223D1E8
	.public _0223D1EC
	.public _0223D1F0
	.public _0223D1F4
	.public _0223D1F8
	.public _0223D1FC
	.public _0223D200
	.public _0223D204
	.public _0223D212
	.public _0223D230
	.public _0223D24A
	.public _0223D25C
	.public _0223D260
	.public _0223D264
	.public _0223D268
	.public _0223D34C
	.public _0223D358
	.public _0223D35C
	.public _0223D360
	.public _0223D364
	.public _0223D368
	.public _0223D36C
	.public _0223D370
	.public _0223D374
	.public _0223D3A8
	.public _0223D3AC
	.public _0223D3B0
	.public _0223D3B4
	.public _0223D3B8
	.public _0223D3F2
	.public _0223D400
	.public _0223D404
	.public _0223D408
	.public _0223D40C
	.public _0223D410
	.public _0223D43C
	.public _0223D440
	.public _0223D444
	.public _0223D448
	.public _0223D464
	.public _0223D46A
	.public _0223D486
	.public _0223D48C
	.public _0223D4B4
	.public _0223D4DE
	.public _0223D536
	.public _0223D556
	.public _0223D572
	.public _0223D578
	.public _0223D57C
	.public _0223D580
	.public _0223D584
	.public _0223D5A0
	.public _0223D5C2
	.public _0223D63C
	.public _0223D65C
	.public _0223D666
	.public _0223D66C
	.public _0223D670
	.public _0223D674
	.public _0223D678
	.public _0223D67C
	.public _0223D688
	.public _0223D68C
	.public _0223D6AC
	.public _0223D6C2
	.public _0223D6C4
	.public _0223D6E8
	.public _0223D720
	.public _0223D75A
	.public _0223D772
	.public _0223D78E
	.public _0223D79A
	.public _0223D7BA
	.public _0223D7C8
	.public _0223D7E0
	.public _0223D7EC
	.public _0223D7F0
	.public _0223D7F4
	.public _0223D7F8
	.public _0223D7FC
	.public _0223D800
	.public _0223D804
	.public _0223D820
	.public _0223D82A
	.public _0223D834
	.public _0223D83C
	.public _0223D85A
	.public _0223D862
	.public _0223D864
	.public _0223D8B0
	.public _0223D8B4
	.public _0223D8BE
	.public _0223D8D0
	.public _0223D8D4
	.public _0223D8D8
	.public _0223D8DC
	.public _0223D8E0
	.public _0223D8E4
	.public _0223D908
	.public _0223D912
	.public _0223D91C
	.public _0223D920
	.public _0223D92C
	.public _0223D932
	.public _0223D990
	.public _0223D994
	.public _0223D9B8
	.public _0223D9BA
	.public _0223D9C2
	.public _0223D9C4
	.public _0223D9C6
	.public _0223D9EE
	.public _0223DA38
	.public _0223DA5A
	.public _0223DA6A
	.public _0223DA76
	.public _0223DA9E
	.public _0223DACC
	.public _0223DAFA
	.public _0223DB16
	.public _0223DB1C
	.public _0223DB20
	.public _0223DB24
	.public _0223DB28
	.public _0223DB2C
	.public _0223DB8C
	.public _0223DB90
	.public _0223DBB4
	.public _0223DBB6
	.public _0223DBBE
	.public _0223DBC0
	.public _0223DBC2
	.public _0223DBE0
	.public _0223DC34
	.public _0223DC56
	.public _0223DC66
	.public _0223DC72
	.public _0223DC9A
	.public _0223DCC8
	.public _0223DCD4
	.public _0223DCF0
	.public _0223DCF8
	.public _0223DCFC
	.public _0223DD00
	.public _0223DD04
	.public _0223DD08
	.public _0223DD20
	.public gBattleFactoryData
	.public _0223DD58
	.public _0223DD64
	.public _0223DD8C
	.public _0223DD90
	.public _0223DDB8
	.public _0223DDC8
	.public _0223DDCC
	.public _0223DDF8
	.public _0223DE20
	.public _0223DE24
	.public _0223DE44
	.public _0223DE5E
	.public _0223DE64
	.public _0223DE68
	.public _0223DEC4
	.public _0223DF0C
	.public _0223DF10
	.public _0223DF3C
	.public _0223DF64
	.public _0223DF68
	.public _0223DFAA
	.public _0223DFC4
	.public _0223DFC8
	.public _0223DFCC
	.public _0223DFEA
	.public _0223E014
	.public _0223E018
	.public _0223E048
	.public _0223E04A
	.public _0223E084
	.public _0223E088
	.public _0223E08C
	.public _0223E090
	.public _0223E0B6
	.public _0223E134
	.public _0223E158
	.public _0223E1DA
	.public _0223E230
	.public _0223E23C
	.public _0223E248
	.public _0223E29A
	.public _0223E2BA
	.public _0223E30E
	.public _0223E326
	.public _0223E336
	.public _0223E3A2
	.public _0223E3AA
	.public _0223E3B6
	.public _0223E3BC
	.public _0223E3FA
	.public _0223E404
	.public _0223E414
	.public _0223E462
	.public _0223E46C
	.public _0223E470
	.public _0223E474
	.public _0223E478
	.public _0223E47C
	.public _0223E480
	.public _0223E484
	.public _0223E488
	.public _0223E48C
	.public _0223E498
	.public _0223E4C0
	.public _0223E4CE
	.public _0223E4F8
	.public _0223E50C
	.public _0223E530
	.public _0223E534
	.public _0223E574
	.public _0223E584
	.public _0223E58A
	.public _0223E58E
	.public _0223E592
	.public _0223E598
	.public _0223E5C2
	.public _0223E5D6
	.public _0223E5E6
	.public _0223E5F8
	.public _0223E60E
	.public _0223E622
	.public _0223E630
	.public _0223E640
	.public _0223E652
	.public _0223E742
	.public _0223E75C
	.public _0223E786
	.public _0223E870
	.public _0223E874
	.public _0223E878
	.public _0223E87C
	.public _0223E880
	.public _0223E8A0
	.public _0223E8E4
	.public _0223E948
	.public _0223E94C
	.public _0223E950
	.public _0223EA30
	.public _0223EA34
	.public _0223EA38
	.public _0223EA3C
	.public _0223EB76
	.public _0223EBC8
	.public _0223EBCC
	.public _0223EBD0
	.public _0223EBE6
	.public _0223EC00
	.public _0223EC04
	.public _0223EC08
	.public _0223EC9C
	.public _0223ECA0
	.public _0223ECC4
	.public _0223ECC8
	.public _0223ED1C
	.public _0223ED20
	.public _0223ED50
	.public _0223ED54
	.public _0223ED80
	.public _0223ED88
	.public _0223EDA6
	.public _0223EDAC
	.public _0223EDC8
	.public _0223EDF2
	.public _0223EDFA
	.public _0223EE02
	.public _0223EE0A
	.public _0223EE2E
	.public _0223EE5E
	.public _0223EE88
	.public _0223EE8E
	.public _0223EECA
	.public _0223EED0
	.public _0223EED4
	.public _0223EED8
	.public _0223EEDC
	.public _0223EEE0
	.public _0223EEE4
	.public _0223EF0C
	.public _0223EF30
	.public _0223EF34
	.public _0223EF58
	.public _0223EF70
	.public _0223EFA0
	.public _0223EFA8
	.public _0223EFAC
	.public _0223EFB0
	.public _0223EFB4
	.public _0223EFDC
	.public _0223F000
	.public _0223F004
	.public _0223F02C
	.public _0223F04E
	.public _0223F054
	.public _0223F096
	.public _0223F09C
	.public _0223F0A0
	.public _0223F0A4
	.public _0223F0A8
	.public _0223F0AC
	.public _0223F0B0
	.public _0223F0D8
	.public _0223F100
	.public _0223F104
	.public _0223F13E
	.public _0223F158
	.public _0223F15C
	.public _0223F160
	.public _0223F190
	.public _0223F1A8
	.public _0223F1B4
	.public _0223F1D2
	.public _0223F206
	.public _0223F240
	.public _0223F276
	.public _0223F2AA
	.public _0223F2B2
	.public _0223F2B8
	.public _0223F2CC
	.public _0223F2FC
	.public _0223F316
	.public _0223F31C
	.public _0223F320
	.public _0223F334
	.public _0223F368
	.public _0223F36C
	.public _0223F3A6
	.public _0223F3A8
	.public _0223F3CC
	.public _0223F3D0
	.public _0223F3D4
	.public _0223F404
	.public _0223F446
	.public _0223F468
	.public _0223F46C
	.public _0223F49C
	.public _0223F4DE
	.public _0223F500
	.public _0223F504
	.public _0223F586
	.public _0223F58A
	.public _0223F5F6
	.public _0223F624
	.public _0223F628
	.public _0223F62C
	.public _0223F630
	.public _0223F680
	.public _0223F6C0
	.public _0223F6C8
	.public _0223F6D0
	.public _0223F6DC
	.public _0223F6E0
	.public _0223F718
	.public _0223F730
	.public _0223F798
	.public _0223F79C
	.public _0223F7A0
	.public _0223F7F4
	.public _0223F7F8
	.public _0223F808
	.public _0223F81C
	.public _0223F820
	.public _0223F824
	.public _0223F83E
	.public _0223F848
	.public _0223F85C
	.public _0223F860
	.public _0223F870
	.public _0223F874
	.public _0223F87E
	.public _0223F890
	.public _0223F898
	.public _0223F8A0
	.public _0223F8A4
	.public _0223F8B4
	.public _0223F8C4
	.public _0223F8C8
	.public _0223F8CC
	.public _0223F8D6
	.public _0223F8F0
	.public gBattleArcadeEventColorThresholds
	.public _0223F922
	.public _0223F938
	.public _0223F944
	.public _0223F94E
	.public _0223F9D0
	.public _0223F9E8
	.public _0223FA04
	.public _0223FB1C
	.public _0223FB20
	.public _0223FB24
	.public _0223FB28
	.public _0223FB2C
	.public _0223FB30
	.public _0223FBD8
	.public _0223FBEA
	.public _0223FBF0
	.public _0223FC2C
	.public _0223FC38
	.public _0223FC3C
	.public _0223FC54
	.public _0223FC60
	.public _0223FC64
	.public _0223FC80
	.public _0223FC9A
	.public _0223FCB8
	.public _0223FCD6
	.public _0223FCF4
	.public _0223FD18
	.public _0223FD30
	.public _0223FD4C
	.public _0223FD50
	.public _0223FD5C
	.public _0223FD60
	.public _0223FD94
	.public _0223FDC2
	.public _0223FDE2
	.public _0223FDFA
	.public _0223FE02
	.public _0223FE0A
	.public _0223FE12
	.public _0223FE1A
	.public gBattleHallAppSummaryPages
	.public _0223FE36
	.public _0223FE3C
	.public _0223FE5C
	.public _0223FE8A
	.public _0223FEAA
	.public _0223FEB0
	.public _0223FEB8
	.public _0223FEC0
	.public _0223FEC6
	.public _0223FEDC
	.public _0223FEE0
	.public _0223FF0C
	.public _0223FF3A
	.public _0223FF5A
	.public _0223FF68
	.public _0223FF86
	.public _0223FF8C
	.public _0223FF92
	.public _0223FF9A
	.public _0223FFA2
	.public _0223FFA8
	.public _0223FFBE
	.public _0223FFC4
	.public _0223FFC8
	.public _0223FFE4
	.public _02240010
	.public _02240030
	.public _02240036
	.public _0224003E
	.public _02240046
	.public _0224004C
	.public _02240062
	.public _02240068
	.public _022400B4
	.public _022400B8
	.public _022400E6
	.public _02240106
	.public _02240138
	.public _02240140
	.public _02240148
	.public _02240150
	.public _02240158
	.public _0224015E
	.public _02240174
	.public _02240178
	.public _0224017C
	.public _02240198
	.public _022401C4
	.public _022401E4
	.public _022401EA
	.public _022401F2
	.public _022401FA
	.public _02240200
	.public _02240216
	.public _0224021C
	.public _0224023C
	.public _0224024E
	.public _0224026C
	.public _0224028E
	.public _02240294
	.public _022402B0
	.public _022402B2
	.public _022402D8
	.public _022402FE
	.public _0224030A
	.public _0224036A
	.public _02240372
	.public _022403BE
	.public _022403C6
	.public _022403CE
	.public _022403D0
	.public _022403E6
	.public _022403EC
	.public _022403F0
	.public _022403F4
	.public _022403F8
	.public _0224042C
	.public _0224045A
	.public _0224047A
	.public _02240490
	.public _02240496
	.public _0224049A
	.public _022404A4
	.public _022404AC
	.public _022404B4
	.public _022404CA
	.public _022404D0
	.public _022404E4
	.public _022404F2
	.public _0224053A
	.public _0224053C
	.public _02240594
	.public _022405B0
	.public _022405DE
	.public _022405FE
	.public _02240604
	.public _0224060C
	.public _0224060E
	.public _02240616
	.public _0224061C
	.public _02240632
	.public _02240638
	.public _022406B4
	.public _022406E0
	.public _02240700
	.public _02240708
	.public _0224070E
	.public _02240714
	.public _0224071C
	.public _02240724
	.public _0224072A
	.public _02240740
	.public _02240744
	.public _02240788
	.public _022407A4
	.public _022407C2
	.public _022407C6
	.public _022407CA
	.public _022407CC
	.public _022407E0
	.public _02240898
	.public _022408B2
	.public _022408B8
	.public _022408D8
	.public _022408DC
	.public _0224093C
	.public _02240944
	.public _02240978
	.public _02240990
	.public _0224099C
	.public _022409BA
	.public _02240A1A
	.public _02240A62
	.public _02240A70
	.public _02240A74
	.public _02240A78
	.public _02240AB0
	.public _02240AF4
	.public _02240B0E
	.public _02240B2C
	.public _02240B54
	.public _02240B84
	.public _02240B98
	.public _02240BC2
	.public _02240BFC
	.public _02240C16
	.public _02240C58
	.public _02240C88
	.public _02240C9C
	.public _02240CD8
	.public _02240CFC
	.public _02240D1E
	.public _02240D3A
	.public _02240D40
	.public _02240D50
	.public _02240D6E
	.public _02240DD8
	.public _02240EAA
	.public _02240ED8
	.public _02240EDC
	.public _02240EE0
	.public _02240EE4
	.public _02240EE8
	.public _02240EEC
	.public _02240EF0
	.public _02240F30
	.public _02240F34
	.public _02240F38
	.public _02240F50
	.public _02240F54
	.public _02240F72
	.public _02240F7A
	.public _02240F8E
	.public _02240FA0
	.public _02240FBA
	.public _02240FD0
	.public _02240FD4
	.public _02240FE2
	.public _02240FF6
	.public _02240FF8
	.public _02240FFC
	.public _02241000
	.public _0224103C
	.public _02241040
	.public _02241044
	.public _02241060
	.public _02241068
	.public _0224107E
	.public _02241090
	.public _022410B0
	.public _022410C4
	.public _022410D6
	.public _022410E0
	.public _022410E4
	.public _022410E8
	.public _022410EC
	.public _0224110E
	.public _0224111C
	.public _0224113A
	.public _02241148
	.public _0224117A
	.public _0224117E
	.public _02241180
	.public _0224119E
	.public _022411AA
	.public _022411E0
	.public _022411E8
	.public _022411F4
	.public _022411FE
	.public _02241218
	.public _0224121C
	.public _02241220
	.public _02241224
	.public _02241228
	.public _0224123C
	.public _0224126E
	.public _02241278
	.public _022412BC
	.public _022412C0
	.public _022412C4
	.public _02241304
	.public _02241324
	.public _02241328
	.public _0224132C
	.public _0224134C
	.public _02241350
	.public _02241354
	.public _02241362
	.public _02241378
	.public _0224137C
	.public _0224138A
	.public _022413A4
	.public _022413A8
	.public _02241460
	.public _02241464
	.public _02241490
	.public _022414B6
	.public _022414C2
	.public _022414D8
	.public _0224151C
	.public _02241560
	.public _022415B2
	.public _02241618
	.public _02241640
	.public _02241644
	.public _0224165C
	.public _0224165E
	.public _0224166E
	.public _022416DA
	.public _022416E8
	.public _022416F0
	.public _02241742
	.public _02241798
	.public _022417A6
	.public _022417B2
	.public _022417BA
	.public _022417C8
	.public _022417FE
	.public _02241804
	.public _02241828
	.public _02241860
	.public _02241864
	.public _02241882
	.public _0224188E
	.public _0224189A
	.public _022418D4
	.public _02241918
	.public _02241924
	.public _02241932
	.public _0224193C
	.public _022419B2
	.public _022419E0
	.public _02241A58
	.public _02241A62
	.public _02241B06
	.public _02241B10
	.public _02241BB2
	.public _02241BBC
	.public _02241C60
	.public _02241C68
	.public _02241C6C
	.public _02241C70
	.public _02241C74
	.public _02241C78
	.public _02241C7C
	.public _02241C80
	.public _02241C84
	.public _02241C8A
	.public _02241D00
	.public _02241D0A
	.public _02241DAA
	.public _02241DB0
	.public _02241DD0
	.public _02241DDC
	.public _02241DEA
	.public _02241DF0
	.public _02241E3C
	.public _02241E48
	.public _02241E4E
	.public _02241E9A
	.public _02241EA6
	.public _02241EAC
	.public _02241EF8
	.public _02241F04
	.public _02241F0A
	.public _02241F56
	.public _02241F6A
	.public _02241F70
	.public _02241FC8
	.public _02241FD4
	.public _02241FD8
	.public _02241FF4
	.public _02241FF8
	.public _02242010
	.public _022420DA
	.public _022420E2
	.public _022420F6
	.public _0224210A
	.public _0224211A
	.public _02242128
	.public _02242160
	.public _02242176
	.public _02242186
	.public _0224218E
	.public _02242196
	.public _0224219E
	.public _022421A6
	.public _022421AE
	.public _022421B4
	.public _022421B8
	.public _022421BC
	.public _022421C0
	.public _022421C4
	.public _022421C8
	.public _022421CC
	.public _022421E0
	.public _022421F6
	.public _02242208
	.public _0224221A
	.public _0224222A
	.public _02242250
	.public _02242260
	.public _02242276
	.public _02242282
	.public _022422B6
	.public _022422BC
	.public _022422DE
	.public _022422E4
	.public _022422EE
	.public _022422F8
	.public _0224230E
	.public _02242314
	.public _02242320
	.public _0224232A
	.public _0224233C
	.public _02242344
	.public _02242348
	.public _0224234C
	.public _02242350
	.public _02242354
	.public _02242358
	.public _0224235C
	.public _02242360
	.public _0224237E
	.public _02242382
	.public _02242386
	.public _0224238C
	.public _022423A0
	.public _022423B6
	.public _022423C8
	.public _022423DA
	.public _022423EA
	.public _022423FC
	.public _02242422
	.public _02242440
	.public _0224247E
	.public _02242488
	.public _022424C0
	.public _022424CA
	.public _022424DC
	.public _022424E0
	.public _022424E4
	.public _022424E8
	.public _022424EC
	.public _022424F0
	.public _022424F4
	.public _022424F8
	.public _022424FC
	.public _02242500
	.public _02242504
	.public _02242512
	.public _0224252E
	.public _02242534
	.public _02242542
	.public _0224254E
	.public _0224256C
	.public _02242570
	.public _022425B6
	.public _022425BE
	.public _022425E8
	.public _022425F0
	.public _02242616
	.public _02242636
	.public _0224263C
	.public _0224264C
	.public _02242652
	.public _02242662
	.public _0224266E
	.public _0224269C
	.public _022426A2
	.public _022426BC
	.public _022426D0
	.public _022426E0
	.public _022426E4
	.public _022426E8
	.public _022426EC
	.public _022426F0
	.public _02242716
	.public _0224271C
	.public _02242734
	.public _02242738
	.public _0224275E
	.public _02242764
	.public _02242784
	.public _0224279E
	.public _022427AE
	.public _022427B0
	.public _022427B4
	.public _022427B8
	.public _022427BC
	.public _022427C0
	.public _022427F8
	.public _02242802
	.public _0224282C
	.public _02242834
	.public _02242874
	.public _02242880
	.public _0224288E
	.public _0224289A
	.public _022428B8
	.public _022428BC
	.public _022428E2
	.public _022428E8
	.public _02242900
	.public _02242906
	.public _02242916
	.public _02242922
	.public _02242948
	.public _0224294E
	.public _02242968
	.public _0224297C
	.public _0224298C
	.public _02242990
	.public _02242994
	.public _02242998
	.public _0224299C
	.public _022429AA
	.public _022429B0
	.public _022429B4
	.public _022429C8
	.public _022429DE
	.public _022429F0
	.public _02242A02
	.public _02242A12
	.public _02242A38
	.public _02242A48
	.public _02242A5E
	.public _02242A6A
	.public _02242A9A
	.public _02242AA4
	.public _02242AAE
	.public _02242AB6
	.public _02242AE6
	.public _02242AF0
	.public _02242B1A
	.public _02242B24
	.public _02242B36
	.public _02242B3C
	.public _02242B40
	.public _02242B44
	.public _02242B48
	.public _02242B4C
	.public _02242B50
	.public _02242B54
	.public _02242B58
	.public _02242B6E
	.public _02242B7A
	.public _02242B88
	.public _02242B94
	.public _02242BB4
	.public _02242BB8
	.public _02242BFE
	.public _02242C06
	.public _02242C30
	.public _02242C38
	.public _02242C5E
	.public _02242C86
	.public _02242C8C
	.public _02242CA4
	.public _02242CAA
	.public _02242CBA
	.public _02242CC6
	.public _02242CEC
	.public _02242CF2
	.public _02242D0C
	.public _02242D20
	.public _02242D30
	.public _02242D34
	.public _02242D38
	.public _02242D3C
	.public _02242D40
	.public _02242D58
	.public _02242D5A
	.public _02242D88
	.public _02242DB2
	.public _02242DBE
	.public _02242DD6
	.public _02242DE0
	.public _02242E34
	.public _02242E50
	.public _02242E54
	.public _02242E80
	.public _02242EE0
	.public _02242F20
	.public _02242F32
	.public _02242FBC
	.public _02242FC0
	.public _02243040
	.public _02243044
	.public _02243060
	.public _02243084
	.public _022430F6
	.public _02243118
	.public _02243142
	.public _02243158
	.public _0224315C
	.public _02243160
	.public _02243168
	.public _022431A0
	.public _022431C2
	.public _022431CA
	.public _02243244
	.public _02243248
	.public _0224324C
	.public _02243250
	.public _022432B0
	.public _022432DA
	.public _022432EE
	.public _0224332C
	.public _0224335A
	.public _02243388
	.public _0224338C
	.public _02243390
	.public _02243394
	.public _02243398
	.public _0224339C
	.public _022433A0
	.public _022433A4
	.public _022433C6
	.public _022433D0
	.public _022433DA
	.public _022433EA
	.public _022433FA
	.public _02243416
	.public _02243418
	.public _0224343C
	.public _0224344A
	.public _02243452
	.public _02243492
	.public _022434AA
	.public _022434B4
	.public _022434D4
	.public _022434FE
	.public _02243512
	.public _02243528
	.public _02243542
	.public _0224356C
	.public _02243580
	.public _02243594
	.public _0224367C
	.public _02243680
	.public _02243684
	.public _022436A2
	.public _022436C4
	.public _022436F6
	.public _022436FC
	.public _0224372E
	.public _02243740
	.public _02243742
	.public _0224374C
	.public _022437C0
	.public _022437C4
	.public _022437EA
	.public _0224380E
	.public _02243832
	.public _0224383A
	.public _02243840
	.public _02243872
	.public _0224387E
	.public _02243886
	.public _022438B2
	.public _022438C4
	.public _022438C8
	.public _022438D0
	.public _02243918
	.public _02243920
	.public _02243924
	.public _02243976
	.public _022439A4
	.public _022439B8
	.public _02243A18
	.public _02243A46
	.public _02243A50
	.public _02243A54
	.public _02243A58
	.public _02243A5C
	.public _02243A60
	.public _02243A64
	.public _02243A68
	.public _02243A8A
	.public _02243A94
	.public _02243A9E
	.public _02243AAE
	.public _02243ABE
	.public _02243AE6
	.public _02243B02
	.public _02243B12
	.public _02243BFC
	.public _02243C00
	.public _02243C04
	.public _02243C22
	.public _02243C52
	.public _02243C84
	.public _02243CA8
	.public _02243CBA
	.public _02243CBC
	.public _02243CC4
	.public _02243CDE
	.public _02243D20
	.public _02243D24
	.public _02243D42
	.public _02243D68
	.public _02243D8A
	.public _02243DD4
	.public _02243DD8
	.public _02243DF6
	.public _02243E2C
	.public _02243E6E
	.public _02243EFC
	.public _02243F9A
	.public _02243FAA
	.public _02243FB4
	.public _02243FC2
	.public _02243FC8
	.public _02243FCC
	.public _02243FD0
	.public _02243FFE
	.public _0224400E
	.public _02244018
	.public _02244026
	.public _0224402C
	.public _02244030
	.public _02244034
	.public _022440EE
	.public _022440FA
	.public _0224410C
	.public _02244114
	.public _02244118
	.public _0224411C
	.public _02244120
	.public _0224414E
	.public _02244150
	.public _0224416E
	.public _02244196
	.public _0224419C
	.public _022441A0
	.public _02244280
	.public _02244284
	.public _02244288
	.public _0224428C
	.public _02244404
	.public _02244416
	.public _02244420
	.public _02244438
	.public _02244482
	.public _022444CC
	.public _022444D0
	.public _022444D4
	.public _022444D8
	.public _022444DC
	.public _022444E0
	.public _0224451A
	.public _02244528
	.public _0224453E
	.public _02244566
	.public _02244582
	.public _02244584
	.public _02244588
	.public _02244634
	.public _02244638
	.public _0224463C
	.public _02244640
	.public _02244664
	.public _02244668
	.public _0224466C
	.public _022446A0
	.public _022446A4
	.public _022446C8
	.public _022446CC
	.public _022446FC
	.public _02244700
	.public _02244704
	.public _02244742
	.public _02244760
	.public _02244768
	.public _0224476C
	.public _02244770
	.public _0224479C
	.public _022447CA
	.public _022447DE
	.public _022447EA
	.public _022447FC
	.public _02244800
	.public _0224482C
	.public _02244830
	.public _02244880
	.public _02244884
	.public _022448E6
	.public _022448F8
	.public _0224491E
	.public _02244934
	.public _0224493E
	.public _0224496E
	.public _0224497A
	.public _02244980
	.public _022449B2
	.public _022449C2
	.public _022449C6
	.public _022449D0
	.public _022449D4
	.public _022449DE
	.public _022449E2
	.public _022449F4
	.public _022449FC
	.public _02244A00
	.public _02244A28
	.public _02244A64
	.public _02244A94
	.public _02244AB8
	.public _02244ABE
	.public _02244ACC
	.public _02244ADA
	.public _02244AE8
	.public _02244AF6
	.public _02244B02
	.public _02244B18
	.public _02244B1C
	.public _02244B4C
	.public _02244B50
	.public _02244B62
	.public _02244B82
	.public _02244BA6
	.public _02244BBE
	.public _02244BD2
	.public _02244BDA
	.public _02244BEA
	.public _02244BF4
	.public _02244BFE
	.public _02244C08
	.public _02244C0E
	.public _02244C18
	.public _02244C22
	.public _02244C2E
	.public _02244C3C
	.public _02244C4A
	.public _02244C58
	.public _02244C66
	.public _02244C72
	.public _02244C88
	.public _02244C8C
	.public _02244C90
	.public _02244C94
	.public _02244C98
	.public _02244C9C
	.public _02244CA0
	.public _02244CA4
	.public _02244CE8
	.public _02244CF6
	.public _02244CFC
	.public _02244D00
	.public _02244D04
	.public _02244D40
	.public _02244D68
	.public _02244D78
	.public _02244D7C
	.public _02244DAA
	.public _02244DB6
	.public _02244DBE
	.public _02244DD4
	.public _02244DE6
	.public _02244DF2
	.public _02244DF6
	.public _02244DFA
	.public _02244DFE
	.public _02244E02
	.public _02244E06
	.public _02244E0A
	.public _02244E0E
	.public _02244E12
	.public _02244E14
	.public _02244E38
	.public _02244E3C
	.public _02244E40
	.public _02244E60
	.public _02244E68
	.public _02244E86
	.public _02244EAC
	.public _02244ECA
	.public _02244EE8
	.public _02244F04
	.public _02244F0C
	.public _02244F10
	.public _02244F2E
	.public _02244F58
	.public _02244F62
	.public _02244F9A
	.public _02244FA0
	.public _0224500C
	.public _02245010
	.public _02245014
	.public _02245026
	.public _0224503C
	.public _0224504A
	.public _0224511C
	.public _02245120
	.public _02245128
	.public _02245198
	.public _0224519C
	.public _022451A0
	.public _022451A4
	.public _022451BA
	.public _022451E4
	.public _022451E8
	.public sGtsListMenuTemplate
	.public gGtsServer
	.public GtsServer_Init
	.public GtsServer_Update
	.public GtsServer_Exit
	.public GtsServer_IsRequestDone
	.public GtsServer_GetResult
	.public GtsServer_RequestPost
	.public GtsServer_RequestPostFinish
	.public GtsServer_RequestGet
	.public GtsServer_RequestResult
	.public GtsServer_RequestDelete
	.public GtsServer_RequestReturn
	.public GtsServer_RequestSearch
	.public GtsServer_RequestSearchEx
	.public GtsServer_RequestExchange
	.public GtsServer_RequestExchangeFinish
	.public GtsServer_RequestInfo
	.public GtsServer_RequestSetProfile
	.public GtsServer_StartRequest
	.public GtsServer_GetErrorResult
	.public Gts_Init
	.public Gts_Main
	.public Gts_Exit
	.public Gts_VBlankCB
	.public Gts_SetGfxBanks
	.public Gts_InitData
	.public Gts_ExitDummy
	.public Gts_SetupWindow0
	.public Gts_InitObjTransfer
	.public Gts_InitSpriteResources
	.public Gts_InitSpriteTemplate
	.public Gts_InitSpriteResourcesHeaders
	.public Gts_CreateYesNoPrompt
	.public Gts_CreateYesNoPromptOnBg
	.public Gts_HandleYesNoPrompt
	.public Gts_CreateListMenu
	.public Gts_ListMenuCallback
	.public Gts_DestroyListMenu
	.public Gts_SetState
	.public Gts_SetSpritePositionRounded
	.public Gts_Alloc
	.public Gts_Free
	.public Gts_GetWifiIconLevel
	.public Gts_SetNextScreen
	.public Gts_SwitchScreen
	.public Gts_GetTextFrameDelay
	.public Gts_InitGraphics
	.public Gts_FreeGraphics
	.public Gts_DecrementTimer
	.public Gts_StartCountingBoxMons
	.public Gts_CountBoxMonsStep
	.public Gts_CreateWaitingIcon
	.public Gts_DeleteWaitingIcon
	.public Gts_SetSpritePosition
	.public Gts_DimScreen
	.public Gts_ClearDim
	.public GtsMainMenu_Init
	.public GtsMainMenu_Main
	.public GtsMainMenu_Exit
	.public GtsMainMenu_InitBgs
	.public Gts_InitSubScreenBgs
	.public Gts_FreeSubScreenBgs
	.public GtsMainMenu_FreeBgs
	.public GtsMainMenu_HideMainScreen
	.public GtsMainMenu_LoadGraphics
	.public GtsMainMenu_CreateCursor
	.public GtsMainMenu_DeleteCursor
	.public GtsMainMenu_CreateWindows
	.public GtsMainMenu_RemoveWindows
	.public GtsMainMenu_CreateStrings
	.public GtsMainMenu_DeleteStrings
	.public GtsMainMenu_WaitEnterAnim
	.public GtsMainMenu_WaitTextBeforeFadeIn
	.public GtsMainMenu_StartFadeIn
	.public GtsMainMenu_WaitFadeIn
	.public GtsMainMenu_WaitFadeIn2
	.public GtsMainMenu_ShowPrompt
	.public GtsMainMenu_GetTouchedButton
	.public GtsMainMenu_SelectButton
	.public GtsMainMenu_HandleInput
	.public GtsMainMenu_StartExitAnim
	.public GtsMainMenu_WaitExitAnim
	.public GtsMainMenu_FadeOut
	.public GtsMainMenu_ShowExitPrompt
	.public GtsMainMenu_HandleExitPrompt
	.public GtsMainMenu_WaitText
	.public GtsMainMenu_WaitTextAndPause
	.public GtsMainMenu_DrawButtons
	.public GtsMainMenu_PrintMessage
	.public GtsMainMenu_PrintPrompt
	.public GtsMainMenu_PrintButtonLabel
	.public Gts_LoadSubScreenBg
	.public Gts_ShowSubScreenPanel
	.public Gts_CreatePanelWindow
	.public GtsSummary_Init
	.public GtsSummary_Main
	.public GtsSummary_Exit
	.public GtsSummary_InitBgs
	.public GtsSummary_FreeBgs
	.public GtsSummary_LoadGraphics
	.public GtsSummary_CreateMonSprite
	.public GtsSummary_DeleteMonSprite
	.public GtsSummary_CreateWindows
	.public GtsSummary_RemoveWindows
	.public GtsSummary_CreateStrings
	.public GtsSummary_DeleteStrings
	.public GtsSummary_Start
	.public GtsSummary_HandleInput
	.public GtsSummary_FadeOut
	.public GtsSummary_ShowTakeBackPrompt
	.public GtsSummary_HandleTakeBackPrompt
	.public GtsSummary_ShowMenu
	.public GtsSummary_HandleMenu
	.public GtsSummary_WaitText
	.public GtsSummary_WaitTextAndPause
	.public GtsSummary_PrintMonMessage
	.public Gts_DrawMonSummary
	.public Gts_DrawTrainerInfo
	.public Gts_LoadMonPicture
	.public GtsSummary_DrawWanted
	.public GtsSearchResult_Init
	.public GtsSearchResult_Main
	.public GtsSearchResult_Exit
	.public GtsSearchResult_InitBgs
	.public GtsSearchResult_FreeBgs
	.public GtsSearchResult_LoadGraphics
	.public GtsSearchResult_CreateMonSprite
	.public GtsSearchResult_DeleteMonSprite
	.public GtsSearchResult_CreateWindows
	.public GtsSearchResult_RemoveWindows
	.public GtsSearchResult_CreateStrings
	.public GtsSearchResult_DeleteStrings
	.public GtsSearchResult_Start
	.public GtsSearchResult_Select
	.public GtsSearchResult_HandleInput
	.public GtsSearchResult_FadeOut
	.public GtsSearchResult_ShowTradePrompt
	.public GtsSearchResult_HandleTradePrompt
	.public GtsSearchResult_DrawDetails
	.public GtsSearchResult_Redraw
	.public GtsSearchResult_ScrollIn
	.public GtsSearchResult_ScrollOut
	.public GtsSearchResult_WaitText
	.public GtsSearchResult_PrintMessage
	.public GtsSearchResult_PrintLabel
	.public GtsSearchResult_PrintButtonLabel
	.public GtsSearchResult_DrawWanted
	.public GtsSearchResult_DrawLocation
	.public GtsSearchResult_ScrollBgs
	.public GtsSearch_Init
	.public GtsSearch_Main
	.public GtsSearch_Exit
	.public GtsSearch_InitBgs
	.public GtsSearch_FreeBgs
	.public GtsSearch_LoadGraphics
	.public GtsSearch_CreateSprites
	.public GtsSearch_DeleteSprites
	.public GtsSearch_CreateWindows
	.public GtsSearch_RemoveWindows
	.public GtsSearch_CreateData
	.public GtsSearch_FreeData
	.public GtsSearch_Start
	.public GtsSearch_GetTouchedButton
	.public GtsSearch_SelectButton
	.public GtsSearch_HandleInput
	.public GtsSearch_StartSearch
	.public GtsSearch_IsDateRecent
	.public GtsSearch_SendSearch
	.public GtsSearch_WaitSearch
	.public GtsSearch_ShowResultCount
	.public GtsSearch_WaitResultsShown
	.public GtsSearch_SearchFailed
	.public GtsSearch_ServerError
	.public GtsSearch_ServerErrorExit
	.public GtsSearch_GetCursorButton
	.public GtsSearch_MoveCursor
	.public GtsSearch_SetCursor
	.public GtsSearch_FadeOut
	.public GtsSearch_AskSpecies
	.public GtsSearch_OpenSpeciesSelector
	.public GtsSearch_HandleSpeciesSelector
	.public GtsSearch_AskGender
	.public GtsSearch_OpenGenderSelector
	.public GtsSearch_HandleGenderSelector
	.public GtsSearch_AskLevel
	.public GtsSearch_OpenLevelSelector
	.public GtsSearch_HandleLevelSelector
	.public GtsSearch_AskCountry
	.public GtsSearch_OpenCountrySelector
	.public GtsSearch_HandleCountrySelector
	.public GtsSearch_ShowExitPrompt
	.public GtsSearch_HandleExitPrompt
	.public GtsSearch_ReturnToInput
	.public GtsSearch_PrintSearchFailed
	.public GtsSearch_WaitText
	.public GtsSearch_WaitTextAndPause
	.public GtsSearch_ScrollOut
	.public GtsSearch_ScrollIn
	.public GtsSearch_HandleScrolledOut
	.public GtsSearch_PrintMessage
	.public GtsSearch_DrawFieldLabels
	.public GtsSearch_DrawResultsButton
	.public GtsSearch_IsSameSearch
	.public GtsSearch_ScrollBgs
	.public GtsSearch_SetBlendBrightness
	.public GtsSelectMon_Init
	.public GtsSelectMon_Main
	.public GtsSelectMon_Exit
	.public GtsSelectMon_InitBgs
	.public GtsSelectMon_FreeBgs
	.public GtsSelectMon_LoadGraphics
	.public GtsSelectMon_CreateSprites
	.public GtsSelectMon_DeleteSprites
	.public GtsSelectMon_CreateWindows
	.public GtsSelectMon_RemoveWindows
	.public GtsSelectMon_CreateData
	.public GtsSelectMon_FreeData
	.public GtsSelectMon_Start
	.public GtsSelectMon_SelectMonToDeposit
	.public GtsSelectMon_SelectMonToTrade
	.public GtsSelectMon_GetTouchedButton
	.public GtsSelectMon_Leave
	.public GtsSelectMon_HandleInput
	.public GtsSelectMon_MoveCursor
	.public GtsSelectMon_SetCursorPosition
	.public GtsSelectMon_StepIndex
	.public GtsSelectMon_OpenDepositMenu
	.public GtsSelectMon_HandleDepositMenu
	.public GtsSelectMon_OpenTradeMenu
	.public GtsSelectMon_HandleTradeMenu
	.public GtsSelectMon_FadeOut
	.public GtsSelectMon_ShowExitPrompt
	.public GtsSelectMon_HandleExitPrompt
	.public GtsSelectMon_AskRemoveCapsuleForTrade
	.public GtsSelectMon_ShowCapsulePromptForTrade
	.public GtsSelectMon_HandleCapsulePromptForTrade
	.public GtsSelectMon_StartTrade
	.public GtsSelectMon_AskRemoveCapsule
	.public GtsSelectMon_ShowCapsulePrompt
	.public GtsSelectMon_HandleCapsulePrompt
	.public GtsSelectMon_WaitText
	.public GtsSelectMon_WaitTextAndClear
	.public GtsSelectMon_PrintMessage
	.public GtsSelectMon_LoadCharData
	.public GtsSelectMon_LoadMonIcon
	.public GtsSelectMon_SetSummaryLevel
	.public GtsSelectMon_TransferMonIcons
	.public GtsSelectMon_ShowSlotMon
	.public GtsSelectMon_ShowBox
	.public Gts_IsPartyBox
	.public Gts_GetBoxMon
	.public GtsSelectMon_CanOffer
	.public GtsSelectMon_HasSpecialRibbon
	.public GtsSelectMon_GetFormRestriction
	.public GtsSelectMon_HoldsGriseousOrb
	.public GtsSelectMon_GetSlotContent
	.public GtsSelectMon_MatchesWanted
	.public GtsSelectMon_BoxMonMatchesWanted
	.public GtsSelectMon_InitTradeRecord
	.public GtsSelectMon_DimUnwantedIcons
	.public Gts_MonHoldsMail
	.public GtsWanted_Init
	.public GtsWanted_Main
	.public GtsWanted_Exit
	.public GtsWanted_PrintMessage
	.public GtsWanted_InitBgs
	.public GtsWanted_FreeBgs
	.public GtsWanted_LoadGraphics
	.public GtsWanted_CreateWindows
	.public GtsWanted_RemoveWindows
	.public GtsWanted_CreateSprites
	.public GtsWanted_DeleteSprites
	.public GtsWanted_CreateData
	.public GtsWanted_FreeData
	.public GtsWanted_Start
	.public GtsWanted_HandleInput
	.public GtsWanted_OpenSpeciesSelector
	.public GtsWanted_InvalidState4
	.public GtsWanted_InvalidState5
	.public Gts_SetFixedGender
	.public GtsWanted_HandleSpeciesSelector
	.public GtsWanted_AskGender
	.public GtsWanted_OpenGenderSelector
	.public GtsWanted_HandleGenderSelector
	.public GtsWanted_AskLevel
	.public GtsWanted_OpenLevelSelector
	.public GtsWanted_HandleLevelSelector
	.public GtsWanted_AskConfirm
	.public GtsWanted_ShowConfirmPrompt
	.public GtsWanted_HandleConfirmPrompt
	.public GtsWanted_FadeOut
	.public GtsWanted_WaitText
	.public Gts_PrintSpeciesName
	.public Gts_PrintSpeciesNameNoTransfer
	.public Gts_PrintCountryName
	.public Gts_GetGenderColor
	.public Gts_PrintGender
	.public Gts_PrintGenderNoTransfer
	.public Gts_PrintLevelRange
	.public Gts_PrintLevelRangeAt
	.public Gts_DrawWantedMon
	.public Gts_DrawWantedMonLevelLeft
	.public GtsWanted_DrawOfferedMon
	.public Gts_LoadAlphabeticalSpecies
	.public Gts_LoadSpeciesByLetter
	.public Gts_CreateJohtoDexFlags
	.public Gts_InitRecord
	.public GtsWanted_InitDepositRecord
	.public Gts_CreateLevelRangeListItems
	.public Gts_SetLevelRange
	.public Gts_FindLevelRange
	.public Gts_SetSearchCountry
	.public Gts_GetCountryGroupRange
	.public Gts_CreateCountryListItems
	.public GtsUnk1234_Clear
	.public GtsUnk1234_SetEntry
	.public GtsTransaction_Init
	.public GtsTransaction_Main
	.public GtsTransaction_Exit
	.public GtsTransaction_InitBgs
	.public GtsTransaction_FreeBgs
	.public GtsTransaction_LoadGraphics
	.public GtsTransaction_CreateWindows
	.public GtsTransaction_RemoveWindows
	.public GtsTransaction_CreateStrings
	.public GtsTransaction_DeleteStrings
	.public GtsTransaction_Start
	.public GtsTransaction_SendPost
	.public GtsTransaction_WaitPost
	.public GtsTransaction_SendPostFinish
	.public GtsTransaction_WaitPostFinish
	.public GtsTransaction_SendGet
	.public GtsTransaction_WaitGet
	.public GtsTransaction_SendReturn
	.public GtsTransaction_WaitReturn
	.public GtsTransaction_SendExchange
	.public GtsTransaction_WaitExchange
	.public GtsTransaction_SendExchangeFinish
	.public GtsTransaction_WaitExchangeFinish
	.public GtsTransaction_SendResult
	.public GtsTransaction_WaitResult
	.public GtsTransaction_ExitToMainMenu
	.public GtsTransaction_SendStatusGet
	.public GtsTransaction_WaitStatusGet
	.public GtsTransaction_ReturnToCaller
	.public GtsTransaction_RecordTradeStats
	.public GtsTransaction_ReceiveTradedMon
	.public GtsTransaction_SendDelete
	.public GtsTransaction_WaitDelete
	.public GtsTransaction_Idle
	.public GtsTransaction_DepositDone
	.public GtsTransaction_ReceiveDone
	.public GtsTransaction_ExchangeDone
	.public GtsTransaction_TradedDone
	.public GtsTransaction_SendUnsavedReturn
	.public GtsTransaction_WaitUnsavedReturn
	.public GtsTransaction_AlreadyTraded
	.public GtsTransaction_PrintServerError
	.public GtsTransaction_ServerErrorExit
	.public GtsTransaction_ServerError
	.public GtsTransaction_SaveAndExit
	.public GtsTransaction_StartSave
	.public GtsTransaction_WaitSaveDelay
	.public GtsTransaction_SaveFirstPart
	.public GtsTransaction_SaveRest
	.public GtsTransaction_StartSaveWithMessage
	.public GtsTransaction_SaveWithMessage
	.public GtsTransaction_FadeOut
	.public GtsTransaction_WaitText
	.public GtsTransaction_StoreSelectedMon
	.public GtsTransaction_ReceiveMon
	.public GtsTransaction_ReceiveExchangedMon
	.public GtsTransaction_SaveTradeDate
	.public GtsTransaction_AddPartnerToWifiHistory
	.public GtsTransaction_CheckCanReceive
	.public GtsTransaction_SetSaveStates
	.public GtsTransaction_IsDepositMissingFromSave
	.public Gts_CreateAvatars
	.public Gts_StartPlayerEnterAnim
	.public Gts_SetPlayerAnim
	.public Gts_PlayerEnterTask
	.public Gts_StartPlayerExitAnim
	.public Gts_PlayerExitTask
	.public Gts_SetAvatarPosition
	.public Gts_GetTouchedAvatar
	.public Gts_ShowResultAvatars
	.public Gts_GetAvatarAnimSeq
	.public Gts_StopAvatarAnims
	.public Gts_LoadAvatarGraphics
	.public Gts_LoadAvatar
	.public Gts_FreeAvatarGraphics
	.public Gts_SetAvatarMarker
	.public Gts_ResetAvatarPositions
	.public Gts_LowerAvatars
	.public GtsViewMon_Init
	.public GtsViewMon_Main
	.public GtsViewMon_Exit
	.public GtsTrade_Init
	.public GtsTrade_Main
	.public GtsTrade_Exit
	.public GtsTrade_CreatePartnerProfile
	.public GtsTrade_GetReceivedMon
	.public GtsTrade_StoreReceivedMon
	.public GtsSelector_AddWindows
	.public GtsSelector_RemoveWindows
	.public GtsSelector_New
	.public GtsSelector_Start
	.public GtsSelector_Delete
	.public GtsSelector_Main
	.public GtsSelector_GetTouchedButton
	.public GtsSelector_HandleGroupInput
	.public GtsSelector_GetLetter
	.public GtsSelector_HandleLetterInput
	.public GtsSelector_CountPages
	.public GtsSelector_SelectSpeciesButton
	.public GtsSelector_ChangeSpeciesPage
	.public GtsSelector_HandleSpeciesListInput
	.public GtsSelector_HandleGenderInput
	.public GtsSelector_ChangeLevelPage
	.public GtsSelector_SelectLevelButton
	.public GtsSelector_HandleLevelInput
	.public GtsSelector_GetCountryGroup
	.public GtsSelector_HandleCountryGroupInput
	.public GtsSelector_SelectCountryButton
	.public GtsSelector_ChangeCountryPage
	.public GtsSelector_HandleCountryListInput
	.public GtsSelector_ShowGroups
	.public GtsSelector_ShowGenders
	.public GtsSelector_ShowLevels
	.public GtsSelector_PrintString
	.public GtsSelector_Idle
	.public GtsSelector_WaitShow
	.public GtsSelector_WaitMove
	.public GtsSelector_WaitHide
	.public GtsSelector_OpenSpeciesGroups
	.public GtsSelector_HandleSpeciesGroups
	.public GtsSelector_CloseSpeciesGroups
	.public GtsSelector_ReopenSpeciesGroups
	.public GtsSelector_OpenSpeciesLetters
	.public GtsSelector_HandleSpeciesLetters
	.public GtsSelector_CloseSpeciesLetters
	.public GtsSelector_BackToSpeciesLetters
	.public GtsSelector_CountSeenSpecies
	.public GtsSelector_CreateSpeciesListItems
	.public GtsSelector_PrintListPage
	.public GtsSelector_PrintCountryPage
	.public GtsSelector_OpenSpeciesList
	.public GtsSelector_HandleSpeciesList
	.public GtsSelector_CancelSpeciesList
	.public GtsSelector_FinishSpecies
	.public GtsSelector_OpenCountryGroups
	.public GtsSelector_HandleCountryGroups
	.public GtsSelector_CloseCountryGroups
	.public GtsSelector_ReopenCountryGroups
	.public GtsSelector_OpenCountryLetters
	.public GtsSelector_HandleCountryLetters
	.public GtsSelector_CloseCountryLetters
	.public GtsSelector_BackToCountryLetters
	.public GtsSelector_OpenCountryList
	.public GtsSelector_HandleCountryList
	.public GtsSelector_CancelCountryList
	.public GtsSelector_FinishCountry
	.public GtsSelector_OpenGenders
	.public GtsSelector_HandleGenders
	.public GtsSelector_FinishGender
	.public GtsSelector_OpenLevels
	.public GtsSelector_HandleLevels
	.public GtsSelector_FinishLevel
	.public GtsSelector_PrintMessage
	.public GtsSelector_PrintButtonLabel
	.public GtsSelector_PrintPageNumber
	.public GtsSelector_CountSeenSpeciesOfLetter
	.public GtsSelector_GroupHasSeenSpecies
	.public GtsSelector_CountCountriesOfLetter
	.public GtsSelector_HasCountriesInGroup
	.public GtsConnection_Init
	.public GtsConnection_Main
	.public GtsConnection_Exit
	.public GtsConnection_InitBgs
	.public GtsConnection_FreeBgs
	.public GtsConnection_LoadGraphics
	.public GtsConnection_AnimatePaletteTask
	.public GtsConnection_CreateWindows
	.public GtsConnection_RemoveWindows
	.public GtsConnection_CreateStrings
	.public GtsConnection_DeleteStrings
	.public GtsConnection_AskConnect
	.public GtsConnection_HandleConnectPrompt
	.public GtsConnection_AskDisconnect
	.public GtsConnection_HandleDisconnectMenu
	.public GtsConnection_PrintDisconnecting
	.public GtsConnection_Disconnect
	.public GtsConnection_PrintDisconnected
	.public GtsConnection_StartConnect
	.public GtsConnection_WaitConnect
	.public GtsConnection_StartAuth
	.public GtsConnection_WaitAuth
	.public GtsConnection_InitServer
	.public GtsConnection_SendInfo
	.public GtsConnection_WaitInfo
	.public GtsConnection_SendSetProfile
	.public GtsConnection_WaitSetProfile
	.public GtsConnection_ShowConnectionError
	.public GtsConnection_WaitCloseError
	.public GtsConnection_FadeOut
	.public GtsConnection_HandleExitPrompt
	.public GtsConnection_PrintServerError
	.public GtsConnection_DisconnectAfterError
	.public GtsConnection_WaitText
	.public GtsConnection_WaitTextAndDelay
	.public GtsConnection_WaitTextAndShowYesNo
	.public Gts_PrintMessage
	.public Gts_GetAlignedX
	.public Gts_PrintAlignedFont1
	.public Gts_PrintAlignedFont0
	.public Gts_PrintAlignedFont4
	.public Gts_PrintPanelCaption
	.public Gts_CreateWirelessStatusIcon
	.public GtsConnection_PrintError
	.public GtsConnection_PrintErrorCode
	.public sGtsGraphicsModes
	.public sGtsObjCharTransferTemplate
	.public sGtsGraphicsBanks
	.public sGtsMainMenuCursorX
	.public sGtsMainMenuCursorY
	.public sGtsMainMenuButtonHitboxes
	.public sGtsMainMenuGraphicsModes
	.public sGtsMainMenuButtonMsgs
	.public sGtsSubBg2Template
	.public sGtsSubBg0Template
	.public sGtsSubBg1Template
	.public sGtsMainMenuBg1Template
	.public sGtsMainMenuBg0Template
	.public sGtsMainMenuBg2Template
	.public sGtsSubBg3Template
	.public sGtsSummaryBg3Template
	.public sGtsSummaryBg2Template
	.public sGtsSummaryBg1Template
	.public sGtsSummaryBg0Template
	.public sGtsSummaryInfoWindowRects
	.public sGtsSearchResultButtonHitboxes
	.public sGtsSearchResultLeft
	.public sGtsSearchResultRight
	.public sGtsSearchResultBg1Template
	.public sGtsSearchResultBg0Template
	.public sGtsSearchResultInfoWindows
	.public sGtsSearchLineWindowPositions
	.public sGtsSearchValueWindowPositions
	.public sGtsSearchFieldWindowPositions
	.public sGtsSearchBg3Template
	.public sGtsSearchBg2Template
	.public sGtsSearchBg0Template
	.public sGtsSearchBg1Template
	.public sGtsSearchButtonHitboxes
	.public sGtsSelectMonArrowPositions
	.public sGtsSelectMonGraphicsModes
	.public sGtsSpecialRibbons
	.public sGtsSelectMonBg3Template
	.public sGtsSelectMonBg1Template
	.public sGtsSelectMonBg2Template
	.public sGtsSelectMonBg0Template
	.public sGtsSelectMonCursorPositions
	.public sGtsSelectMonCursorY
	.public sGtsSelectMonCursorMoves
	.public sGtsSelectMonHitboxes
	.public gGtsCountryCount
	.public sGtsGenderSymbolMsgs
	.public sGtsWantedWindowPositions
	.public sGtsWantedBg3Template
	.public sGtsWantedBg2Template
	.public sGtsWantedBg0Template
	.public sGtsWantedBg1Template
	.public sGtsCountryGroups
	.public sGtsSearchLevelRanges
	.public sGtsWantedLevelRanges
	.public sGtsSpeciesLetterFiles
	.public sGtsCountries
	.public sGtsTransactionGraphicsModes
	.public sGtsTransactionSubBg1Template
	.public sGtsTransactionBg1Template
	.public sGtsTransactionBg0Template
	.public sGtsTransactionSubBg0Template
	.public sGtsTransactionBg2Template
	.public sGtsAvatarCharOffsets
	.public sGtsAvatarPositions
	.public sGtsAvatarY
	.public sGtsAvatarHitboxes
	.public sGtsViewMonSummaryPages
	.public sGtsTradeSequenceTemplate
	.public sGtsSelectorGenderWindowPositions
	.public sGtsSelectorGenderCursorX
	.public sGtsSelectorGenderCursorY
	.public sGtsSelectorLevelWindowPositions
	.public sGtsSelectorSpeciesCursorX
	.public sGtsSelectorSpeciesCursorY
	.public sGtsSelectorLevelCursorX
	.public sGtsSelectorLevelCursorY
	.public sGtsSelectorCountryCursorX
	.public sGtsSelectorCountryCursorY
	.public sGtsSelectorCountryWindowPositions
	.public sGtsSelectorSpeciesWindowPositions
	.public sGtsSelectorGenders
	.public sGtsSelectorLetterNextUp
	.public sGtsSelectorLetterNextDown
	.public sGtsSelectorLetterNextLeft
	.public sGtsSelectorLetterNextRight
	.public sGtsSelectorGenderHitboxes
	.public sGtsSelectorLetterHitboxes
	.public sGtsSelectorCountryGroupCursorX
	.public sGtsSelectorCountryGroupCursorY
	.public sGtsSelectorGridWindowPositions
	.public ov70_02245E10
	.public sGtsSelectorGroupCursorX
	.public sGtsSelectorGroupCursorY
	.public sGtsSelectorListHitboxes
	.public sGtsSelectorCountryListHitboxes
	.public gGtsSelectorGroupStarts
	.public sGtsSelectorGroupNext
	.public ov70_02245EA9
	.public ov70_02245EAA
	.public ov70_02245EAB
	.public sGtsSelectorGroupHitboxes
	.public sGtsSelectorCountryGroupNextUp
	.public sGtsSelectorCountryGroupNextDown
	.public sGtsSelectorCountryGroupNextLeft
	.public sGtsSelectorCountryGroupNextRight
	.public sGtsSelectorCountryGroupHitboxes
	.public gGtsSelectorLetterGroups
	.public ov70_02245F5C
	.public sGtsSelectorLetterMsgs
	.public sGtsPanelCaptionMsgIds
	.public sGtsConnectionSubBg0Template
	.public sGtsConnectionBg1Template
	.public sGtsConnectionBg0Template
	.public sGtsConnectionSubBg1Template
	.public sGtsPostUrl
	.public sGtsPostFinishUrl
	.public sGtsGetUrl
	.public sGtsResultUrl
	.public sGtsDeleteUrl
	.public sGtsReturnUrl
	.public sGtsSearchUrl
	.public sGtsExchangeUrl
	.public sGtsExchangeFinishUrl
	.public sGtsInfoUrl
	.public sGtsSetProfileUrl
	.public sGtsScreens
	.public sGtsMainMenuStates
	.public sGtsGenderSymbolColors
	.public sGtsSummaryStates
	.public sGtsSearchResultStates
	.public sGtsSearchButtonColumns
	.public sGtsSearchButtonRows
	.public sGtsSearchCursorX
	.public sGtsSearchCursorY
	.public sGtsSearchCursorAnims
	.public sGtsSearchStates
	.public sGtsSelectMonStates
	.public sGtsGenderColors
	.public sGtsWantedStates
	.public sGtsTransactionStates
	.public sGtsSelectorStates
	.public sGtsConnectionStates
	.public gGtsServerFriendKey
	.public gGtsServerRequest
	.public ov70_02246900
	.public ov70_02246920
	.public gGtsServerShortResponse
	.public gGtsGlobals
	.include "overlay_70.inc"
	.include "global.inc"

	.text
	.public GtsServer_Exit
	.public GtsServer_GetResult
	.public Gts_ExitDummy
	.public Gts_DestroyListMenu
	.public Gts_SetState
	.public Gts_GetWifiIconLevel
	.public Gts_SetNextScreen
	.public Gts_SwitchScreen
	.public Gts_GetTextFrameDelay
	.public Gts_DecrementTimer
	.public Gts_StartCountingBoxMons
	.public Gts_ClearDim
	.public Gts_FreeSubScreenBgs
	.public GtsMainMenu_FreeBgs
	.public GtsMainMenu_DeleteCursor
	.public GtsMainMenu_DeleteStrings
	.public GtsMainMenu_WaitTextBeforeFadeIn
	.public GtsMainMenu_WaitFadeIn
	.public GtsMainMenu_WaitFadeIn2
	.public GtsMainMenu_StartExitAnim
	.public GtsMainMenu_WaitExitAnim
	.public GtsSummary_DeleteMonSprite
	.public GtsSummary_Start
	.public GtsSearchResult_FreeBgs
	.public GtsSearchResult_DeleteMonSprite
	.public GtsSearch_ReturnToInput
	.public GtsSelectMon_StepIndex
	.public GtsSelectMon_SetSummaryLevel
	.public Gts_IsPartyBox
	.public GtsSelectMon_CanOffer
	.public Gts_MonHoldsMail
	.public GtsWanted_DeleteSprites
	.public GtsWanted_InvalidState4
	.public GtsWanted_InvalidState5
	.public GtsUnk1234_Clear
	.public GtsUnk1234_SetEntry
	.public GtsTransaction_Idle
	.public GtsTransaction_SaveAndExit
	.public GtsTransaction_WaitSaveDelay
	.public GtsTransaction_SaveRest
	.public GtsTransaction_StartSaveWithMessage
	.public GtsTransaction_SetSaveStates
	.public GtsTransaction_IsDepositMissingFromSave
	.public Gts_GetAvatarAnimSeq
	.public GtsViewMon_Exit
	.public GtsSelector_CountPages
	.public GtsSelector_GetCountryGroup
	.public GtsSelector_Idle
	.public GtsSelector_WaitMove
	.public GtsSelector_WaitHide
	.public GtsSelector_CloseSpeciesLetters
	.public GtsSelector_BackToSpeciesLetters
	.public GtsSelector_BackToCountryLetters
	.public GtsConnection_FreeBgs
	.public GtsConnection_DeleteStrings
	.public GtsConnection_Disconnect
	.public GtsConnection_StartAuth
	.public Gts_CreateWirelessStatusIcon
	.public GtsConnection_PrintError
	.public GtsConnection_PrintErrorCode
	.rodata

sGtsListMenuTemplate:
	.byte 0x02, 0x00, 0x00, 0x0A
	.byte 0x00, 0x00, 0x80, 0x01, 0xBC, 0x01, 0x3C, 0x00

sGtsGraphicsModes: ; 0x022451F8
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsObjCharTransferTemplate: ; 0x02245208
	.byte 0x14, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x3D, 0x00, 0x00, 0x00

sGtsGraphicsBanks: ; 0x02245218
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x60, 0x00, 0x00, 0x00

sGtsMainMenuCursorX: ; 0x02245240
	.byte 0x80, 0x00

sGtsMainMenuCursorY: ; 0x02245242
	.byte 0x38, 0x00, 0x80, 0x00, 0x60, 0x00, 0x80, 0x00, 0x88, 0x00

sGtsMainMenuButtonHitboxes: ; 0x0224524C
	.byte 0x28, 0x47, 0x18, 0xE7
	.byte 0x50, 0x6F, 0x18, 0xE7, 0x78, 0x97, 0x18, 0xE7, 0xFF, 0x00, 0x00, 0x00

sGtsMainMenuGraphicsModes: ; 0x0224525C
	.byte 0x01, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsMainMenuButtonMsgs: ; 0x0224526C
	.byte 0x29, 0x00, 0x00, 0x00
	.byte 0x2A, 0x00, 0x00, 0x00, 0x2B, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 0x2A, 0x00, 0x00, 0x00
	.byte 0x2B, 0x00, 0x00, 0x00

sGtsSubBg2Template: ; 0x02245284
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x05, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSubBg0Template: ; 0x022452A0
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1E, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSubBg1Template: ; 0x022452BC
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x1C, 0x00
	.byte 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsMainMenuBg1Template: ; 0x022452D8
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x02, 0x00, 0x01, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sGtsMainMenuBg0Template: ; 0x022452F4
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsMainMenuBg2Template: ; 0x02245310
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1D, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSubBg3Template: ; 0x0224532C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1B, 0x04
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSummaryBg3Template: ; 0x02245348
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1C, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sGtsSummaryBg2Template: ; 0x02245364
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1D, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSummaryBg1Template: ; 0x02245380
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1E, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSummaryBg0Template: ; 0x0224539C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSummaryInfoWindowRects: ; 0x022453B8
	.byte 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x09, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00
	.byte 0x06, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00
	.byte 0x0B, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00
	.byte 0x06, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00
	.byte 0x09, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00
	.byte 0x0C, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00
	.byte 0x0A, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00
	.byte 0x0C, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00
	.byte 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00

sGtsSearchResultButtonHitboxes: ; 0x02245498
	.byte 0xA2, 0xBF, 0x03, 0x7D, 0xA2, 0xBF, 0x82, 0xFD
	.byte 0xFF, 0x00, 0x00, 0x00

sGtsSearchResultLeft: ; 0x022454A4
	.byte 0x01

sGtsSearchResultRight: ; 0x022454A5
	.byte 0x02, 0x03, 0x00, 0x00, 0x04, 0x05, 0x01, 0x02, 0x06, 0x05, 0x03
	.byte 0x04, 0x06, 0x00, 0x00

sGtsSearchResultBg1Template: ; 0x022454B4
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSearchResultBg0Template: ; 0x022454D0
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSearchResultInfoWindows: ; 0x022454EC
	.byte 0x01, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0E, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x07, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x0A, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00
	.byte 0x09, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x00, 0x00
	.byte 0x0D, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x0D, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00, 0x1B, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00
	.byte 0x1B, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
	.byte 0x07, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x08, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00
	.byte 0x02, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x1B, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00

sGtsSearchLineWindowPositions: ; 0x0224562C
	.byte 0x01, 0x00, 0x10, 0x00
	.byte 0x02, 0x00, 0x12, 0x00

sGtsSearchValueWindowPositions: ; 0x02245634
	.byte 0x16, 0x00, 0x08, 0x00, 0x16, 0x00, 0x0D, 0x00, 0x16, 0x00, 0x03, 0x00

sGtsSearchFieldWindowPositions: ; 0x02245640
	.byte 0x01, 0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00, 0x01, 0x00, 0x06, 0x00, 0x02, 0x00, 0x08, 0x00
	.byte 0x01, 0x00, 0x0B, 0x00, 0x02, 0x00, 0x0D, 0x00

sGtsSearchBg3Template: ; 0x02245658
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x03, 0x07, 0x00, 0x02, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sGtsSearchBg2Template: ; 0x02245674
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x02, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSearchBg0Template: ; 0x02245690
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSearchBg1Template: ; 0x022456AC
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x03
	.byte 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSearchButtonHitboxes: ; 0x022456C8
	.byte 0x03, 0x29, 0x02, 0x63, 0x2B, 0x51, 0x02, 0x63
	.byte 0x53, 0x79, 0x02, 0x63, 0x7B, 0xA1, 0x02, 0x63, 0x13, 0x2D, 0x91, 0xFF, 0x3A, 0x55, 0x91, 0xFF
	.byte 0x62, 0x7D, 0x91, 0xFF, 0xFF, 0x00, 0x00, 0x00

sGtsSelectMonArrowPositions: ; 0x022456E8
	.byte 0x9A, 0x00, 0x0C, 0x00, 0x0E, 0x00, 0x0C, 0x00

sGtsSelectMonGraphicsModes: ; 0x022456F0
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSpecialRibbons: ; 0x02245700
	.byte 0x67, 0x00, 0x68, 0x00, 0x69, 0x00, 0x2E, 0x00, 0x2F, 0x00, 0x30, 0x00, 0x31, 0x00, 0x32, 0x00
	.byte 0x33, 0x00, 0x34, 0x00

sGtsSelectMonBg3Template: ; 0x02245714
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSelectMonBg1Template: ; 0x02245730
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1E, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSelectMonBg2Template: ; 0x0224574C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1D, 0x02
	.byte 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsSelectMonBg0Template: ; 0x02245768
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sGtsSelectMonCursorPositions: ; 0x02245784
	.byte 0x13, 0x00

sGtsSelectMonCursorY: ; 0x02245786
	.byte 0x24, 0x00, 0x2D, 0x00, 0x24, 0x00, 0x47, 0x00, 0x24, 0x00
	.byte 0x61, 0x00, 0x24, 0x00, 0x7B, 0x00, 0x24, 0x00, 0x95, 0x00, 0x24, 0x00, 0x13, 0x00, 0x3B, 0x00
	.byte 0x2D, 0x00, 0x3B, 0x00, 0x47, 0x00, 0x3B, 0x00, 0x61, 0x00, 0x3B, 0x00, 0x7B, 0x00, 0x3B, 0x00
	.byte 0x95, 0x00, 0x3B, 0x00, 0x13, 0x00, 0x52, 0x00, 0x2D, 0x00, 0x52, 0x00, 0x47, 0x00, 0x52, 0x00
	.byte 0x61, 0x00, 0x52, 0x00, 0x7B, 0x00, 0x52, 0x00, 0x95, 0x00, 0x52, 0x00, 0x13, 0x00, 0x69, 0x00
	.byte 0x2D, 0x00, 0x69, 0x00, 0x47, 0x00, 0x69, 0x00, 0x61, 0x00, 0x69, 0x00, 0x7B, 0x00, 0x69, 0x00
	.byte 0x95, 0x00, 0x69, 0x00, 0x13, 0x00, 0x80, 0x00, 0x2D, 0x00, 0x80, 0x00, 0x47, 0x00, 0x80, 0x00
	.byte 0x61, 0x00, 0x80, 0x00, 0x7B, 0x00, 0x80, 0x00, 0x95, 0x00, 0x80, 0x00, 0xE0, 0x00, 0x87, 0x00
	.byte 0x52, 0x00, 0x10, 0x00

sGtsSelectMonCursorMoves: ; 0x02245804
	.byte 0x1F, 0x06, 0x05, 0x01, 0x1F, 0x07, 0x00, 0x02, 0x1F, 0x08, 0x01, 0x03
	.byte 0x1F, 0x09, 0x02, 0x04, 0x1F, 0x0A, 0x03, 0x05, 0x1F, 0x0B, 0x04, 0x00, 0x00, 0x0C, 0x0B, 0x07
	.byte 0x01, 0x0D, 0x06, 0x08, 0x02, 0x0E, 0x07, 0x09, 0x03, 0x0F, 0x08, 0x0A, 0x04, 0x10, 0x09, 0x0B
	.byte 0x05, 0x11, 0x0A, 0x06, 0x06, 0x12, 0x11, 0x0D, 0x07, 0x13, 0x0C, 0x0E, 0x08, 0x14, 0x0D, 0x0F
	.byte 0x09, 0x15, 0x0E, 0x10, 0x0A, 0x16, 0x0F, 0x11, 0x0B, 0x17, 0x10, 0x0C, 0x0C, 0x18, 0x17, 0x13
	.byte 0x0D, 0x19, 0x12, 0x14, 0x0E, 0x1A, 0x13, 0x15, 0x0F, 0x1B, 0x14, 0x16, 0x10, 0x1C, 0x15, 0x17
	.byte 0x11, 0x1D, 0x16, 0x12, 0x12, 0x1F, 0x1E, 0x19, 0x13, 0x1F, 0x18, 0x1A, 0x14, 0x1F, 0x19, 0x1B
	.byte 0x15, 0x1F, 0x1A, 0x1C, 0x16, 0x1F, 0x1B, 0x1D, 0x17, 0x1F, 0x1C, 0x1E, 0x1E, 0x1E, 0x1D, 0x18
	.byte 0x1A, 0x02, 0x63, 0x65

sGtsSelectMonHitboxes: ; 0x02245884
	.byte 0x17, 0x31, 0x08, 0x1E, 0x17, 0x31, 0x22, 0x38, 0x17, 0x31, 0x3C, 0x52
	.byte 0x17, 0x31, 0x56, 0x6C, 0x17, 0x31, 0x70, 0x86, 0x17, 0x31, 0x8A, 0xA0, 0x2E, 0x48, 0x08, 0x1E
	.byte 0x2E, 0x48, 0x22, 0x38, 0x2E, 0x48, 0x3C, 0x52, 0x2E, 0x48, 0x56, 0x6C, 0x2E, 0x48, 0x70, 0x86
	.byte 0x2E, 0x48, 0x8A, 0xA0, 0x45, 0x5F, 0x08, 0x1E, 0x45, 0x5F, 0x22, 0x38, 0x45, 0x5F, 0x3C, 0x52
	.byte 0x45, 0x5F, 0x56, 0x6C, 0x45, 0x5F, 0x70, 0x86, 0x45, 0x5F, 0x8A, 0xA0, 0x5C, 0x76, 0x08, 0x1E
	.byte 0x5C, 0x76, 0x22, 0x38, 0x5C, 0x76, 0x3C, 0x52, 0x5C, 0x76, 0x56, 0x6C, 0x5C, 0x76, 0x70, 0x86
	.byte 0x5C, 0x76, 0x8A, 0xA0, 0x73, 0x8D, 0x08, 0x1E, 0x73, 0x8D, 0x22, 0x38, 0x73, 0x8D, 0x3C, 0x52
	.byte 0x73, 0x8D, 0x56, 0x6C, 0x73, 0x8D, 0x70, 0x86, 0x73, 0x8D, 0x8A, 0xA0, 0x7B, 0x94, 0xBA, 0xF5
	.byte 0x04, 0x1C, 0x92, 0xA2, 0x04, 0x1C, 0x02, 0x12, 0xFF, 0x00, 0x00, 0x00

gGtsCountryCount: ; 0x0224590C
	.byte 0x82, 0x00, 0x00, 0x00

sGtsGenderSymbolMsgs: ; 0x02245910
	.byte 0x7C, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x7C, 0x00, 0x00, 0x00

sGtsWantedWindowPositions: ; 0x02245920
	.byte 0x02, 0x00, 0x03, 0x00, 0x03, 0x00, 0x05, 0x00, 0x03, 0x00, 0x07, 0x00, 0x02, 0x00, 0x0B, 0x00
	.byte 0x03, 0x00, 0x0D, 0x00, 0x03, 0x00, 0x0F, 0x00

sGtsWantedBg3Template: ; 0x02245938
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1C, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sGtsWantedBg2Template: ; 0x02245954
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1D, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsWantedBg0Template: ; 0x02245970
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsWantedBg1Template: ; 0x0224598C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x02
	.byte 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0A, 0x00, 0x06, 0x00, 0x04, 0x08, 0x00, 0x12
	.byte 0x2F, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsCountryGroups: ; 0x022459C8
	.byte 0x00, 0x00, 0x08, 0x01, 0x16, 0x02, 0x23, 0x03
	.byte 0x26, 0x04, 0x29, 0x05, 0x2D, 0x06, 0x38, 0x07, 0x3C, 0x08, 0x43, 0x09, 0x46, 0x0A, 0x48, 0x0B
	.byte 0x4C, 0x0C, 0x54, 0x0D, 0x5B, 0x0E, 0x5C, 0x0F, 0x63, 0x11, 0x66, 0x12, 0x73, 0x13, 0x78, 0x14
	.byte 0x7F, 0x15, 0x82, 0xFF

sGtsSearchLevelRanges: ; 0x022459F4
	.byte 0x9F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xA0, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x0A, 0x00, 0xA1, 0x00, 0x00, 0x00, 0x0B, 0x00, 0x14, 0x00, 0xA2, 0x00, 0x00, 0x00
	.byte 0x15, 0x00, 0x1E, 0x00, 0xA3, 0x00, 0x00, 0x00, 0x1F, 0x00, 0x28, 0x00, 0xA4, 0x00, 0x00, 0x00
	.byte 0x29, 0x00, 0x32, 0x00, 0xA5, 0x00, 0x00, 0x00, 0x33, 0x00, 0x3C, 0x00, 0xA6, 0x00, 0x00, 0x00
	.byte 0x3D, 0x00, 0x46, 0x00, 0xA7, 0x00, 0x00, 0x00, 0x47, 0x00, 0x50, 0x00, 0xA8, 0x00, 0x00, 0x00
	.byte 0x51, 0x00, 0x5A, 0x00, 0xA9, 0x00, 0x00, 0x00, 0x5B, 0x00, 0x64, 0x00

sGtsWantedLevelRanges: ; 0x02245A4C
	.byte 0x80, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x81, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x82, 0x00, 0x00, 0x00
	.byte 0x0A, 0x00, 0x00, 0x00, 0x83, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x84, 0x00, 0x00, 0x00
	.byte 0x1E, 0x00, 0x00, 0x00, 0x85, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 0x86, 0x00, 0x00, 0x00
	.byte 0x32, 0x00, 0x00, 0x00, 0x87, 0x00, 0x00, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x88, 0x00, 0x00, 0x00
	.byte 0x46, 0x00, 0x00, 0x00, 0x89, 0x00, 0x00, 0x00, 0x50, 0x00, 0x00, 0x00, 0x8A, 0x00, 0x00, 0x00
	.byte 0x5A, 0x00, 0x00, 0x00, 0x8B, 0x00, 0x00, 0x00, 0x64, 0x00, 0x64, 0x00

sGtsSpeciesLetterFiles: ; 0x02245AAC
	.byte 0x12, 0x00, 0x00, 0x00
	.byte 0x13, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x00, 0x15, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00
	.byte 0x17, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x19, 0x00, 0x00, 0x00, 0x1A, 0x00, 0x00, 0x00
	.byte 0x1B, 0x00, 0x00, 0x00, 0x1C, 0x00, 0x00, 0x00, 0x1D, 0x00, 0x00, 0x00, 0x1E, 0x00, 0x00, 0x00
	.byte 0x1F, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x21, 0x00, 0x00, 0x00, 0x22, 0x00, 0x00, 0x00
	.byte 0x23, 0x00, 0x00, 0x00, 0x24, 0x00, 0x00, 0x00, 0x25, 0x00, 0x00, 0x00, 0x26, 0x00, 0x00, 0x00
	.byte 0x27, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 0x29, 0x00, 0x00, 0x00, 0x2A, 0x00, 0x00, 0x00
	.byte 0x2B, 0x00, 0x00, 0x00, 0x2C, 0x00, 0x00, 0x00, 0x2D, 0x00, 0x00, 0x00, 0x2E, 0x00, 0x00, 0x00
	.byte 0x2F, 0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x31, 0x00, 0x00, 0x00, 0x32, 0x00, 0x00, 0x00
	.byte 0x33, 0x00, 0x00, 0x00, 0x34, 0x00, 0x00, 0x00, 0x35, 0x00, 0x00, 0x00, 0x36, 0x00, 0x00, 0x00
	.byte 0x37, 0x00, 0x00, 0x00, 0x38, 0x00, 0x00, 0x00, 0x39, 0x00, 0x00, 0x00, 0x3A, 0x00, 0x00, 0x00
	.byte 0x3B, 0x00, 0x00, 0x00, 0x3C, 0x00, 0x00, 0x00, 0x3D, 0x00, 0x00, 0x00

sGtsCountries: ; 0x02245B5C
	.byte 0x01, 0x00, 0x02, 0x00
	.byte 0x03, 0x00, 0x06, 0x00, 0x08, 0x00, 0x09, 0x00, 0x0C, 0x00, 0x0D, 0x00, 0x0F, 0x00, 0x10, 0x00
	.byte 0x11, 0x00, 0x12, 0x00, 0x14, 0x00, 0x15, 0x00, 0x16, 0x00, 0x17, 0x00, 0x19, 0x00, 0x1B, 0x00
	.byte 0x1C, 0x00, 0x1D, 0x00, 0x1F, 0x00, 0x21, 0x00, 0x22, 0x00, 0x23, 0x00, 0x24, 0x00, 0x28, 0x00
	.byte 0x2A, 0x00, 0x2B, 0x00, 0x2D, 0x00, 0x30, 0x00, 0x31, 0x00, 0x32, 0x00, 0x34, 0x00, 0x36, 0x00
	.byte 0x37, 0x00, 0x38, 0x00, 0x3A, 0x00, 0x3B, 0x00, 0x3C, 0x00, 0x3D, 0x00, 0x3E, 0x00, 0x45, 0x00
	.byte 0x46, 0x00, 0x47, 0x00, 0x48, 0x00, 0x4A, 0x00, 0x4D, 0x00, 0x4E, 0x00, 0x4F, 0x00, 0x50, 0x00
	.byte 0x51, 0x00, 0x52, 0x00, 0x53, 0x00, 0x55, 0x00, 0x56, 0x00, 0x58, 0x00, 0x59, 0x00, 0x5A, 0x00
	.byte 0x5B, 0x00, 0x5C, 0x00, 0x5D, 0x00, 0x5E, 0x00, 0x5F, 0x00, 0x61, 0x00, 0x62, 0x00, 0x64, 0x00
	.byte 0x65, 0x00, 0x66, 0x00, 0x67, 0x00, 0x68, 0x00, 0x6B, 0x00, 0x6F, 0x00, 0x73, 0x00, 0x75, 0x00
	.byte 0x76, 0x00, 0x79, 0x00, 0x7A, 0x00, 0x7E, 0x00, 0x81, 0x00, 0x83, 0x00, 0x85, 0x00, 0x87, 0x00
	.byte 0x8C, 0x00, 0x8E, 0x00, 0x92, 0x00, 0x94, 0x00, 0x95, 0x00, 0x96, 0x00, 0x97, 0x00, 0x98, 0x00
	.byte 0x9C, 0x00, 0x9D, 0x00, 0x9E, 0x00, 0xA0, 0x00, 0xA1, 0x00, 0xA3, 0x00, 0xA4, 0x00, 0xA6, 0x00
	.byte 0xA7, 0x00, 0x6E, 0x00, 0xAB, 0x00, 0xAC, 0x00, 0xB3, 0x00, 0xB7, 0x00, 0xBA, 0x00, 0xBB, 0x00
	.byte 0xBC, 0x00, 0xBD, 0x00, 0xC0, 0x00, 0xC1, 0x00, 0xC2, 0x00, 0xC4, 0x00, 0xC6, 0x00, 0xC7, 0x00
	.byte 0xC8, 0x00, 0xCA, 0x00, 0xCD, 0x00, 0xCF, 0x00, 0xD3, 0x00, 0xD4, 0x00, 0xD8, 0x00, 0xDA, 0x00
	.byte 0xDB, 0x00, 0xCC, 0x00, 0xDD, 0x00, 0xDC, 0x00, 0xDE, 0x00, 0xE0, 0x00, 0xE2, 0x00, 0xE3, 0x00

sGtsTransactionGraphicsModes: ; 0x02245C60
	.byte 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsTransactionSubBg1Template: ; 0x02245C70
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x01, 0x1C, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsTransactionBg1Template: ; 0x02245C8C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x02
	.byte 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsTransactionBg0Template: ; 0x02245CA8
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sGtsTransactionSubBg0Template: ; 0x02245CC4
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsTransactionBg2Template: ; 0x02245CE0
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1D, 0x02, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsAvatarCharOffsets: ; 0x02245CFC
	.byte 0x00, 0x24, 0x00, 0x26
	.byte 0x00, 0x28, 0x00, 0x2A, 0x00, 0x2C, 0x00, 0x2E, 0x00, 0x30

sGtsAvatarPositions: ; 0x02245D0A
	.byte 0x80, 0x00

sGtsAvatarY: ; 0x02245D0C
	.byte 0x36, 0x00, 0x60, 0x00
	.byte 0x37, 0x00, 0xA0, 0x00, 0x37, 0x00, 0x40, 0x00, 0x46, 0x00, 0xC0, 0x00, 0x46, 0x00, 0x30, 0x00
	.byte 0x66, 0x00, 0xD0, 0x00, 0x66, 0x00

sGtsAvatarHitboxes: ; 0x02245D26
	.byte 0x46, 0x66, 0x70, 0x90, 0x47, 0x67, 0x50, 0x70, 0x47, 0x67
	.byte 0x90, 0xB0, 0x56, 0x76, 0x30, 0x50, 0x56, 0x76, 0xB0, 0xD0, 0x76, 0x96, 0x20, 0x40, 0x76, 0x96
	.byte 0xC0, 0xE0, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsViewMonSummaryPages: ; 0x02245D48
	.byte 0x00, 0x01, 0x02, 0x03, 0x04, 0x00, 0x00, 0x00

sGtsTradeSequenceTemplate: ; 0x02245D50
	.word TradeSequence_Init, TradeSequence_Main, TradeSequence_Exit, FS_OVERLAY_ID(OVY_71)

sGtsSelectorGenderWindowPositions: ; 0x02245D60
	.byte 0x04, 0x03, 0x04, 0x07, 0x04, 0x0B

sGtsSelectorGenderCursorX: ; 0x02245D66
	.byte 0xC0

sGtsSelectorGenderCursorY: ; 0x02245D67
	.byte 0x20, 0xC0, 0x40, 0xC0, 0x60, 0xC0, 0x88

sGtsSelectorLevelWindowPositions: ; 0x02245D6E
	.byte 0x03, 0x02
	.byte 0x03, 0x05, 0x03, 0x08, 0x03, 0x0B

sGtsSelectorSpeciesCursorX: ; 0x02245D76
	.byte 0xC0

sGtsSelectorSpeciesCursorY: ; 0x02245D77
	.byte 0x18, 0xC0, 0x30, 0xC0, 0x48, 0xC0, 0x60, 0xC0, 0x88

sGtsSelectorLevelCursorX: ; 0x02245D80
	.byte 0xC0

sGtsSelectorLevelCursorY: ; 0x02245D81
	.byte 0x18, 0xC0, 0x30, 0xC0, 0x48, 0xC0, 0x60, 0xC0, 0x88

sGtsSelectorCountryCursorX: ; 0x02245D8A
	.byte 0x88

sGtsSelectorCountryCursorY: ; 0x02245D8B
	.byte 0x10, 0x88, 0x28, 0x88, 0x40
	.byte 0x88, 0x58, 0x88, 0x70, 0xC0, 0x88

sGtsSelectorCountryWindowPositions: ; 0x02245D96
	.byte 0x03, 0x01, 0x03, 0x04, 0x03, 0x07, 0x03, 0x0A, 0x03, 0x0D
	.byte 0x18, 0x11

sGtsSelectorSpeciesWindowPositions: ; 0x02245DA2
	.byte 0x04, 0x02, 0x00, 0x04, 0x05, 0x00, 0x04, 0x08, 0x00, 0x04, 0x0B, 0x00, 0x00, 0x00

sGtsSelectorGenders: ; 0x02245DB0
	.byte 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0xFE, 0xFF, 0xFF, 0xFF

sGtsSelectorLetterNextUp: ; 0x02245DC0
	.byte 0x03

sGtsSelectorLetterNextDown: ; 0x02245DC1
	.byte 0x03

sGtsSelectorLetterNextLeft: ; 0x02245DC2
	.byte 0x02

sGtsSelectorLetterNextRight: ; 0x02245DC3
	.byte 0x01, 0x03, 0x03, 0x00, 0x02, 0x03, 0x03, 0x01, 0x00, 0x02, 0x02, 0x03, 0x03

sGtsSelectorGenderHitboxes: ; 0x02245DD0
	.byte 0x18, 0x2C, 0x88, 0xF8, 0x38, 0x4C, 0x88, 0xF8, 0x58, 0x6C, 0x88, 0xF8, 0x85, 0x9A, 0xC5, 0xFA
	.byte 0xFF, 0x00, 0x00, 0x00

sGtsSelectorLetterHitboxes: ; 0x02245DE4
	.byte 0x28, 0x3C, 0x88, 0x97, 0x28, 0x3C, 0xA8, 0xB7, 0x28, 0x3C, 0xC8, 0xD7
	.byte 0x85, 0x9A, 0xC5, 0xFA, 0xFF, 0x00, 0x00, 0x00

sGtsSelectorCountryGroupCursorX: ; 0x02245DF8
	.byte 0x01

sGtsSelectorCountryGroupCursorY: ; 0x02245DF9
	.byte 0x05, 0x05, 0x05, 0x09, 0x05, 0x0D, 0x05
	.byte 0x01, 0x08, 0x05, 0x08, 0x09, 0x08, 0x0D, 0x08, 0x01, 0x0B, 0x08, 0x11, 0x08, 0x03

sGtsSelectorGridWindowPositions: ; 0x02245E0E
	.byte 0x01, 0x05

ov70_02245E10: ; 0x02245E10
	.byte 0x05, 0x05, 0x09, 0x05, 0x0D, 0x05, 0x01, 0x08, 0x05, 0x08, 0x09, 0x08, 0x0D, 0x08, 0x01, 0x0B
	.byte 0x09, 0x11, 0x01, 0x02, 0x01, 0x02

sGtsSelectorGroupCursorX: ; 0x02245E26
	.byte 0x01

sGtsSelectorGroupCursorY: ; 0x02245E27
	.byte 0x05, 0x05, 0x05, 0x09, 0x05, 0x0D, 0x05, 0x01, 0x08
	.byte 0x05, 0x08, 0x09, 0x08, 0x0D, 0x08, 0x01, 0x0B, 0x08, 0x11, 0x01, 0x02, 0x01, 0x02

sGtsSelectorListHitboxes: ; 0x02245E3E
	.byte 0x10, 0x23
	.byte 0x88, 0xF8, 0x28, 0x3C, 0x88, 0xF8, 0x40, 0x54, 0x88, 0xF8, 0x58, 0x6C, 0x88, 0xF8, 0x85, 0x9A
	.byte 0xC6, 0xF8, 0x6C, 0x81, 0x8F, 0xA0, 0x6C, 0x7E, 0xDF, 0xF0, 0xFF, 0x00, 0x00, 0x00

sGtsSelectorCountryListHitboxes: ; 0x02245E5E
	.byte 0x08, 0x1C
	.byte 0x08, 0xF7, 0x20, 0x34, 0x08, 0xF7, 0x38, 0x4C, 0x08, 0xF7, 0x50, 0x64, 0x08, 0xF7, 0x68, 0x7C
	.byte 0x08, 0xF7, 0x85, 0x9A, 0xC3, 0xF8, 0x7C, 0x91, 0x4D, 0x60, 0x7C, 0x91, 0xAD, 0xBE, 0xFF, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

gGtsSelectorGroupStarts: ; 0x02245E84
	.byte 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00
	.byte 0x09, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00
	.byte 0x15, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00

sGtsSelectorGroupNext: ; 0x02245EA8
	.byte 0x09

ov70_02245EA9: ; 0x02245EA9
	.byte 0x04

ov70_02245EAA: ; 0x02245EAA
	.byte 0x03

ov70_02245EAB: ; 0x02245EAB
	.byte 0x01, 0x09, 0x05, 0x00, 0x02
	.byte 0x09, 0x06, 0x01, 0x03, 0x09, 0x07, 0x02, 0x00, 0x00, 0x08, 0x07, 0x05, 0x01, 0x09, 0x04, 0x06
	.byte 0x02, 0x09, 0x05, 0x07, 0x03, 0x09, 0x06, 0x04, 0x04, 0x09, 0x08, 0x08, 0x08, 0x02, 0x09, 0x09

sGtsSelectorGroupHitboxes: ; 0x02245ED0
	.byte 0x28, 0x3C, 0x88, 0x97, 0x28, 0x3C, 0xA8, 0xB7, 0x28, 0x3C, 0xC8, 0xD7, 0x28, 0x3C, 0xE8, 0xF7
	.byte 0x40, 0x54, 0x88, 0x97, 0x40, 0x54, 0xA8, 0xB7, 0x40, 0x54, 0xC8, 0xD7, 0x40, 0x54, 0xE8, 0xF7
	.byte 0x58, 0x6C, 0x88, 0x97, 0x85, 0x9A, 0xC5, 0xFA, 0xFF, 0x00, 0x00, 0x00

sGtsSelectorCountryGroupNextUp: ; 0x02245EFC
	.byte 0x0A

sGtsSelectorCountryGroupNextDown: ; 0x02245EFD
	.byte 0x04

sGtsSelectorCountryGroupNextLeft: ; 0x02245EFE
	.byte 0x03

sGtsSelectorCountryGroupNextRight: ; 0x02245EFF
	.byte 0x01
	.byte 0x0A, 0x05, 0x00, 0x02, 0x0A, 0x06, 0x01, 0x03, 0x0A, 0x07, 0x02, 0x00, 0x00, 0x08, 0x07, 0x05
	.byte 0x01, 0x09, 0x04, 0x06, 0x02, 0x09, 0x05, 0x07, 0x03, 0x09, 0x06, 0x04, 0x04, 0x09, 0x08, 0x08
	.byte 0x08, 0x0A, 0x09, 0x09, 0x09, 0x00, 0x0A, 0x0A

sGtsSelectorCountryGroupHitboxes: ; 0x02245F28
	.byte 0x28, 0x3C, 0x88, 0x97, 0x28, 0x3C, 0xA8, 0xB7
	.byte 0x28, 0x3C, 0xC8, 0xD7, 0x28, 0x3C, 0xE8, 0xF7, 0x40, 0x54, 0x88, 0x97, 0x40, 0x54, 0xA8, 0xB7
	.byte 0x40, 0x54, 0xC8, 0xD7, 0x40, 0x54, 0xE8, 0xF7, 0x58, 0x6C, 0x88, 0x97, 0x85, 0x9A, 0xC5, 0xFA
	.byte 0x10, 0x23, 0x88, 0xF8, 0xFF, 0x00, 0x00, 0x00

gGtsSelectorLetterGroups: ; 0x02245F58
	.byte 0x00, 0x00, 0x00, 0x00

ov70_02245F5C: ; 0x02245F5C
	.byte 0x03, 0x00, 0x00, 0x00
	.byte 0x03, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x09, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x0C, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x0F, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00
	.byte 0x15, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00

sGtsSelectorLetterMsgs: ; 0x02245FA0
	.byte 0xBC, 0x00, 0x00, 0x00, 0xBD, 0x00, 0x00, 0x00, 0xBE, 0x00, 0x00, 0x00, 0xBF, 0x00, 0x00, 0x00
	.byte 0xC0, 0x00, 0x00, 0x00, 0xC1, 0x00, 0x00, 0x00, 0xC2, 0x00, 0x00, 0x00, 0xC3, 0x00, 0x00, 0x00
	.byte 0xC4, 0x00, 0x00, 0x00, 0xC5, 0x00, 0x00, 0x00, 0xC6, 0x00, 0x00, 0x00, 0xC7, 0x00, 0x00, 0x00
	.byte 0xC8, 0x00, 0x00, 0x00, 0xC9, 0x00, 0x00, 0x00, 0xCA, 0x00, 0x00, 0x00, 0xCB, 0x00, 0x00, 0x00
	.byte 0xCC, 0x00, 0x00, 0x00, 0xCD, 0x00, 0x00, 0x00, 0xCE, 0x00, 0x00, 0x00, 0xCF, 0x00, 0x00, 0x00
	.byte 0xD0, 0x00, 0x00, 0x00, 0xD1, 0x00, 0x00, 0x00, 0xD2, 0x00, 0x00, 0x00, 0xD3, 0x00, 0x00, 0x00
	.byte 0xD4, 0x00, 0x00, 0x00, 0xD5, 0x00, 0x00, 0x00, 0xE8, 0x00, 0x00, 0x00

sGtsPanelCaptionMsgIds: ; 0x0224600C
	.byte 0xE9, 0x00, 0x00, 0x00
	.byte 0xEA, 0x00, 0x00, 0x00, 0xEB, 0x00, 0x00, 0x00, 0xEC, 0x00, 0x00, 0x00, 0xED, 0x00, 0x00, 0x00

sGtsConnectionSubBg0Template: ; 0x02246020
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x01, 0x00, 0x1E, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsConnectionBg1Template: ; 0x0224603C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1E, 0x02
	.byte 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

sGtsConnectionBg0Template: ; 0x02246058
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00

sGtsConnectionSubBg1Template: ; 0x02246074
	.byte 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x1B, 0x02, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

	.data

	.balign 4, 0
sGtsPostUrl:
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/post.asp"

	.balign 4, 0
sGtsPostFinishUrl: ; 0x022460EC
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/post_finish.asp"

	.balign 4, 0
sGtsGetUrl: ; 0x0224613C
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/get.asp"

	.balign 4, 0
sGtsResultUrl: ; 0x02246184
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/result.asp"

	.balign 4, 0
sGtsDeleteUrl: ; 0x022461D0
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/delete.asp"

	.balign 4, 0
sGtsReturnUrl: ; 0x0224621C
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/return.asp"

	.balign 4, 0
sGtsSearchUrl: ; 0x02246268
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/search.asp"

	.balign 4, 0
sGtsExchangeUrl: ; 0x022462B4
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/exchange.asp"

	.balign 4, 0
sGtsExchangeFinishUrl: ; 0x02246304
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/exchange_finish.asp"

	.balign 4, 0
sGtsInfoUrl: ; 0x02246358
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/worldexchange/info.asp"

	.balign 4, 0
sGtsSetProfileUrl: ; 0x022463A4
	.asciz "http://gamestats2.gs.nintendowifi.net/pokemondpds/common/setProfile.asp"

	.balign 4, 0
sGtsScreens: ; 0x022463EC
	.word GtsConnection_Init, GtsConnection_Main, GtsConnection_Exit
	.word GtsMainMenu_Init, GtsMainMenu_Main, GtsMainMenu_Exit
	.word GtsSummary_Init, GtsSummary_Main, GtsSummary_Exit
	.word GtsSearchResult_Init, GtsSearchResult_Main, GtsSearchResult_Exit
	.word GtsSearch_Init, GtsSearch_Main, GtsSearch_Exit
	.word GtsSelectMon_Init, GtsSelectMon_Main, GtsSelectMon_Exit
	.word GtsWanted_Init, GtsWanted_Main, GtsWanted_Exit
	.word GtsTransaction_Init, GtsTransaction_Main, GtsTransaction_Exit
	.word GtsViewMon_Init, GtsViewMon_Main, GtsViewMon_Exit
	.word GtsTrade_Init, GtsTrade_Main, GtsTrade_Exit

sGtsMainMenuStates: ; 0x02246464
	.word GtsMainMenu_WaitEnterAnim
	.word GtsMainMenu_WaitTextBeforeFadeIn
	.word GtsMainMenu_StartFadeIn
	.word GtsMainMenu_WaitFadeIn
	.word GtsMainMenu_WaitFadeIn2
	.word GtsMainMenu_ShowPrompt
	.word GtsMainMenu_HandleInput
	.word GtsMainMenu_StartExitAnim
	.word GtsMainMenu_WaitExitAnim
	.word GtsMainMenu_FadeOut
	.word GtsMainMenu_WaitText
	.word GtsMainMenu_WaitTextAndPause
	.word GtsMainMenu_ShowExitPrompt
	.word GtsMainMenu_HandleExitPrompt

sGtsGenderSymbolColors: ; 0x0224649C
	.byte 0x00, 0x00, 0x00, 0x00
	.byte 0x00, 0x06, 0x05, 0x00, 0x00, 0x04, 0x03, 0x00

sGtsSummaryStates: ; 0x022464A8
	.word GtsSummary_Start
	.word GtsSummary_HandleInput
	.word GtsSummary_FadeOut
	.word GtsSummary_WaitText
	.word GtsSummary_WaitTextAndPause
	.word GtsSummary_ShowTakeBackPrompt
	.word GtsSummary_HandleTakeBackPrompt
	.word GtsSummary_ShowMenu
	.word GtsSummary_HandleMenu

sGtsSearchResultStates: ; 0x022464CC
	.word GtsSearchResult_Start
	.word GtsSearchResult_HandleInput
	.word GtsSearchResult_FadeOut
	.word GtsSearchResult_WaitText
	.word GtsSearchResult_ShowTradePrompt
	.word GtsSearchResult_HandleTradePrompt
	.word GtsSearchResult_Redraw
	.word GtsSearchResult_ScrollIn
	.word GtsSearchResult_ScrollOut

sGtsSearchButtonColumns: ; 0x022464F0
	.byte 0x00

sGtsSearchButtonRows: ; 0x022464F1
	.byte 0x00, 0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x01, 0x00, 0x01, 0x01, 0x01, 0x02

sGtsSearchCursorX: ; 0x022464FE
	.byte 0x00, 0x00

sGtsSearchCursorY: ; 0x02246500
	.byte 0x00, 0x00

sGtsSearchCursorAnims: ; 0x02246502
	.byte 0x2D, 0x00, 0x00, 0x00, 0x28, 0x00, 0x2D, 0x00, 0x00, 0x00, 0x50, 0x00, 0x2D, 0x00
	.byte 0x00, 0x00, 0x78, 0x00, 0x2D, 0x00, 0xC0, 0x00, 0x20, 0x00, 0x2E, 0x00, 0xC0, 0x00, 0x48, 0x00
	.byte 0x2E, 0x00, 0xC0, 0x00, 0x70, 0x00, 0x2E, 0x00

sGtsSearchStates: ; 0x02246528
	.word GtsSearch_Start
	.word GtsSearch_HandleInput
	.word GtsSearch_FadeOut
	.word GtsSearch_AskSpecies
	.word GtsSearch_OpenSpeciesSelector
	.word GtsSearch_HandleSpeciesSelector
	.word GtsSearch_AskGender
	.word GtsSearch_OpenGenderSelector
	.word GtsSearch_HandleGenderSelector
	.word GtsSearch_AskLevel
	.word GtsSearch_OpenLevelSelector
	.word GtsSearch_HandleLevelSelector
	.word GtsSearch_AskCountry
	.word GtsSearch_OpenCountrySelector
	.word GtsSearch_HandleCountrySelector
	.word GtsSearch_StartSearch
	.word GtsSearch_SendSearch
	.word GtsSearch_WaitSearch
	.word GtsSearch_ShowResultCount
	.word GtsSearch_WaitResultsShown
	.word GtsSearch_SearchFailed
	.word GtsSearch_WaitText
	.word GtsSearch_WaitTextAndPause
	.word GtsSearch_ShowExitPrompt
	.word GtsSearch_HandleExitPrompt
	.word GtsSearch_ReturnToInput
	.word GtsSearch_PrintSearchFailed
	.word GtsSearch_ServerError
	.word GtsSearch_ServerErrorExit
	.word GtsSearch_ScrollOut
	.word GtsSearch_ScrollIn
	.word GtsSearch_HandleScrolledOut

sGtsSelectMonStates: ; 0x022465A8
	.word GtsSelectMon_Start
	.word GtsSelectMon_HandleInput
	.word GtsSelectMon_FadeOut
	.word GtsSelectMon_WaitText
	.word GtsSelectMon_WaitTextAndClear
	.word GtsSelectMon_ShowExitPrompt
	.word GtsSelectMon_HandleExitPrompt
	.word GtsSelectMon_OpenDepositMenu
	.word GtsSelectMon_HandleDepositMenu
	.word GtsSelectMon_OpenTradeMenu
	.word GtsSelectMon_HandleTradeMenu
	.word GtsSelectMon_AskRemoveCapsuleForTrade
	.word GtsSelectMon_ShowCapsulePromptForTrade
	.word GtsSelectMon_HandleCapsulePromptForTrade
	.word GtsSelectMon_AskRemoveCapsule
	.word GtsSelectMon_ShowCapsulePrompt
	.word GtsSelectMon_HandleCapsulePrompt

sGtsGenderColors: ; 0x022465EC
	.byte 0x00, 0x06, 0x05, 0x00
	.byte 0x00, 0x04, 0x03, 0x00, 0x7C, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00
	.byte 0x00, 0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x7F, 0x00, 0x00, 0x00
	.byte 0xFE, 0xFF, 0xFF, 0xFF

sGtsWantedStates: ; 0x02246614
	.word GtsWanted_Start
	.word GtsWanted_HandleInput
	.word GtsWanted_FadeOut
	.word GtsWanted_OpenSpeciesSelector
	.word GtsWanted_InvalidState4
	.word GtsWanted_InvalidState5
	.word GtsWanted_HandleSpeciesSelector
	.word GtsWanted_AskGender
	.word GtsWanted_OpenGenderSelector
	.word GtsWanted_HandleGenderSelector
	.word GtsWanted_AskLevel
	.word GtsWanted_OpenLevelSelector
	.word GtsWanted_HandleLevelSelector
	.word GtsWanted_AskConfirm
	.word GtsWanted_ShowConfirmPrompt
	.word GtsWanted_HandleConfirmPrompt
	.word GtsWanted_WaitText

sGtsTransactionStates: ; 0x02246658
	.word GtsTransaction_Start
	.word GtsTransaction_Idle
	.word GtsTransaction_SendPost
	.word GtsTransaction_WaitPost
	.word GtsTransaction_SendPostFinish
	.word GtsTransaction_WaitPostFinish
	.word GtsTransaction_DepositDone
	.word GtsTransaction_SendGet
	.word GtsTransaction_WaitGet
	.word GtsTransaction_SendReturn
	.word GtsTransaction_WaitReturn
	.word GtsTransaction_ReceiveDone
	.word GtsTransaction_SendExchange
	.word GtsTransaction_WaitExchange
	.word GtsTransaction_SendExchangeFinish
	.word GtsTransaction_WaitExchangeFinish
	.word GtsTransaction_ExchangeDone
	.word GtsTransaction_AlreadyTraded
	.word GtsTransaction_ReceiveTradedMon
	.word GtsTransaction_SendDelete
	.word GtsTransaction_WaitDelete
	.word GtsTransaction_TradedDone
	.word GtsTransaction_SendUnsavedReturn
	.word GtsTransaction_WaitUnsavedReturn
	.word GtsTransaction_SendResult
	.word GtsTransaction_WaitResult
	.word GtsTransaction_SendStatusGet
	.word GtsTransaction_WaitStatusGet
	.word GtsTransaction_ExitToMainMenu
	.word GtsTransaction_SaveAndExit
	.word GtsTransaction_StartSave
	.word GtsTransaction_WaitSaveDelay
	.word GtsTransaction_SaveFirstPart
	.word GtsTransaction_SaveRest
	.word GtsTransaction_StartSaveWithMessage
	.word GtsTransaction_SaveWithMessage
	.word GtsTransaction_FadeOut
	.word GtsTransaction_WaitText
	.word GtsTransaction_ServerErrorExit
	.word GtsTransaction_ServerError

sGtsSelectorStates: ; 0x022466F8
	.word GtsSelector_Idle
	.word GtsSelector_WaitShow
	.word GtsSelector_WaitMove
	.word GtsSelector_WaitHide
	.word GtsSelector_OpenSpeciesGroups
	.word GtsSelector_HandleSpeciesGroups
	.word GtsSelector_CloseSpeciesGroups
	.word GtsSelector_ReopenSpeciesGroups
	.word GtsSelector_OpenSpeciesLetters
	.word GtsSelector_HandleSpeciesLetters
	.word GtsSelector_CloseSpeciesLetters
	.word GtsSelector_BackToSpeciesLetters
	.word GtsSelector_OpenSpeciesList
	.word GtsSelector_HandleSpeciesList
	.word GtsSelector_CancelSpeciesList
	.word GtsSelector_FinishSpecies
	.word GtsSelector_OpenCountryGroups
	.word GtsSelector_HandleCountryGroups
	.word GtsSelector_CloseCountryGroups
	.word GtsSelector_ReopenCountryGroups
	.word GtsSelector_OpenCountryLetters
	.word GtsSelector_HandleCountryLetters
	.word GtsSelector_CloseCountryLetters
	.word GtsSelector_BackToCountryLetters
	.word GtsSelector_OpenCountryList
	.word GtsSelector_HandleCountryList
	.word GtsSelector_CancelCountryList
	.word GtsSelector_FinishCountry
	.word GtsSelector_OpenGenders
	.word GtsSelector_HandleGenders
	.word GtsSelector_FinishGender
	.word GtsSelector_OpenLevels
	.word GtsSelector_HandleLevels
	.word GtsSelector_FinishLevel

sGtsConnectionStates: ; 0x02246780
	.word GtsConnection_AskConnect
	.word GtsConnection_HandleConnectPrompt
	.word GtsConnection_StartConnect
	.word GtsConnection_WaitConnect
	.word GtsConnection_StartAuth
	.word GtsConnection_WaitAuth
	.word GtsConnection_InitServer
	.word GtsConnection_SendInfo
	.word GtsConnection_WaitInfo
	.word GtsConnection_SendSetProfile
	.word GtsConnection_WaitSetProfile
	.word GtsConnection_FadeOut
	.word GtsConnection_WaitText
	.word GtsConnection_WaitTextAndShowYesNo
	.word GtsConnection_HandleExitPrompt
	.word GtsConnection_AskDisconnect
	.word GtsConnection_HandleDisconnectMenu
	.word GtsConnection_PrintDisconnecting
	.word GtsConnection_Disconnect
	.word GtsConnection_PrintDisconnected
	.word GtsConnection_WaitTextAndDelay
	.word GtsConnection_PrintServerError
	.word GtsConnection_DisconnectAfterError
	.word GtsConnection_ShowConnectionError
	.word GtsConnection_WaitCloseError

	.bss

gGtsServer:
	.space 0xC

gGtsServerFriendKey: ; 0x0224680C
	.space 0x8

gGtsServerRequest: ; 0x02246814
	.space 0xEC

ov70_02246900: ; 0x02246900
	.space 0x20

ov70_02246920: ; 0x02246920
	.space 0x1C

gGtsServerShortResponse: ; 0x0224693C
	.space 0x8

gGtsGlobals: ; 0x02246944
	.space 0x1c
