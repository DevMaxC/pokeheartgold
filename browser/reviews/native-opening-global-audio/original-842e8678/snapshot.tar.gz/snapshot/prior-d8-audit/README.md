# Native global audio coverage audit — immutable d8ea2791

Source: `d8ea27916307a61c57fbfda3be053cf985988bef`, `/Users/maxchurch/Documents/pokeheartgold-campaign-release`. Read-only source audit; no repository files, browser, audio playback, tests or builds were touched. Parent's later OpeningView changes are outside this receipt.

The HTML entry is `/src/source/main.ts`. TypeScript AST traversal finds **113 project-owned local runtime modules**, excluding type-only imports; sorted source-byte graph SHA-256 is `57a1503289d7b4d6abc1074dce597abf74fdce7913eb1640875fd4ba21e4a37f`. This is finite source coverage, not external-library or browser/auditory validation. The JSON records every module/hash, candidate line and import path. `node reproduce.cjs` repeats the immutable-object scan without executing game code.

| Path | Current native reachability | Result |
| --- | --- | --- |
| `opening-view.ts:48`, Marill183 | Main New Game → `runOpeningSession` → `runOakIntroduction` → `effect('marill-cry')` | **Confirmed source-level mute bypass.** Independent `new Audio`, fixed `.6` volume, no preference/master gain/visibility port. Any browser-admitted voice ignores mute, volume zero and page-active gate. |
| `opening-input.ts:8` | Real introduction choices | **Confirmed global-input ownership conflict.** Window Enter/Space/F handler clicks remembered choice while the global mute button is focused. UI intentionally yields those keys; the opening listener can prevent native button activation and advance the introduction. |
| `field-music.ts` | Field, battle/tutorial, hatch music | Shared gain, immediate live enabled/volume updates, page-active gate. No separate audible destination found. |
| `hatch-host-audio.ts:144` | Main injects `cry:audio.cry` into every hatch view | Togepi cry connects its own source gain to shared `output.output`; live preference checks before and after decode. No current independent-HTMLAudio hatch path. |
| `egg-hatch-view.ts:44` | Imported module, **dormant default fallback** | Independent HTMLAudio exists, but Main always injects the shared cry. A future uninjected caller would bypass mute; this is not a current Main leak. |
| `OpeningView.title`, Ho-Oh250 | **Dormant legacy method** | Modern Main uses `ui.startScreen`; neither `OpeningPort` nor `runOpeningSession` invokes `.title()`. Its unguarded key/cry code is a latent risk, distinct from active choice handling. |
| `hatch-music.ts:44/87` | **Outside runtime import closure** | Standalone default creates/resumes a private Context and connects directly to destination; static boolean preference. Current hatch host only imports its types and uses the shared transport. |
| `cut-field-effect.ts:147` | **Outside runtime import closure** | Injected output, no own Context; future host must provide master gain/lifetime rather than raw destination. Current Main does not create the Cut host/audio. |
| `browser/src/main.ts:128` | **Not the HTML entry, outside native graph** | Prototype synth/ambient/chime audio is not active native runtime evidence. |

The smallest active fix is to inject a live preference and existing shared-output port into OpeningView, borrow the already-unlocked Context, connect to the master gain, and cancel pending/owned sources on view disposal. Do not create/resume another Context or disable native completion merely because the master output is muted. Yield global-audio owned keys in the real choice listener; guard the legacy title listener as a future safeguard.

`audio-controls.ts:8–12` applies initial visibility and subscribes to visibility/pagehide/pageshow/storage. Main `114–115` updates the actual player; `field-music.ts:68/174/177` gates all shared voices synchronously. Consequently the current field, battle, hatch music and injected hatch cry do not expose another independent global-mute bypass in this source graph. This does not certify timing, complete native sound coverage, future Azalea/Cut bindings, or the parent's unreviewed fix.
